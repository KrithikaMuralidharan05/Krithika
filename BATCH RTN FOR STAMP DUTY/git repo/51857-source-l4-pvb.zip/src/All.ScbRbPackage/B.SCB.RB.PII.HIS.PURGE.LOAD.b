$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PII.HIS.PURGE.LOAD
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* ADO Ref				       2653147
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.PII.HIS.PURGE
*
* Workflow                     This Multi Thread Service will first look for the file presence in SAVEDLISTS>PARTY.PURGE.REL.IDS
*
*                              - If above said file present in SL then service will execute only purging of underlying history
*                              records of those REL-IDS by keeping CURR.NO EQ "1" and no.of records parameterized.
*                               
*                              - If there is no file present in SL then service will select the SCB.RSG.PARTY.DETAILS table and
*                              proceed with the purging activity accordingly.
*
*                              - In both the cases, if the Live CURR.NO < Hist Retain Value (Param Value + 1) then purging activity
*                              aganist that RELID will be skipped and proceed with next in the loop.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        05/Jan/2024      2653147             Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_B.SCB.RB.PII.HIS.PURGE.COMMON

	GOSUB INIT
	GOSUB PROCESS

	RETURN
*--------------------------------------------------------------------------------------------------------
INIT:
*****

	FN.PARTY.DETS = 'F.SCB.RSG.PARTY.DETAILS'
	F.PARTY.DETS = ''
	CALL OPF(FN.PARTY.DETS,F.PARTY.DETS)
	
	FN.PARTY.DETS.HIS = 'F.SCB.RSG.PARTY.DETAILS$HIS'
	F.PARTY.DETS.HIS = ''
	CALL OPF(FN.PARTY.DETS.HIS,F.PARTY.DETS.HIS)
	
	FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.SCB.WM.H.LOCAL.PARAM = ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
	
	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********

	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,'PII.HIST.PURGE',R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,SCB.LCL.READ.ERR)
	IF R.SCB.WM.H.LOCAL.PARAM THEN
        Y.PARAM.VAL = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE,1,1>
		Y.HIST.RETAIN.VAL = Y.PARAM.VAL + 1		;* As we are going to maintain CURR.NO EQ '1' data by default.
    END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END