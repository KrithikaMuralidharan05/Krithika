$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GST.ENTRIES.PROCESS(ENTRY.ID)
*------------------------------------------------------------------------------
*
* Author                       Loganathan G
* EPACC/Story/Sub task Ref     CPSGMIG-3231
* Routine Type                 Batch process routine
* Attached To                  BATCH>SNG/SCB.RB.STATIC.ENTRY
* Workflow                     To update SCB.GST.RBSG.EXTRACT for GST Amount and GST Rate
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*
*
*
*----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES	
    $INSERT I_BATCH.FILES
    $INSERT I_F.CURRENCY
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.STMT.ENTRY
    $INSERT I_F.SCB.GST.RBSG.PARAM
    $INSERT I_F.SCB.GST.RBSG.EXTRACT
    $INSERT I_B.SCB.RB.GST.ENTRIES.PROCESS.COMMON
    
    GOSUB INIT
    GOSUB PROCESS

    RETURN

*****
INIT:
*****

    Y.CUST.LOB 		= ''
    Y.CUST.ID 		= ''
    Y.RECORD.STATUS	= ''
    Y.ACCOUNT.NUMBER 	= ''
    Y.COMPANY.CODE	= ''
    Y.AMOUNT.LCY	= ''
    Y.ST.ID		= ''
    Y.CUSTOMER.ID 	= ''
    Y.CURRENCY		= ''
    Y.AMOUNT.FCY	= ''
    Y.EXCHANGE.RATE	= ''
    Y.REVERSAL.MARKER 	= ''
    Y.RBSG.TAX.ID 	= ''
    R.STMT.ENTRY 	= ''
    R.CUSTOMER 		= ''
    R.SCB.GST.RBSG.EXTRACT = ''
    
    RETURN

********	
PROCESS:
********
    
    CALL OCOMO("RBSG GST Category STMT Entry ID Processing ":ENTRY.ID)

    CALL F.READ(FN.SCB.GST.RBSG.PARAM,'SG1090400*SEC.TRADE',R.SCB.GST.RBSG.PARAM,F.SCB.GST.RBSG.PARAM,PARAM.ERR)

    CALL F.READ(FN.STMT.ENTRY, ENTRY.ID, R.STMT.ENTRY, F.STMT.ENTRY, ERR.STMT.ENTRY)

    GOSUB READ.STMT.ENTRY
    
    IF NOT(Y.REVERSAL.MARKER) AND Y.ST.ID[1,6] EQ 'SCTRSC' THEN
        LOCATE Y.CUST.LOB IN Y.ALLOWED.LOB<1,1> SETTING SEG.POSN THEN
            GOSUB MAIN.PROCESS
	END 
    END   
    
    RETURN

****************
READ.STMT.ENTRY:
****************

    Y.ACCOUNT.NUMBER 	= R.STMT.ENTRY<AC.STE.ACCOUNT.NUMBER>
    S.CATEG.ID		= Y.ACCOUNT.NUMBER[4,5]
    Y.COMPANY.CODE	= R.STMT.ENTRY<AC.STE.COMPANY.CODE>
    Y.AMOUNT.LCY	= R.STMT.ENTRY<AC.STE.AMOUNT.LCY>
    Y.TXN.CODE		= R.STMT.ENTRY<AC.STE.TRANSACTION.CODE>

    Y.ST.ID		= R.STMT.ENTRY<AC.STE.TRANS.REFERENCE>
    Y.CUSTOMER.ID 	= R.STMT.ENTRY<AC.STE.CUSTOMER.ID>
    Y.CURRENCY		= R.STMT.ENTRY<AC.STE.CURRENCY>
    Y.AMOUNT.FCY	= R.STMT.ENTRY<AC.STE.AMOUNT.FCY>

    Y.EXCHANGE.RATE	= R.STMT.ENTRY<AC.STE.EXCHANGE.RATE>
    Y.REVERSAL.MARKER	= R.STMT.ENTRY<AC.STE.REVERSAL.MARKER>
   
    CALL F.READ(FN.CUSTOMER,Y.CUSTOMER.ID,R.CUSTOMER,F.CUSTOMER,CUS.ERR)
    Y.CUST.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF><1,CUS.LOB.POS>

    RETURN
	
*************
MAIN.PROCESS:
*************
    
    Y.EXTRACT.ID = Y.ST.ID
    CALL F.READ(FN.SCB.GST.RBSG.EXTRACT,Y.EXTRACT.ID,R.SCB.GST.RBSG.EXTRACT,F.SCB.GST.RBSG.EXTRACT,EXT.ERR1)
    LOCATE S.CATEG.ID IN Y.GST.INT.CATEG<1,1> SETTING CAT.POS THEN
        Y.RBSG.TAX.ID = R.SCB.GST.RBSG.PARAM<RB.PARAM.TAX.ID,CAT.POS>
        Y.RBSG.GST.TXN.CODE = R.SCB.GST.RBSG.PARAM<RB.PARAM.GST.TRAN.CODE,CAT.POS>
    END

    R.SEC.TRADE = ''
    R.SEC.TRADE.HIS = ''
    CALL F.READ(FN.SEC.TRADE,Y.ST.ID,R.SEC.TRADE,F.SEC.TRADE,ST.ERR)
    IF NOT(R.SEC.TRADE) THEN
	CALL EB.READ.HISTORY.REC(F.SEC.TRADE.HIS,Y.ST.ID,R.SEC.TRADE.HIS,ST.HIS.ERR)
        Y.RECORD.STATUS = R.SEC.TRADE.HIS<SC.SBS.RECORD.STATUS>
    END

    IF ((R.SCB.GST.RBSG.EXTRACT EQ '') AND (Y.TXN.CODE EQ Y.RBSG.GST.TXN.CODE) AND (Y.RECORD.STATUS EQ '')) THEN
        R.SCB.GST.RBSG.EXTRACT<RB.STA.STMT.ENTRIES> 	= ENTRY.ID
        R.SCB.GST.RBSG.EXTRACT<RB.STA.GST.AMT>		= Y.AMOUNT.FCY
        R.SCB.GST.RBSG.EXTRACT<RB.STA.GST.AMT.LCY> 	= Y.AMOUNT.LCY
        R.SCB.GST.RBSG.EXTRACT<RB.STA.GST.RATE> 	= Y.RBSG.TAX.ID
        CALL F.WRITE(FN.SCB.GST.RBSG.EXTRACT,Y.EXTRACT.ID,R.SCB.GST.RBSG.EXTRACT)
    END

    RETURN

END
