$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.TXN.DETS.PDW.EXT(Y.TRANS.ID)
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 16/08/2022 - kalaikuamran p - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_TransDets_YYYYMMDD.txt
* 12/12/2022 - kalaikumaran p - Included ICONV Conversion to identify Day.
* 06-Mar-2023 - CPSGMIG-19926 - Lavanya L - Changes in PP CODE mapping.
* 08-Mar-2023 - CPSGMIG-19969 - Lavanya L - Adding new fields
*----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SECURITY.TRANS
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.CURRENCY
    $INSERT I_F.SC.TRANS.TYPE
    $INSERT I_F.CUSTOMER
    $INSERT I_B.SCB.RB.TXN.DETS.PDW.EXT.COMMON
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.SC.TRANS.NAME
*
    GOSUB INIT
    GOSUB CHECK.DAY
    GOSUB PROCESS
*
    CLOSESEQ F.AMEX.FILES
*
RETURN
*-------
INIT:
*-------
		
	OPENSEQ AMEX.FILES,FILE.NAME TO F.AMEX.FILES ELSE CREATE F.AMEX.FILES ELSE
        CALL OCOMO("Error opening ":FILE.NAME)
        CALL FATAL.ERROR("B.SCB.RB.TXN.DETS.PDW.EXT.LOAD")
    END
    
RETURN
*---------------------------------------------------------------------
CHECK.DAY:
*--------
    FROM.DATE = '' ; TO.DATE = ''
    IF OCONV(ICONV(TODAY,'D'),'DWA') EQ 'FRIDAY' THEN
        FROM.DATE = TODAY
        CALL CDT("",FROM.DATE,"-6C")
        TO.DATE = TODAY
    END ELSE
    	BEGIN CASE
            CASE OCONV(ICONV(TODAY,'D'),'DWA') EQ 'MONDAY'
                FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-2C")
                TO.DATE = TODAY
            CASE OCONV(ICONV(TODAY,'D'),'DWA') EQ 'TUESDAY'
            	FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-3C")
                TO.DATE = TODAY
            CASE OCONV(ICONV(TODAY,'D'),'DWA') EQ 'WEDNESDAY'
            	FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-4C")
                TO.DATE = TODAY
            CASE OCONV(ICONV(TODAY,'D'),'DWA') EQ 'THURSDAY'
            	FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-5C")
                TO.DATE = TODAY
        END CASE
    END
*
RETURN
*--------------------------------------------------------------

*------
PROCESS:
*-------
	Y.TXN.REC = ''
	Y.RECORD.IND = 'D'
    IF Y.TRANS.ID[1,6] EQ 'OPODSC' THEN
        R.SEC.OPEN.ORDER = '' ; SOO.ERR = ''
        CALL F.READ(FN.SEC.OPEN.ORDER,Y.TRANS.ID,R.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER,SOO.ERR)
		Y.CUST.NUMBER = R.SEC.OPEN.ORDER<SC.SOO.CUST.NUMBER,1>
		R.CUSTOMER = '' ; CUSTOMER.ERR = ''
		CALL F.READ(FN.CUSTOMER,Y.CUST.NUMBER,R.CUSTOMER,F.CUSTOMER,CUSTOMER.ERR)
		Y.LOB.CUS = R.CUSTOMER<EB.CUS.LOCAL.REF,L.O.B.CUS.POS>
*CPSGMIG-19969 - S             
        Y.DAO.ID = R.CUSTOMER<EB.CUS.ACCOUNT.OFFICER>
        R.DAO = ''
        ERR.DAO = ''
        CALL F.READ(FN.DAO,Y.DAO.ID,R.DAO,F.DAO,ERR.DAO)
        Y.ARM.CODE =R.DAO<EB.DAO.LOCAL.REF,LR.ARM.CODE.POS>
*CPSGMIG-19969 - E 
        
		IF (Y.LOB.CUS EQ '8') ELSE
			RETURN
		END
*
        Y.ORDER.DATE = R.SEC.OPEN.ORDER<SC.SOO.ORDER.DATE>
        
        IF Y.ORDER.DATE GE FROM.DATE AND Y.ORDER.DATE LE TO.DATE THEN
        END ELSE
            RETURN
        END
*
		Y.SEC.ACCOUNT = R.SEC.OPEN.ORDER<SC.SOO.SECURITY.ACCNT>
        Y.TXN.TYPE = R.SEC.OPEN.ORDER<SC.SOO.TRANSACTION.CODE>
        Y.TRANS.REF = Y.TRANS.ID
        Y.CONFIRM.FLAG = 'N'
        Y.CONFIRM.DATE = "00010101"
        Y.REV.DATE = ''
        Y.REV.FLAG = 'N'
        Y.FUND.CODE = R.SEC.OPEN.ORDER<SC.SOO.SECURITY.NO>
        Y.BRANCH.CODE = ''
        Y.STAFF.NO = ''
        Y.SRC.FUND = ''
        R.SECURITY.MASTER = ''
        CALL F.READ(FN.SECURITY.MASTER,Y.FUND.CODE,R.SECURITY.MASTER,F.SECURITY.MASTER,"")
        Y.INV.FUND.CCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
*       Y.TXN.AMT.FUND.CCY = R.SEC.OPEN.ORDER<SC.SOO.CU.CASH.AMOUNT>
                
        Y.GRS.COMM = ''
        Y.NETT.COMM = ''
        Y.REDEM.FEE = ''
        Y.CU.CHARGE.TAX.TYPE = R.SEC.OPEN.ORDER<SC.SOO.CU.CHARGE.TAX.TYPE>
        LOCATE 'EXIT.FEE.ALL' IN Y.CU.CHARGE.TAX.TYPE<1,1> SETTING CHARGE.POS THEN
            Y.REDEM.FEE = R.SEC.OPEN.ORDER<SC.SOO.CU.CHARGE.TAX.AMT,CHARGE.POS>
        END

        Y.NO.NOMINAL = R.SEC.OPEN.ORDER<SC.SOO.NO.NOMINAL>
        Y.PRICE = R.SEC.OPEN.ORDER<SC.SOO.CURR.PRICE>
		Y.CFM.PRICE = R.SEC.OPEN.ORDER<SC.SOO.CURR.PRICE>
		Y.B.OR.S = R.SECURITY.MASTER<SC.SCM.BOND.OR.SHARE>      
		IF Y.B.OR.S EQ 'B' THEN
			Y.PRICE = Y.PRICE / 100
			Y.CFM.PRICE = Y.CFM.PRICE / 100
		END
        Y.TXN.STATUS = "7"
		Y.TXN.AMT.FUND.CCY = Y.NO.NOMINAL * Y.PRICE
        	
        Y.NET.AMT.FUND.CCY = R.SEC.OPEN.ORDER<SC.SOO.CU.CASH.AMOUNT>
        Y.BONUS.PER = ''
        Y.BONUS.AMT = ''
        Y.FUND.HSE.COMM = ''
        Y.SCB.COMM = ''
        Y.DISC.AMT = ''
        Y.TOT.AUM.FEE = ''
        Y.FUND.HSE.FEE = ''
        Y.PIP.REDM.FEE = ''
        R.SEC.ACC.MASTER = ''
        CALL F.READ(FN.SEC.ACC.MASTER,Y.SEC.ACCOUNT,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,"")
        Y.OPENING.DATE = R.SEC.ACC.MASTER<SC.SAM.START.DATE>
        Y.CFM.UNIT = R.SEC.OPEN.ORDER<SC.SOO.NO.NOMINAL>
        Y.DISCOUNT = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.DISC.PERC.ORD.POS>
        Y.FHSE.COMM.PER = ''
        Y.REBATE = ''
        Y.LR.PAYMENT.TYPE = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.PAYMENT.TYPE.ORD.POS>
        Y.REF.ID = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.CLOSING.ID.ORD.POS> 		;*CPSGMIG-19969 - S/E
    	GOSUB CPF.CHECK  			;*CPSGMIG-19969 - S/E
        Y.SETL.ACC.PRODUCT = ''
        Y.TXN.CODE = R.SEC.OPEN.ORDER<SC.SOO.TRANSACTION.CODE>
        GOSUB BUY.SELL
        IF Y.BUY.SELL = 'BUY' THEN
            Y.SETL.ACCOUNT.NO = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.PAY.CASA.ACC.ORD.POS>
            Y.SETL.ANT.CCY = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.PAY.CASA.CCY.ORD.POS>
        END ELSE
            Y.SETL.ACCOUNT.NO = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.REC.CASA.ACC.ORD.POS>
            Y.SETL.ANT.CCY = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.REC.CASA.CCY.ORD.POS>
        END
        Y.CORP.ACT = ''
        Y.CHANNEL.CODE = R.SEC.OPEN.ORDER<SC.SOO.TXN.CHANNEL>
            
        Y.SUB.ASSET.TYPE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
        Y.ASSET.TYPE = ''
        LOCATE Y.SUB.ASSET.TYPE IN Y.MF.SAT.CODES<1,1> SETTING POS THEN
            Y.ASSET.TYPE = 'UT'
        END ELSE
            LOCATE Y.SUB.ASSET.TYPE IN Y.SN.SAT.CODES<1,1> SETTING POS THEN
                Y.ASSET.TYPE = 'Notes'
            END ELSE
                Y.ASSET.TYPE = 'Bond'
            END
        END
         
        Y.PRO.PROV.CDE = ''
        Y.PRO.PROV.NAME = ''
*        Y.ISSUER = R.SECURITY.MASTER<SC.SCM.ISSUER>
*CPSGMIG-19926 - S
*		Y.RET.DEPO = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.RET.DEPO.POS>
*  		IF Y.RET.DEPO EQ '' THEN
*        	Y.RET.DEPO = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.RET.DEPO.INV.POS>
*    	END
    	Y.RET.DEPO = R.SECURITY.MASTER<SC.SCM.TR.ISSUER>
*CPSGMIG-19926 - E
    	R.CUST = ''
    	ERR.CUST = ''
    	CALL F.READ(FN.CUSTOMER,Y.RET.DEPO,R.CUST,F.CUSTOMER,ERR.CUST)
    	Y.PRO.PROV.CDE = R.CUST<EB.CUS.LOCAL.REF,LR.PP.CODE.POS>
        Y.PRO.PROV.NAME = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,MF.ISSUER.NAME.POS>
        CONVERT @SM TO '' IN Y.PRO.PROV.NAME
        
        IF NOT(Y.PRO.PROV.NAME) THEN
        	Y.PRO.PROV.NAME = R.SECURITY.MASTER<SC.SCM.COMPANY.NAME,1>
    	END
        CONVERT ',' TO '|' IN Y.PRO.PROV.NAME    
        Y.ISIN.CDE = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
        Y.FUND.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME,1>
        Y.NET.SALE.CHG.PER = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.NET.SAL.PERC.ORD.POS>
        Y.RSP.PLAN = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.RSP.REF.ORD.POS>
        Y.REBATE.AMT = ''
        Y.COST.INV.BCCY = ''
        Y.SEC.CCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
            
        IF Y.SEC.CCY EQ LCCY THEN
            Y.COST.INV.BCCY = Y.TXN.AMT.FUND.CCY
        END ELSE
            BUY.CCY<1,1> = Y.SEC.CCY
            Y.DATE = R.SEC.OPEN.ORDER<SC.SOO.DATE.TIME,1>
            BUY.CCY<1,2> = '20':Y.DATE[1,6]
            BUY.AMT = Y.TXN.AMT.FUND.CCY
            GOSUB CONVERT.AMT.LCY
            Y.COST.INV.BCCY = SELL.AMT
        END
            
        Y.ORG.SALES.PER = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,LR.MAX.SAL.PERC.ORD.POS>
        Y.RSP.LCY = ''
        Y.RSP.CCY = ''
        Y.RSP.INSTALL = ''
*
		GOSUB WRITE.AMEX.FILE
    END ELSE
    	
        R.TRN.CON.DATE = ''
	    CALL F.READ(FN.TRN.CON.DATE,Y.TRANS.ID,R.TRN.CON.DATE,F.TRN.CON.DATE,"")
        
		TRANS.REC.COUNT = DCOUNT(R.TRN.CON.DATE,@FM)
		FOR TRN.CON.DATE.REC.COUNT = 1 TO TRANS.REC.COUNT
			TRN.CON.TRD.DATE = FIELD(R.TRN.CON.DATE<TRN.CON.DATE.REC.COUNT>,'.',10)
           
			IF (TRN.CON.TRD.DATE GE FROM.DATE) AND (TRN.CON.TRD.DATE LE TO.DATE) THEN
				Y.TRANS.ID = FIELD(R.TRN.CON.DATE<TRN.CON.DATE.REC.COUNT>,'.',11,2)
                IF Y.TRANS.ID[1,6] EQ 'DIARSC' THEN
            		TRN.CON.DATE.REC.COUNT++
                    CONTINUE
       			END
                R.SECURITY.TRANS = '' ; SECURITY.TRANS.ERR = ''
                CALL F.READ(FN.SECURITY.TRANS,Y.TRANS.ID,R.SECURITY.TRANS,F.SECURITY.TRANS,SECURITY.TRANS.ERR)
				Y.SEC.ACCOUNT = R.SECURITY.TRANS<SC.SCT.SECURITY.ACCOUNT>
				Y.CUST.NUMBER = FIELD(Y.SEC.ACCOUNT,'-',1)
                R.CUSTOMER = '' ; CUSTOMER.ERR = '' ; Y.LOB.CUS = ''
                CALL F.READ(FN.CUSTOMER,Y.CUST.NUMBER,R.CUSTOMER,F.CUSTOMER,CUSTOMER.ERR)
                Y.LOB.CUS = R.CUSTOMER<EB.CUS.LOCAL.REF,L.O.B.CUS.POS>
*CPSGMIG-19969 - S             
                Y.DAO.ID = R.CUSTOMER<EB.CUS.ACCOUNT.OFFICER>
                R.DAO = ''
                ERR.DAO = ''
                CALL F.READ(FN.DAO,Y.DAO.ID,R.DAO,F.DAO,ERR.DAO)
                Y.ARM.CODE =R.DAO<EB.DAO.LOCAL.REF,LR.ARM.CODE.POS>
*CPSGMIG-19969 - E          
                IF Y.LOB.CUS EQ '8' ELSE
                    CONTINUE
                END
                Y.ORDER.DATE = R.SECURITY.TRANS<SC.SCT.TRADE.DATE>
                Y.TXN.TYPE = R.SECURITY.TRANS<SC.SCT.TRANS.TYPE>
                Y.TRANS.REF = R.SECURITY.TRANS<SC.SCT.REF.NO.SEQUENCE>
            	Y.TXN.CODE = Y.TXN.TYPE
                GOSUB BUY.SELL
                Y.SECURITY.NO = R.SECURITY.TRANS<SC.SCT.SECURITY.NUMBER>
                R.SECURITY.MASTER = ''
                CALL F.READ(FN.SECURITY.MASTER,Y.SECURITY.NO,R.SECURITY.MASTER,F.SECURITY.MASTER,"")
                Y.SUB.ASSET.TYPE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
				Y.SEC.CCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
                VALUE.DATE = R.SECURITY.TRANS<SC.SCT.VALUE.DATE>
            
                Y.CONFIRM.FLAG = ''
                Y.DISCOUNT = ''
                Y.SETL.ACCOUNT.NO = ''
                Y.SETL.ANT.CCY = ''
                Y.CPF.FLAG = 'N'
                Y.NET.SALE.CHG.PER = ''
                Y.ORG.SALES.PER = ''
                Y.TXN.AMT.FUND.CCY = ''
                Y.CORP.ACT = ''
                Y.CHANNEL.CODE = ''
                Y.REDEM.FEE = ''
                BEGIN CASE
                    CASE Y.TRANS.REF[1,6] EQ 'SCTRSC'
                        R.SEC.TRADE = ''
                        CALL F.READ(FN.SEC.TRADE,Y.TRANS.REF,R.SEC.TRADE,F.SEC.TRADE,"")
                        Y.DISCOUNT = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.DISC.PERC.TRD.POS>
                        Y.TRANS.ID = Y.TRANS.REF
                        IF Y.BUY.SELL = 'BUY' THEN
                            Y.SETL.ACCOUNT.NO = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.PAY.CASA.ACC.TRD.POS>
                            Y.SETL.ANT.CCY = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.PAY.CASA.CCY.TRD.POS>
                        END ELSE
                            Y.SETL.ACCOUNT.NO = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.REC.CASA.ACC.TRD.POS>
                            Y.SETL.ANT.CCY = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.REC.CASA.CCY.TRD.POS>
                        END
                        
                        Y.LR.PAYMENT.TYPE = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.PAYMENT.TYPE.TRD.POS>
                        GOSUB CPF.CHECK  			;*CPSGMIG-19969 - S/E
                        Y.NET.SALE.CHG.PER = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.NET.SAL.PERC.TRD.POS>
                        Y.ORG.SALES.PER = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.MAX.SAL.PERC.TRD.POS>
*                        Y.TXN.AMT.FUND.CCY = R.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>
                                         
                        Y.CHANNEL.CODE = R.SEC.TRADE<SC.SBS.TXN.CHANNEL>
                        Y.RECORD.STATUS =  R.SEC.TRADE<SC.SBS.RECORD.STATUS>
                        Y.SEC.CCY = R.SEC.TRADE<SC.SBS.SECURITY.CURRENCY>
                        Y.DATE = R.SEC.TRADE<SC.SBS.DATE.TIME,1>
                        Y.REF.ID = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.CLOSING.ID.ST.POS>		;*CPSGMIG-19969 - S/E
                        IF Y.RECORD.STATUS EQ '' THEN
                            LOCATE Y.SUB.ASSET.TYPE IN Y.MF.SAT.CODES<1,1> SETTING POS THEN
                                Y.CONFIRM.FLAG = 'Y'
                            END ELSE
                                LOCATE Y.SUB.ASSET.TYPE IN Y.FI.SAT.CODES<1,1> SETTING POS THEN
                                    IF VALUE.DATE GT TODAY THEN
                                        Y.CONFIRM.FLAG = 'N'
                                    END ELSE
                                        Y.CONFIRM.FLAG = 'Y'
                                    END
                                END ELSE
                                    LOCATE Y.SUB.ASSET.TYPE IN Y.SN.SAT.CODES<1,1> SETTING POS THEN
                                        IF VALUE.DATE GT TODAY THEN
                                            Y.CONFIRM.FLAG = 'N'
                                        END ELSE
                                            Y.CONFIRM.FLAG = 'Y'
                                        END
                                    END
                                END
                            END
                        END
                        Y.CU.CHARGE.TAX.TYPE = R.SEC.OPEN.ORDER<SC.SBS.CU.CHARGE.TAX.TYPE>
                        LOCATE 'EXIT.FEE.ALL' IN Y.CU.CHARGE.TAX.TYPE<1,1> SETTING CHARGE.POS THEN
                            Y.REDEM.FEE = R.SEC.OPEN.ORDER<SC.SBS.CU.CHARGE.TAX.AMT,CHARGE.POS>
                        END
                    CASE 1
                        IF VALUE.DATE GT TODAY THEN
                            Y.CONFIRM.FLAG = 'N'
                        END ELSE
                            Y.CONFIRM.FLAG = 'Y'
                        END
*
                        BEGIN CASE
                            CASE Y.TRANS.REF[1,6] EQ 'SECTSC'
                                R.SECURITY.TRANSFER = ''
                                CALL F.READ(FN.SECURITY.TRANSFER,Y.TRANS.REF,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,"")
*                                Y.TXN.AMT.FUND.CCY = R.SECURITY.TRANSFER<SC.STR.NET.AMT.SEC.CCY>
                                Y.SEC.CCY = R.SECURITY.TRANSFER<SC.STR.SECURITY.CCY>                                
                                 Y.DATE = R.SECURITY.TRANSFER<SC.STR.DATE.TIME,1>
                                Y.LR.PAYMENT.TYPE = R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,LR.PAYMENT.TYPE.TRANSFER.POS>
                                GOSUB CPF.CHECK  			;*CPSGMIG-19969 - S/E
*                            CASE Y.TRANS.REF[1,6] EQ 'DIARSC'
*                                R.ENTITLEMENT = ''
*                                CALL F.READ(FN.ENTITLEMENT,Y.TRANS.REF,R.ENTITLEMENT,F.ENTITLEMENT,"")
*                                Y.CORP.ACT = R.ENTITLEMENT<SC.ENT.OPTION.DESC,1>
*                                Y.TXN.AMT.FUND.CCY = R.ENTITLEMENT<SC.ENT.NET.AMOUNT>
*                                Y.SETL.ACCOUNT.NO = R.ENTITLEMENT<SC.ENT.LOCAL.REF,LR.REC.CASA.ACC.ENT.POS>
*                                Y.SETL.ANT.CCY = R.ENTITLEMENT<SC.ENT.LOCAL.REF,LR.REC.CASA.CCY.ENT.POS>
                        END CASE
                END CASE
*
*			    Y.COST.INV.BCCY = R.SECURITY.TRANS<SC.SCT.BOOK.COST.BSE.CCY>
*                Y.COST.INV.BCCY = TRIM(Y.COST.INV.BCCY,'-')
			
*                IF Y.CONFIRM.FLAG EQ 'Y' THEN
                    Y.CONFIRM.DATE = R.SECURITY.TRANS<SC.SCT.VALUE.DATE>
*                END ELSE
*                    Y.CONFIRM.DATE = "00010101"
*                END
                Y.REV.DATE = R.SECURITY.TRANS<SC.SCT.REVERSAL.DATE>
                IF NOT(Y.REV.DATE) THEN
                    Y.REV.FLAG = 'N'
                END ELSE
                    Y.REV.FLAG = 'Y'
                END
                Y.FUND.CODE = R.SECURITY.TRANS<SC.SCT.SECURITY.NUMBER>
                Y.BRANCH.CODE = ''
                Y.STAFF.NO = ''
                Y.SRC.FUND = ''
                Y.INV.FUND.CCY = R.SECURITY.TRANS<SC.SCT.SECURITY.CURRENCY>
                Y.GRS.COMM = ''
                Y.NETT.COMM = ''
                Y.NO.NOMINAL = R.SECURITY.TRANS<SC.SCT.NO.NOMINAL>
                Y.PRICE = R.SECURITY.TRANS<SC.SCT.PRICE>
				Y.CFM.PRICE = R.SECURITY.TRANS<SC.SCT.PRICE>
				Y.B.OR.S = R.SECURITY.MASTER<SC.SCM.BOND.OR.SHARE>      
				IF Y.B.OR.S EQ 'B' THEN
					Y.PRICE = Y.PRICE / 100
					Y.CFM.PRICE = Y.CFM.PRICE / 100
				END
*
                Y.TXN.AMT.FUND.CCY = Y.NO.NOMINAL * Y.PRICE
                IF Y.SEC.CCY EQ LCCY THEN
        			Y.COST.INV.BCCY = Y.TXN.AMT.FUND.CCY
        		END ELSE
           	 		BUY.CCY<1,1> = Y.SEC.CCY
                    BUY.CCY<1,2> = '20':Y.DATE[1,6]
                	BUY.AMT = Y.TXN.AMT.FUND.CCY
                	GOSUB CONVERT.AMT.LCY
                    Y.COST.INV.BCCY = SELL.AMT
        		END
*
                IF Y.CONFIRM.FLAG EQ "N" THEN
                    Y.TXN.STATUS = "3"
                END ELSE
                    Y.TXN.STATUS = "9"
                END
                IF Y.REV.FLAG EQ 'Y' THEN
                    Y.TXN.STATUS = "8"
                END
            	 
            	Y.BONUS.PER = ''
                Y.BONUS.AMT = ''
                Y.FUND.HSE.COMM = ''
                Y.SCB.COMM = ''
                Y.DISC.AMT = ''
                Y.TOT.AUM.FEE = ''
                Y.FUND.HSE.FEE = ''
                Y.PIP.REDM.FEE = ''
                R.SEC.ACC.MASTER = ''
                CALL F.READ(FN.SEC.ACC.MASTER,Y.SEC.ACCOUNT,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,"")
                Y.OPENING.DATE = R.SEC.ACC.MASTER<SC.SAM.START.DATE>
                Y.CFM.UNIT = R.SECURITY.TRANS<SC.SCT.NO.NOMINAL>
                Y.FHSE.COMM.PER = ''
                Y.REBATE = ''
                Y.SETL.ACC.PRODUCT = ''
                Y.ASSET.TYPE = ''
                LOCATE Y.SUB.ASSET.TYPE IN Y.MF.SAT.CODES<1,1> SETTING POS THEN
                    Y.ASSET.TYPE = 'UT'
                END ELSE
                    LOCATE Y.SUB.ASSET.TYPE IN Y.SN.SAT.CODES<1,1> SETTING POS THEN
                        Y.ASSET.TYPE = 'Notes'
                    END ELSE
                        Y.ASSET.TYPE = 'Bond'
                    END
                END
            
*            	Y.ISSUER = R.SECURITY.MASTER<SC.SCM.ISSUER>
*CPSGMIG-19926 - S
*				Y.RET.DEPO = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.RET.DEPO.POS>
*  				IF Y.RET.DEPO EQ '' THEN
*        			Y.RET.DEPO = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.RET.DEPO.INV.POS>
*    			END
	            Y.RET.DEPO = R.SECURITY.MASTER<SC.SCM.TR.ISSUER>
*CPSGMIG-19926 - E
    			R.CUST = ''
    			ERR.CUST = ''
    			CALL F.READ(FN.CUSTOMER,Y.RET.DEPO,R.CUST,F.CUSTOMER,ERR.CUST)
    			Y.PRO.PROV.CDE = R.CUST<EB.CUS.LOCAL.REF,LR.PP.CODE.POS>
                Y.PRO.PROV.NAME = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,MF.ISSUER.NAME.POS>
                CONVERT @SM TO '' IN Y.PRO.PROV.NAME
                IF NOT(Y.PRO.PROV.NAME) THEN
        			Y.PRO.PROV.NAME = R.SECURITY.MASTER<SC.SCM.COMPANY.NAME,1>
    			END
                
                Y.ISIN.CDE = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
                Y.FUND.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME,1>
                Y.RSP.PLAN = ''
                Y.REBATE.AMT = ''
*                Y.COST.INV.BCCY = R.SECURITY.TRANS<SC.SCT.COST.INVS.BASE.CCY>
                Y.RSP.LCY = ''
                Y.RSP.CCY = ''
                Y.RSP.INSTALL = ''
*
                GOSUB WRITE.AMEX.FILE
            END
        NEXT TRN.CON.DATE.REC.COUNT
*
    END
*
RETURN
*--------------------------------------------------------------
CPF.CHECK:
*----------
	Y.CPF.FLAG = Y.LR.PAYMENT.TYPE
                                
    IF Y.CPF.FLAG EQ '' THEN
    	Y.CPF.FLAG = 'N'
    END
	Y.CPFOA = 'N'
    Y.CPFSA = 'N'
    Y.SRS = 'N'
    IF Y.LR.PAYMENT.TYPE EQ 'CPF-OA' THEN
    	Y.CPFOA = 'Y'
    END  
    IF Y.LR.PAYMENT.TYPE EQ 'CPF-SA' THEN
    	Y.CPFSA = 'Y'
    END 
    IF Y.LR.PAYMENT.TYPE EQ 'SRS' THEN
        Y.SRS = 'Y'
    END 
    RETURN
*-----------------------------------------------------------------------------
WRITE.AMEX.FILE:
*---------------
*
	CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.TXN.AMT.FUND.CCY,'1','')
	CALL EB.ROUND.AMOUNT('SGD',Y.COST.INV.BCCY,'1','')
*
	Y.NET.AMT.FUND.CCY = Y.TXN.AMT.FUND.CCY
	IF Y.BUY.SELL EQ 'SELL' THEN
        Y.NET.AMT.FUND.CCY = '0.00'
    END
*
	DELIM = CHAR(01)
*
    Y.TXN.REC = Y.RECORD.IND:DELIM:Y.ORDER.DATE:DELIM:
    Y.TXN.REC :=Y.SEC.ACCOUNT:DELIM:Y.TXN.TYPE:DELIM:Y.TRANS.ID:DELIM:
    Y.TXN.REC :=Y.CONFIRM.FLAG:DELIM:Y.CONFIRM.DATE:DELIM:Y.REV.FLAG:DELIM:Y.REV.DATE:DELIM:
    Y.TXN.REC :=Y.FUND.CODE:DELIM:Y.BRANCH.CODE:DELIM:Y.STAFF.NO:DELIM:
    Y.TXN.REC :=Y.SRC.FUND:DELIM:Y.INV.FUND.CCY:DELIM:Y.TXN.AMT.FUND.CCY:DELIM:
    Y.TXN.REC :=Y.GRS.COMM:DELIM:Y.NETT.COMM:DELIM:Y.REDEM.FEE:DELIM:
    Y.TXN.REC :=Y.NO.NOMINAL:DELIM:Y.PRICE:DELIM:Y.TXN.STATUS:DELIM:
    Y.TXN.REC :=Y.NET.AMT.FUND.CCY:DELIM:Y.BONUS.PER:DELIM:Y.BONUS.AMT:DELIM:
    Y.TXN.REC :=Y.FUND.HSE.COMM:DELIM:Y.SCB.COMM:DELIM:Y.DISC.AMT:DELIM:
    Y.TXN.REC :=Y.TOT.AUM.FEE:DELIM:Y.FUND.HSE.FEE:DELIM:Y.PIP.REDM.FEE:DELIM:
    Y.TXN.REC :=Y.OPENING.DATE:DELIM:Y.CFM.UNIT:DELIM:Y.CFM.PRICE:DELIM:
    Y.TXN.REC :=Y.DISCOUNT:DELIM:Y.FHSE.COMM.PER:DELIM:Y.REBATE:DELIM:
    Y.TXN.REC :=Y.CPF.FLAG:DELIM:Y.SETL.ACC.PRODUCT:DELIM:Y.SETL.ACCOUNT.NO:DELIM:
    Y.TXN.REC :=Y.SETL.ANT.CCY:DELIM:Y.CORP.ACT:DELIM:Y.CHANNEL.CODE:DELIM:
    Y.TXN.REC :=Y.ASSET.TYPE:DELIM:Y.PRO.PROV.CDE:DELIM:Y.PRO.PROV.NAME:DELIM:
    Y.TXN.REC :=Y.ISIN.CDE:DELIM:Y.FUND.NAME:DELIM:Y.NET.SALE.CHG.PER:DELIM:
    Y.TXN.REC :=Y.RSP.PLAN:DELIM:Y.REBATE.AMT:DELIM:Y.COST.INV.BCCY:DELIM:
    Y.TXN.REC :=Y.RSP.LCY:DELIM:Y.RSP.CCY:DELIM:Y.RSP.INSTALL:DELIM:Y.ORG.SALES.PER
*CPSGMIG-19969 - S
	Y.TXN.REC := DELIM:'':DELIM:'':DELIM:Y.ARM.CODE:DELIM:Y.ORDER.DATE:DELIM:Y.TXN.NAME:DELIM:Y.CPFOA:DELIM:Y.CPFSA:DELIM:Y.SRS
    Y.TXN.REC := DELIM:Y.REF.ID
*CPSGMIG-19969 - E
    WRITESEQ Y.TXN.REC APPEND TO F.AMEX.FILES ELSE
        CALL FATAL.ERROR('Unable to write ':F.AMEX.FILES)
    END
*
RETURN
*-----------------------------------------------------------------------------
BUY.SELL:
*--------
	R.SC.TRA.CODE = '' ; SC.TRA.CODE.ERR = '' ; Y.BUY.SELL = ''
	R.SC.TRANS = '' ; ERR.SC.TRANS = '' ; TXN.POS = ''
*
    CALL F.READ(FN.SC.TRA.CODE,Y.TXN.CODE,R.SC.TRA.CODE,F.SC.TRA.CODE,SC.TRA.CODE.ERR)
    Y.TRA.CODE = R.SC.TRA.CODE<1>
*
	CALL F.READ(FN.SC.TRANS.TYPE,Y.TRA.CODE,R.SC.TRANS,F.SC.TRANS.TYPE,ERR.SC.TRANS)
	LOCATE Y.TXN.CODE IN R.SC.TRANS<SC.TRN.SECURITY.CR.CODE> SETTING TXN.POS THEN
		Y.BUY.SELL = 'BUY'
	END ELSE
		Y.BUY.SELL = 'SELL'
	END
*CPSGMIG-19969 - S
	R.SC.TRANS.NAME = ''
    ERR.NAME = ''
	CALL F.READ(FN.SC.TRANS.NAME,Y.TXN.CODE,R.SC.TRANS.NAME,F.SC.TRANS.NAME,ERR.NAME)
    Y.TXN.NAME = R.SC.TRANS.NAME<SC.TNM.SHORT.NAME,1>
*CPSGMIG-19969 - E
RETURN
*-----------------------------------------------------------------------------
CONVERT.AMT.LCY:
*---------------
	CCY.MKT = '1'
	SELL.AMT = ''
    RATE = ''
    DIFFERENCE = ''
    CCY.AMT = ''
    RETURN.CODE = ''
    CALL EXCHRATE(CCY.MKT,BUY.CCY,BUY.AMT,LCCY,SELL.AMT,"",RATE,DIFFERENCE,CCY.AMT,RETURN.CODE)
	RETURN
END
