$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgIcmMandRemoval
*
* Description: - processing and removing the ord id and corr id from SCB.RSG.ICM.T24.MAND.LIST
* 				 whose record doesnot exist or got removed after 30 days
* yIds(INOUT) :  Fetching the list from BUILD.LIST
* Developed by :- Pawan kr(1668106)
* Jira Refs:
* CPSGMIG-5191 - Initial draft to purge FSNG.SCB.RSG.ICM.T24.MAND.LIST
* CPSGMIG-32559: - fix_ F.SCB.RSG.ICM.T24.MAND.LIST getting deleted even ord record was present _fixed. 
SUBROUTINE B.SCB.RSG.ICM.MAND.REMOVAL(Y.IDS)

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.ICM.MAND.REMOVAL.COMMON
    $INSERT I_F.SCB.RSG.ICM.T24.MAND.LIST


    GOSUB PROCESS ; *
RETURN

*-----------------------------------------------------------------------------

*** <region name= PROCESS>
PROCESS:
*** <desc> </desc>

*

    CALL F.READ(FN.SRIT.MAND.LIST,Y.IDS,R.SRIT.MAND.LIST,F.SRIT.MAND.LIST,SRIT.MAND.LIST.ERR)
    CORR.ID = R.SRIT.MAND.LIST<MAND.LIST.ICM.CORR.ID>
    MAND.ORD.ID = R.SRIT.MAND.LIST<MAND.LIST.ICM.ORD.ID>
    IF R.SRIT.MAND.LIST EQ "" THEN
        GOSUB DELETE.MAND
    END
    ELSE
        MAND.ORD.CNT = DCOUNT(MAND.ORD.ID,@VM)
        I =1
*
        FLAG =""
        Y.TMP.ORD.ARR = ""
        Y.TMP.CORR.ARR = ""
        IF MAND.ORD.CNT EQ '0' THEN
            FLAG = 1
            GOSUB DELETE.MAND
        END
        IF MAND.ORD.CNT EQ '1' THEN
		ORD.ID =  MAND.ORD.ID
            GOSUB ORD.DETAILS
            IF R.ORD.DET EQ "" THEN
                GOSUB DELETE.MAND
            END
        END
        ELSE

            IF NOT(FLAG) THEN
                LOOP
                WHILE I LE MAND.ORD.CNT
	
                    ORD.ID =  MAND.ORD.ID<1,I>
				
                    GOSUB ORD.DETAILS
   
                    IF R.ORD.DET THEN
                        FLAG = 1
                        Y.TMP.ORD.ARR<-1> = MAND.ORD.ID<1,I>
                        Y.TMP.CORR.ARR<-1> = CORR.ID<1,I>
    
                    END

                    I+=1
                REPEAT
                IF MAND.ORD.CNT NE DCOUNT(Y.TMP.CORR.ARR,@FM) THEN
                    CHANGE @FM TO @VM IN Y.TMP.ORD.ARR
                    CHANGE @FM TO @VM IN Y.TMP.CORR.ARR
                    R.SRIT.MAND.LIST<MAND.LIST.ICM.CORR.ID> = Y.TMP.CORR.ARR
                    R.SRIT.MAND.LIST<MAND.LIST.ICM.ORD.ID> = Y.TMP.ORD.ARR

                    CALL F.WRITE(FN.SRIT.MAND.LIST,Y.IDS,R.SRIT.MAND.LIST)

                    CALL OCOMO("Records written for ":Y.IDS)
                END		;*End for sub value count not eq modified field count
            END  ;*end for not flag condition
        END   ;*end for nested else condtion
    END   ;*end for first else confiton



RETURN
*** </region>
***************
ORD.DETAILS:
    CALL F.READ(FN.ORD.DET,ORD.ID,R.ORD.DET,F.ORD.DET,ORD.ERR)
RETURN
*********************
DELETE.MAND:
******************
    CALL OCOMO("Record deleted for ":Y.IDS)
    CALL F.DELETE(FN.SRIT.MAND.LIST,Y.IDS)
RETURN
END