$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.RB.ENT.ADVICE.1560(MAT HANDOFF.REC,ERR.MSG)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Vinothkumar M(1519171)
* CPSGMIG-775
* New Routine attached into DE.MAPPING of 1530.SC.003
* AEB.SET.SC.ISIN - Its an existing routine which is already attached into DE.MAPPING>1530.SC.003
* This routine will be triggered first and do the mapping as per PVB BAU.
* This new routine will execute the flow only if the customer is RB
* CPSGMIG-5868- Usage of LR.RB.EX.DATE field instead of EX.DATE for RB clients.
* Cross Compilation for CPSGMIG-775
* 10/10/22 - CPSGMIG -14110 -Ananthy.S - Convert UTS Description from @SM to null.
* 23/10/22 - CPSGMIG-14680 - 1389710 - Added Redemption and E.redemption in LR.EVENT.DESC
* 24/10/22 - CPSGMIG-14662 - 1389710 - Tender Offer Hand off values corrected.
* 27/10/22 - CPSGMIG-14657 - Same mapping used if LR.EVENT.DESC updated for REDEMPTION
* 27/10/22 - CPSGMIG-14976 - Ananthy.S - KnockInPercentage should be taken from SM>PRICE.PERCENTAGE
* 03/11/2022 -CPSGMIG-15180- 1389710-Percentage values in Template CA.03.1 and CA.02.1
* 17/11/2022 -CPSGMIG-17256- 1389710-If LR event desc is EARLY.REDEMPTION then it is nullified.
* 16-Feb-2023 - CPSGMIG -15109 - kalaikumaranp - Advice Mapping for SN Redemption.
* 28-Feb-22 -CPSGMIG-19407-1667095-ReversalFlag passed SAME/NEXT
* 09-Mar-2023 - CPSGMIG-20940 - kalaikumaranp - Currency and Nominal Amount appeared twice.
* 27-Mar-2023 - CPSGMIG-22427 - kalaikumaranp - Mapping CA.03.1 template for Maturity In Shares.
* 17-Apr-2023 - CPSGMIG-24833 - kalaikumaranp - ISIN Code and Share Mapping.
* 19-Apr-2023 - CPSGMIG-24842 - kalaikumaranp - MF Redemption Price,RedemAmount Tags missed.
* 21-Apr-2023 - CPSGMIG-24985 - 1657186 - SN Redemption Mapping Issue.
* 10-May-2023 - CPSGMIG-24985 - 1657186 - E.REDEMPTION should be align with MATURITY.IN.SHARES.
* 10-Aug-2023 - CPSGMIG-32375 - 1648769 - Rel ID Delimiters needs to be fixed from '-' to ':' for Joint Accounts.
* 02-Dec-2025 - ADO-10849423 - Prithi Koppolu - Removal of T24 security master code from Asset Name in RBSG Contract Notes
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.DIARY.TYPE
    $INSERT I_F.DIARY

* PVB mapping routine as is
    CALL AEB.SET.SC.ISIN(MAT HANDOFF.REC,ERR.MSG)
*
    IF ID.COMPANY[1,2] NE "SG" THEN
        RETURN    ;*  to be impacted only from Singapore company
    END
* Below mapping change applys to only SNG company trades
    IF HANDOFF.REC(10)<1> EQ '1560.SC.003' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
RETURN
*---*
INIT:
*----
    Y.CUSTOMER.NO = FIELD(R.NEW(SC.ENT.PORTFOLIO.NO),'-',1)
    Y.SECURITY.NO = R.NEW(SC.ENT.SECURITY.NO)
*
    FnClientOutputParam= 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    FClientOutputParam = ''
    CALL OPF(FnClientOutputParam,FClientOutputParam)
*
    FnSecAccMaster = 'F.SEC.ACC.MASTER'
    FSecAccMaster = ''
    CALL OPF(FnSecAccMaster,FSecAccMaster)
*
    FN.DIARY.TYPE = 'F.DIARY.TYPE'
    F.DIARY.TYPE  = ''
    CALL OPF(FN.DIARY.TYPE,F.DIARY.TYPE)
*
    FN.DIARY = 'F.DIARY'
    F.DIARY  = ''
    CALL OPF(FN.DIARY,F.DIARY)
*
    FnSecMaster = 'F.SECURITY.MASTER'
    FSecMaster = ''
    CALL OPF(FnSecMaster,FSecMaster)
*
    YAppName = 'CUSTOMER':@FM:'SECURITY.MASTER':@FM:'ENTITLEMENT':@FM:'DIARY'
    YFldName = 'L.O.B':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.EBBS.REL':@FM:'LR.UTS.INS.DESC':@FM:'LR.REC.CASA.ACC':@VM:'LR.INT.AMOUNT':@VM:'LR.NO.OF.SHS':@FM:'LR.RB.EX.DATE':@VM:'LR.EVENT.DESC':@VM:'LR.FIXING.DATE':@VM:'LR.SN.STRK.PERC':@VM:'LR.SN.KI.PERC':@VM:'LR.SN.KO.PERC':@VM:'LR.SHS.ISIN.CDE'
    YFldPos = ""
    CALL MULTI.GET.LOC.REF(YAppName,YFldName,YFldPos)
    YLobPos          = YFldPos<1,1>
    YStfPos          = YFldPos<1,2>
    YPfolPos         = YFldPos<1,3>
    YEbbsRelIdpos    = YFldPos<1,4>
    YUtsPos          = YFldPos<2,1>
    YRecCasaAccPos   = YFldPos<3,1>
    Y.LR.INT.AMT.POS = YFldPos<3,2>
* CPSGMIG-15109    
    Y.LR.NO.OF.SHS.POS = YFldPos<3,3>
* CPSGMIG-15109    
    Y.RB.EX.DATE.POS = YFldPos<4,1>
    Y.LR.EVNT.DC.POS = YFldPos<4,2>
* CPSGMIG-15109
    Y.LR.FIXING.DATE.POS = YFldPos<4,3>
    Y.LR.SN.STRK.PERC.POS = YFldPos<4,4>
    Y.LR.SN.KI.PERC.POS = YFldPos<4,5>
    Y.LR.SN.KO.PERC.POS = YFldPos<4,6>
    Y.LR.SN.ISIN.CDE.POS = YFldPos<4,7>
* CPSGMIG-15109
*
* Nullify the values
    ClientIdentifier    = ''
    AdviceId            = ''
    ConsolId            = ''
    R2wFolder           = ''
    DelMode             = ''
    DisclaimerId        = ''
    ConfNotice          = ''
    ReversalFlag        = ''
    PriAcctHolder       = ''
    JntHolder           = ''
    yDescName           = ''
    Y.TRANS.TYPE        = ''
    Y.QUALIFY.HOLDING   = ''
    Y.NOMINAL           = ''
    Y.ISIN              = ''
    Y.PAY.DATE          = ''
    Y.EX.DATE           = ''
    Y.TRANS.TYPE        = ''
    Y.DIARY.TYPE        = ''
    Y.ENT.ID            = ''
    Y.CURRENCY          = ''
    Y.NET.AMOUNT        = ''
    Y.PRICE             = ''
    Y.VALUE.DATE        = ''
    Y.DIARY.RATE        = ''
    Y.ENT.ACC.EXCH.RATE = ''
    Y.ENT.AMT           = ''
    Y.MAT.DATE          = ''
    Y.OPT.NOM           = ''
    Y.SM.ISSUER.NAME    = ''
    Y.SM.ISSUER.PRICE   = ''
    Y.SM.VALN.DATE      = ''
    Y.SPOT.PRICE        = ''
    Y.STRIKE.PRICE      = ''
    Y.STRIKE.PERC1      = ''
    Y.STRIKE.PERC       = ''
    Y.PRICE.BARR.TYPE   = ''
    Y.PRICE.PERCENTAGE  = ''
    Y.UNDERLYING        = ''
    Y.NOTE.PRICE.BARRIER= ''
    Y.NEWSEC.SHT.NAME   = ''
    Y.NEW.SEC.NO        = ''
    Y.LR.EVENT.DESC     = ''
    Y.FGN.CHARGES.AMT   = ''
    Y.COMMISSION.AMT    = ''
    Y.SP.PRI.ARR        = ''
    Y.SN.ARR            = ''
    Y.STR.PRI.ARR       = ''
*
* Fetch LOB value
    FN.CUST = 'F.CUSTOMER'
    F.CUST  = ''
    CALL OPF(FN.CUST,F.CUST)
*
    CALL F.READ(FN.CUST,Y.CUSTOMER.NO,R.CUST,F.CUST,CUST.ERR)
    L.O.B             = R.CUST<EB.CUS.LOCAL.REF,YLobPos>
    LR.PFOLIO.KEY.VAL = R.CUST<EB.CUS.LOCAL.REF,YPfolPos>
    PriAcctHolder     = FIELD(LR.PFOLIO.KEY.VAL,':',1)
    JntHolder         = LR.PFOLIO.KEY.VAL
    CHANGE ':' TO '|' IN JntHolder
* As per the new logic for cleint Identifier provided as on 20220208
    STAFF.IND = R.CUST<EB.CUS.LOCAL.REF,YStfPos>
*
    BEGIN CASE
        CASE R.CUST<EB.CUS.SECTOR> EQ "21"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "23"
            YY.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
*
RETURN
*------
PROCESS:
*------*
* Get the list of PVB LOB
    Y.PARAM.ID =''; Y.ALLOW.SEG ='PVB'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    IF L.O.B MATCHES Y.ALLOWED.LOB THEN
        RETURN   ;* As the customer is private return, no need of further processing and mapping
    END ELSE
        ERR.MSG = ''           ;*If any error w.r.t PVB mapping routine can be ignored as we have all tags mapping below which r not liasing with Pb rtn
    END
    GOSUB GET.REQ.FIELDS        ;* Fetch the necessary field values from trade sm and param tables
*
    IF YNomineeCode EQ '' THEN
        Lending = 'No'
    END ELSE
        Lending = 'Yes'
    END
*CPSGMIG-19407(S)
    Y.ENT.REC = HANDOFF.REC(4)
    Y.DEL.KEY = Y.ENT.REC<146>
    Y.DEL.KEY = FIELD(Y.DEL.KEY,@VM,1)
    Y.BANK.DATE = Y.DEL.KEY[2,8]
    Y.RECORD.STATUS = R.NEW(SC.ENT.RECORD.STATUS)
    IF (YRevFlg NE '') OR (Y.RECORD.STATUS[1,1] EQ "R") THEN
        YRevFlgValue ='REVE'
        BEGIN CASE
            CASE Y.BANK.DATE EQ TODAY
                ReversalFlag = 'SAME'
            CASE Y.BANK.DATE NE TODAY
                ReversalFlag = 'NEXT'
        END CASE
    END ELSE
        YRevFlgValue ='AUTH'
        END
*CPSGMIG-19407(E)

    IF ProductGrp NE '' THEN
        GOSUB GET.ADVICE.FIELD.VALUE
        BEGIN CASE
            CASE ProductGrpValue EQ 'FIXEDINCOME'
                YAssetName = yDescName
            CASE  ProductGrpValue EQ 'FUNDS'            ;* Fetch values w.r.t to MF
                GOSUB GET.FUND.VALUE
            CASE  ProductGrpValue EQ 'STRUCTUREDPRODUCTS'               ;*Fetch values w.r.t to SN
                YAssetName = yDescName
        END CASE
    END
    GOSUB UPDATE.USR.DEF.VALUE                     ;*Assign the values arrived to Handoff record
RETURN
*--------------*
GET.REQ.FIELDS:
*--------------*
** Values from Entitlement
    Y.ENT.ID            = ID.NEW
    YNomineeCode        = FIELD(Y.ENT.ID,'.',4)
    Y.QUALIFY.HOLDING   = R.NEW(SC.ENT.QUALIFY.HOLDING)
    Y.CURRENCY          = R.NEW(SC.ENT.CURRENCY)
    Y.NET.AMOUNT        = R.NEW(SC.ENT.NET.AMOUNT)
    Y.LR.REC.CASA.ACC   = R.NEW(SC.ENT.LOCAL.REF)<1,YRecCasaAccPos>
    Y.NOMINAL           = R.NEW(SC.ENT.NOMINAL)<1,1>
    Y.PRICE             = R.NEW(SC.ENT.PRICE)<1,1>
    Y.VALUE.DATE        = R.NEW(SC.ENT.VALUE.DATE)
    Y.ENT.AMT           = R.NEW(SC.ENT.ENTITLEMENT.AMT)<1,1>
    Y.OPT.NOM           = R.NEW(SC.ENT.OPTION.NOM)
    Y.ENT.ACC.EXCH.RATE = R.NEW(SC.ENT.ACC.EXCH.RATE)
    Y.NEW.SEC.NO        = R.NEW(SC.ENT.NEW.SECURITY)
    Y.FGN.CHARGES.AMT   = R.NEW(SC.ENT.FGN.CHARGES.AMT)
    Y.LR.INT.AMT        = R.NEW(SC.ENT.LOCAL.REF)<1,Y.LR.INT.AMT.POS>
    Y.COMMISSION.AMT    = R.NEW(SC.ENT.COMMISSION.AMT)
*
** Logic to form the Asset Name
    CALL F.READ(FnSecMaster,Y.SECURITY.NO,RSecurityMaster,FSecMaster,YSecErr)
    Y.SM.DESCRIPTION      = RSecurityMaster<SC.SCM.DESCRIPT>
    YSmNewDescription     = RSecurityMaster<SC.SCM.LOCAL.REF,YUtsPos>
    Y.MAT.DATE = RSecurityMaster<SC.SCM.MATURITY.DATE>
    Y.SM.ISSUER.NAME      = RSecurityMaster<SC.SCM.ISSUER.NAME>
    Y.SM.ISSUER.PRICE     = RSecurityMaster<SC.SCM.ISSUE.PRICE>
    Y.SM.ISSUER.DATE      = RSecurityMaster<SC.SCM.ISSUE.DATE>
    Y.SM.VALN.DATE        = RSecurityMaster<SC.SCM.FIXING.DATE>
    Y.SPOT.PRICE          = RSecurityMaster<SC.SCM.SPOT.PRICE><1,1>
    Y.STRIKE.PRICE        = RSecurityMaster<SC.SCM.STRIKE.PRICE><1,1>
    Y.PRICE.BARR.TYPE     = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE><1,1,1>
*CPSGMIG-14976(S)
*    Y.PRICE.PERCENTAGE    = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE>
     Y.PRICE.PERCENTAGE    = RSecurityMaster<SC.SCM.PRICE.PERCENTAGE><1,1,1>
*CPSGMIG-14976(E)
    Y.UNDERLYING          = RSecurityMaster<SC.SCM.UNDERLYING>
    Y.NOTE.PRICE.BARRIER  = RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER>
    Y.STRIKE.PERC1        = Y.SPOT.PRICE/Y.STRIKE.PRICE *100
    IF Y.STRIKE.PERC1 THEN
     Y.STRIKE.PERC        = Y.STRIKE.PERC1
    END
*CPSGMIG-15180(S)    
    IF Y.PRICE.PERCENTAGE THEN
      Y.PRICE.PERCENTAGE = Y.PRICE.PERCENTAGE
    END
    IF Y.SM.ISSUER.PRICE THEN
      Y.SM.ISSUER.PRICE = Y.SM.ISSUER.PRICE
    END
*CPSGMIG-15180(E)
*
	IF YSmNewDescription THEN
        yDescName = YSmNewDescription                  ;* As per new mapping on 21 Feb 2022 Client Advice impacts
    END ELSE
*CPSGMIG -14110(S)
 *       Y.DESC.CNT = DCOUNT(Y.SM.DESCRIPTION,@VM)
 *       CNT = 1
 *       LOOP
 *       WHILE CNT LE Y.DESC.CNT
 *           yDescName<-1> = Y.SM.DESCRIPTION<1,CNT,1>
 *           CNT = CNT + 1
 *       REPEAT
 *       CHANGE @FM TO ' ' IN yDescName
         yDescName = Y.SM.DESCRIPTION
    END

         CHANGE @SM TO '' IN yDescName
*CPSGMIG -14110(E)
*
    Y.ISIN = RSecurityMaster<SC.SCM.I.S.I.N.>
    YInvestType = RSecurityMaster<SC.SCM.INVEST.OPTION.TYPE>
*
** Logic to get the Product Group
    CALL SCB.GET.PRODUCT.API(Y.SECURITY.NO, ProductGrp) ;* Get the Product Type FI SN or Funds

** Get the Diary Details
    R.DIARY = ''; ERR.DIARY = '' ; Y.LR.EVENT.DESC = ''
    Y.DIARY.ID = FIELD(Y.ENT.ID,'.',1)
    CALL F.READ(FN.DIARY,Y.DIARY.ID,R.DIARY,F.DIARY,ERR.DIARY)
    Y.PAY.DATE   = R.DIARY<SC.DIA.PAY.DATE>
    Y.EX.DATE    = R.DIARY<SC.DIA.LOCAL.REF><1,Y.RB.EX.DATE.POS>  ;* CPSGMIG-5868(S/E)
    Y.DIARY.TYPE = R.DIARY<SC.DIA.EVENT.TYPE>
    Y.DIARY.RATE = R.DIARY<SC.DIA.RATE,1>
    IF Y.DIARY.TYPE THEN
        R.DIARY.TYPE = ''; ERR.DIARY.TYPE = ''
        CALL F.READ(FN.DIARY.TYPE,Y.DIARY.TYPE,R.DIARY.TYPE,F.DIARY.TYPE,ERR.DIARY.TYPE)
        Y.TRANS.TYPE = R.DIARY.TYPE<SC.DRY.EVENT.DESC,1>
    END
    Y.LR.EVENT.DESC = R.DIARY<SC.DIA.LOCAL.REF><1,Y.LR.EVNT.DC.POS>
    IF Y.LR.EVENT.DESC EQ 'OTHERS' OR Y.LR.EVENT.DESC EQ 'E.REDEMPTION' OR Y.LR.EVENT.DESC EQ 'REDEMPTION' OR Y.LR.EVENT.DESC EQ 'EARLY.REDEMPTION' THEN ; *CPSGMIG-14680(S/E)
     Y.LR.EVENT.DESC = ''
    END
*
** Other Values
    YRevFlg = HANDOFF.REC(2)<1> ;* Hold the reversal Flag
*
RETURN
*----------------------------------------------------------------------------------*
GET.ADVICE.FIELD.VALUE:
*-----------------------*
    ProductGrpValue = TRIM(ProductGrp," ","A")
    ProductGrpValue = UPCASE(ProductGrpValue)
    YRecID = APPLICATION:"-":ProductGrpValue:"-":Y.DIARY.TYPE
    IF Y.LR.EVENT.DESC THEN ;* CPSGMIG-20940
     YRecID = APPLICATION:"-":ProductGrpValue:"-":Y.LR.EVENT.DESC
    END
    CALL F.READ(FnClientOutputParam,YRecID,RClientOutputParam,FClientOutputParam,YAdviceErr)
    EventTypeArr = RClientOutputParam<SC.CO.EVENT.TYPE>
    CHANGE @VM TO @FM IN EventTypeArr
*
    LOCATE YRevFlgValue IN EventTypeArr SETTING AdvPos THEN
        AdviceId     = RClientOutputParam<SC.CO.ADVICE.ID,AdvPos>
        ConsolId     = RClientOutputParam<SC.CO.CONSOL.ID,AdvPos>
        DisclaimerId = RClientOutputParam<SC.CO.DISCLAMIER.ID,AdvPos>
        ConfNotice   = RClientOutputParam<SC.CO.CONFIRMATION.NOTICE,AdvPos>
        DelMode      = RClientOutputParam<SC.CO.DELIVERY.MODE,AdvPos>
    END
    CALL SCB.CLIENTIDEN.R2WFOLD.RTN(YY.CLIENT.IDENTIFIER,R2wFolder)
*
RETURN
*--------------*
GET.FUND.VALUE:
*--------------*
    IF YInvestType NE '' THEN
        YInvestOption = 'INVEST.OPTION'
        CALL F.READ(FnClientOutputParam,YInvestOption,RInvestLocalParam,FClientOutputParam,YInvestErr)
        InvestFieldName = RInvestLocalParam<SC.CO.FIELD.NAME>
        LOCATE YInvestType IN InvestFieldName<1,1> SETTING YInvestPos THEN
            YDepoAsset = RInvestLocalParam<SC.CO.FIELD.SUB.VALUE,YInvestPos>
        END
    END
    IF YDepoAsset NE '' THEN
        YAssetName = yDescName:' ':YDepoAsset
    END ELSE
        YAssetName = yDescName
    END
*
RETURN
*-----------------------------------------------------------------------------
UPDATE.USR.DEF.VALUE:
*----------------------*
    *YAssetName = Y.SECURITY.NO:' ':YAssetName ;* Asset name should be prefixed with Security No CPSGMIG-4914
	YAssetName = YAssetName ;* ADO-10849423 - (s/e)
    HANDOFF.REC(9)<1> = YY.CLIENT.IDENTIFIER
    HANDOFF.REC(9)<2> = ConsolId
    HANDOFF.REC(9)<3> = AdviceId
    HANDOFF.REC(9)<4> = ConfNotice
    HANDOFF.REC(9)<5> = R2wFolder
    HANDOFF.REC(9)<6> = PriAcctHolder
    HANDOFF.REC(9)<7> = JntHolder
    HANDOFF.REC(9)<8> = Y.ENT.ID
    HANDOFF.REC(9)<9> = Y.TRANS.TYPE
    HANDOFF.REC(9)<10> = YAssetName
    HANDOFF.REC(9)<11> = Y.ISIN
    HANDOFF.REC(9)<12> = ProductGrp
    HANDOFF.REC(9)<13> = Lending
    HANDOFF.REC(9)<18> = DisclaimerId
    HANDOFF.REC(9)<19> = "TNO"
*
    BEGIN CASE
     CASE ProductGrpValue EQ 'FIXEDINCOME'
        HANDOFF.REC(9)<25> = Y.LR.REC.CASA.ACC
        IF Y.DIARY.TYPE EQ 'E.REDEMPTION' OR  Y.DIARY.TYPE EQ 'REDEMPTION' AND Y.LR.EVENT.DESC THEN
          GOSUB GET.TO.VALUES
        END
        IF Y.DIARY.TYPE EQ 'E.REDEMPTION' OR  Y.DIARY.TYPE EQ 'REDEMPTION' AND NOT(Y.LR.EVENT.DESC) THEN
          HANDOFF.REC(9)<14> = Y.VALUE.DATE
          HANDOFF.REC(9)<15> = Y.MAT.DATE
          HANDOFF.REC(9)<16> = Y.CURRENCY
          HANDOFF.REC(9)<17> = Y.QUALIFY.HOLDING
          HANDOFF.REC(9)<20> = Y.DIARY.RATE
          HANDOFF.REC(9)<21> = Y.OPT.NOM
          HANDOFF.REC(9)<22> = Y.ENT.AMT
          HANDOFF.REC(9)<23> = Y.DIARY.RATE
          HANDOFF.REC(9)<24> = Y.NET.AMOUNT
        END
     CASE ProductGrpValue EQ 'FUNDS'
*CPSGMIG-14657(S)
        IF Y.DIARY.TYPE EQ 'REDEMPTION' AND Y.LR.EVENT.DESC THEN
          HANDOFF.REC(9)<9> =  Y.LR.EVENT.DESC ;* CPSGMIG-24842
        END
        IF Y.DIARY.TYPE EQ 'REDEMPTION' THEN
*CPSGMIG-14657(E)
        HANDOFF.REC(9)<26> = Y.EX.DATE
        HANDOFF.REC(9)<27> = Y.CURRENCY
        HANDOFF.REC(9)<28> = Y.QUALIFY.HOLDING
        HANDOFF.REC(9)<29> = Y.DIARY.RATE
        HANDOFF.REC(9)<30> = Y.ENT.AMT
        HANDOFF.REC(9)<31> = Y.ENT.ACC.EXCH.RATE
        HANDOFF.REC(9)<32> = Y.NET.AMOUNT
        HANDOFF.REC(9)<33> = Y.LR.REC.CASA.ACC
      END
CASE ProductGrpValue EQ 'STRUCTUREDPRODUCTS'
* CPSGMIG-15109
    	IF Y.DIARY.TYPE EQ 'REDEMPTION' AND Y.LR.EVENT.DESC EQ 'MATURITY.IN.SHARES' THEN
            GOSUB GET.SP.RDM.VALUES
    	END
* CPSGMIG-15109
*    
        IF Y.DIARY.TYPE EQ 'E.REDEMPTION' OR Y.DIARY.TYPE EQ 'REDEMPTION' AND Y.LR.EVENT.DESC AND Y.LR.EVENT.DESC NE 'MATURITY.IN.SHARES' THEN
          GOSUB GET.TO.VALUES
        END
        IF Y.DIARY.TYPE EQ 'E.REDEMPTION' AND NOT(Y.LR.EVENT.DESC) THEN
          Y.SM.VALN.DATE = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.FIXING.DATE.POS> ;* CPSGMIG - 24985
          Y.STRIKE.PERC = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.SN.STRK.PERC.POS>
          GOSUB GET.SP.VALUES
* CPSGMIG - 24985-S
          HANDOFF.REC(9)<42> = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.SN.KI.PERC.POS>
    	  HANDOFF.REC(9)<43> = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.SN.KO.PERC.POS>
* CPSGMIG - 24985-E
        END
        IF Y.DIARY.TYPE EQ 'REDEMPTION' AND NOT(Y.LR.EVENT.DESC) THEN
          GOSUB GET.SP.VALUES
          R.SM1 = ''
          CALL F.READ(FnSecMaster,Y.NEW.SEC.NO,R.SM1,FSecMaster,Y.SMERR)
          Y.NEWSEC.SHT.NAME = R.SM1<SC.SCM.SHORT.NAME>
          HANDOFF.REC(9)<51> = Y.NEWSEC.SHT.NAME
        END
     END CASE
    HANDOFF.REC(9)<64> = ReversalFlag ;**CPSGMIG-19407(S/E)
*
   RETURN
*-------------
GET.SP.VALUES:
*-------------
   HANDOFF.REC(9)<34> = Y.NET.AMOUNT
   HANDOFF.REC(9)<35> = Y.CURRENCY
   HANDOFF.REC(9)<36> = Y.SM.ISSUER.NAME
   HANDOFF.REC(9)<37> = Y.SM.ISSUER.PRICE
   HANDOFF.REC(9)<38> = Y.SM.ISSUER.DATE
   HANDOFF.REC(9)<39> = Y.SM.VALN.DATE
   HANDOFF.REC(9)<40> = Y.MAT.DATE
   HANDOFF.REC(9)<41> = Y.STRIKE.PERC
*
   IF Y.PRICE.BARR.TYPE EQ 'KNOCK.IN' THEN
      HANDOFF.REC(9)<42> = Y.PRICE.PERCENTAGE<1,1,1>
   END
   IF Y.PRICE.BARR.TYPE EQ 'KNOCK.OUT' THEN
      HANDOFF.REC(9)<43> = Y.PRICE.PERCENTAGE<1,1,1>
   END
*
   HANDOFF.REC(9)<44> = Y.OPT.NOM
   GOSUB GET.SM.VALUES
   HANDOFF.REC(9)<45> = Y.SN.ARR
   HANDOFF.REC(9)<46> = Y.SP.PRI.ARR
   HANDOFF.REC(9)<47> = Y.STR.PRI.ARR
* CPSGMIG-24985
   HANDOFF.REC(9)<48> = Y.KNIN.NOTE.PRC.ARR
   HANDOFF.REC(9)<49> = Y.KNOUT.NOTE.PRC.ARR
* CPSGMIG-24985
   HANDOFF.REC(9)<50> = Y.CURRENCY
*
   RETURN
*-------------
GET.TO.VALUES:
*-------------
  HANDOFF.REC(9)<9> =  Y.LR.EVENT.DESC
  HANDOFF.REC(9)<52> = Y.CURRENCY
  HANDOFF.REC(9)<53> = Y.EX.DATE
  HANDOFF.REC(9)<54> = Y.VALUE.DATE
  HANDOFF.REC(9)<55> = Y.MAT.DATE
*CPSGMIG-14662(S)
  HANDOFF.REC(9)<56> = Y.DIARY.RATE
  HANDOFF.REC(9)<57> = Y.FGN.CHARGES.AMT
  HANDOFF.REC(9)<58> = Y.LR.INT.AMT
  HANDOFF.REC(9)<59> = Y.COMMISSION.AMT
  HANDOFF.REC(9)<60> = Y.OPT.NOM
  HANDOFF.REC(9)<61> = Y.ENT.AMT
  HANDOFF.REC(9)<62> = Y.NET.AMOUNT
  HANDOFF.REC(9)<63> = Y.LR.REC.CASA.ACC
*CPSGMIG-14662(E)
*
  RETURN
*-------------
GET.SM.VALUES:
*-------------
* CPSGMIG-24985
	Y.SN.ARR = RSecurityMaster<SC.SCM.UNDERLYING.DESCRIPTION>
   CONVERT @VM TO '|' IN Y.SN.ARR
   HANDOFF.REC(9)<45> = Y.SN.ARR
*
   Y.SP.PRI.ARR = RSecurityMaster<SC.SCM.SPOT.PRICE>
   CONVERT @VM TO '|' IN Y.SP.PRI.ARR
   HANDOFF.REC(9)<46> = Y.SP.PRI.ARR
*
	Y.STR.PRI.ARR = RSecurityMaster<SC.SCM.STRIKE.PRICE>
    CONVERT @VM TO '|' IN Y.STR.PRI.ARR
    HANDOFF.REC(9)<47> = Y.STR.PRI.ARR

*
* KnockInPrice and KnockOutPrice
	Y.KNIN.NOTE.PRC.ARR = ''
	Y.KNOUT.NOTE.PRC.ARR = ''
	Y.PRICE.BARR.TYPE = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE>
	NoOfUnderLying = DCOUNT(RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE>,@VM)
	FOR SM.CNT = 1 TO NoOfUnderLying
		NoOfBarTpe=DCOUNT(RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,SM.CNT>,@SM)
		FOR BAR.CNT=1 TO NoOfBarTpe
		IF RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,SM.CNT,BAR.CNT> EQ 'KNOCK.IN' THEN
			Y.KNIN.NOTE.PRC = RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER,SM.CNT,BAR.CNT>
			BEGIN CASE
				CASE Y.KNIN.NOTE.PRC AND NOT(Y.KNIN.NOTE.PRC.ARR)
					Y.KNIN.NOTE.PRC.ARR = Y.KNIN.NOTE.PRC
				CASE Y.KNIN.NOTE.PRC.ARR AND Y.KNIN.NOTE.PRC
					Y.KNIN.NOTE.PRC.ARR :='|':Y.KNIN.NOTE.PRC
			END CASE
		END
		IF RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,SM.CNT,BAR.CNT> EQ 'KNOCK.OUT' THEN
			Y.KNOUT.NOTE.PRC = RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER,SM.CNT,BAR.CNT>
			BEGIN CASE
				CASE Y.KNOUT.NOTE.PRC AND NOT(Y.KNOUT.NOTE.PRC.ARR)
					Y.KNOUT.NOTE.PRC.ARR = Y.KNOUT.NOTE.PRC
				CASE Y.KNOUT.NOTE.PRC.ARR AND Y.KNOUT.NOTE.PRC
					Y.KNOUT.NOTE.PRC.ARR :='|':Y.KNOUT.NOTE.PRC
			END CASE
		END
    NEXT BAR.CNT
    NEXT SM.CNT    
* CPSGMIG-24985
RETURN
*-------------------------
GET.SP.RDM.VALUES:
* ------------------------
**CPSGMIG -15109
   HANDOFF.REC(9)<34> = Y.NET.AMOUNT
   HANDOFF.REC(9)<35> = Y.CURRENCY
   HANDOFF.REC(9)<36> = Y.SM.ISSUER.NAME
   HANDOFF.REC(9)<37> = Y.SM.ISSUER.PRICE
   HANDOFF.REC(9)<38> = Y.SM.ISSUER.DATE
   Y.SM.VALN.DATE = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.FIXING.DATE.POS>
   HANDOFF.REC(9)<39> = Y.SM.VALN.DATE
   HANDOFF.REC(9)<40> = Y.MAT.DATE
   Y.STRIKE.PERC = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.SN.STRK.PERC.POS>
   HANDOFF.REC(9)<41> = Y.STRIKE.PERC
*
	HANDOFF.REC(9)<42> = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.SN.KI.PERC.POS>
    HANDOFF.REC(9)<43> = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.SN.KO.PERC.POS>
*
   HANDOFF.REC(9)<44> = Y.OPT.NOM
*   
   Y.SN.ARR = RSecurityMaster<SC.SCM.UNDERLYING.DESCRIPTION>
   CONVERT @VM TO '|' IN Y.SN.ARR
   HANDOFF.REC(9)<45> = Y.SN.ARR
*
   Y.SP.PRI.ARR = RSecurityMaster<SC.SCM.SPOT.PRICE>
   CONVERT @VM TO '|' IN Y.SP.PRI.ARR
   HANDOFF.REC(9)<46> = Y.SP.PRI.ARR
*
	Y.STR.PRI.ARR = RSecurityMaster<SC.SCM.STRIKE.PRICE>
    CONVERT @VM TO '|' IN Y.STR.PRI.ARR
    HANDOFF.REC(9)<47> = Y.STR.PRI.ARR
    
   NoOfUnits = R.NEW(SC.ENT.LOCAL.REF)<1,Y.LR.NO.OF.SHS.POS> 
   HANDOFF.REC(9)<65>=NoOfUnits
   
*
* KnockInPrice and KnockOutPrice
	Y.KNIN.NOTE.PRC.ARR = ''
	Y.KNOUT.NOTE.PRC.ARR = ''
	Y.PRICE.BARR.TYPE = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE>
	NoOfUnderLying = DCOUNT(RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE>,@VM)
	FOR SM.CNT = 1 TO NoOfUnderLying
		NoOfBarTpe=DCOUNT(RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,SM.CNT>,@SM)
		FOR BAR.CNT=1 TO NoOfBarTpe
		IF RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,SM.CNT,BAR.CNT> EQ 'KNOCK.IN' THEN
			Y.KNIN.NOTE.PRC = RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER,SM.CNT,BAR.CNT>
			BEGIN CASE
				CASE Y.KNIN.NOTE.PRC AND NOT(Y.KNIN.NOTE.PRC.ARR)
					Y.KNIN.NOTE.PRC.ARR = Y.KNIN.NOTE.PRC
				CASE Y.KNIN.NOTE.PRC.ARR AND Y.KNIN.NOTE.PRC
					Y.KNIN.NOTE.PRC.ARR :='|':Y.KNIN.NOTE.PRC
			END CASE
		END
		IF RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,SM.CNT,BAR.CNT> EQ 'KNOCK.OUT' THEN
			Y.KNOUT.NOTE.PRC = RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER,SM.CNT,BAR.CNT>
			BEGIN CASE
				CASE Y.KNOUT.NOTE.PRC AND NOT(Y.KNOUT.NOTE.PRC.ARR)
					Y.KNOUT.NOTE.PRC.ARR = Y.KNOUT.NOTE.PRC
				CASE Y.KNOUT.NOTE.PRC.ARR AND Y.KNOUT.NOTE.PRC
					Y.KNOUT.NOTE.PRC.ARR :='|':Y.KNOUT.NOTE.PRC
			END CASE
		END
    NEXT BAR.CNT
    NEXT SM.CNT
    
    HANDOFF.REC(9)<48> = Y.KNIN.NOTE.PRC.ARR
    HANDOFF.REC(9)<49> = Y.KNOUT.NOTE.PRC.ARR
*
*
   HANDOFF.REC(9)<50> = Y.CURRENCY
*
* Shares
	Y.ISIN.DESC = R.DIARY<SC.DIA.LOCAL.REF,Y.LR.SN.ISIN.CDE.POS>
    Y.ISIN.CDE = FIELD(Y.ISIN.DESC,'-',3,1)
    MKT.POS = ''
    IF Y.ISIN.CDE THEN ;* CPSGMIG-24833
    	LOCATE Y.ISIN.CDE IN RSecurityMaster<SC.SCM.MARKET.IDENTIFIER,1> SETTING MKT.POS THEN
        	HANDOFF.REC(9)<51> = RSecurityMaster<SC.SCM.UNDERLYING.DESCRIPTION,MKT.POS>
    	END
    END
*
RETURN
*----------------------------------------------------
END