$PACKAGE All.ScbRbPackage
*JIRA REF:- CPSGMIG-17684
SUBROUTINE E.CONV.SCB.RSG.ENT.DETAILS
*-----------------------------------------------------------------------------
*Conversion routine attached to E.SCB.RSG.ENT.DETAILS to get "" Amt values as zero
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
 
    Y.HOLDING = O.DATA
    IF Y.HOLDING EQ "" THEN
    
        O.DATA ="0"
    END

RETURN
************************
END
