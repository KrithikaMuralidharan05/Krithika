* @ValidationCode : MjotMTUxMTczNDMwNzpJU08tODg1OS0xOjE2ODIzMzM3MjYwODg6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 24 Apr 2023 16:25:26
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PROD.PRVIDR.LIST.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-15222
* Developed By                   :       Senthil
* Developed On                   :       02-Feb-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* POST Routine to generate Extract file of Product Provide detail listing
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 1663000       1663000          CPSGMIG-20051 Remove non T24 columns
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename Change
* 13-Jun-2023   1671073          CPSGMIG-24884 - New Header "Identifier" to be added in the "Product Provider detail Listing report" 
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB PROCESS
	 
RETURN
*---------------------------------------------------------------------------------------------
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    AMEXPATH =""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.TXN.FINAL.FILE    = BATCH.DETAILS<3,1>
    Y.LWD            = R.DATES(EB.DAT.LAST.WORKING.DAY) ;* CPSGMIG-21498
    Y.TXN.FINAL.FILE = EREPLACE(Y.TXN.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498

RETURN
*---------------------------------------------------------------------------------------------
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.TXN.ARR = '' ; Y.FINAL.TXN.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = "SCBCUSPROVIDERLIST-" :TODAY:"-*.csv*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(R.TXN.ARR) THEN
                R.TXN.ARR = R.AMEX.FILE
            END ELSE
                R.TXN.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

        IF R.TXN.ARR THEN
           
* Include the Header part
            Y.TXN.HDR = "Product Provider Code,Id,Short Name,Name,Address#1," ;*CPSGMIG-20051
            Y.TXN.HDR:= "Address#2,Address#3,Address#4,Contact Person,Phone No,Fax No,Identifier"   ;*CPSGMIG-20051
 
* Include the Data content
            Y.FINAL.TXN.ARR     = Y.TXN.HDR
            Y.FINAL.TXN.ARR<-1> = R.TXN.ARR
    
            WRITE Y.FINAL.TXN.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
            
        END
    END

RETURN
*----------------------------------------------------------------------------------------------------------------------
END