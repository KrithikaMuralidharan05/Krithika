$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.OMF.SM.EXTRACT(Y.SM.ID)
*--------------------------------------------------------------------------------------------
* Project Name  : CPSGMIG-309 - JEWEL_T24_PROJECT
* Developed By  : 1625136
* Developed On  : 03 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract SM details
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SC.SECURITY.CONSTRAINT
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.RB.OMF.SM.EXTRACT.COMMON
            
    GOSUB EXTRACT.SM.DETS
    GOSUB FORM.ARRAY

RETURN
*---------------------------------------------------------------------------------------
EXTRACT.SM.DETS:
*****************
	DL = '|'
	R.SECURITY.MASTER = ''
	ERR = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,ERR)
    IF R.SECURITY.MASTER THEN
        Y.DESCRIPT     = R.SECURITY.MASTER<SC.SCM.DESCRIPT>
        CONVERT @VM TO '' IN Y.DESCRIPT
		Y.ISIN = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
		Y.SEC.CUR = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
		
		Y.CUT.OFF.TIME = ''
		Y.FIELD.VALUE = ''
		Y.FIELD.NAME =  ''
		PARAM.ID = 'FUNDS.CUT.OFF.TIME'
			
		CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,PARAM.ID,R.PARAM,F.SCB.WM.H.LOCAL.PARAM,R.PARAM.ERR)
		Y.FIELD.NAME = R.PARAM<SCBWM.PRM.FIELD.NAME>
		
		Y.CASH.OR.REINV = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,CASH.OR.REINV.POS>
		IF Y.CASH.OR.REINV EQ '' THEN
			Y.CASH.OR.REINV = "X"
		END
		Y.TDS.GLOBAL.ID = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,TDS.GLOBAL.ID.POS>
		
		Y.MF.ISSUER.NAME = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,MF.ISSUER.NAME.POS>
 		CONVERT @SM TO @VM IN Y.MF.ISSUER.NAME
        CONVERT @VM TO '' IN Y.MF.ISSUER.NAME
        CONVERT ',' TO '~' IN Y.MF.ISSUER.NAME			;*To Handle comma in the values.
        
		Y.TR.ISSUER = R.SECURITY.MASTER<SC.SCM.TR.ISSUER>
        R.CUSTOMER = ''
		ERR1 = ''
		CALL F.READ(FN.CUSTOMER,Y.TR.ISSUER,R.CUSTOMER,F.CUSTOMER,ERR1)
		Y.LR.PP.CODE = R.CUSTOMER<EB.CUS.LOCAL.REF,LR.PP.CODE.POS>
        
*Vestima check	
		Y.LR.RETAIL.DEPO = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LR.RETAIL.DEPO.POS>
        Y.LM.RET.DEPO.INV = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LM.RET.DEPO.INV.POS>
        
        Y.DEPOSITORY = Y.LR.RETAIL.DEPO
		
		IF Y.LR.RETAIL.DEPO EQ '' THEN 
			Y.DEPOSITORY = Y.LM.RET.DEPO.INV 
		END
        
 		Y.VESTIMA = ''
		IF Y.DEPOSITORY THEN
			CALL SCB.RB.VEST.FLAG(Y.DEPOSITORY,Y.VESTIMA)
		END
		IF Y.VESTIMA EQ 'Y' THEN
			Y.VESTIMA.VAL = 'VESTIMA.FUNDS'
		END
		IF Y.VESTIMA EQ 'N' THEN
			Y.VESTIMA.VAL = 'NON.VESTIMA.FUNDS'
		END
		LOCATE Y.VESTIMA.VAL IN Y.FIELD.NAME<1,1> SETTING Y.POS THEN
			Y.CUT.OFF.TIME = R.PARAM<SCBWM.PRM.FIELD.VALUE><1,Y.POS>
		END
		
		R.SECURITY.CONST = ''
		ERR.CONST = ''
		CALL F.READ(FN.SECURITY.CONST,Y.SM.ID,R.SECURITY.CONST,F.SECURITY.CONST,ERR.CONST)
		Y.RESTRICT = R.SECURITY.CONST<SC.SCO.RESTRICTION>
				
		Y.INT = 1
		Y.CNT = 12
		Y.POS = ''
		LOOP
		WHILE Y.INT LE Y.CNT 
			SUB.POS = ''
			FINDSTR Y.RESTRICTED.ARR<Y.INT>  IN Y.RESTRICT SETTING SUB.POS THEN
				Y.SUB.ALLOW<-1> = 'N'
			END
			ELSE
				Y.SUB.ALLOW<-1> = 'Y'
			END
		Y.INT ++
		REPEAT
		
    END
RETURN
*-------------------------------------------------------------------------------------
FORM.ARRAY:
************
    Y.ARRAY = 'D':DL:Y.SM.ID			;* 1.SCB_FundCode
    Y.ARRAY:= DL:Y.DESCRIPT     		;* 2.SCB_FundName
    Y.ARRAY:= DL:Y.ISIN         	    ;* 3.SCB_ISIN
    Y.ARRAY:= DL:Y.SEC.CUR      	  	;* 4.SCB_FundClassCurrency
	Y.ARRAY:= DL:Y.MF.ISSUER.NAME		;* 5.SCB_FundHouse
    Y.ARRAY:= DL:Y.CUT.OFF.TIME 	    ;* 6.CutOffTime
    Y.ARRAY:= DL:Y.CASH.OR.REINV	 	;* 7.FundDividendInstructionCode
    Y.ARRAY:= DL:Y.TDS.GLOBAL.ID	   	;* 8.TDS Global ID
    Y.ARRAY:= DL:Y.LR.PP.CODE		    ;* 9.Product Provider Code
    Y.ARRAY:= DL:Y.SUB.ALLOW<1> 	   	;* 10.Subscription Allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<2> 	  	;* 11.Redemption Allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<3> 	  	;* 12.Transfer IN Allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<4>		  	;* 13.Transfer OUT Allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<5> 	   	;* 14.Switch IN allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<6> 	   	;* 15.Switch OUT allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<7> 	   	;* 16.Cancellation Allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<8>		 	;* 17.Cash Allowed
    Y.ARRAY:= DL:Y.SUB.ALLOW<9> 	   	;* 18.OA
    Y.ARRAY:= DL:Y.SUB.ALLOW<10>	    ;* 19.SA
    Y.ARRAY:= DL:Y.SUB.ALLOW<11>	    ;* 20.SRS
    Y.ARRAY:= DL:Y.SUB.ALLOW<12>	   	;* 21.15

    GOSUB WRITE.SM.FILE
RETURN
*-----------------------------------------------------------------------------------------
WRITE.SM.FILE:
***************
    IF Y.ARRAY THEN
        OPENSEQ AMEX.FILES,Y.FILE.ID TO FP.AMEX.FILES ELSE
        END
        WRITESEQ Y.ARRAY APPEND TO FP.AMEX.FILES ELSE
            CALL OCOMO("Unable to Write PCAT file")
        END
        CLOSESEQ FP.AMEX.FILES
        
    END
RETURN
END
