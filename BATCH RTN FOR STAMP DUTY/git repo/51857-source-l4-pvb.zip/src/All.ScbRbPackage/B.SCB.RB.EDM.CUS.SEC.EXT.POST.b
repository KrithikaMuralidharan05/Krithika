$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-44</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.CUS.SEC.EXT.POST
**************************************************************************
*Modification History:
************************
* 27-May-2022 - CPSGMIG-3321 - Lavanya L - Copy of the existing routine B.SCB.EDM.CUS.SEC.EXTRACT.POST
****************************************************************************************************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
*********************************************************************************************
    GOSUB INIT
    GOSUB PROCESS
RETURN
*********************************************************************************************
INIT:
****
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*	TAFJUPG -S
    ARG1 = 'AMEX.FILES'
	AMEXPATH=""
	CALL SCB.GET.ORACLE.FILENAME(ARG1,"",AMEXPATH)
    FW.AMEX.FILES = AMEXPATH

*	TAFJUPG -E
	DL = CHAR(01)
**Headers**
   Y.HEADER = ''
   Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
   Y.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
   Y.HEADER<-1> = 'D':DL:'CUSTOMER_ID':DL:'CUSTOMER_TYPE'			;*CPSGMIG-3321 - S/E
**Headers**
*
    Y.FINAL.FILE.NAME = ''
    Y.COMP.NAME = ''
    Y.COMP = ''
    R.CUS.SEC.FINAL.ARR = ''
    Y.COMP = ID.COMPANY
    Y.COMP.NAME = ID.COMPANY[1,2]
    IF Y.COMP.NAME EQ 'GB' THEN
        Y.COMP.NAME = 'UK'
    END
    Y.FINAL.FILE.NAME = Y.COMP.NAME:"-RB-CUS.SECURITY-":TODAY:".CSV"			;*CPSGMIG-3321 - S/E
RETURN
*********************************************************************************************
PROCESS:
********
    SEL.CMD = ''
    SEL.ERR = ''
    SEL.LIST = ''
    NO.OF.FILES = ''

*TAFJUPG Fix - Start

    Y.UDFILE = 'AMEX.FILES'
    SEL.CMD  = Y.COMP:'*-RB-CUSSECURITY-*':TODAY:'.CSV'		;*CPSGMIG-3321 - S/E
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
    *TAFJUPG Fix - End
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.CUS.SEC.FINAL.ARR EQ '' THEN
                R.CUS.SEC.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.CUS.SEC.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
            
        REPEAT
    END
*QC1901-S
    WRITE R.CUS.SEC.FINAL.ARR TO F.AMEX.FILES,Y.FINAL.FILE.NAME
    GOSUB REMOVE.DUP.LINE
    CALL F.READ(FN.AMEX.FILES,Y.FINAL.FILE.NAME,R.CUS.SEC.FINAL.ARR,F.AMEX.FILES,READ.ERR1)
*QC1901-E
*CPSGMIG-3321 - S
   Y.COUNT = DCOUNT(R.CUS.SEC.FINAL.ARR,@FM)
   R.CUS.SEC.FINAL.ARR = Y.HEADER:FM:R.CUS.SEC.FINAL.ARR
   
   R.CUS.SEC.FINAL.ARR<-1> ='T':DL:Y.COUNT
*    R.CUS.SEC.FINAL.ARR = R.CUS.SEC.FINAL.ARR
*CPSGMIG-3321 - E
*R20 UPG -S
*CALL F.WRITE(FN.AMEX.FILES,Y.FINAL.FILE.NAME,R.CUS.SEC.FINAL.ARR)
    R.CUS.SEC.FINAL.ARR = UTF8(R.CUS.SEC.FINAL.ARR)
	CALL F.WRITE(FW.AMEX.FILES,Y.FINAL.FILE.NAME,R.CUS.SEC.FINAL.ARR)
*R20 UPG -E
RETURN
*********************************************************************************************
*QC1901-S
REMOVE.DUP.LINE:
****************
    FILE.PATH.ORG = AMEXPATH
    FILE.PATH.ORG = EREPLACE(FILE.PATH.ORG, "&", "\&")
    CALL SCB.REMOVE.DUPLICATE.LINE(FILE.PATH.ORG,Y.FINAL.FILE.NAME)
RETURN
*QC1901-E
END
