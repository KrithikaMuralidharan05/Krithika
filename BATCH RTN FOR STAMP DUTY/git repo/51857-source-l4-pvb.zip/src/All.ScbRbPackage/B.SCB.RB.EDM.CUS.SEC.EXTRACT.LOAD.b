$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.CUS.SEC.EXTRACT.LOAD
**************************************************************************
* 25 Feb 2016 - FCC EDMP - Subramanian M
*             - This routine will generate the Customer Security Dump in AMEX.FILES.
**************************************************************************
*******************************************************************************
*Modification History:
************************
* 27-May-2022 - CPSGMIG-3321 - Lavanya L - Copy of the existing routine B.SCB.EDM.CUS.SEC.EXTRACT.LOAD
* 23-Mar- 2023 - CPSGMIG-18238 - Lakshmi PR- Parameterised the customer tranche records
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.EDM.CUS.SEC.EXTRACT.COMMON
	 $INSERT I_F.SCB.WM.H.LOCAL.PARAM ;*CPSGMIG-18238- Start/End
*
    GOSUB INIT
*
RETURN
**************************************************************************
INIT:
*****
    FN.CUSTOMER.SECURITY = 'F.CUSTOMER.SECURITY'
    F.CUSTOMER.SECURITY = ''
    CALL OPF(FN.CUSTOMER.SECURITY,F.CUSTOMER.SECURITY)
    
    FN.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.LOC.PARAM = ''
    CALL OPF(FN.LOC.PARAM,F.LOC.PARAM)
*
*R20 UPG -S
    FN.CUST = 'F.CUSTOMER'
    F.CUST = ''
    CALL OPF(FN.CUST,F.CUST)
    
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	ARG1 = 'AMEX.FILES'
    ARG2= ''
    ARG3 =''
    CALL SCB.GET.ORACLE.FILENAME(ARG1, ARG2, ARG3)
    FW.AMEX.FILES = ARG3
*R20 UPG -E

*CPSGMIG-2796-S
	IF ID.COMPANY[1,2] EQ 'SG' THEN
		Y.PARAM.ID    = 'SCB.CUST.SEG'
		Y.ALLOW.SEG   = 'RET'				;*CPSGMIG-3321 - S/E
		Y.ALLOWED.LOB = ''
		CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
		CHANGE @VM TO ' ' IN Y.ALLOWED.LOB
	END
*CPSGMIG-2796-E
*CPSGMIG-18238- Start
        
   Y.APP = 'CUSTOMER'
   Y.FIELD = 'LR.POS.MIG.DT'
   Y.FIELD.POS = ''
   CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
   Y.MIG.DAT.POS = Y.FIELD.POS<1,1>
 
    
   Y.FILE.FLAG =  ''
   ID.LOC.PARAM = 'SCB.RB.CUST.FULL.TRANCHE'
   Y.FIND.FILE.NAME = 'T24_SG_RB_EDM_CUST.SEC'
   CALL F.READ(FN.LOC.PARAM,ID.LOC.PARAM,R.LOC.PARAM,F.LOC.PARAM,LOC.ERR)
   IF R.LOC.PARAM THEN
      Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
          LOCATE Y.FIND.FILE.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
           Y.FILE.FLAG = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>
           CONVERT SM TO VM IN Y.FILE.FLAG
           Y.FILE.FLAG = Y.FILE.FLAG<1,2>
          END
   END   
*CPSGMIG-18238- End   

	RETURN
END
