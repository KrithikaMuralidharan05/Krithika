$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.EDM.RB.SAM.EXTRACT.SELECT
*-----------------------------------------------------------------------------  *
* Desc   - This routine will generate the SAM Dump in AMEX.FILES.
*Modification History:
************************
* 18-Jul-2022 - CPSGMIG-4230 - Lavanya L - Copy of B.SCB.SW.RB.SAM.EXTRACT.SELECT to generate the report only for Retail customers.
*
* 21-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
*-----------------------------------------------------------------------------  *

*******************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.EDM.RB.SAM.EXTRACT.COMMON
*
    GOSUB SEL.PROCESS
RETURN
*******************************************************************************
SEL.PROCESS:
************
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SAM:" WITH L.O.B EQ ":Y.ALLOWED.LOB		;*CPSGMIG-1871 - S/E
*CPSGMIG-13878(S)
*                SEL.CMD := " AND CUST.SECTOR EQ 23"
*CPSGMIG-13878(E)
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
RETURN
*******************************************************************************
END
