$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
   SUBROUTINE B.SCB.RB.SUPP.SP.DAVINCI.SELECT
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This is a new multithreaded job introduced for improving the COB performance
*  as the replacement of the single threaded routine SCB.SUPPLEMENTARY.SP.DAVINCI.
* Copy of existing SCB.SUPPLEMENTARY.SP.DAVINCI.SELECT, include LOB logic for RB.
*-----------------------------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 29-Apr-2022       Lavanya L       CPSGMIG-2776        Initial Creation
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.SUPP.SP.DAVINCI.COMMON
*-----------------------------------------------------------------------------

    SEL.CMD.SEC.POS = 'SELECT ': FN.SECURITY.POSITION : ' WITH CLOSING.BAL.NO.NOM NE 0'
    CALL EB.READLIST(SEL.CMD.SEC.POS, SEC.POS.ID.LIST, '', NO.OF.REC, Y.SEC.POS.ERR)

    CALL BATCH.BUILD.LIST('',SEC.POS.ID.LIST)

    RETURN
*-----------------------------------------------------------------------------
END
