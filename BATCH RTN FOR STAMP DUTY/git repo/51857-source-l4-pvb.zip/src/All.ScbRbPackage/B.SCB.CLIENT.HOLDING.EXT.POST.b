* @ValidationCode : MjoxMzk0NzQ5Mjk5OklTTy04ODU5LTE6MTY4MjQyNDEyMzk3NToxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 25 Apr 2023 17:32:03
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CLIENT.HOLDING.EXT.POST

*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5321 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       13 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* POST Routine to merge the client portfolio details and generate final report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CLIENT.HOLDING.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------------------
* 16-Nov-2022 - CPSGMIG-14651 - Swaminathan - ADVICE.INDEX field addition
* 24-Apr-2023 - CPSGMIG-22844 - New field "Position Migration flag"[ LR.POS.MIG.DT]to be introduced in Reports for users to filter the migrated positions.
* 26-Apr-2023 - CPSGMIG-21498 - 1663000     - Filename/Date Change
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.CLIENT.HOLDING.EXT.COMMON
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB PROCESS
    
RETURN

*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;
    F.AMEX.FILES = '' ;
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    AMEXPATH=''
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX.FILES,F.AMEX.FILES,AMEXPATH)
    
    Y.UTS.FINAL.FILE    = BATCH.DETAILS<3,1>
    Y.LWD               = R.DATES(EB.DAT.LAST.WORKING.DAY) ;* CPSGMIG-21498
    Y.UTS.FINAL.FILE    = EREPLACE(Y.UTS.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
    
    YDL = ','

RETURN
*------*
PROCESS:
*------*

    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.UTS.ARR = '' ; Y.FINAL.UTS.ARR = ''
*
    Y.UDFILE    = 'AMEX.FILES'
    SEL.CMD     = "ClientDetailsPerUTCode-":TODAY:"*.csv*"
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN

        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS

            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)

            IF NOT(R.UTS.ARR) THEN
                R.UTS.ARR = R.AMEX.FILE
            END ELSE
                R.UTS.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)

        REPEAT
* Include the Header part
        Y.UTS.HDR  = 'Product Type':YDL:'Vestima':YDL:'Asset Code':YDL:'Asset Name':YDL:'Account No':YDL:'ISA Account status':YDL:
        Y.UTS.HDR  := 'Residential Country':YDL:'ISIN':YDL:'Country of Operation':YDL:'Dividend Type':YDL:'Confirmed Units':YDL:
        Y.UTS.HDR  := 'Available Units':YDL:'Pending Subscription Units':YDL:'Pending Redemption Units':YDL:
        Y.UTS.HDR  := 'Account Holder 1':YDL:'Rel 1':YDL:'ID Type 1':YDL:'ID Number 1':YDL:'Mobile Phone 1':YDL:
        Y.UTS.HDR  := 'Account Holder 2':YDL:'Rel 2':YDL:'ID Type 2':YDL:'ID Number 2':YDL:'Mobile Phone 2':YDL:
        Y.UTS.HDR  := 'Account Holder 3':YDL:'Rel 3':YDL:'ID Type 3':YDL:'ID Number 3':YDL:'Mobile Phone 3':YDL:
        Y.UTS.HDR  := 'Account Holder 4':YDL:'Rel 4':YDL:'ID Type 4':YDL:'ID Number 4':YDL:'Mobile Phone 4':YDL:
        Y.UTS.HDR  := 'Address 1':YDL:'Address 2':YDL:'Address 3':YDL:'Address 4':YDL:'City':YDL:'State':YDL:
        Y.UTS.HDR  := 'Postal Code':YDL:'Country Full Name':YDL:'Branch Code':YDL:'ARM Code':YDL:
        Y.UTS.HDR  := 'Marketing Information':YDL:'Email':YDL:'RM Name':YDL:'RM Bank ID':YDL:'ClientIdentifier':YDL:'PrimaryAcctHolder':YDL:'Advice Index':YDL:'Position Migration flag'  ; *CPSGMIG-22488-S/E
        Y.FINAL.UTS.ARR     = Y.UTS.HDR
        Y.FINAL.UTS.ARR<-1> = R.UTS.ARR

        WRITE Y.FINAL.UTS.ARR TO F.AMEX.FILES,Y.UTS.FINAL.FILE
    END

RETURN
        
END
