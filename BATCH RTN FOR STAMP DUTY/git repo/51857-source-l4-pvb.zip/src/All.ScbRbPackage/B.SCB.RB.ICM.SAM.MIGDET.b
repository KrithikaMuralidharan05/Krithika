$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ICM.SAM.MIGDET(Y.SAM.ID)
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-22772 - JEWEL_T24_PROJECT
* Developed By                   :       Revathi G
* Developed On                   :       5thMay2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is a multi threaded Routine which extract details of SAM
* with LR.POS.MIG.DT EQ TODAY for ICM
*-----------------------------------------------------------------------------
* Modification History :
* 08-Aug-2023 CPSGMIG-32375 1670271 Rel ID Delimiters needs to be fixed for Joint Accounts
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.ICM.SAM.MIGDET.COMMON
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER

      GOSUB INIT
      IF Y.CUS.LOB MATCHES Y.ALLOWED.LOB THEN
          GOSUB SAM.PROCESS    ;*To get the details of sec acc master and exract field values
      END

RETURN
*****************
INIT:
*****************

      R.SAM = ''
      CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,Y.SAM.POS)
      IF R.SAM THEN
         CUS.NO = R.SAM<SC.SAM.CUSTOMER.NUMBER>
         R.CUS= ""; CUS.ERR= ""
         CALL F.READ(FN.CUSTOMER,CUS.NO,R.CUS,F.CUSTOMER,CUS.ERR)
         Y.CUS.LOB =R.CUS<EB.CUS.LOCAL.REF,Y.L.O.B>
      END


RETURN
*****************
SAM.PROCESS:
*****************
      Y.PFOLIO.KEY = R.SAM<SC.SAM.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
      PFOLIO.KEY.COUNT =DCOUNT(Y.PFOLIO.KEY,":")
      PFOLIO.KEY.PRIMARY =FIELD(Y.PFOLIO.KEY,":",1)
      PFOLIO.SECONDARY1 = FIELD(Y.PFOLIO.KEY,":",2)
      PFOLIO.SECONDARY2 = FIELD(Y.PFOLIO.KEY,":",3)
      PFOLIO.SECONDARY3 = FIELD(Y.PFOLIO.KEY,":",4)
      PFOLIO.SECONDARY4 = FIELD(Y.PFOLIO.KEY,":",5)
      MAIL.TYPE = R.SAM<SC.SAM.ADVICE.INDEX>
      START.DATE = R.SAM<SC.SAM.START.DATE>
      ISA.CONSOL.FLAG = 'Y'
      PRODUCT.CODE = 'T24'
      SYSTEM.NAME = 'T24'
      PRODUCT.NAME = 'Investment Account'
      GOSUB SAM.WRITE.PROCESS
			
RETURN			
**************************
SAM.WRITE.PROCESS:
*************************

       Y.SAM.ARRAY = Y.SAM.ID:',':CUS.NO:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:','
       Y.SAM.ARRAY := PFOLIO.SECONDARY4:',':MAIL.TYPE:',':ISA.CONSOL.FLAG:',':START.DATE:',':PRODUCT.CODE:',':SYSTEM.NAME:',':PRODUCT.NAME
       Y.ARRAY = Y.SAM.ARRAY
       GOSUB FILE.WRITE.PROCESS
RETURN
********************
FILE.WRITE.PROCESS:
********************
      OPENSEQ AMEX.FILES.PATH,Y.FILE.ID TO F.OUT.FILE ELSE
	  CREATE F.OUT.FILE
      END

      WRITESEQ Y.ARRAY APPEND TO F.OUT.FILE ELSE
            PRINT 'UNABLE TO WRITE'
      END
      CLOSESEQ F.OUT.FILE
RETURN
************************************************************
END