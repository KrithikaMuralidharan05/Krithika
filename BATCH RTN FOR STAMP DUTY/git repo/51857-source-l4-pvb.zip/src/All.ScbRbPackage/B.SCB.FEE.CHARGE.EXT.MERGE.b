$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FEE.CHARGE.EXT.MERGE
*---------------------------------------------------------------------------
* Modification History :- 
* 07-Mar-2022 - Lavanya L  - NEW - CPSGMIG-1885
* Description 	: The routine is used to merge the generated files to a single file to send to Springwatch.
*--------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SC.CHARGE.TAX.CALC.CREATE
	$INSERT I_F.FT.COMMISSION.TYPE
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_B.SCB.FEE.CHARGE.EXTRACT.COMMON
	$INSERT I_F.DATES
	
	FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
	
	Y.FINAL.FILE.NAME = 'T24-RBSG-Charges-Commission.':TODAY:'.txt'
	GOSUB GET.HEADER
	GOSUB REMOVE.DUP.LINE
	GOSUB WRITE.DETS
		
	RETURN
*-------------------------------------------------------------------------------
GET.HEADER:
*----------
	Y.HEADER<-1> = 'Activity':'|':'Charge Tax Type':'|':'Stock Exchange':'|':'Sec Type':'|':'Sec Domicile':'|':'Txn Type':'|':'Cust Group':'|'
	Y.HEADER := 'Base Amount':'|':'Chg Comm Code':'|':'Tax Code':'|':'Till Date':'|':'Source':'|':'Last Upd Date':'|':'Charge Type':'|'
	Y.HEADER := 'Charge Description':'|':'Calculation Basis':'|':'Currency':'|':'Percentage':'|':'Sequence':'|':'Upto Amt':'|':'Comm Upd Date'

	RETURN
*-------------------------------------------------------------------------------------------
REMOVE.DUP.LINE:
*-----------------	
	ARG1 = 'AMEX.FILES'
    ARG2 = ''
    AMEX.FILES.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME(ARG1,ARG2,AMEX.FILES.PATH)

    FILE.PATH.ORG = AMEX.FILES.PATH
    CALL SCB.REMOVE.DUPLICATE.LINE(FILE.PATH.ORG,Y.FINAL.FILE.NAME)
RETURN
*---------------------------------------------------------------------------------
WRITE.DETS:
*------------

* Select all the files with file name like T24.TAX.CALC...
* and consolidate into a single file.
* Footer of the file contains total record count, time stamp, and next working date

    Y.UDFILE    = 'AMEX.FILES'
    Y.CRITERIA  = 'T24.TAX.CALC*'
    SEL.FILE.ID = ''
    NO.OF.IDS   = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, SEL.FILE.ID, NO.OF.IDSD)

    IF SEL.FILE.ID THEN
        Y.FILE.ARRAY = Y.HEADER
        Y.DEL.FILE.ID = SEL.FILE.ID
        LOOP
            REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
        WHILE Y.FILE.ID:POS
            CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.AMEX.FILES,F.APPEND.FILES,APP.ERR)
            ! Checking whether the file contains any record
            IF R.AMEX.FILES NE '' THEN
                Y.FILE.ARRAY := @FM:R.AMEX.FILES
* Count the number of records in the file to get the total count of CUSTOMER
                LINE.COUNT = 0
                LINE.COUNT = DCOUNT(R.AMEX.FILES, @FM)
                TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
            END
* Delete the file after forming the array
            CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
            LINE.COUNT = ''
        REPEAT
    END
    WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME
    CALL F.READ(FN.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FILE.ARRAY,F.APPEND.FILES,READ.ERR1)
    TOTAL.LINE.COUNT = DCOUNT(Y.FILE.ARRAY,@FM)-1

   Y.STAMP = OCONV(TIME(),"MTS")
*
* Footer should be in the following format
* EOF,2012-03-09 00:32,3086,2012-03-12
*
    Y.FILE.ARRAY := @FM:'EOF':'|':TODAY[1,4]:'-':TODAY[5,2]:'-':TODAY[7,2]:' ':Y.STAMP[1,5]:'|':TOTAL.LINE.COUNT
    Y.FILE.ARRAY := '|':R.DATES(EB.DAT.NEXT.WORKING.DAY)[1,4]:'-':R.DATES(EB.DAT.NEXT.WORKING.DAY)[5,2]:'-':R.DATES(EB.DAT.NEXT.WORKING.DAY)[7,2]
*
* Finally write the single file to the AMEX.FILES path
*    
	WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME

	RETURN

END

	