* @ValidationCode : MjotMTQ3MDM0MDA2MjpJU08tODg1OS0xOjE2ODI0MTY1ODY0NzY6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 25 Apr 2023 15:26:26
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.MTM.BOOKBUILD.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14087 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       16 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract Unsettled Trades
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 29-Mar-23     1663000          CPSGMIG-21519 - Pull Unsettled trades with ValueDate GT Today
* 03-Mar-2023   1663000          CPSGMIG-14087 - Selection Changed to SEC.TRADE
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename Change
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.MTM.BOOKBUILD.COMMON
    $INSERT I_F.DATES             ;*CPSGMIG-21498
*--------------------------------------------------------------------------------------------

    GOSUB DO.PROCESS

RETURN
*---------*
DO.PROCESS:
*---------*

    Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY) ;*CPSGMIG-21498
    SEL.CMD = "SELECT ":FN.SEC.TRADE:" WITH VALUE.DATE GT ":Y.LWD ;*CPSGMIG-21498
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
    CALL BATCH.BUILD.LIST('',SEL.LIST)

RETURN
END
