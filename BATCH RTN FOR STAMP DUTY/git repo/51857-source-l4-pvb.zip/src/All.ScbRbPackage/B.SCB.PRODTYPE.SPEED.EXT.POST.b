$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.PRODTYPE.SPEED.EXT.POST
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 27/04/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> eSpeed
*						RBSG_ESPEED_PRODTYPE_YYYYMMDD.txt 
* 29/07/2022 - kalaikumaran P - Header, Footer Format Change and File name Change to T24_SG_PRODTYPE_YYYYMMDDHHMMSS.txt
*
* 04/08/2022 - Kalaikumaran P - Footer No Of Records not Populated.
*
* 12/08/2022 - kalaikumaran P - CPSGMIG-3138 - Calculation of Hash256 Checksum value of Body portion of the Interface file.
* 26-Apr-2023 - 1657186 - CPSGMIG-23326 - File date changed to last calendar date.
* 25-Oct-2023 - 1664794 - AWMQPR-6021   - Hard Code to Soft Code of Flow Identifier.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.ASSET.TYPE
	$INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_B.SCB.PRODTYPE.SPEED.EXT.COMMON
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
*
    GOSUB INIT
    GOSUB PROCESS
    GOSUB FILE.TRANSFER
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH = ''
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
* Header, Footer Timestamp format YYYYMMDDHHMMSS
 	Y.TIMEDATE.STP = TIMEDATE()
* CPSGMIG-23326-S    
    L.WORK.DATE=OCONV(DATE(),'D-') ;*MM-DD-YYYY
    L.WORK.DATE= L.WORK.DATE[7,4]:L.WORK.DATE[1,2]:L.WORK.DATE[4,2]
    CALL CDT("",L.WORK.DATE,"-1C")
* CPSGMIG-23326-E    
    Y.TIMESTAMP = L.WORK.DATE:Y.TIMEDATE.STP[1,2]:Y.TIMEDATE.STP[4,2]:Y.TIMEDATE.STP[7,2]

    Y.FINAL.FILE.NAME = '' ; R.PRODTYPE.RPT.FINAL.ARR = ''
    Y.FINAL.FILE.NAME = 'T24_SG_PRODTYPE_':Y.TIMESTAMP:'.txt'
*
	FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.SCB.WM.H.LOCAL.PARAM = ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
	
	Y.PARAM.ID = 'SCB.RBSPEED.FLOW.ID' ; R.PARAM.REC = '' 		; Y.PARAM.ERR = ''
	Y.PARAM.FLDNAME = ''		       ; Y.PARAM.FLDVAL = ''
	
	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.PARAM.ID,R.PARAM.REC,F.SCB.WM.H.LOCAL.PARAM,Y.PARAM.ERR)
    Y.PARAM.FLDNAME = R.PARAM.REC<SCBWM.PRM.FIELD.NAME>
	Y.PARAM.FLDVAL = R.PARAM.REC<SCBWM.PRM.FIELD.VALUE>
	CONVERT @SM TO @VM IN Y.PARAM.FLDVAL
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = ID.COMPANY[1,2]:'*-PRODUCT-TYPE-*':TODAY:'.csv-*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.PRODTYPE.RPT.FINAL.ARR EQ '' THEN
                R.PRODTYPE.RPT.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.PRODTYPE.RPT.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
    END
*
*
*---Call Java API to get Hash256 Sum value ----*
    Y.INPUT.PARAM = R.PRODTYPE.RPT.FINAL.ARR
    CHANGE @FM TO "" IN Y.INPUT.PARAM

    class_name = "com.hash.main.Sha256Utility"
    method_name = "sumValue"
    param = Y.INPUT.PARAM

    CALLJ class_name, method_name, param SETTING ret
 
 

    Y.HASH256SUM.VALUE = ret

*---Call Java API to get Hash256 Sum value ----*
*
* * Header TimeStamp to be YYYYMMDDHHMMSS and Footer should contain no of Records.
	NO.OF.RECORDS = DCOUNT(R.PRODTYPE.RPT.FINAL.ARR,@FM)
	Y.SAT.HEADER = 'H|':Y.TIMESTAMP
	Y.SAT.FOOTER = 'T|':NO.OF.RECORDS:'|':Y.HASH256SUM.VALUE:'|':Y.TIMESTAMP
	R.PRODTYPE.RPT.FINAL = Y.SAT.HEADER:@FM:R.PRODTYPE.RPT.FINAL.ARR:@FM:Y.SAT.FOOTER
*
    WRITE R.PRODTYPE.RPT.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
*
RETURN
*-----------------------------------------------------------------------------
*-------------
FILE.TRANSFER:
*-------------
*
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''
*    
    FLOW.IDENTIFER.ID = Y.PARAM.FLDVAL<1,1>
*    
    FILE.NAME = AMEXPATH
    RECORD.NAME = Y.FINAL.FILE.NAME
    TARGET.FILE.NAME = Y.FINAL.FILE.NAME
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'')

RETURN
*----------------------------------------------------------------------------------
END
