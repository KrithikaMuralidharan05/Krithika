$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>3</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.R2W.GROUP.AUM.POST
*-----------------------------------------------------------------------------
* Modification History:
*----------------------
* 10-Oct-2022 - CPSGMIG-5314  - Sasi V - R2W report: AUM for Group for RBSG
* 08-Dec-2022 - MONTHCHECK    - Sasi V - File should be generated only during month end
* 02-Jan-2026 - ADO-11478676 - Prithi Koppolu - Enhanced to include additional column and capture
*                                               the details in 2 separate rows based on PLEDGED and UNPLEDGED positions.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* MONTHCHECK - S/E
    $INSERT I_B.SCB.RB.R2W.GROUP.AUM.COMMON

    GOSUB INITIALISE
    GOSUB PROCESS
	 
RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*---------
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
	DL = ','
    Y.FINAL.FILE.NAME = ''
    R.ASSETPRICE.RPT.FINAL.ARR = ''
	Y.FINAL.FILE.NAME = ID.COMPANY[1,2]:"-RB-R2W-GROUP-AUM-":TODAY:".csv"
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    Y.UDFILE	= 'AMEX.FILES'
	SEL.CMD     = ID.COMPANY[1,2]:"*-RB-GROUP-AUM-DATA*":TODAY:"-*.CSV*"
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
* MONTHCHECK - S
	EOM.FLAG = ''
	Y.LAST.WORKING.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
	
*IF TODAY[5,2] NE Y.LAST.WORKING.DAY[5,2] THEN ; *Commented for UAT testing
    EOM.FLAG = '1'
*END
	
*   IF SEL.LIST THEN
	IF EOM.FLAG THEN
* MONTHCHECK - E
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.GROUP.AUM.FINAL.ARR EQ '' THEN
                R.GROUP.AUM.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.GROUP.AUM.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
*
		Y.GROUP.AUM.HEADER = 'Vestima':DL:'Ctry of Sale':DL:'Security Code':DL:'Fund Status':DL:'Fund Name':DL:'ISIN Code':DL
		Y.GROUP.AUM.HEADER := 'Fund House':DL:'Currency of Fund':DL:'SCB AUM':DL:'NAV':DL:'NAV Date':DL:'Product Category':DL
		Y.GROUP.AUM.HEADER := 'Maturity Date':DL:'Issue Date':DL:'Coupons Paid %':DL:'Security Type':DL:'Protection':DL:'Islamic Flag':DL:'Pledge' ; *ADO-11478676-(s/e)
*
		R.GROUP.AUM.FINAL.ARR = Y.GROUP.AUM.HEADER:@FM:R.GROUP.AUM.FINAL.ARR
		WRITE R.GROUP.AUM.FINAL.ARR TO F.AMEX.FILES,Y.FINAL.FILE.NAME
*
    END
*-----------------------------------------------------------------------------
END