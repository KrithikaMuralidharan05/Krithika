$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.HOLDING.SPEED.EXT.SELECT
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 09/05/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> eSpeed
*						RBSG_ESPEED_HOLDING_YYYYMMDD.txt
*
* 25/07/2022 - kalaikumaran P - CPSGMIG-3138 - eSpeed RBSG_ESPEED_HOLDING_YYYYMMDD.txt
*
* 28/07/2022 - Kalaikumaran p - CPSGMIG-4090- PVB/RB Customer Demarkation - Changes done for Skipping the SG retail customers
* 03/01/2022 - kalaikumaran p - CPSGMIG-17776 - Selected all Security Position records.
* 17-May-2023 - GLSPD-5231 - 1657816 - Duplicate records identified in the holding file.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.AEB.SEC.PAR
    $INSERT I_B.SCB.HOLDING.SPEED.EXT.COMMON
*
	GOSUB SEL.PROCESS
*
RETURN
*-----------------------------------------------------------------------------
SEL.PROCESS:
*-----------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SEC.ACC.MASTER:" WITH L.O.B EQ ":Y.ALLOWED.LOB
*
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
END
