$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.UTS.HIST.EBBS.RELID.SELECT
*-----------------------------------------------------------------------------
*
* Modification History :
*------------------------------------------------------------------------------------
* Multithread routine to load the EBBS.REL historical table post checking if the REL.ID exists or not.
* 17/01/2023 - Drafted by - Raja Prabhu S
*JIRA REF - CPSGMIG-17731
*----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.UTS.HIST.EBBS.RELID.COMMON
    
    
    GOSUB READ.FILE
    
RETURN
*--------------
READ.FILE:
*-----------------
 
    READ R.DETS.ARR1 FROM Y.SRC.FILEPATH, Y.SRC.FILE.NAME THEN
        
        CALL BATCH.BUILD.LIST("", R.DETS.ARR1)
    END
RETURN

*----------------------------------------------------------
END