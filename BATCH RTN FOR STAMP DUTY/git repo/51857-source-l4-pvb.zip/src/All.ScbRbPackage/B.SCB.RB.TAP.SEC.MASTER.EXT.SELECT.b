$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.SEC.MASTER.EXT.SELECT
*** ----------------------------------------------------------------------------------------
*
* This SELECT routine is done as part of the multiple elimination project for Security Master extract
* Select all the records from security master as delta file(file generated at each hour) 
* and send the data to TAP team 
* ----------------------------------------------------------------------------------------
*
* Modification History :
*
* 05/07/2022 - Lavanya L - CPSGMIG-4001 - Copy of the existing routine B.SCB.RB.SEC.MASTER.EXTRACT.SELECT
* -----------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.RB.TAP.SEC.MAS.EXT.COMMON
*

    SEL.CMD = 'SELECT ':FN.SCB.SECMAS.DAILY

    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END

*
RETURN
* ----------------------------------------------------------------------------------------
END
