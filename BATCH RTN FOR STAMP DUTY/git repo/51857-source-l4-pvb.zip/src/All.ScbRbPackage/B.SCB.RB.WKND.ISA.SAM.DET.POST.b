$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.WKND.ISA.SAM.DET.POST

* Routine to extract the SAM and its equivalent UTS and ISA Account details that were loaded
*Created by :- 1657186
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
**
* 05-June-2025 - CATALYST 8020007 - 1404392 - T24 -> SG CSE File Transfer file is sent to eStatement
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    
    AMEX.FILES.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME('AMEX.FILES', '', AMEX.FILES.PATH)
    
    L.WORK.DATE=OCONV(DATE(),'D-') ;*MM-DD-YYYY
    L.WORK.DATE= L.WORK.DATE[7,4]:L.WORK.DATE[1,2]:L.WORK.DATE[4,2]
    CALL CDT("",L.WORK.DATE,"-1C")
    ETEXT = ""
    Y.FINAL.ID = 'SAM.ISA.FILE-':L.WORK.DATE:'.csv'

	Y.UDFILE       = 'AMEX.FILES'
	Y.ST.CRITERIA  = 'SG.SAM.ISA.FILE.':TODAY:'-*'
	Y.FILE.ARRAY = ''
	Y.FILE.ARRAY = "Portfolio ID":",":"Customer ID":",":"ISA":",":"Rel ID(primary)":",":"Rel ID Secondary1":",":"Rel ID Secondary2":",":"Rel ID Secondary3":",":"Rel ID Secondary4":",":"Segment Code":",":"ISA Status"

    SEL.FILE.ID    = ''
    Y.ST.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.CRITERIA, SEL.FILE.ID, Y.ST.CNT)

    Y.DEL.FILE.ID = SEL.FILE.ID
    LOOP
        REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
    WHILE Y.FILE.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.SAM.REC,F.APPEND.FILES,APP.ERR)
        IF R.SAM.REC NE  '' THEN
            Y.FILE.ARRAY<-1> = R.SAM.REC
            LINE.COUNT = DCOUNT(R.SAM.REC, @FM)
            TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
        LINE.COUNT = ''
    REPEAT

	WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID
	
	*
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''
*    
    FLOW.IDENTIFER.ID = 'T24-RBSGDPL-SG'
*    
    FILE.NAME = AMEX.FILES.PATH
    RECORD.NAME = Y.FINAL.ID
    TARGET.FILE.NAME = 'SAM.ISA.FILE_':L.WORK.DATE:'.csv'
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'') 
*
    FLOW.IDENTIFER.ID = 'T24-ISASG-SG'
*    
    FILE.NAME = AMEX.FILES.PATH
    RECORD.NAME = Y.FINAL.ID
    TARGET.FILE.NAME = 'SAM.ISA.FILE.CSE_':L.WORK.DATE:'.csv'
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'') 
*
RETURN
*****************
END