$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.SPA.BLD.DAY.LOAD
*
*--------------------------------------------------------------------------------------------------*
* Description:
*----------------------------------------------------------------------------------------
* Multi thread load routine for the 2nd part of SCB.RB.SEC.POS.ACTIVITY which builds the day wise
* updates into SCB.RB.SEC.POS.ACTIVITY table
*-------------------------------------------------------------------------------------------------------------
* Modification History:
*-------------------------------------------------------------------------------------------------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- Daily job to update the day wise nominal in SCB.RB.SEC.POS.ACTIVITY.
* 09-Jun-2023 - CPSGMIG-29137 - 1657186 - To update Last working Day.
*-------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_SCB.RB.SPA.BLD.DAY.COMMON
*
    F.SCB.RB.SEC.POS.ACTIVITY = ""
    YF.SCB.RB.SEC.POS.ACTIVITY = "F.SCB.RB.SEC.POS.ACTIVITY"
    CALL OPF(YF.SCB.RB.SEC.POS.ACTIVITY,F.SCB.RB.SEC.POS.ACTIVITY)
*
    YF.SEC.ACC.MASTER = "F.SEC.ACC.MASTER"
    F.SEC.ACC.MASTER = ""
    CALL OPF(YF.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
    YF.LOCKING = "F.LOCKING"
    FP.LOCKING = ''
    CALL OPF(YF.LOCKING,FP.LOCKING)
*
    YTODAY = TODAY
    BASE.CCY = LCCY
* CPSGMIG-29137	
    Y.LWORK.DAY = OCONV(DATE(),'D-') ;*MM-DD-YYYY
    Y.LWORK.DAY = Y.LWORK.DAY[7,4]:Y.LWORK.DAY[1,2]:Y.LWORK.DAY[4,2]
    CALL CDT("",Y.LWORK.DAY,"-1C")
    
    YLASTWRKDAY = Y.LWORK.DAY
* CPSGMIG-29137
RETURN
END
