$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgEbbsW8W9Process
*
* Y.IDS(INOUT) :
*EBBS.W8.W9.PROCESS
SUBROUTINE B.SCB.RSG.EBBS.W8.W9.PROCESS(Y.IDS)
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RSG.EBBS.W8.W9.PROCESS.COMMON
    $INSERT I_F.CUSTOMER

    GOSUB INIT
    GOSUB FORM.DMD
RETURN
*******************
INIT:
***************
    Y.LEN = LEN(Y.IDS)
    REL.ID =TRIM(Y.IDS[1,20],"",'A')
    W8.W9.FLAG =Y.IDS[21,3]
    DOCT.TYPE.DET = Y.IDS[25,35]
    EXP.DATE = TRIM(Y.IDS[59,8],"",'A')
    SIGNATORY.DATE = Y.IDS[67,8]
    IF EXP.DATE THEN
        EXP.DATE = EXP.DATE[5,4]:EXP.DATE[3,2]:EXP.DATE[1,2]
    END
 
RETURN
******************
FORM.DMD:
*******************

    CALL F.READ(FN.EBBS.CONCAT,REL.ID,R.EBBS.CONCAT,F.EBBS.CONCAT,EBBS.ERR)
    IF R.EBBS.CONCAT THEN
        IF W8.W9.FLAG EQ "W8B" OR W8.W9.FLAG EQ "W8C" OR W8.W9.FLAG EQ "W8N" OR W8.W9.FLAG EQ "W8X" OR W8.W9.FLAG EQ "W9N" THEN
            Y.VM.CUS.ID = R.EBBS.CONCAT<1>
            Y.CUS.TYPE = R.EBBS.CONCAT<3>

            CUS.CNT = DCOUNT(Y.VM.CUS.ID,@VM)
            C.CNT =1
            LOOP
            WHILE C.CNT LE CUS.CNT
                Y.CUS.ID = Y.VM.CUS.ID<1,C.CNT>
                CALL F.READ(FN.CUS,Y.CUS.ID,R.CUS,F.CUS,CUS.ERR)
                CUS.STATUS = R.CUS<EB.CUS.CUSTOMER.STATUS>
                IF CUS.STATUS EQ "82" THEN
                    Y.EXCP.ARR = REL.ID:"|":Y.CUS.ID:"|Customer is closed"
                    GOSUB EXCP.WRITE
                END ELSE
                    IF Y.CUS.TYPE<1,C.CNT> EQ 'RSG.BB' THEN
                        BEGIN CASE
                            CASE (W8.W9.FLAG EQ "W8B" OR W8.W9.FLAG EQ "W8C" OR W8.W9.FLAG EQ "W8N" OR W8.W9.FLAG EQ "W8X")
                                IF EXP.DATE GT TODAY OR EXP.DATE EQ "" THEN
                                    W8.FLAG ="Y"
                                    W8.EXP.DATE = EXP.DATE
                                    Y.FORM.ARR = Y.CUS.ID:"|":W8.FLAG:"|":W8.EXP.DATE:"|":"|":"|"
                                    GOSUB FILE.WRITE
                                END
                                ELSE
                                    W8.FLAG ="N"
                                    W8.EXP.DATE = EXP.DATE
                                    Y.FORM.ARR = Y.CUS.ID:"|":W8.FLAG:"|":W8.EXP.DATE:"|":"|":"|"
                                    GOSUB FILE.WRITE

*   Y.EXCP.ARR = REL.ID:"|":Y.CUS.ID:"|":W8.W9.FLAG:"|":EXP.DATE:"|Expiry date is not greater then Todays date the criteria for customer W8 flag update"
*  GOSUB EXCP.WRITE
                                END
                            CASE W8.W9.FLAG EQ "W9N"
                                IF EXP.DATE GT TODAY OR EXP.DATE EQ "" THEN
                                    W9.FLAG ="Y"
                                    W9.EXP.DATE =EXP.DATE
                                    Y.FORM.ARR = Y.CUS.ID:"|":"|":"|":W9.FLAG:"|":W9.EXP.DATE:"|"
                                    GOSUB FILE.WRITE
                                END ELSE
                                    W9.FLAG ="N"
                                    W9.EXP.DATE =EXP.DATE
                                    Y.FORM.ARR = Y.CUS.ID:"|":"|":"|":W9.FLAG:"|":W9.EXP.DATE:"|"
                                    GOSUB FILE.WRITE
                                END
                            CASE 1
                    
                                Y.EXCP.ARR = REL.ID:"|":Y.CUS.ID:"|":W8.W9.FLAG:"|Flag not matches the criteria for customer W8-w9 flag update"
                                GOSUB EXCP.WRITE
                        END CASE
                    END
                END ;*end for else
                C.CNT+=1
            REPEAT

        END ELSE
            Y.EXCP.ARR = REL.ID:"|":Y.CUS.ID:"|Not matched with mapping definition as flag type |":W8.W9.FLAG
            GOSUB EXCP.WRITE
        END
    END
* 
       
RETURN
**************
FILE.WRITE:
*
    WRITESEQ Y.FORM.ARR APPEND TO Y.SL.FILEPATH ELSE
        CALL OCOMO("UNABLE TO WRITE DMD LOAD FILE for w8_w9 flag")
    END
RETURN
*****************
EXCP.WRITE:
*************
    WRITESEQ Y.EXCP.ARR APPEND TO Y.EXCP.FILEPATH ELSE
        CALL OCOMO("UNABLE TO WRITE Exception FILE for w8_w9 flag")
    END
RETURN
************
END
