* @ValidationCode : Mjo1MzEyMTE1MTpJU08tODg1OS0xOjE2OTM5MDEyMTkyNTA6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 05 Sep 2023 13:36:59
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CONF.NOTICE.TXNS.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-34072
* Developed By                   :       1663000
* Developed On                   :       5-Sep-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .LOAD Routine to fetch transactions for which Contract notes are generated
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description

*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.DE.HEADER
    $INSERT I_F.DIARY
    $INSERT I_F.DIARY.TYPE
    $INSERT I_F.SCB.DP.XML.ADV.STATUS
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_B.SCB.RB.CONF.NOTICE.TXNS.COMMON
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB OPEN.FILES

RETURN
*---------*
INITIALISE:
*---------*

* Get LOB Value by Segment
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)

    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE = "SCBGETCONFNOTICETXNS-":TODAY:"-":SESSION.NO:".csv"
   
    Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)
RETURN
*---------*
OPEN.FILES:
*---------*
      
    FN.DIARY                 = 'F.DIARY'                 ; F.DIARY                  = '' ; CALL OPF(FN.DIARY,F.DIARY)
    FN.DIARY.HIS             = 'F.DIARY$HIS'             ; F.DIARY.HIS              = '' ; CALL OPF(FN.DIARY.HIS,F.DIARY.HIS)
    FN.DIARY.TYPE            = 'F.DIARY.TYPE'            ; F.DIARY.TYPE             = '' ; CALL OPF(FN.DIARY.TYPE,F.DIARY.TYPE)
    FN.CONCAT.DIARY          = 'F.CONCAT.DIARY'          ; F.CONCAT.DIARY           = '' ; CALL OPF(FN.CONCAT.DIARY,F.CONCAT.DIARY)
    FN.SCB.DP.XML.ADV.STATUS = 'F.SCB.DP.XML.ADV.STATUS' ; F.SCB.DP.XML.ADV.STATUS  = '' ; CALL OPF(FN.SCB.DP.XML.ADV.STATUS,F.SCB.DP.XML.ADV.STATUS)
    FN.SEC.TRADE             = 'F.SEC.TRADE'             ; F.SEC.TRADE              = '' ; CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    FN.SEC.TRADE.HIS         = 'F.SEC.TRADE$HIS'         ; F.SEC.TRADE.HIS          = '' ; CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)
    FN.SECURITY.TRANSFER     = 'F.SECURITY.TRANSFER'     ; F.SECURITY.TRANSFER      = '' ; CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
    FN.SECURITY.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS' ; F.SECURITY.TRANSFER.HIS  = '' ; CALL OPF(FN.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS)
    FN.SEC.OPEN.ORDER        = 'F.SEC.OPEN.ORDER'        ; F.SEC.OPEN.ORDER         = '' ; CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    FN.SEC.OPEN.ORDER.HIS    = 'F.SEC.OPEN.ORDER$HIS'    ; F.SEC.OPEN.ORDER.HIS     = '' ; CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
    FN.CUSTOMER              = 'F.CUSTOMER'              ; F.CUSTOMER               = '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SC.TRANS.NAME         = 'F.SC.TRANS.NAME'         ; F.SC.TRANS.NAME          = '' ; CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
    FN.DE.O.HEADER           = 'F.DE.O.HEADER'           ; F.DE.O.HEADER            = '' ; CALL OPF(FN.DE.O.HEADER, F.DE.O.HEADER)
    FN.SCB.WM.H.LOCAL.PARAM  = 'F.SCB.WM.H.LOCAL.PARAM'  ; F.SCB.WM.H.LOCAL.PARAM   = '' ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
    FN.SECURITY.MASTER       = 'F.SECURITY.MASTER'       ; F.SECURITY.MASTER        = '' ; CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SEC.ACC.MASTER        = 'F.SEC.ACC.MASTER'        ; F.SEC.ACC.MASTER         = '' ; CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER) ;* CPSGMIG-19402

RETURN
END