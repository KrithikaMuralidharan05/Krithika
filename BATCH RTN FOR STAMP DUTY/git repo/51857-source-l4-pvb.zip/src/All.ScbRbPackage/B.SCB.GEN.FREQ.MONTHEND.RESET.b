SUBROUTINE B.SCB.GEN.FREQ.MONTHEND.RESET
*-----------------------------------------------------------------------------
*DESCRIPTION:
*------------
* This is a single-threaded batch routine which reset the NEXT.RUN.DATE based
* on frequency and BATCH provided in the DATA field. DATA field format(BATCHNAME*FREQUENCY)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date          Who        Reference                             Description
* 07-Jun-2023   1670271    CPSGMIG-29143                         Initial version
* 04-July-2023  1670271    CPSGMIG-29143                         Frequency not changed for Job name which is having both D and M01 as frequency.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.BATCH
    $INSERT I_BATCH.FILES
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB PROCESS

RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*----------

    COMI.SAVE = COMI
    RUN.DATE.NOW =  TODAY

    Y.NEXT.RUN.DATE = ''
    Y.REGION = ''
    FREQ.FLG = 0
	Y.BATCH.NAME = ''
	Y.DATA.FREQUENCY = ''
	Y.FREQUENCY.VALUE = ''
	VALUE.NEED = ''
    SEL.POS = ''
	JOB.CNT = ''
	
	FN.BATCH = F.BATCH
    F.BATCH = ''
    CALL OPF(FN.BATCH,F.BATCH)
	
	VALUE.NEED = BATCH.DETAILS<3,1>
	CONVERT @SM TO @FM IN VALUE.NEED
		
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    LOOP                                                   ;* When multiple BATCH records mentioned in DATA.FIELD
        REMOVE VAL.ID FROM VALUE.NEED SETTING SEL.POS
    WHILE VAL.ID:SEL.POS
    
        Y.BATCH.NAME    = FIELD(VAL.ID,'*', 1)  ;* Contains the Batch Name given in data field of Batch.
        Y.DATA.FREQUENCY = FIELD(VAL.ID,'*', 2) ;* Contain the value as Daily or Monthly
        Y.FREQUENCY.VALUE = FIELD(VAL.ID,'*', 2)[2,3]
	
        COMI = ''
        COMI = RUN.DATE.NOW
        CALL LAST.DAY.OF.THIS.MONTH         ;* Routine returns last date of the Month in COMI
        Y.NEXT.RUN.DATE = COMI
        Y.REGION = R.COMPANY(EB.COM.BRANCH.HOLIDAY)
        CALL CDT(Y.REGION,Y.NEXT.RUN.DATE,"+":Y.FREQUENCY.VALUE:"W")      ;*Returns the nth Working day after crossing month end.
        COMI = COMI.SAVE
	
        ERR.BAT = ''
        R.BATCH = ''
        CALL F.READ(FN.BATCH,Y.BATCH.NAME,R.BATCH,F.BATCH,ERR.BAT)
        IF R.BATCH THEN
            JOB.CNT = DCOUNT(R.BATCH<BAT.JOB.NAME>,VM)
            M01.CNT = 1
            LOOP
            WHILE M01.CNT LE JOB.CNT
                Y.FREQ = R.BATCH<BAT.FREQUENCY,M01.CNT>
                IF Y.FREQ EQ Y.DATA.FREQUENCY THEN
                    R.BATCH<BAT.NEXT.RUN.DATE,M01.CNT> = Y.NEXT.RUN.DATE
                    FREQ.FLG = 1
                END
				IF FREQ.FLG THEN
                    CALL F.WRITE(FN.BATCH,Y.BATCH.NAME,R.BATCH)
                END
                M01.CNT = M01.CNT + 1
            REPEAT
        END
    REPEAT

RETURN
*-----------------------------------------------------------------------------
END