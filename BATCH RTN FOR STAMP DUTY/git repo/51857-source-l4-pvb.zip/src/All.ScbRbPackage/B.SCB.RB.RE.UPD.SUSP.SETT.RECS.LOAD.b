$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.RE.UPD.SUSP.SETT.RECS.LOAD
*-----------------------------------------------------------------------------
* Description:
*-----------------------------------------------------------------------------
* Routine Type                 Batch Pre process routine
* Attached To                  BATCH>SNG/SCB.RB.IN.SUSP.SETT.RES.EBBS
* Workflow                     To create record in SCB.CASH.BLK.SETT for
*                              Commission entries.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*  Bharathiraja P    23-Aug-2022         CPSGMIG-387            Automation of accounting entries for commission in EBBS
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.RE.UPD.SUSP.SETT.RECS.COMMON
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.SCB.CASH.BLK.SETT
    $INSERT I_F.SEC.TRADE

    GOSUB PROCESS

RETURN
*-----------------------------------------------------------------------------
*** <region name= Process>
PROCESS:
*** <desc>Process </desc>

    FN.APP = "F.SCB.CASH.BLK.SETT"
    F.APP = ""
    CALL OPF(FN.APP, F.APP)

    FN.SEC.TRADE.SUSP = 'F.SEC.TRADE'
    F.SEC.TRADE.SUSP = ''
    CALL OPF(FN.SEC.TRADE.SUSP, F.SEC.TRADE.SUSP)

    FN.SEC.TRADE.SUSP.HIS = 'F.SEC.TRADE$HIS'
    F.SEC.TRADE.SUSP.HIS = ''
    CALL OPF(FN.SEC.TRADE.SUSP.HIS, F.SEC.TRADE.SUSP.HIS)

    FN.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.LOCAL.PARAM = ''
    CALL OPF(FN.LOCAL.PARAM, F.LOCAL.PARAM)

    Y.LOCAL.REC.ID = "EBBS.ONLINE.SUSP.ACCT"
    R.LOCAL.REC = ''; R.LOCAL.REC.ERR = ''
    CALL F.READ(FN.LOCAL.PARAM,Y.LOCAL.REC.ID,R.LOCAL.REC,F.LOCAL.PARAM,R.LOCAL.REC.ERR)
    IF NOT(R.LOCAL.REC.ERR) THEN      
        Y.EBBS.SUSP.ACCT = R.LOCAL.REC<SCBWM.PRM.FIELD.VALUE>     
    END
    
RETURN
*--------------------------------------------------------------------------------------
END
