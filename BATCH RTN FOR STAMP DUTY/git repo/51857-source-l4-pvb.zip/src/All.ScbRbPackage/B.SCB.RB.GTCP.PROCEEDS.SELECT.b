$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.PROCEEDS.SELECT
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-PROCEEDS-<start.date>-<end.date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.GTCP.PROCEEDS.COMMON

	IF Y.START.DATE AND Y.END.DATE THEN
		GOSUB PROCESS
	END

RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    IF NOT(CONTROL.LIST) THEN
        CONTROL.LIST = "SEC.TRADE.EXT":@FM:"SECURITY.TRANSFER.EXT":@FM:"POSITION.TRANSFER.EXT"
    END

    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "SEC.TRADE.EXT"
            SEL.CMD = "SELECT ":FN.SEC.TRADE:" WITH L.O.B EQ ":Y.ALLOWED.LOB
            CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
            CALL BATCH.BUILD.LIST('',SEL.LIST)

        CASE CONTROL.LIST<1,1> = "SECURITY.TRANSFER.EXT"
            SEL.CMD = "SELECT ":FN.SECURITY.TRANSFER:" WITH L.O.B EQ ":Y.ALLOWED.LOB
            CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
            CALL BATCH.BUILD.LIST('',SEL.LIST)

        CASE CONTROL.LIST<1,1> = "POSITION.TRANSFER.EXT"
            SEL.CMD = "SELECT ":FN.POSITION.TRANSFER:" WITH L.O.B EQ ":Y.ALLOWED.LOB
            CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
            CALL BATCH.BUILD.LIST('',SEL.LIST)
	END CASE
*
RETURN
*-----------------------------------------------------------------------------
END
