$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ASSETLIAB.SAM.VAL.LOAD
* -------------------------------------------------------------------------------------
* Multithread routine for the file generation of SG-RB-ASSET-LIAB-<date>.csv to EDMP
*
**---------------------------------------------------------------------------------------------------------------------------------------------------
*
* Modification History : 
*
* 31/10/2022 - Lavanya L - CPSGMIG-291 - DAY 0 file generation
*--------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_BATCH.FILES
	$INSERT I_B.SCB.RB.ASSETLIAB.SAM.VAL.COMMON
	
	FN.SAM = 'F.SEC.ACC.MASTER'
	F.SAM = ''
	CALL OPF(FN.SAM,F.SAM)
	
	RETURN
	END