$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SAM.PF.FEE.OFS.UPD(Y.SAM.ID)
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-16591
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.SAM.PF.ZERO.UPD
* Workflow                     This routine will select the SEC.ACC.MASTER table and look for the L.O.B
*                              value of that particular customer. If the customer is retail category then
*                              update PORTFOLIO.FEES field value to 'NONE' through OFS.
*
**************************
* EXTRA CARE MUST BE TAKEN
**************************
* This service has to be run only when it is really required as it will affect the majority of the 
* SEC.ACC.MASTER records.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        25/Nov/2022     CPSGMIG-16591        Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_BATCH.FILES
	$INSERT I_F.CUSTOMER
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_B.SCB.RB.SAM.PF.FEE.OFS.UPD.COMMON

	GOSUB INIT
	GOSUB PROCESS
	GOSUB WRITE.DATA
	
	RETURN
*--------------------------------------------------------------------------------------------------------
INIT:
*****
	
	Y.CUS.ID = '' 		; R.CUS = ''  ; CUS.READ.ERR = ''		
	SAM.READ.ERR = '' 	; R.SAM = ''  ; Y.CO.CODE = ''
	Y.ARRAY = ''		; Y.ARR.INFO = ''
		
	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********

	Y.CUS.ID = FIELD(Y.SAM.ID,'-',1)	
	CALL F.READ(FN.CUS,Y.CUS.ID,R.CUS,FV.CUS,CUS.READ.ERR)
	IF NOT(CUS.READ.ERR) THEN
		Y.LOB.STATUS = R.CUS<EB.CUS.LOCAL.REF,Y.LOB.POS>
		IF Y.LOB.STATUS MATCHES Y.ALLOWED.LOB THEN
			CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM,FV.SAM,SAM.READ.ERR)
			IF NOT(SAM.READ.ERR) THEN
				IF R.SAM<SC.SAM.PORTFOLIO.FEES> NE 'NONE' THEN
					Y.CO.CODE = R.SAM<SC.SAM.CO.CODE>
					GOSUB DO.OFS.PROCESSING
				END ELSE
					Y.ARRAY = Y.SAM.ID:",":Y.LOB.STATUS:",FAILED,PORTFOLIO.FEES.VALUE.ALREADY.WITH.NONE"
			    END
			END ELSE
				Y.ARRAY = Y.SAM.ID:",":Y.LOB.STATUS:",FAILED,SAM.REC.NOT.FOUND"
			END
		END ELSE
			Y.ARRAY = Y.SAM.ID:",":Y.LOB.STATUS:",FAILED,NOT.RETAIL.CUSTOMER"
		END
	END ELSE
		Y.ARRAY = Y.SAM.ID:",NA,FAILED,CUSTOMER.REC.NOT.FOUND"
	END

	RETURN
*--------------------------------------------------------------------------------------------------------
DO.OFS.PROCESSING:
******************

	Y.OFS.HEAD = "SEC.ACC.MASTER,/I/PROCESS//0/,//":Y.CO.CODE:"/3,":Y.SAM.ID:","
	Y.OFS.MSG  = Y.OFS.HEAD:"PORTFOLIO.FEES::=NONE"
	
	Y.OFS.SOURCE = "SCB.UPD.THRU.OFS"
	CALL OFS.GLOBUS.MANAGER(Y.OFS.SOURCE,Y.OFS.MSG)
	
	Y.RESP.FLAG = '' ; Y.FIRST.MSG = ''
	Y.FIRST.MSG = FIELDS(Y.OFS.MSG,',',1,1)
	Y.RESP.FLAG = FIELDS(Y.FIRST.MSG,'/',3,1)
	
	IF Y.RESP.FLAG EQ '1' THEN
		Y.ARRAY = Y.SAM.ID:",":Y.LOB.STATUS:",SUCCESS,RECORD.UPDATED.SUCCESSFULLY"
	END ELSE
		Y.ERR.MSG = ''
		Y.ERR.MSG = FIELD(Y.OFS.MSG,",",2)
		Y.ARRAY = Y.SAM.ID:",":Y.LOB.STATUS:",FAILED,":Y.ERR.MSG
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
WRITE.DATA:
***********

	Y.FINAL.FILE.NAME = 'SCB.SAM.PF.UPD.DET.':TODAY:'.':SESSION.NO
	
	READLIST Y.ARR.INFO FROM Y.FINAL.FILE.NAME THEN
		Y.ARR.INFO<-1> = Y.ARRAY
		WRITELIST Y.ARR.INFO TO Y.FINAL.FILE.NAME
	END ELSE
		WRITELIST Y.ARRAY TO Y.FINAL.FILE.NAME
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END