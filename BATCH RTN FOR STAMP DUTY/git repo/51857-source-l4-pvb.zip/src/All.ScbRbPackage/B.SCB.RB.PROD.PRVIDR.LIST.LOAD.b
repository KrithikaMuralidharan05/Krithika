* @ValidationCode : MjoxMjQyNzg0NDQxOklTTy04ODU5LTE6MTY3NTc4Nzg1NjY3MzoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 07 Feb 2023 22:07:36
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PROD.PRVIDR.LIST.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14082
* Developed By                   :       Senthil
* Developed On                   :       02-Feb-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* LOAD Routine to generate Extract file of Product Provide detail listing Report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 13-Jun-2023   1671073          CPSGMIG-24884 Identifier for PP or Depo to be introduced
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.PROD.PRVIDR.LIST.COMMON
	$INSERT I_F.CUSTOMER.SECURITY
*--------------------------------------------------------------------------------------------
    GOSUB INITIALISE
    GOSUB OPENFILES
   
RETURN
*--------------------------------------------------------------------------------------------
INITIALISE:
*---------*

* Get LRT Position
    Y.APP.NAME = 'CUSTOMER'
    Y.FLD.NAME = 'LR.PP.CODE'
   
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
    
*Customer LRT
    Y.LR.PP.CODE.POS = Y.FLD.POS<1,1>
	
RETURN
*---------------------------------------------------------------------------------------------
OPENFILES:
*--------*
    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER  = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
 *
 
   FN.CUSTOMER.SECURITY = 'F.CUSTOMER.SECURITY'
   F.CUSTOMER.SECURITY = ''
   CALL OPF(FN.CUSTOMER.SECURITY,F.CUSTOMER.SECURITY)
 
 *
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE = "SCBCUSPROVIDERLIST-":TODAY:"-":SESSION.NO:".csv"
    
RETURN
*---------------------------------------------------------------------------------------------
END