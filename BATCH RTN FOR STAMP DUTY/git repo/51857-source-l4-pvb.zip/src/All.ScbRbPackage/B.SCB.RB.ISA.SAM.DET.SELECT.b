$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ISA.SAM.DET.SELECT

* Routine to extract the SM and SAM and its equivalent UTS and ISA Account details that were loaded
*Created by :- 1657186

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.ISA.SAM.DET.COMMON

    
    SEL.SAM.CMD = "SELECT ": FN.SEC.ACC.MASTER : " WITH LR.PFOLIO.KEY NE ''"
    CALL OCOMO("Selecting the SAM Records")

    CALL EB.READLIST(SEL.SAM.CMD,SEL.LIST,'',NO.REC,RET.CODE)

    CALL OCOMO(SEL.SAM.CMD)
    CALL OCOMO("No of Records Selected for Processing ":NO.REC)
    
    IF SEL.LIST THEN
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
RETURN
******
************************************************************
END