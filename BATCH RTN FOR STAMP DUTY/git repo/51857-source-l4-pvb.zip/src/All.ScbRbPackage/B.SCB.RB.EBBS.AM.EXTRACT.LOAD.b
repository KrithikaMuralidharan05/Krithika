$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.AM.EXTRACT.LOAD
*----------------------------------------------------------------------------------------------------------------
* 
* 
*-----------------------------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-----------------------------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864
*
* 04/12/2022 - Sasi V - PF.SKIP - To suppress configured portfolio in SCB.WM.H.LOCAL.PARAM>SCB.RB.DPL.PF
*-----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_TSA.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.LOCAL.TABLE
    $INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM ;* PF.SKIP - S/E
    $INSERT I_B.SCB.RB.EBBS.AM.EXT.COMMON
*
    GOSUB INITIALISE
    GOSUB GET.LOC.REF.POS
*
    COUNTRY.NAME = ID.COMPANY[1,2]
*
    Y.FILE.NAME = COUNTRY.NAME:'-eBBS-T24AM-':TODAY:'.txt-':AGENT.NUMBER
*
    RETURN
*
*-----------------------------------------------------------------------------------------------------------------
INITIALISE:
*---------*
* Initialise and open all the required application
*
	FN.SEC.ACC.MAST = 'F.SEC.ACC.MASTER'
	F.SEC.ACC.MAST = ''
	CALL OPF(FN.SEC.ACC.MAST,F.SEC.ACC.MAST)
*
	FN.CUST = 'F.CUSTOMER'
	F.CUST = ''
	CALL OPF(FN.CUST,F.CUST)
*
* PF.SKIP - S
	FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.SCB.WM.H.LOCAL.PARAM  = ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)

	LOC.PARAM.ID = 'SCB.RB.DPL.PF'
	R.LOC.PARAM.REC = '' ; E.LOC.PARAM.ERR = '' ; Y.PF.LIST = ''
	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,LOC.PARAM.ID,R.LOC.PARAM.REC,F.SCB.WM.H.LOCAL.PARAM,E.LOC.PARAM.ERR)
*
	IF R.LOC.PARAM.REC THEN
		Y.FLD.NAME = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.NAME>
		LOCATE 'PORT.SKIP' IN Y.FLD.NAME<1,1> SETTING Y.NAME.POS THEN
            Y.PF.LIST = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.VALUE,Y.NAME.POS>
			CHANGE @SM TO @FM IN Y.PF.LIST
        END
	END
* PF.SKIP - E

	AMEX.FILES.PATH = 'AMEX.FILES'
        CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, Y.APPEND.FILE)
*
    RETURN
*
*-----------------------------------------------------------------------------------------------------------------
GET.LOC.REF.POS:
*--------------*
* Get Local Ref Fields
*
	Y.APPLICATION = 'CUSTOMER'
*	
        Y.FIELD = 'LR.EBBS.REL':@VM:'LR.PRIM.SEC.ID':@VM:'L.O.B'
*	
	CALL MULTI.GET.LOC.REF(Y.APPLICATION,Y.FIELD,Y.LOC.REF.POS)
*	
	Y.EBBS.CUST.REL.ID.POS = Y.LOC.REF.POS<1,1>
        Y.PRI.SEC.ID.POS = Y.LOC.REF.POS<1,2>
        Y.CUST.LOB.POS = Y.LOC.REF.POS<1,3>
*
        Y.PARAM.ID    = 'SCB.CUST.SEG'	
        Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
        Y.ALLOWED.LOB = ''
        CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
*
    RETURN
*
*-----------------------------------------------------------------------------------------------------------------
END
*-----------------------------------------------------------------------------------------------------------------