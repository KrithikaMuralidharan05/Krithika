* @ValidationCode : MjoyMDU5Nzg4NTk3OklTTy04ODU5LTE6MTY4MTk2NjE2MDIyNTo4MTg5OTg3Oi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 20 Apr 2023 10:19:20
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 8189987
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.SW.RB.SAM.EXTRACT.POST
* Desc   - Single threaded service routine to build a .csv file on daily basis
*
*Modification History:
************************
*
* 06-Apr-2022 - CPSGMIG-1871 - Lavanya L - Copy of B.SCB.SW.SAM.EXTRACT.POST to generate the report only for Retail customers.
*18-April-2023 - PVBCOREBAU-7129 - Merging the RB & EDM SAM extracts to SW SAM extract. Changing Today to LWD after the change
*************************************************************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
*********************************************************************************************
    GOSUB INIT
    GOSUB PROCESS
RETURN
*********************************************************************************************
INIT:
****
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*	TAFJUPG -S
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*	TAFJUPG -E
***PVBCOREBAU-7129-S
    Y.LWORK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
***PVBCOREBAU-7129-E
    Y.FINAL.FILE.NAME = ''
    Y.COMP.NAME = ''
    Y.COMP = ''
    R.SAM.RPT.FINAL.ARR = ''
    Y.COMP = ID.COMPANY
    Y.COMP.NAME = ID.COMPANY[1,2]
    IF Y.COMP.NAME EQ 'GB' THEN
        Y.COMP.NAME = 'UK'
    END
    Y.FINAL.FILE.NAME = 'SCB.':Y.COMP.NAME:'.RB.SAM.EXTRACT.':Y.LWORK.DAY:'.CSV'	;*PVBCOREBAU-7129

    Y.TOTAL = '0'   ;* DQMF - S/E
    LINE.COUNT  = ''          ;* DQMF - S/E
    
RETURN
*********************************************************************************************
PROCESS:
********
    SEL.CMD = ''
    SEL.ERR = ''
    SEL.LIST = ''
    NO.OF.FILES = ''

*   SEL.CMD = 'SELECT ':FN.AMEX.FILES :' WITH @ID LIKE ':Y.COMP:'...SW_SAMDUMP_...':TODAY:'.csv'		;* TAFJUPG -S/E
*   CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.FILES,SEL.ERR)		;* TAFJUPG -S/E
*
**	TAFJUPG -S
*    Y.CHAR = CHAR(10)
*	EXE.CMD= "SH -c ls -lrt ":AMEXPATH:" | grep -v '^d' | grep ":Y.COMP:" | grep SW_SAMDUMP_ | grep ":TODAY:".csv | awk '{print $9}'"
*	EXECUTE EXE.CMD CAPTURING SEL.LIST
*	SEL.LIST = TRIM(SEL.LIST,Y.CHAR,"R")
*    CHANGE CHAR(10) TO @FM IN SEL.LIST
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = Y.COMP:'*SW_RB_SAMDUMP_*':Y.LWORK.DAY:'.csv'	;* PVBCOREBAU-7129
    SEL.LIST = ''
    NO.OF.FILES = ''
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)

**	TAFJUPG -E
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.SAM.RPT.FINAL.ARR EQ '' THEN
                R.SAM.RPT.FINAL.ARR = R.AMEX.FILE
* DQMF - S
                LINE.COUNT = DCOUNT(R.AMEX.FILE,@FM)
                Y.TOTAL = Y.TOTAL + LINE.COUNT
* DQMF - E
            END ELSE
                R.SAM.RPT.FINAL.ARR :=@FM:R.AMEX.FILE
* DQMF - S
                LINE.COUNT = DCOUNT(R.AMEX.FILE,@FM)
                Y.TOTAL = Y.TOTAL + LINE.COUNT
* DQMF - E
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
            LINE.COUNT = ''   ;* DQMF - S/E
        REPEAT
    END

*QC2023-S
    IF R.SAM.RPT.FINAL.ARR THEN
        WRITE R.SAM.RPT.FINAL.ARR TO F.AMEX.FILES,Y.FINAL.FILE.NAME
    END
    GOSUB REMOVE.DUP.LINE
    CALL F.READ(FN.AMEX.FILES,Y.FINAL.FILE.NAME,R.SAM.RPT.FINAL.ARR,F.AMEX.FILES,READ.ERR1)
    Y.TOTAL = DCOUNT(R.SAM.RPT.FINAL.ARR,@FM)
*QC2023-E

* DQMF - S
    ACT.DATE = OCONV(ICONV(Y.LWORK.DAY,'D4-'),'D4-')	;* PVBCOREBAU-7129
    Y.STAMP = OCONV(TIME(),"MTS")
    R.SAM.RPT.FINAL.ARR<-1> = Y.COMP.NAME:',':ACT.DATE:'/':Y.STAMP[1,5]:',':Y.TOTAL

* DQMF - E

    CALL F.WRITE(FN.AMEX.FILES,Y.FINAL.FILE.NAME,R.SAM.RPT.FINAL.ARR)
RETURN

*QC2023-S
REMOVE.DUP.LINE:
*===============
*	TAFJUPG -S
*   OPEN "","VOC" TO F.VOC ELSE
*       TEXT = "CAN'T OPEN VOC"
*       CALL FATAL.ERROR("B.SCB.SW.SAM.EXTRACT.POST")
*   END
*   READ R.VOC FROM F.VOC, FN.AMEX.FILES THEN
*	TAFJUPG -E
    FILE.PATH.ORG = AMEXPATH				;*	TAFJUPG -S/E
    FILE.PATH.ORG = EREPLACE(FILE.PATH.ORG, "&", "\&")
*   END
    CALL SCB.REMOVE.DUPLICATE.LINE(FILE.PATH.ORG,Y.FINAL.FILE.NAME)
RETURN
*QC2023-E
*********************************************************************************************
END
