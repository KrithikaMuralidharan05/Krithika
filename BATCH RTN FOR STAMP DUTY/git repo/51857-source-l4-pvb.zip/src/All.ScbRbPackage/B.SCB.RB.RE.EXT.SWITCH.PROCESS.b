$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.RE.EXT.SWITCH.PROCESS(Y.ID)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
** Author		      Date 	         Reference	    Description
*-------------------------------------------------------------------------------------------------------------------------------------------
* Bharathiraja Ponmudi        24-May-2022        CPSGMIG-565        Settle MF Trade: Cash Debit / Credit in Client's Account
* Loganathan G		      28-Aug-2023        CPSGMIG-23267	    Block and Settlement process for Ext Switch (FSO-FSI)
*****************************************************************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SCB.CASH.BLK.SETT
    $INSERT I_F.SEC.TRADE
    $INSERT I_B.SCB.RB.RE.EXT.SWITCH.PROCESS.COMMON
*-----------------------------------------------------------------------------
    
    R.REC = '';         REC.ERR = ''
    CALL F.READ(FN.CASH.BLK.SETT, Y.ID, R.REC, F.CASH.BLK.SETT, REC.ERR)

    IF R.REC THEN
        GOSUB UpdateStatus
        CALL F.WRITE(FN.CASH.BLK.SETT, Y.ID, R.REC)
    END
    
RETURN
*-----------------------------------------------------------------------------
UpdateStatus:
    
    YBlockStatus    = R.REC<S.BLOCK.STATUS>
    YBlkCreateDate  = R.REC<S.BLK.CREATE.DATE>
    IF YBlockStatus = "SWITCH_BLOCK" AND YBlkCreateDate LE YDate THEN
        R.REC<S.BLOCK.STATUS> = "TO_BE_BLOCKED"
    END

RETURN
*-----------------------------------------------------------------------------
END
