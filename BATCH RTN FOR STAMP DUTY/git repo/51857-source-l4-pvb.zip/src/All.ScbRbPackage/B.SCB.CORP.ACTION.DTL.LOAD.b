$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CORP.ACTION.DTL.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14066 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       08 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .LOAD Routine to extract Daily corporate action details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CORP.ACTION.DTL.LOAD
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 23-Jun-2023   1648769          CPSGMIG-29355 - Changes;
*                                                 1. If SP>NOMINEE.CODE is 1 then default ESPD esle check SAM>LR.LIEN.CODE is value exist update else Check the 
*                                                 table SC.SCB.RB.BLOCK>selected portfolio record with SM and Depo combination.If record exist then pick the 
*                                                 value from SC.SCB.RB.BLOCK>LR.LIEN.CODE else LR.LIEN.CODE and LIEN remarks values should be left Blank.
*                                                 2. Lien Remarks, replace ',' to '' to not exceed to next columns.
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DIARY
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_B.SCB.CORP.ACTION.DTL.COMMON
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION
*--------------------------------------------------------------------------------------------
    
    GOSUB OPEN.FILES
    GOSUB GET.VALUES

RETURN
*---------*
OPEN.FILES:
*---------*

    COUNTRY.CODE = ID.COMPANY[7,3]
    COUNTRY.NAME = ID.COMPANY[1,2]

    FN.SEC.TRADES.MDAY  = 'F.SCB.SEC.TRADES.MDAY'   ; F.SEC.TRADES.MDAY       = ''  ; CALL OPF(FN.SEC.TRADES.MDAY,F.SEC.TRADES.MDAY)
    FN.ENTITLEMENT 		= 'F.ENTITLEMENT'		;   F.ENTITLEMENT	= ''	;	CALL OPF(FN.ENTITLEMENT,F.ENTITLEMENT)
    FN.DIARY			= 'F.DIARY'				;	F.DIARY			= ''	;	CALL OPF(FN.DIARY,F.DIARY)
    FN.DAO				= 'F.DEPT.ACCT.OFFICER'	;	F.DAO 			= ''	;	CALL OPF(FN.DAO,F.DAO)
    FN.CUSTOMER 		= 'F.CUSTOMER' 			; 	F.CUSTOMER 		= ''	;	CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SECURITY.MASTER 	= 'F.SECURITY.MASTER' 	; 	F.SECURITY.MASTER = ''	;	CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SEC.ACC.MASTER   = 'F.SEC.ACC.MASTER'	;   F.SEC.ACC.MASTER  = ''	;   CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    FN.SC.SCB.LIEN.CODE = 'F.SC.SCB.LIEN.CODE'  ; 	F.SC.SCB.LIEN.CODE= '' 	; 	CALL OPF(FN.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE)
    FN.SC.SCB.RB.BLOCK        = 'F.SC.SCB.RB.BLOCK'        ; F.SC.SCB.RB.BLOCK        = '' ; CALL OPF(FN.SC.SCB.RB.BLOCK,F.SC.SCB.RB.BLOCK)
    FN.SECURITY.POSITION      = 'F.SECURITY.POSITION'      ; F.SECURITY.POSITION      = '' ; CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)

    CALL SCB.GET.ORACLE.VIEWNAME(FN.SECURITY.POSITION,Y.VIEW.NAME)   ;* Get Security Position View Name
    
*
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE = "SCBCORPACTIONDTL-":TODAY:"-":SESSION.NO:".csv"
    
*  Y.MAP.REC.ID = BATCH.DETAILS<3,1>
    Y.APP = 'CUSTOMER':@FM:'SEC.ACC.MASTER':@FM:'SECURITY.MASTER':@FM:'ENTITLEMENT':@FM:'DEPT.ACCT.OFFICER'
    Y.FIELD = 'L.O.B':@VM:'LR.PFOLIO.KEY':@VM:'LR.STAFF.IND':@FM:'LR.LIEN.CODE':@FM:'CASH.OR.REINV':@VM:'LR.RETAIL.DEPO':@VM:'LR.UTS.INS.DESC':@VM:'LM.RET.DEPO.INV':@VM:'ISLAMIC.SUKUK':@FM:'LR.REC.CASA.ACC':@FM:'LR.ARM.CODE'
    Y.FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    L.O.B.CUS.POS = Y.FIELD.POS<1,1>
    LR.PFOLIO.KEY.POS = Y.FIELD.POS<1,2>
    LR.STAFF.IND.POS = Y.FIELD.POS<1,3>
    LR.LIEN.CODE.POS 	= Y.FIELD.POS<2,1>
    Y.CASH.OR.REINV.POS 	= Y.FIELD.POS<3,1>
    Y.LR.RETAIL.DEPO.POS 	= Y.FIELD.POS<3,2>
    LR.UTS.INS.DESC.POS 	= Y.FIELD.POS<3,3>
    LM.RET.DEPO.INV.POS		= Y.FIELD.POS<3,4>
    ISLAMIC.SUKUK.POS		= Y.FIELD.POS<3,5>
    LR.REC.CASA.ACC.POS		= Y.FIELD.POS<4,1>
    LR.ARM.CODE.POS			= Y.FIELD.POS<5,1>
    
RETURN
*---------*
GET.VALUES:
*---------*
    
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    
RETURN
END
