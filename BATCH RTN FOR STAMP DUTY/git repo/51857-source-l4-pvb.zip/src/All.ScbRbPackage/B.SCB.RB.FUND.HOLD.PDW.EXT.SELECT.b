$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.FUND.HOLD.PDW.EXT.SELECT
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 06/09/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_FundHolding_YYYYMMDD.csv
* 17/04/2024 - MD, Dhayanandan 	- ADO-4015113 - The code has fine tuned
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.FUND.HOLD.PDW.EXT.COMMON
*
    GOSUB SEC.POS
*
*	LIST.PARAMETER = ''
    IF TRANS.ID.LIST THEN

*	LIST.PARAMETER<7> = 'FILTER'
        CALL BATCH.BUILD.LIST('',TRANS.ID.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
SEC.POS:
*-------
    SEL.SECPOS = '' ; SECPOS.LIST = '' ; NO.OF.SECPOS = '' ; SECPOS.ERR = ''
    TRANS.ID.LIST = ''
    SEL.SECPOS = "SSELECT ":FN.SECURITY.POSITION:" WITH L.O.B EQ ":Y.ALLOWED.LOB
*
    CALL EB.READLIST(SEL.SECPOS,SECPOS.LIST,'',NO.OF.SECPOS,SECPOS.ERR)
*ADO-4015113-Start    
    * GOSUB GET.FILTER.DATA
    GOSUB NEW.GET.FILTER.DATA
*ADO-4015113-End    
*    TRANS.ID.LIST<-1> = SECPOS.LIST
*
RETURN
*-----------------------------------------------------------------------------
GET.FILTER.DATA:
*---------------
	Y.INT = 1
	LOOP
	WHILE Y.INT LE NO.OF.SECPOS
    	Y.ID = FIELD(SECPOS.LIST<Y.INT>,'.',1,2)					;*500000005-1.000001-103.....
*        Y.DEPO = FIELD(SECPOS.LIST<Y.INT>,'.',3)
*        IF Y.DEPO THEN
        	TP.POS = ''
        	FINDSTR Y.ID IN TRANS.ID.LIST SETTING TP.POS ELSE
        		TRANS.ID.LIST<-1> = Y.ID
        	END
*        END
      Y.INT++
    REPEAT  
RETURN    

NEW.GET.FILTER.DATA:
    
	Y.INT = 1
	LOOP
	REMOVE SP.ID FROM SECPOS.LIST SETTING SP.POS
	WHILE SP.ID
		Y.ID = FIELD(SP.ID,'.',1,2)
		LOCATE Y.ID IN TRANS.ID.LIST<1> SETTING FIND.POS ELSE
			TRANS.ID.LIST<-1> = Y.ID
		END
	REPEAT
RETURN
END
