$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>331</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE B.SCB.RB.CCMS.FILE.PROCESS
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Month end job to process the incoming request file to CCMS.
*
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- CCMS - Month end job to process the incoming request file to CCMS..
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_F.COMPANY
*
    GOSUB INIT
    GOSUB OPEN.FILES
*
    RETURN
*
*-----------------------------------------------------------------------------
INIT:
*---
	Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.LAST.MONTH = Y.LWD[5,2] ;* Last Month
    Y.CUR.MONTH = TODAY[5,2] ;* Current Month
	
    CALL CDT("",Y.LWD,"+1C") ;* CPSGMIG-29137
    
	Y.SYSTEM.DATE = OCONV(DATE(),'D-') ;*MM-DD-YYYY
    Y.SYSTEM.DATE = Y.SYSTEM.DATE[7,4]:Y.SYSTEM.DATE[1,2]:Y.SYSTEM.DATE[4,2]
    
    RETURN
*
*-----------------------------------------------------------------------------
OPEN.FILES:
*---------
*
	FN.TSA.SERVICE = 'F.TSA.SERVICE'
    F.TSA.SERVICE = ''
    CALL OPF(FN.TSA.SERVICE,F.TSA.SERVICE)
    
	GOSUB PROCESS.SERVICE
    RETURN
*
*-----------------------------------------------------------------------------
PROCESS.SERVICE:
*--------------
* CPSGMIG-312 -Start
	IF ID.COMPANY[1,2] EQ 'SG' THEN
        IF (Y.LAST.MONTH NE Y.CUR.MONTH) AND (Y.SYSTEM.DATE EQ Y.LWD) THEN
            Y.SERVICE.ID = 'SNG/CCMS.FILE.PROCESS'
            Y.OPERATION = 'START' 
            ERR.TSA.SERVICE = ''; R.TSA.SERVICE = ''; SERVICE.MESSAGE = ''
    		CALL F.READ(FN.TSA.SERVICE,Y.SERVICE.ID,R.TSA.SERVICE,F.TSA.SERVICE,ERR.TSA.SERVICE)
    		IF R.TSA.SERVICE THEN
        		CALL SERVICE.CONTROL(Y.SERVICE.ID,Y.OPERATION,SERVICE.MESSAGE)
    		END ELSE
        		CALL OCOMO("CANNOT READ TSA.SERVICE/Region Holiday")
    		END
    
        END
	END
* CPSGMIG-312 -End
    RETURN
*
*-----------------------------------------------------------------------------
END
