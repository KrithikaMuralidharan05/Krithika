* @ValidationCode : MjoxMTAzMTY3NzE1OklTTy04ODU5LTE6MTY2Njc2NzA1MDk3NToxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 26 Oct 2022 12:20:50
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SP.EXTRACT.SELECT
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-12700 - JEWEL_T24_PROJECT
* Developed By                   :       Sathish
* Developed On                   :       14 October 2022
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is the multi-threaded routine which generates the spoke monthly
* report to get the SECURITY.POSITION transaction data every month.
*-------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 1663000     26-Oct-2022    CPSGMIG-14917   To update FileOpen command for Temp Sequential file.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_B.SCB.RB.SP.EXTRACT.COMMON
    $INSERT I_BATCH.FILES ;*CPSGMIG-14917
    
    
    SE.ERR = '' ; NO.OF.IDS = '' ; SE.ID.LIST = ''
    SEL.CMD = "SELECT ":FN.SP
    CALL EB.READLIST(SEL.CMD,SE.ID.LIST,'',NO.OF.IDS,SE.ERR)

    IF SE.ID.LIST THEN
        CALL BATCH.BUILD.LIST('',SE.ID.LIST)
    END

RETURN
    
END
