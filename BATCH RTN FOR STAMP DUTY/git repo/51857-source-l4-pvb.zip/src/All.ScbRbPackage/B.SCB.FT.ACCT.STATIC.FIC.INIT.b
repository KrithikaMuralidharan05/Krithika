$PACKAGE All.ScbRbPackage
*-------------------------------------------------------------------------------------------------------------
* <Rating>-120</Rating>
*-------------------------------------------------------------------------------------------------------------
SUBROUTINE B.SCB.FT.ACCT.STATIC.FIC.INIT
*-------------------------------------------------------------------------------------------------------------
* Developed By      : Gowthami K
* Developed On      : 25-11-2024 
* As Part of		: (ADO-4718839)
* Attached to       : BATCH > SNG/SCB.ACCT.STATIC.FIC.DELTA & SCB.JOB.SCHED > FICD
*					  BATCH > SNG/SCB.ACCT.STATIC.FIC
* Attached as       : Batch Routine
*
* In Parameter      : N/A
* Out Parameter     : N/A
*-------------------------------------------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Transfer file initiation from source path to Nas path/destination path using flow identifier and also saving a copy in archive folder.
*-------------------------------------------------------------------------------------------------------------
* Modification History:
*-------------------------------------------------------------------------------------------------------------
* 
*-------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.LOCKING
    $INSERT I_F.SCB.WM.H.GEN.PARAM
*
    GOSUB INIT
    GOSUB FILE.TO.ARC
    GOSUB FILE.TRANSFER
    RETURN
*----------
INIT:
*-----------
*	Y.SOURCE.PATH = BATCH.DETAILS<3,1,1>
*

    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES  = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
    AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
    Y.FINAL.DATE  = TODAY[7,2]:TODAY[5,2]:TODAY[1,4]
    Y.TIME.FORMAT = OCONV(TIME(),'MTS')
    Y.TIME        = Y.TIME.FORMAT[1,2]:Y.TIME.FORMAT[4,2]:Y.TIME.FORMAT[7,2]
*
    FILE.ID1 = "T24_":ID.COMPANY[1,2]:"_CLIENT_STATIC_":Y.FINAL.DATE
*

    Y.UDFILE = ''; Y.CRITERIA = ''
    Y.UDFILE = 'F.AMEX.FILES'
    Y.CRITERIA = FILE.ID1:'*'
    FILE.LIST = ''
    FILES.SELECTED = ''
    CALL SCB.UDLIST(Y.UDFILE,Y.CRITERIA, FILE.LIST, FILES.SELECTED)
	K = '' ; L = '' ; Y.F = '' ; Y.F1 = '' ; Y.F2 = ''
	FOR K = 1 TO FILES.SELECTED
		Y.F = FIELD(FILE.LIST<K>,'_',6)
		Y.F1 = FIELD(Y.F,'.',1)
		IF Y.F1 GT Y.F2 THEN
		    Y.F2 = Y.F1
			L = K
		END
	NEXT K
*	Y.CUST.STATIC.MAIN.FILE = "T24_":ID.COMPANY[1,2]:"_CLIENT_STATIC_":Y.FINAL.DATE:"_":Y.TIME:".txt"
    Y.CUST.STATIC.MAIN.FILE = FILE.LIST<L>
*	
    FN.SCB.WM.H.GEN.PARAM = "F.SCB.WM.H.GEN.PARAM"
    F.SCB.WM.H.GEN.PARAM = ""
    CALL OPF(FN.SCB.WM.H.GEN.PARAM,F.SCB.WM.H.GEN.PARAM)
*	
    RETURN
*-------------
FILE.TO.ARC:
*------------

    GEN.PARAM.ID = 'SCB.FIOMS.SM'
    R.SCB.WM.H.GEN.PARAM = '' ; Y.ERR = '' ; Y.ARC.DIR = ''
    CALL CACHE.READ(FN.SCB.WM.H.GEN.PARAM,GEN.PARAM.ID,R.SCB.WM.H.GEN.PARAM,Y.ERR)
    Y.ARC.DIR = R.SCB.WM.H.GEN.PARAM<SCBWM.GEN.ARC.DIR>
*    Y.SOURCE.ID = '../bnk.interface/AMEX.FILES/':Y.CUST.STATIC.MAIN.FILE
    Y.SOURCE.ID =AMEXPATH:'/':Y.CUST.STATIC.MAIN.FILE
    Y.ARC.FILE = Y.ARC.DIR:'/':Y.CUST.STATIC.MAIN.FILE
    UNIX.CMD ='SH -c "cp ':Y.SOURCE.ID:' ':Y.ARC.FILE:'"'
    CALL OCOMO("Copy command from T24 Src path to Archive path :- ":UNIX.CMD)
    EXECUTE UNIX.CMD
RETURN	
*-------------
FILE.TRANSFER:
*-------------
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = '' ; Y.CNT = '' ; I = '' 
*    
    FILE.NAME = AMEXPATH
    RECORD.NAME = Y.CUST.STATIC.MAIN.FILE
    TARGET.FILE.NAME = Y.CUST.STATIC.MAIN.FILE
    Y.CNT = DCOUNT(BATCH.DETAILS<3,1>, @SM)
	FOR I = 1 TO Y.CNT
	    FLOW.IDENTIFER.ID = BATCH.DETAILS<3,1,I>
	    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'')
	    SLEEP 60
	NEXT I
    RETURN
*----------------------------
END	