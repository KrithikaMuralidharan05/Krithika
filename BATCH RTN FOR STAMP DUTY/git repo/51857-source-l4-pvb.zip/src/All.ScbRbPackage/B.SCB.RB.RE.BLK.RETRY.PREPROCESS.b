$PACKAGE All.ScbRbPackage
* @ValidationCode : MjoyMjgxNTIyMDI6Q3AxMjUyOjE1NTIyOTM2ODM1NzY6MTU3MTg3ODotMTotMTowOjA6ZmFsc2U6Ti9BOkRFVl8yMDE3MTEuNjotMTotMQ==
* @ValidationInfo : Timestamp         : 11 Mar 2019 14:11:23
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1571878
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201711.6
* $PACKAGE SC.ScbEbbs
SUBROUTINE B.SCB.RB.RE.BLK.RETRY.PREPROCESS(Y.ID)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Author		      Date 	         Reference	    Description
*-------------------------------------------------------------------------------------------------------------------------------------------
* Revathi G        24-May-2022        CPSGMIG-565        Settle MF Trade: Cash Debit / Credit in Client's Account 
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SCB.CASH.BLK.SETT
    $INSERT I_B.SCB.RB.RE.BLK.RETRY.PREPROCESS.COMMON
    
    
    R.REC = ''; REC.ERR = ''
    CALL F.READ(FN.APP, Y.ID, R.REC, F.APP, REC.ERR)
    IF R.REC THEN
        R.REC<S.BLOCK.STATUS> = "COMPLETED"
        CALL F.WRITE(FN.APP, Y.ID, R.REC)
    END

RETURN

END
