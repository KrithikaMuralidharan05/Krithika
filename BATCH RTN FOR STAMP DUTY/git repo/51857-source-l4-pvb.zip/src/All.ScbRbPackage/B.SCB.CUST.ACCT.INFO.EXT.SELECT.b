$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CUST.ACCT.INFO.EXT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13123 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       30 December 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Select Routine to extract Customer Info batch for iBanking from CUSTOMER and SAM
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CUST.ACCT.INFO.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 05-Apr-23     1667095          CPSGMIG-23264 - Remove duplicate entries
* 02-Jun-23     1648769          CPSGMIG-27441 - Customer records should be taken from IBANKING_RELIDS.txt and file is read from &SAVEDLISTS&. 
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT ;*CPSGMIG-23264(S/E)
    $INSERT I_B.SCB.CUST.ACCT.INFO.EXT.COMMON

    FN.SL =  '&SAVEDLISTS&'
    F.SL = ''
    Y.CUST.INFO.FILE = BATCH.DETAILS<3,1>
    CALL B.SCB.C.CONV.FILE.NAME(Y.CUST.INFO.FILE)
    CALL OPF(FN.SL,F.SL)
    ARG2 = ''
    SAVE.LIST.PATH=''
    CALL SCB.GET.ORACLE.FILENAME(FN.SL, ARG2, SAVE.LIST.PATH)

    OPEN SAVE.LIST.PATH TO SL.PATH THEN
        READ R.FILE.DATA FROM SL.PATH,Y.CUST.INFO.FILE THEN
            CALL BATCH.BUILD.LIST('', R.FILE.DATA)
        END ELSE
            CALL OCOMO("Unable to read iBanking Request file from In-Directory")
        END
    END ELSE
        CALL OCOMO("Unable to open iBanking Request File")
    END

RETURN
END

