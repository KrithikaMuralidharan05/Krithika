$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.UTS.HIST.EBBS.RELID.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------------------------
*
* Multithread routine to load the EBBS.REL historical table post checking if the REL.ID exists or not.
* 17/01/2023 - Drafted by - Raja Prabhu S
*JIRA REF - CPSGMIG-17731
*-----------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.UTS.HIST.EBBS.RELID.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.SCB.UTS.HIST.EBBS.REL.ID
    

    
    GOSUB INIT
RETURN
*---------------------
INIT:
*--------------------
    FN.DEST.PATH = "./DATA.IN"
    F.DEST.PATH  = ''
    CALL OPF(FN.DEST.PATH,F.DEST.PATH)
	
    FN.SCB.UTS.HIST.EBBS.REL.ID= "F.SCB.UTS.HIST.EBBS.REL.ID"
    F.SCB.UTS.HIST.EBBS.REL.ID  = ''
    CALL OPF(FN.SCB.UTS.HIST.EBBS.REL.ID,F.SCB.UTS.HIST.EBBS.REL.ID)

    
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.SCB.WM.H.LOCAL.PARAM  = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)

    Y.ID = "MIG.MT.POST.PARAM"
 
    Y.BATCH.DATA = BATCH.DETAILS<3,1,1>

    
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.ID,R.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.PARAM.ERR)
    Y.BATCH.ID = R.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.FILE.NAMES = R.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>

    LOCATE Y.BATCH.DATA IN Y.BATCH.ID<1,1> SETTING Y.BATCH.POS THEN


        Y.PATH.FILE.SET = Y.FILE.NAMES<1,Y.BATCH.POS>

        Y.PATH.FILE = RAISE(Y.PATH.FILE.SET)
        Y.PATH.FILE.CNT = DCOUNT(Y.PATH.FILE,@VM)

        FOR I = 1 TO Y.PATH.FILE.CNT

            Y.FILE.CHECK = ''; Y.FILE.CHECK = Y.PATH.FILE<1,I>;*SRC need to be defined as first SV  in MIG.MT.POST.PARAM

            IF I = '1' THEN
                Y.SRC.FLD.PATH = FIELD(Y.FILE.CHECK,'>',1)
                Y.SRC.FILE.NAME = FIELD(Y.FILE.CHECK,'*',2)

                CALL OPF(Y.SRC.FLD.PATH,Y.SRC.FILEPATH)
            END ELSE
                Y.DEST.FLD.PATH = FIELD(Y.FILE.CHECK,'>',1)
                Y.DEST.FILE.NAME = FIELD(Y.FILE.CHECK,'>',2):'.':SESSION.NO ;*Filename.SESSION.NO
                GOSUB DEST.FILE.BUILD
            END
        NEXT I
    END
RETURN
*----------------
DEST.FILE.BUILD:
*------------------

    Y.ISA.NO.FILEPATH =  Y.DEST.FLD.PATH
    Y.ISA.NO.FILENAME = Y.DEST.FILE.NAME

    OPENSEQ Y.ISA.NO.FILEPATH,Y.ISA.NO.FILENAME TO Y.NS.FILEPATH ELSE
    END
  

RETURN
*-----------------
END
*-----------------------------------------
