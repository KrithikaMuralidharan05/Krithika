* @ValidationCode : MjotMTU3MjUwNzE3MjpJU08tODg1OS0xOjE2ODM2MzUxNjIyNzY6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 09 May 2023 17:56:02
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SETT.UNSETT.TRADES(YMTHTRADEID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14422 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       18 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* PROCESS Routine to extract Daily Trasaction details for the current month.
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 3-Nov-2022    1663000          Update Dateformat
* 11-Nov-2022   1667095          CPSGMIG-17411 Update Mapping
* 04-Jan-2023   1404392          CPSGMIG-17782 - Vestima Flag introduction and new requirement changes
* 23-Jan-2023   1667095          CPSGMIG-17723 - Update mapping for product provider name
* 09-Mar-2023   1667095          CPSGMIG-20017 - Update done to retreive POSITION.TRANSFER
* 31-Mar-2023   1667095          CPSGMIG-22789 - Update done to display Vestima and DivInst for PT
* 03-Apr-2023   1663000          CPSGMIG-18645 & 14067 - PII Column Included
* 18-Apr-2023   1663000          CPSGMIG-24521 - Price & OrderTxntype mapping
* 21-Apr-2023   1663000          CPSGMIG-24521 - Mapping for Entitlement Transaction Date
* 08-May-2023   1667095			 CPSGMIG-26771 - Updated to display POSITION.TRANSFER for PTO &PTI
* 27-May-2023   1667095			 CPSGMIG-27415 - Product provider name - comma replaced
* 08-Aug-2023   1671073          CPSGMIG-32375 - Rel ID Delimiters needs to be fixed for Joint Accounts
* 29-Sep-2023   1670271          CPSGMIG-34479 - Reports - Mapping Changes
* 16-Jul-2025   8212847          ADO-8729382   - Converting the Comma in the fieldsLr Referral Id, Lr Sourcing Id, Lr Closing Id of the file into null,so system should not move the data to next column

*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.POSITION.TRANSFER
    $INSERT I_F.SECURITY.TRANS
    $INSERT I_F.SECURITY.MASTER
	$INSERT I_F.SEC.OPEN.ORDER
	$INSERT I_F.SC.TRANS.NAME
	$INSERT I_F.DIARY
	$INSERT I_F.CUSTOMER
	$INSERT I_F.CUSTOMER.SECURITY
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.SETT.UNSETT.TRADES.COMMON
    $INSERT I_F.DEPT.ACCT.OFFICER                     ;*CPSGMIG-18645 & 14067
    $INSERT I_F.SCB.WM.H.SEGMENT                      ;*CPSGMIG-18645 & 14067
*--------------------------------------------------------------------------------------------
    
    Y.TRADE.ID = '' ; Y.TRADE.ID = FIELD(YMTHTRADEID,'*',2)
    
    Y.CL.NRC         = "" ; Y.CL.NAME  = ""  ; Y.DISC.PERCT     = "" ; Y.ACCT.HLDR.DOB  = "" ; Y.CHARGE.AMT.CCY = ""    ;*CPSGMIG-18645 & 14067
    Y.ACCT.BRCH.CODE = "" ; Y.LR.REFID = ""  ; Y.CHARGE.AMT.ARR = "" ; Y.REBATE.AMT.CCY = ""                            ;*CPSGMIG-18645 & 14067
       
    BEGIN CASE
        CASE Y.TRADE.ID[1,6] EQ "SCTRSC"
            GOSUB GET.SECTRADE.DETS
        CASE Y.TRADE.ID[1,6] EQ "DIARSC"
            GOSUB GET.ENT.DETS
        CASE Y.TRADE.ID[1,6] EQ "POSTSC"
            GOSUB GET.POSTRFR.DETS
        CASE Y.TRADE.ID[1,6] EQ "SECTSC"
            GOSUB GET.SECTRFR.DETS
    END CASE
    

RETURN
*----------------*
GET.SECTRADE.DETS:
*----------------*    
    R.SECTRADE = '' ; SECTR.ERR = '' ; SECTRHIS.ERR = '' ; Y.RM.NAME  = ''
    CALL F.READ(FN.SEC.TRADE,Y.TRADE.ID,R.SEC.TRADE,F.SEC.TRADE,SECTR.ERR)
    IF R.SEC.TRADE EQ "" THEN
        Y.HISTRADE.ID = '' ; Y.HISTRADE.ID = Y.TRADE.ID
        CALL EB.READ.HISTORY.REC(F.SEC.TRADE.HIS,Y.HISTRADE.ID,R.SEC.TRADE,SECTRHIS.ERR)
    END
    
    Y.CUST.NO = '' ; Y.CUST.NO = R.SEC.TRADE<SC.SBS.CUSTOMER.NO>
    GOSUB CHK.LOB
    
    IF Y.PROCEED.FLAG THEN
    
        Y.SECURITY.CODE  = '' ;  Y.SECURITY.CODE  = R.SEC.TRADE<SC.SBS.SECURITY.CODE>
        Y.TRANS.CODE     = '' ;  Y.TRANS.CODE     = R.SEC.TRADE<SC.SBS.CUST.TRANS.CODE>
        Y.ORDER.NO       = '' ;  Y.ORDER.NO       = R.SEC.TRADE<SC.SBS.CU.ORDER.NOS>
        Y.VALUE.DATE     = '' ;  Y.VALUE.DATE     = R.SEC.TRADE<SC.SBS.DATE.TIME,1>[1,6] ;*CPSGMIG-17411(S/E)
        Y.DIV.INSTR      = '' ;  Y.DIV.INSTR      = R.SEC.TRADE<SC.SBS.INVEST.OPTION.TYPE>
        Y.TXN.UNIT       = '' ;  Y.TXN.UNIT       = R.SEC.TRADE<SC.SBS.CUST.NO.NOM>
        Y.DEPO           = '' ;  Y.DEPO           = R.SEC.TRADE<SC.SBS.DEPOSITORY>
        Y.LR.PAY.TYPE    = '' ;  Y.LR.PAY.TYPE    = R.SEC.TRADE<SC.SBS.LOCAL.REF,LRPAY.STRADE.POS>
		Y.TRANS.DATE     = '' ;  Y.TRANS.DATE     = R.SEC.TRADE<SC.SBS.TRADE.DATE>
        
        Y.TXN.AMT        = R.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>                            ;*CPSGMIG-18645 & 14067 -S
        Y.CHARGE.AMT.ARR = R.SEC.TRADE<SC.SBS.CU.CHARGE.TAX.AMT>
        
        Y.REBATE.AMT.CCY = Y.CHARGE.AMT.ARR<1,1,1>
        Y.CHARGE.AMT.CCY = Y.CHARGE.AMT.ARR<1,1,1> + Y.CHARGE.AMT.ARR<1,1,2>
        Y.DISC.PERCT     = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.RM.DISC.POS>
        Y.CO.CODE        = R.SEC.TRADE<SC.SBS.CO.CODE>
        Y.SAM.ID         = R.SEC.TRADE<SC.SBS.CUST.SEC.ACC,1>
        Y.SALES.CODE     = R.SEC.TRADE<SC.SBS.LOCAL.REF,LR.SEC.CLOSEID.POS>
*8729382 - S
        Y.SALES.CODE   = EREPLACE(Y.SALES.CODE, ",", "")
*8729382 - E
        IF NOT(Y.REBATE.AMT.CCY) THEN
            Y.REBATE.AMT.CCY = "0"
        END
    
        IF NOT(Y.CHARGE.AMT.CCY) THEN
            Y.CHARGE.AMT.CCY = "0"
        END
    
        Y.TXN.PRC        = '' ;  Y.TXN.PRC        = R.SEC.TRADE<SC.SBS.CUST.PRICE>    ;*CPSGMIG-18645 & 14067 -E
        
        IF Y.ORDER.NO EQ "" THEN
            Y.ORDER.NO = Y.TRADE.ID
        END
*CPSGMIG-17411(S)
        BEGIN CASE
            CASE Y.DIV.INSTR EQ 'C'
                Y.DIV.INSTR = "CASH"
            CASE Y.DIV.INSTR EQ 'R'
                Y.DIV.INSTR = "REINVEST"
        END CASE
*CPSGMIG-17411(E)
		
* Get Order details
        R.SOO = '' ; SOO.ERR = ''
        CALL F.READ(FN.SEC.OPEN.ORDER,Y.ORDER.NO,R.SOO,F.SEC.OPEN.ORDER,SOO.ERR)
        IF R.SOO EQ "" THEN
            Y.SOOHIS.ID = '' ; SOOHIS.ERR = ''
            Y.SOOHIS.ID = Y.ORDER.NO
            CALL EB.READ.HISTORY.REC(F.SEC.OPEN.ORDER.HIS,Y.SOOHIS.ID,R.SOO,SOOHIS.ERR)
        END
        Y.ORDER.DATE   = '' ; Y.ORDER.DATE  = R.SOO<SC.SOO.ORDER.DATE>
        Y.LR.RSP.REF   = '' ; Y.LR.RSP.REF  = R.SOO<SC.SOO.LOCAL.REF,LR.RSP.REF.POS>
   
* Fetch ORDER Transaction TYPE details
        Y.ORDTRANS.TYPE = ''
        BEGIN CASE
            CASE Y.LR.RSP.REF NE ''
                Y.ORDTRANS.TYPE = "Savings Plan"
            
            CASE Y.LR.RSP.REF EQ ''
                IF Y.TRANS.CODE THEN
                    GOSUB GET.SCTRANS.NAME
                END
        END CASE
*CPSGMIG-17411(S)
        GOSUB GET.SM.DETS
        GOSUB GET.RM.NAME
        GOSUB GET.TXN.STATUS
        GOSUB GET.CASH.REINV
        GOSUB GET.CPF.SRS
        GOSUB WRITE.FILE
*CPSGMIG-17411(E)
    END
  
RETURN
*-----------*
GET.ENT.DETS:
*-----------*
    
    R.ENTITLEMENT = '' ; ENTITLEMENT.ERR = ''
    CALL F.READ(FN.ENTITLEMENT,Y.TRADE.ID,R.ENTITLEMENT,F.ENTITLEMENT,ENTITLEMENT.ERR)
    
    IF R.ENTITLEMENT EQ "" THEN
        Y.ENTHIS.ID = '' ; ENTHIS.ERR = '' ; Y.ENTHIS.ID = Y.TRADE.ID
        CALL EB.READ.HISTORY.REC(F.ENTITLEMENT.HIS,Y.ENTHIS.ID,R.ENTITLEMENT,ENTHIS.ERR)
    END
    
    Y.PORTFOLIO.NO = R.ENTITLEMENT<SC.ENT.PORTFOLIO.NO>
         
    Y.CUST.NO = '' ; Y.CUST.NO = FIELD(Y.PORTFOLIO.NO,'-',1)
    GOSUB CHK.LOB
    
    R.DIARY = '' ; DIARY.ERR = ''                                       ;*CPSGMIG-18645 & 14067 -S
    Y.DIARY.ID      = '' ; Y.DIARY.ID      = FIELD(Y.TRADE.ID,".",1)    ;*CPSGMIG-24521 -S/E
    CALL F.READ(FN.DIARY,Y.DIARY.ID,R.DIARY,F.DIARY,DIARY.ERR)
    
    IF R.DIARY EQ "" THEN                                               ;*CPSGMIG-24521 -S
        Y.DIAHIS.ID = '' ; DIAHIS.ERR = '' ; Y.DIAHIS.ID = Y.DIARY.ID
        CALL EB.READ.HISTORY.REC(F.DIARY.HIS,Y.DIAHIS.ID,R.DIARY,DIAHIS.ERR)
    END                                                                 ;*CPSGMIG-24521 -E
    
    Y.ORDTRANS.TYPE = '' ; Y.ORDTRANS.TYPE = R.DIARY<SC.DIA.EVENT.TYPE>
        
    IF (Y.PROCEED.FLAG) AND (Y.ORDTRANS.TYPE NE "MERGER") THEN                 ;*CPSGMIG-18645 & 14067 -E
        Y.TRANS.DATE    = '' ; Y.TRANS.DATE    = R.ENTITLEMENT<SC.ENT.VALUE.DATE> ;*CPSGMIG-24521 -S/E
        Y.SECURITY.CODE = '' ; Y.SECURITY.CODE = R.ENTITLEMENT<SC.ENT.SECURITY.NO>
        Y.TXN.UNIT      = '' ; Y.TXN.UNIT      = R.ENTITLEMENT<SC.ENT.EVENT.NOMINAL>
        Y.DEPO          = '' ; Y.DEPO          = R.ENTITLEMENT<SC.ENT.DEPOSITORY>
        Y.ORDER.NO      = '' ; Y.ORDER.NO      = Y.TRADE.ID
        
        Y.ORDER.DATE    = '' ; Y.LR.PAY.TYPE   = ''
        Y.CO.CODE       = R.ENTITLEMENT<SC.ENT.CO.CODE>                   ;*CPSGMIG-18645 & 14067 -S
        Y.SAM.ID        = R.ENTITLEMENT<SC.ENT.PORTFOLIO.NO>              ;*CPSGMIG-18645 & 14067 -E
        
    
        Y.VALUE.DATE    = '' ; Y.VALUE.DATE    = Y.TRANS.DATE
        
        IF Y.ORDTRANS.TYPE EQ 'REINVEST' THEN        ;*CPSGMIG-18645 & 14067 -S
            Y.TXN.AMT = R.ENTITLEMENT<SC.ENT.NOMINAL>
        END ELSE
            Y.TXN.AMT = R.ENTITLEMENT<SC.ENT.ENTITLEMENT.AMT>
        END
        
        BEGIN CASE
            CASE (Y.ORDTRANS.TYPE EQ 'DIVIDENDS') OR (Y.ORDTRANS.TYPE EQ 'COUPON')
                Y.TXN.PRC = ""
            CASE (Y.ORDTRANS.TYPE EQ 'MERGER')
                Y.TXN.PRC = R.DIARY<SC.DIA.OLD.MKT.PRC> :'|': R.DIARY<SC.DIA.NEW.MKT.PRC>
            CASE (Y.ORDTRANS.TYPE EQ 'REDEMPTION') OR (Y.ORDTRANS.TYPE EQ 'E.REDEMPTION')
                Y.TXN.PRC = R.DIARY<SC.DIA.RATE>
            CASE (Y.ORDTRANS.TYPE EQ 'STOCK.DIV')
                Y.TXN.PRC = R.DIARY<SC.DIA.OLD.RATIO>
            CASE 1
                Y.TXN.PRC = ""
        END CASE                                              ;*CPSGMIG-18645 & 14067 -E
                
*CPSGMIG-17411(S)
        GOSUB GET.SM.DETS
*        GOSUB GET.ACCT.TYPE
        GOSUB GET.TXN.STATUS
        GOSUB GET.CASH.REINV
        GOSUB GET.CPF.SRS
        GOSUB WRITE.FILE
*CPSGMIG-17411(E)
    END
    
RETURN
*----------------*
GET.POSTRFR.DETS:
*----------------*
    
    R.POSITION.TRANSFER = '' ; POSITION.TRANSFER.ERR = ''
    CALL F.READ(FN.POSITION.TRANSFER,Y.TRADE.ID,R.POSITION.TRANSFER,F.POSITION.TRANSFER,POSITION.TRANSFER.ERR)
 
    IF R.POSITION.TRANSFER EQ "" THEN
        Y.POSHIS.ID = '' ; POSHIS.ERR = '' ; Y.POSHIS.ID = Y.TRADE.ID
        CALL EB.READ.HISTORY.REC(F.POSITION.TRANSFER.HIS,Y.POSHIS.ID,R.POSITION.TRANSFER,POSHIS.ERR)
    END
    
    IF R.POSITION.TRANSFER THEN
        Y.TRANS.DATE    = '' ; Y.TRANS.DATE    = R.POSITION.TRANSFER<SC.PST.TRADE.DATE>
        Y.SECURITY.ARR  = '' ; Y.SECURITY.ARR  = R.POSITION.TRANSFER<SC.PST.SECURITY.NO>
        Y.VALUE.DATE    = '' ; Y.VALUE.DATE    = R.POSITION.TRANSFER<SC.PST.DATE.TIME,1>[1,6] ;*CPSGMIG-17411(S/E)
        Y.TXN.UNIT.TMP  = '' ; Y.TXN.UNIT.TMP  = R.POSITION.TRANSFER<SC.PST.NO.NOMINAL> ;*CPSGMIG-17411(S/E)
        Y.DEPO.ARR      = '' ; Y.DEPO.ARR      = R.POSITION.TRANSFER<SC.PST.DEPOSITORY>    ;*CPSGMIG-22789(S/E)
        Y.SEC.ACCT.ARR	= '' ; Y.SEC.ACCT.ARR  = R.POSITION.TRANSFER<SC.PST.SECURITY.ACCT> ;*CPSGMIG-20017(S/E)
        Y.ORDER.NO      = '' ; Y.ORDER.NO      = Y.TRADE.ID
        Y.ORDER.DATE    = '' ;
        Y.TXN.PRC.ARR   = R.POSITION.TRANSFER<SC.PST.PRICE>                ;*CPSGMIG-18645 & 14067 -S
        Y.CO.CODE       = R.POSITION.TRANSFER<SC.PST.CO.CODE>
        Y.SAM.ID        = R.POSITION.TRANSFER<SC.PST.SEC.ACCT.FROM,1>
        Y.TXN.AMT       = ''                                               ;*CPSGMIG-18645 & 14067 -E

*CPSGMIG-17411/CPSGMIG-26771(S)
        Y.SEC.CODE.CNT         = DCOUNT(Y.SECURITY.ARR,@VM)
        SM.COUNTER = '1'
        LOOP
        WHILE SM.COUNTER LE Y.SEC.CODE.CNT
            Y.SECURITY.CODE	= '' ; Y.SECURITY.CODE	= Y.SECURITY.ARR<1,SM.COUNTER>
            Y.TXN.UNIT 		= '' ; Y.TXN.UNIT 		= Y.TXN.UNIT.TMP<1,SM.COUNTER>
            Y.DEPO 			= '' ; Y.DEPO      		= Y.DEPO.ARR<1,SM.COUNTER> ;*CPSGMIG-22789(S/E)
            Y.TXN.PRC       = '' ; Y.TXN.PRC        = Y.TXN.PRC.ARR<1,SM.COUNTER> ;*CPSGMIG-18645 & 14067
            FOR NOM.IND = 1 TO 2
                BEGIN CASE
                    CASE NOM.IND EQ "1"
                        Y.ORDTRANS.TYPE = '' ; Y.ORDTRANS.TYPE = R.POSITION.TRANSFER<SC.PST.TRANS.TYPE.DR>
                        Y.SECURITY.ACCT	   = Y.SEC.ACCT.ARR<1,SM.COUNTER> ;*Changes done to get CUSTOMER.NUMBER from PORTFOLIO ID - CPSGMIG-20017(S/E)
                        Y.CUST.NO = '' ; Y.CUST.NO = FIELD(Y.SECURITY.ACCT,'-',1)
                        Y.SAM.ID  = Y.SECURITY.ACCT   ;*CPSGMIG-18645 & 14067
                        GOSUB GET.MAPPING.DTL
                    CASE NOM.IND EQ "2"
                        Y.SEC.ACC.TO = '' ; Y.SEC.ACC.TO	= R.POSITION.TRANSFER<SC.PST.SEC.ACCT.TO>
                        Y.ORDTRANS.TYPE = '' ; Y.ORDTRANS.TYPE  = R.POSITION.TRANSFER<SC.PST.TRANS.TYPE.CR>
                        Y.CUST.NO = '' ; Y.CUST.NO = FIELD(Y.SEC.ACC.TO,'-',1)
                        Y.SAM.ID  = Y.SEC.ACC.TO   ;*CPSGMIG-18645 & 14067
                        GOSUB GET.MAPPING.DTL
                END CASE
            NEXT NOM.IND
            SM.COUNTER ++
        REPEAT
*CPSGMIG-17411/CPSGMIG-26771(E)
    END
    
RETURN

*---------------*
GET.MAPPING.DTL:
*---------------*
    GOSUB CHK.LOB
    IF Y.PROCEED.FLAG THEN
        GOSUB GET.SM.DETS
*            GOSUB GET.ACCT.TYPE
        GOSUB GET.TXN.STATUS
        GOSUB GET.CASH.REINV
        GOSUB GET.CPF.SRS
        GOSUB WRITE.FILE
    END
RETURN

*---------------*
GET.SECTRFR.DETS:
*---------------*
    
    R.SECURITY.TRANSFER = '' ; SECURITY.TRANSFER.ERR = ''
    CALL F.READ(FN.SECURITY.TRANSFER,Y.TRADE.ID,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,SECURITY.TRANSFER.ERR)
    IF R.SECURITY.TRANSFER EQ "" THEN
        Y.SECHIS.ID = '' ; SECHIS.ERR = '' ; Y.SECHIS.ID = Y.TRADE.ID
        CALL EB.READ.HISTORY.REC(F.SECURITY.TRANSFER.HIS,Y.SECHIS.ID,R.SECURITY.TRANSFER,SECHIS.ERR)
    END
  
    Y.CUST.NO = '' ; Y.CUST.NO = R.SECURITY.TRANSFER<SC.STR.CUSTOMER.NO>
    GOSUB CHK.LOB
    
    IF Y.PROCEED.FLAG THEN
        Y.TRANS.DATE    = '' ; Y.TRANS.DATE    = R.SECURITY.TRANSFER<SC.STR.TRADE.DATE>
        Y.SECURITY.CODE = '' ; Y.SECURITY.CODE = R.SECURITY.TRANSFER<SC.STR.SECURITY.NO>
        Y.ORDER.NO      = '' ; Y.ORDER.NO      = Y.TRADE.ID
        Y.TXN.UNIT      = '' ; Y.TXN.UNIT      = R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
        Y.DEPO          = '' ; Y.DEPO          = R.SECURITY.TRANSFER<SC.STR.DEPOSITORY>
        Y.VALUE.DATE    = '' ; Y.VALUE.DATE    = R.SECURITY.TRANSFER<SC.STR.DATE.TIME,1>[1,6]
        Y.TRANS.CODE    = '' ; Y.TRANS.CODE    = R.SECURITY.TRANSFER<SC.STR.TRANSACTION.TYPE>
        Y.LR.PAY.TYPE   = '' ; Y.LR.PAY.TYPE   = R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,LRPAY.STRFR.POS>
        Y.ORDER.DATE    = ''
        Y.TXN.AMT       = R.SECURITY.TRANSFER<SC.STR.NET.AMT.SEC.CCY> ;*CPSGMIG-18645 & 14067 -S
        Y.TXN.PRC       = R.SECURITY.TRANSFER<SC.STR.PRICE>
        Y.SAM.ID        = R.SECURITY.TRANSFER<SC.STR.SECURITY.ACC>
        Y.CO.CODE       = R.SECURITY.TRANSFER<SC.STR.CO.CODE>
        Y.CHARGE.AMT.ARR = R.SECURITY.TRANSFER<SC.STR.CU.CHARGE.TAX.AMT>
        
        Y.REBATE.AMT.CCY = Y.CHARGE.AMT.ARR<1,1,1>
        Y.CHARGE.AMT.CCY = Y.CHARGE.AMT.ARR<1,1,1> + Y.CHARGE.AMT.ARR<1,1,2>
        IF NOT(Y.REBATE.AMT.CCY) THEN
            Y.REBATE.AMT.CCY = "0"
        END
    
        IF NOT(Y.CHARGE.AMT.CCY) THEN
            Y.CHARGE.AMT.CCY = "0"
        END                                         ;*CPSGMIG-18645 & 14067 -E
        
        IF Y.TRANS.CODE THEN
            GOSUB GET.SCTRANS.NAME
        END
*CPSGMIG-17411(S)
        GOSUB GET.SM.DETS
*        GOSUB GET.ACCT.TYPE
        GOSUB GET.TXN.STATUS
        GOSUB GET.CASH.REINV
        GOSUB GET.CPF.SRS
        GOSUB WRITE.FILE
*CPSGMIG-17411(E)
    END
       
RETURN
*-------------*
GET.CASH.REINV:
*-------------*

    Y.ASSET.CASHACT = '' ; Y.ASSET.REINVACT = ''
*CPSGMIG-17411(S)
    R.DEPO.CUSTOMER = '' ; DEPO.CUST.ERR = '' ; Y.LOB = ''
    CALL F.READ(FN.CUSTOMER,Y.DEPO,R.DEPO.CUSTOMER,F.CUSTOMER,DEPO.CUST.ERR)
*CPSGMIG-17411(E)
    IF Y.DEPO = '6708' THEN
        Y.ASSET.CASHACT = R.DEPO.CUSTOMER<EB.CUS.EXTERN.CUS.ID> ;*CPSGMIG-17411(S/E)
    END ELSE
        R.CUSTOMER.SECURITY = '' ; CUSTOMER.SECURITY.ERR = ''
        CALL F.READ(FN.CUSTOMER.SECURITY,Y.DEPO,R.CUSTOMER.SECURITY,F.CUSTOMER.SECURITY,CUSTOMER.SECURITY.ERR)
        Y.ASSET.CASHACT = R.CUSTOMER.SECURITY<SC.CSC.DEP.EXT.ACC.ID>
    END
	
    IF Y.DEPO = '6709' THEN
        Y.ASSET.REINVACT = R.DEPO.CUSTOMER<EB.CUS.EXTERN.CUS.ID> ;*CPSGMIG-17411(S/E)
    END ELSE
        R.CUSTOMER.SECURITY = '' ; CUSTOMER.SECURITY.ERR = ''
        CALL F.READ(FN.CUSTOMER.SECURITY,Y.DEPO,R.CUSTOMER.SECURITY,F.CUSTOMER.SECURITY,CUSTOMER.SECURITY.ERR)
        Y.ASSET.REINVACT = R.CUSTOMER.SECURITY<SC.CSC.DEP.EXT.ACC.ID>
    END
	
RETURN
*----------*
GET.CPF.SRS:
*----------*

    BEGIN CASE
        CASE Y.LR.PAY.TYPE = 'CPF-OA'
            Y.CPFOA = 'Y'
            Y.CPFSA = 'N'
            Y.SRS   = 'N'
        CASE Y.LR.PAY.TYPE = 'CPF-SA'
            Y.CPFOA = 'N'
            Y.CPFSA = 'Y'
            Y.SRS   = 'N'
        CASE Y.LR.PAY.TYPE = 'SRS'
            Y.CPFOA = 'N'
            Y.CPFSA = 'N'
            Y.SRS   = 'Y'
        CASE 1
            Y.CPFOA = 'N'
            Y.CPFSA = 'N'
            Y.SRS   = 'N'
    END CASE
	
RETURN
*-------------*
GET.TXN.STATUS:
*-------------*
        
    Y.TXN.STATUS = '' ; YTXNARG1 = Y.TRADE.ID ; YTXNARG2 = ''
    CALL SCB.C.GET.TXN.STATUS(YTXNARG1,YTXNARG2)
    IF YTXNARG2 NE "" THEN
        Y.TXN.STATUS = YTXNARG2
    END
    
RETURN
*------*
CHK.LOB:
*------*
    
    R.CUSTOMER = '' ; CUSTOMER.ERR = '' ; Y.LOB = ''
    CALL F.READ(FN.CUSTOMER,Y.CUST.NO,R.CUSTOMER,F.CUSTOMER,CUSTOMER.ERR)
    Y.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF,L.O.B.POS>
    Y.SECTOR           = R.CUSTOMER<EB.CUS.SECTOR>                                        ;*CPSGMIG-18645 & 14067 -S
    Y.STAFF.IND        = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.CU.STAFFIND.POS>
    Y.LRPFOLIOS        = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.CUS.LRPFOLIO.POS>
    Y.PRIM.RELID       = FIELD(Y.LRPFOLIOS,':',1)
    Y.DAO              = R.CUSTOMER<EB.CUS.ACCOUNT.OFFICER>
    Y.CUS.INDTR        = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.PVB.RB.POS>
    
    R.SCB.WM.H.SEGMENT = '' ;  ERR.SCB.WM.H.SEGMENT = ''
    CALL F.READ(FN.SCB.WM.H.SEGMENT,Y.CUS.INDTR,R.SCB.WM.H.SEGMENT,F.SCB.WM.H.SEGMENT,ERR.SCB.WM.H.SEGMENT)
    Y.CUS.TYPE = DQUOTE(R.SCB.WM.H.SEGMENT<SCBWM.SEG.DESCRIPTION>)
    
    Y.CLIENT.IDENT = ""
    BEGIN CASE
        CASE Y.SECTOR EQ "21"
            Y.CLIENT.IDENT = "SG.RETAIL"
        CASE Y.SECTOR EQ "51" AND Y.STAFF.IND EQ "Y"
            Y.CLIENT.IDENT = "SG.RETAIL"
        CASE Y.SECTOR EQ "23"
            Y.CLIENT.IDENT = "SG.RET.CB.BB"
    END CASE                                                                 ;*CPSGMIG-18645 & 14067 -E

    Y.PROCEED.FLAG = ''
    IF Y.LOB MATCHES Y.ALLOWED.LOB THEN
        Y.PROCEED.FLAG = '1'
    END
    
RETURN
*----------*
GET.SM.DETS:
*----------*
    
    SAM.ERR = '' ; R.SM = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SECURITY.CODE,R.SM,F.SECURITY.MASTER,SM.ERR)
    Y.ISIN.CODE  = '' ; Y.ISIN.CODE  = R.SM<SC.SCM.I.S.I.N.>
    Y.ASSET.CCY  = '' ; Y.ASSET.CCY  = R.SM<SC.SCM.SECURITY.CURRENCY>

    Y.ASSET.NAME = '' ; Y.ASSET.NAME = R.SM<SC.SCM.LOCAL.REF,LR.UTS.INS.DESC.POS>
    IF Y.ASSET.NAME NE '' THEN
        CONVERT @SM TO '' IN Y.ASSET.NAME
    END ELSE
        Y.ASSET.NAME = R.SM<SC.SCM.DESCRIPT,1>
    END
    Y.ASSET.NAME = EREPLACE(Y.ASSET.NAME,',',' ')
    
*CPSGMIG-17723(S)
    GOSUB GET.ACCT.TYPE
    Y.PROD.NAME = '' ; Y.TR.ISSUER = ''
    Y.TR.ISSUER = R.SM<SC.SCM.TR.ISSUER>
    Y.ASSET.UTCODE  = R.SM<SC.SCM.LOCAL.REF,LR.UTCODE.ID.POS>    ;*CPSGMIG-18645 & 14067
    
    IF Y.TR.ISSUER AND (Y.ACCT.TYPE EQ 'MF') THEN
        R.ISSUER.CUST = '' ; ISS.CUST.ERR = ''
        CALL F.READ(FN.CUSTOMER,Y.TR.ISSUER,R.ISSUER.CUST,F.CUSTOMER,ISS.CUST.ERR)
        Y.NAME.1 = '' ; Y.NAME.2 = ''; NAME.DL = ''
        IF R.ISSUER.CUST THEN
            Y.NAME.1 = R.ISSUER.CUST<EB.CUS.NAME.1>
            Y.NAME.2 = R.ISSUER.CUST<EB.CUS.NAME.2>
            NAME.DL = ' '
            Y.PROD.NAME = Y.NAME.1:NAME.DL:Y.NAME.2
            CONVERT @VM TO '' IN Y.PROD.NAME
            Y.PROD.NAME	= EREPLACE(Y.PROD.NAME,',',' ')
        END
    END
*CPSGMIG-17723(E)
        
    IF Y.TRADE.ID[1,6] NE "SCTRSC" THEN
        Y.DIV.INSTR = '' ; Y.DIV.INSTR = R.SM<SC.SCM.LOCAL.REF,CASH.OR.REINV.POS>
*CPSGMIG-17411(S)
        BEGIN CASE
            CASE Y.DIV.INSTR EQ 'C'
                Y.DIV.INSTR = "CASH"
            CASE Y.DIV.INSTR EQ 'R'
                Y.DIV.INSTR = "REINVEST"
        END CASE
*CPSGMIG-17411(E)
*CPSGMIG-17782 Start
        IF Y.DIV.INSTR EQ '' THEN
            Y.LR.RETAIL.DEPO     = R.SM<SC.SCM.LOCAL.REF,LR.RETAIL.DEPO.POS>
            Y.LM.RET.DEPO.INV    = R.SM<SC.SCM.LOCAL.REF,LM.RET.DEPO.INV.POS>
            IF Y.DEPO EQ Y.LR.RETAIL.DEPO THEN
                Y.DIV.INSTR  = "CASH"
            END ELSE
                IF Y.DEPO EQ Y.LM.RET.DEPO.INV THEN
                    Y.DIV.INSTR  = "REINVEST"
                END
            END
        END
*CPSGMIG-17782 End
    END
	
	IF (Y.ACCT.TYPE EQ 'MF') AND (Y.TRADE.ID[1,6] EQ "SCTRSC") THEN
	Y.SALES.CODE = '' ; Y.SALES.CODE = R.SOO<SC.SOO.LOCAL.REF,LR.SOO.CLOSEID.POS>	
        END
	    
RETURN
*---------------*
GET.SCTRANS.NAME:
*---------------*
    
    R.SCTRANS.NAME = '' ; SCTRANS.NAME.ERR = '' ; Y.ORDTRANS.TYPE = ''
    CALL F.READ(FN.SC.TRANS.NAME,Y.TRANS.CODE,R.SCTRANS.NAME,F.SC.TRANS.NAME,SCTRANS.NAME.ERR)
    IF R.SCTRANS.NAME THEN
        Y.ORDTRANS.TYPE = R.SCTRANS.NAME<SC.TNM.SHORT.NAME,1>
        Y.ORDTRANS.TYPE = EREPLACE(Y.ORDTRANS.TYPE,',',' ')
    END
                
RETURN
*------------*
GET.ACCT.TYPE:
*------------*

    Y.ACCT.TYPE = ''
    CALL SCB.WM.GET.PRODUCT.TYPE(Y.SECURITY.CODE,Y.ACCT.TYPE)
    
RETURN

*---------*
WRITE.FILE:
*---------*
*CPSGMIG-17782 Start
    IF (Y.ACCT.TYPE EQ 'MF') AND (Y.LR.PAY.TYPE EQ '') THEN
        Y.CPFOA = 'N'
        Y.CPFSA = 'N'
        Y.SRS   = 'N'
    END
*
    Y.VESTIMA.FLAG = ''
    CALL SCB.RB.VEST.FLAG(Y.DEPO,Y.VESTIMA.FLAG)
    Y.VESTIMA = Y.VESTIMA.FLAG
*CPSGMIG-17782 End
* Write into file

    Y.ORDER.DATE   = OCONV(ICONV(Y.ORDER.DATE,'D4'),'D4')
    Y.TRANS.DATE   = OCONV(ICONV(Y.TRANS.DATE,'D4'),'D4')
    Y.VALUE.DATE    = OCONV(ICONV(Y.VALUE.DATE,'D4'),'D4') ;*CPSGMIG-17411(S/E)
    
    Y.OUT.ARR = ''
    Y.OUT.ARR  = Y.ACCT.TYPE     :YD: Y.ORDER.NO       :YD: 'NA'         :YD: Y.ORDER.DATE    :YD: Y.TRANS.DATE     :YD: Y.VALUE.DATE  :YD:
    Y.OUT.ARR := Y.ORDTRANS.TYPE :YD: Y.ORDTRANS.TYPE  :YD: Y.TXN.STATUS :YD: Y.PROD.NAME     :YD: Y.SECURITY.CODE  :YD: Y.ASSET.NAME :YD:
    Y.OUT.ARR := Y.ASSET.CCY     :YD: Y.DIV.INSTR      :YD: Y.TXN.UNIT   :YD: Y.ASSET.CASHACT :YD: Y.ASSET.REINVACT :YD: Y.ISIN.CODE  :YD:
    Y.OUT.ARR := Y.CPFOA         :YD: Y.CPFSA          :YD: Y.SRS        :YD: Y.VESTIMA       :YD:                                               ;*CPSGMIG-18645 & 14067 -S
    Y.OUT.ARR := Y.CL.NRC        :YD: Y.CL.NAME        :YD: Y.TXN.AMT    :YD: Y.REBATE.AMT.CCY :YD:Y.CHARGE.AMT.CCY :YD: Y.ASSET.UTCODE :YD
    Y.OUT.ARR := Y.CLIENT.IDENT  :YD: Y.LRPFOLIOS      :YD: Y.DISC.PERCT :YD: Y.TXN.PRC       :YD: Y.CO.CODE[1,2]   :YD: Y.RM.NAME      :YD
    Y.OUT.ARR := Y.SAM.ID        :YD: Y.ACCT.HLDR.DOB  :YD: Y.PRIM.RELID :YD: Y.ACCT.BRCH.CODE:YD: Y.CUS.TYPE       :YD: Y.SALES.CODE            ;*CPSGMIG-18645 & 14067 -E
  
    OPENSEQ AMEX.FILES,Y.TEMP.FILE TO FP.AMEX.FILES ELSE
    END
    WRITESEQ Y.OUT.ARR APPEND TO FP.AMEX.FILES ELSE
        CALL OCOMO("Unable to Write Daily Transactions Report")
    END
    CLOSESEQ FP.AMEX.FILES
    
RETURN

*---------*
GET.RM.NAME:
*---------*
    IF Y.SALES.CODE NE '' THEN
    FILTER.CMD = '' ; FILTER.LIST = '' ; NO.FIL.REC = ''; FIL.ERR = ''
    FILTER.CMD = "SELECT ":FN.DEPT.ACCT.OFFICER:" WITH TELEX.NO EQ ":Y.SALES.CODE
    CALL EB.READLIST(FILTER.CMD,FILTER.LIST,'',NO.FIL.REC,FIL.ERR)
    FILTER.DAO.ID = FILTER.LIST<1,1>
	
	FILTER.DEPT.ACCT.OFFICER = ''   ;   FILTER.DAO.ERR = ''
    CALL F.READ(FN.DEPT.ACCT.OFFICER,FILTER.DAO.ID,FILTER.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER,FILTER.DAO.ERR)
	IF FILTER.DEPT.ACCT.OFFICER THEN 
         Y.RM.NAME = DQUOTE(FILTER.DEPT.ACCT.OFFICER<EB.DAO.NAME>)
	END
    END
	
RETURN
END