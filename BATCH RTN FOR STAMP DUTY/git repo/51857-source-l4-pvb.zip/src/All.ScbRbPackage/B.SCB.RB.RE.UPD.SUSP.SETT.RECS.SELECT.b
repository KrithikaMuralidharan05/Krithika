$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.RE.UPD.SUSP.SETT.RECS.SELECT
*-----------------------------------------------------------------------------
* Routine Type                 Batch Pre process routine
* Attached To                  BATCH>SNG/SCB.RB.IN.SUSP.SETT.RES.EBBS
* Workflow                     To create record in SCB.CASH.BLK.SETT for
*                              Commission entries.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*  Bharathiraja P    23-Aug-2022         CPSGMIG-387            Automation of accounting entries for commission in EBBS
*  Lakshmi PR        20-April-2023       CPSGMIG-24881          Commission file is generated if trade settled on next day of value date.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_B.SCB.RB.RE.UPD.SUSP.SETT.RECS.COMMON

    GOSUB PROCESS.SELECT

RETURN
*-----------------------------------------------------------------------------
*** <region name= Process>:
PROCESS.SELECT:
*** <desc>Process </desc>

*Get Last Working Day
    Y.LAST.WRK.DAY = ''
    Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
    
*Perform Select
    SEL.LIST = ''; LIST.NAME = ''; SELECTED = ''; SYSTEM.RETURN.CODE = ''
    SEL.CMD = "SELECT ":FN.APP:" WITH TYPE EQ SEC.TRADE AND WITH SETT.STATUS EQ SETTLED AND WITH STATUS.DATE GE ":Y.LAST.WRK.DAY ;*CPSGMIG-24881(S/E)
    CALL EB.READLIST(SEL.CMD, SEL.LIST, LIST.NAME, SELECTED, SYSTEM.RETURN.CODE)

    IF (SEL.LIST) THEN
        CALL BATCH.BUILD.LIST("", SEL.LIST)
    END

RETURN
*---------------------------------------------------------------------------------
END
