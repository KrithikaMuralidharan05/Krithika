$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ISA.PORTF.ICM.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13848 - JEWEL_T24_PROJECT
* Developed By                   :       Chandru Sampath
* Developed On                   :       19 October 2022
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract Day0 File for ICM
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/B.SCB.RB.ISA.PORTF.ICM
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	   
    GOSUB INITIALISE
    GOSUB PROCESS
	 
RETURN
*---------*
INITIALISE:
*---------*

    Y.DATA = BATCH.DETAILS<3,1>  ;* Contains the file name as Daily Transactions Confirmed Order
    CONVERT @SM TO @FM IN Y.DATA
   
    Y.PATH = FIELD(Y.DATA,'*', 1)
    Y.FILE.ID = FIELD(Y.DATA,'*', 2)
    CALL B.SCB.C.CONV.FILE.NAME(Y.FILE.ID)

    FN.AMEX.FILES = Y.PATH ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    AMEXPATH = ""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    YDL = ','

RETURN
*------*
PROCESS:
*------*

    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.UTS.ARR = '' ; Y.FINAL.UTS.ARR = ''
*
    Y.UDFILE	= Y.PATH
    SEL.CMD     = "SAM.ISA.ICM-":TODAY:"-*.csv*"
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(R.UTS.ARR) THEN
                R.UTS.ARR = R.AMEX.FILE
            END ELSE
                R.UTS.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

* Include the Header part
        Y.UTS.HDR = "Portfolio ID":YDL:"Customer ID":YDL:"ISA":YDL:"Rel ID(primary)":YDL:"Segment Code":YDL:"ISA Status":YDL:"Portfolio CCY":YDL:"Status":YDL:"Profile_Role"
        Y.FINAL.UTS.ARR     = Y.UTS.HDR
        Y.FINAL.UTS.ARR<-1> = R.UTS.ARR
    
	    WRITE Y.FINAL.UTS.ARR TO F.AMEX.FILES,Y.FILE.ID
    END
RETURN
END
