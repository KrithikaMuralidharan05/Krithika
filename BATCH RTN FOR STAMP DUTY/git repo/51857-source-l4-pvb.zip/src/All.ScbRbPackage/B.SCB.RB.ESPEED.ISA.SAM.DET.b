$PACKAGE All.ScbRbPackage
PROGRAM B.SCB.RB.ESPEED.ISA.SAM.DET
*----------------------------------------
* Routine to extract the SM and SAM and its equivalent UTS and ISA Account details that were loaded
*Created by :- Copy of existing routine SCB.ISA.PORTF.GET.SM.SAM.DET
*
* 08-Jun-2023  - CPSGMIG-26749 - Lavanya L - Include new column to the existing file.
* 08-Aug-2023   1671073          CPSGMIG-32375 - Rel ID Delimiters needs to be fixed for Joint Accounts
*------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM

    GOSUB INIT    ;*To initialise the variables AND open files
*    GOSUB SM.PROCESS   ;*
    GOSUB SAM.PROCESS    ;*To get the details of sec acc master and exract field values
    CALL JOURNAL.UPDATE("")
RETURN
******
INIT:
******

    CALL LOAD.COMPANY("SG1090401")

    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER  = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER  = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

	
	FN.CUSTOMER ="F.CUSTOMER"
	F.CUSTOMER =""
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)

	
	FN.SCB.WM.H.LOCAL.PARAM ="F.SCB.WM.H.LOCAL.PARAM"
	F.SCB.WM.H.LOCAL.PARAM =""

	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)

	Y.WM.ID ="RSG.PILOT.IND"
	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.WM.ID,R.SCB.WM.H.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOC.P)
	
    ISA.LISTS = R.SCB.WM.H.LOC.PARAM<SCBWM.PRM.FIELD.VALUE>		;*Get the list of Individual ISA lists from table SCB.WM.H.LOCAL.PARAM
    ISA.LISTS.CNT = DCOUNT(ISA.LISTS,@SM)
*ISA.LISTS = 113776100101 :@VM:111642260101 :@VM:112120770101 :@VM:112120770105 :@VM:112120770403:@VM:112120770604

	CONVERT @SM TO @FM IN ISA.LISTS
	
    FN.SL = "&SAVEDLISTS&"
    F.SL = ''
    CALL OPF(FN.SL,F.SL)

    Y.APPL = "SEC.ACC.MASTER":@FM:"SECURITY.MASTER":@FM:"CUSTOMER"
    Y.FLD = "LR.TP.ACCT.NO":@VM:"LR.PFOLIO.KEY":@VM:"LR.TP.AC.STATUS":@VM:"LR.WLTH.LND.IND":@FM:"LR.UT.CODE.ID":@VM:"LR.UTS.INS.DESC"
	Y.FLD:=@VM:"LR.RETAIL.DEPO":@VM:"CASH.OR.REINV":@VM:"TDS.GLOBAL.ID":@VM:"LM.RET.DEPO.INV":@FM:"LR.PP.CODE"
    Y.POS = ''

    CALL MULTI.GET.LOC.REF(Y.APPL, Y.FLD,Y.POS)
    Y.LR.TP.ACCT.NO.POS = Y.POS<1,1>
    Y.LR.PFOLIO.KEY.POS = Y.POS<1,2>
	Y.LR.TP.AC.STATUS.POS=Y.POS<1,3>
	Y.LR.WLTH.LND.IND.POS = Y.POS<1,4>
	Y.LR.UT.CODE.ID.POS = Y.POS<2,1>
	Y.LR.UTS.INS.DESC.POS =Y.POS<2,2>
	Y.LR.RETAIL.DEPO.POS =Y.POS<2,3>
	Y.CASH.REINV.POS = Y.POS<2,4>
	Y.TDS.GLOBAL.ID.POS =Y.POS<2,5>
    Y.LM.RET.DEPO.POS =Y.POS<2,6>
    Y.LR.PP.CODE.POS = Y.POS<3,1>
	
    Y.SM.ARRAY<-1> = "SM.ID":",":"UT Code":",":"TDS Global Id":",":"Asset Name":",":"Asset Type":",":"Cash or Reinv":",":"PP Code":",":"ISIN":",":"Fund CCY"
    Y.SAM.ARRAY<-1> = "Portfolio ID":",":"Customer ID":",":"ISA":",":"Rel ID(primary)":",":"Rel ID Secondary1":",":"Rel ID Secondary2":",":"Rel ID Secondary3":",":"Rel ID Secondary4":",":"Segment Code":",":"ISA Status":",WL Flag"
	
	
RETURN
*****************
***********
SM.PROCESS:
***********

    SEL.SM.CMD = "SELECT ": FN.SECURITY.MASTER: " WITH LR.UT.CODE.ID NE ''"
    CALL OCOMO("Selecting the SM Record")
    CALL EB.READLIST(SEL.SM.CMD,SEL.LIST,'',NO.REC,RET.CODE)
    CALL OCOMO(SEL.SM.CMD)
    CALL OCOMO("No of Records Selected for Processing ":NO.REC)
    LOOP

        REMOVE Y.SM.ID FROM SEL.LIST SETTING Y.SEL.POS

    WHILE Y.SM.ID:Y.SEL.POS
        
        CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,Y.SEC.MASTER.ERR)

        IF R.SECURITY.MASTER NE "" THEN

            Y.LR.UT.CODE.ID = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.UT.CODE.ID.POS>
			Y.TDS.GLOBAL.ID = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.TDS.GLOBAL.ID.POS>
			Y.UTS.INS.DESC = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.UTS.INS.DESC.POS>

			IF Y.UTS.INS.DESC EQ "" THEN
                ASSET.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME>
                CONVERT @VM TO "|" IN ASSET.NAME

                CONVERT "," TO "-" IN ASSET.NAME
			END
			ELSE
                ASSET.NAME = Y.UTS.INS.DESC
                CONVERT "," TO "-" IN ASSET.NAME
                CONVERT @SM TO "|" IN ASSET.NAME
			END

			Y.ISIN =R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
			Y.FCCY =R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>

            Y.SAT.CODE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
            Y.CODES.FUNDS =112:@VM:160:@VM:161:@VM:162:@VM:163:@VM:179:@VM:180:@VM:195:@VM:208:@VM
            Y.CODES.FUNDS:=212:@VM:213:@VM:214:@VM:215:@VM:216:@VM:217:@VM:218:@VM:219:@VM:283
	
            Y.CODES.BOND = 100:@VM:103:@VM:131:@VM:@VM:144:@VM:145:@VM:146:@VM:147:@VM:148:@VM:149:@VM:156:@VM:254:@VM:257:@VM
            Y.CODES.BOND:= 258:@VM:259:@VM:260:@VM:262:@VM:265:@VM:266:@VM:267:@VM:268:@VM:269:@VM:271:@VM:272:@VM:273:@VM:274
            Y.CODES.STRUCT =185:@VM:@VM:281:@VM:285:@VM:286:@VM:287:@VM:288
            CASH_OR_REINV =""	;*intialising Cash or Reinvestment variable
            BEGIN CASE
                CASE Y.SAT.CODE MATCHES Y.CODES.BOND
                    Y.SAT.CODE = "Bond"
                CASE Y.SAT.CODE MATCHES Y.CODES.FUNDS
                    Y.SAT.CODE ="Fund"
                CASE Y.SAT.CODE MATCHES Y.CODES.STRUCT
                    Y.SAT.CODE ="Structured Notes"
                CASE 1
                    Y.SAT.CODE = ""

            END CASE

            IF Y.SAT.CODE EQ "Fund" THEN
	
                GOSUB CASH.OR.REINV.PROCESS

            END
            Y.PP.CODES = ""
            CUS.PP.CODE = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.RETAIL.DEPO.POS>
            LM.CUS.PP.CODE = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LM.RET.DEPO.POS>
            CUS.ID = ""
            PP.CODE = ""
            BEGIN CASE
*
                CASE CUS.PP.CODE AND LM.CUS.PP.CODE

                    CUS.ID = CUS.PP.CODE
                    
                    GOSUB CUSTOMER.PROCESS
                    PP.CODE=Y.PP.CODE
                    IF PP.CODE ELSE
                        CUS.ID =LM.CUS.PP.CODE
                        GOSUB CUSTOMER.PROCESS
                        PP.CODE=Y.PP.CODE
                    END
                CASE CUS.PP.CODE AND LM.CUS.PP.CODE EQ ""
                    CUS.ID = CUS.PP.CODE
                    
                    GOSUB CUSTOMER.PROCESS
                    PP.CODE=Y.PP.CODE
*
                CASE CUS.PP.CODE EQ "" AND LM.CUS.PP.CODE

                    CUS.ID = LM.CUS.PP.CODE
                    
                    GOSUB CUSTOMER.PROCESS
                    PP.CODE=Y.PP.CODE
            END CASE
		
           
        END		;*end for first if
        CALL OCOMO("Processing Record :": Y.SM.ID)
        Y.SM.ARRAY<-1> = Y.SM.ID:',':Y.LR.UT.CODE.ID:',':Y.TDS.GLOBAL.ID:',':ASSET.NAME:',':Y.SAT.CODE:',':CASH_OR_REINV:',':PP.CODE:',':Y.ISIN:',':Y.FCCY

    REPEAT
    Y.FILE.NAME = "SM.UTS.FILE.csv"
    Y.ARRAY = Y.SM.ARRAY
    GOSUB FILE.WRITE.PROCESS
    CALL OCOMO("SM Records processing completed")



RETURN
***************
CASH.OR.REINV.PROCESS:
**********************
    CASH.REINV = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.CASH.REINV.POS>
    BEGIN CASE
        CASE CASH.REINV EQ "C"
            CASH_OR_REINV = "Cash"
        CASE CASH.REINV EQ "R"
            CASH_OR_REINV = "Reinvestment"
        CASE CASH.REINV EQ ""
            CASH_OR_REINV ="Both"
    END CASE
RETURN
*****************
SAM.PROCESS:
*****************

    CRT @(1,20): "Choose Option 1- To extract SAM full dump without BB and Pilot Customer"
    CRT @(1,21): "              2- To Extract with Migration date"
    INPUT Y.OPTION

    BEGIN CASE

        CASE Y.OPTION = 1

            SEL.SAM.CMD = "SELECT ": FN.SEC.ACC.MASTER : " WITH LR.PFOLIO.KEY NE '' AND CLOSURE.DATE EQ ''"
            CALL OCOMO("Selecting the SAM Records")

        CASE Y.OPTION = 2
            CRT @(1,30): "Enter the date to be filtered"
            INPUT Y.MIG.DT

            SEL.SAM.CMD = "SELECT ": FN.SEC.ACC.MASTER : " WITH LR.POS.MIG.DT EQ ":Y.MIG.DT:" AND CLOSURE.DATE EQ ''"
            CALL OCOMO("Selecting the SAM Records")

    END CASE

    CALL EB.READLIST(SEL.SAM.CMD,SEL.LIST,'',NO.REC,RET.CODE)

    CALL OCOMO(SEL.SAM.CMD)
    CALL OCOMO("No of Records Selected for Processing ":NO.REC)
	LOOP

        REMOVE Y.SAM.ID FROM SEL.LIST SETTING Y.SAM.POS
    WHILE Y.SAM.ID:Y.SAM.POS
 
        CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,Y.SAM.POS)

        IF R.SAM THEN

            Y.PFOLIO.KEY = R.SAM<SC.SAM.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
			PFOLIO.KEY.COUNT =DCOUNT(Y.PFOLIO.KEY,":")
			PFOLIO.KEY.PRIMARY =FIELD(Y.PFOLIO.KEY,":",1)
			PFOLIO.SECONDARY1 = FIELD(Y.PFOLIO.KEY,":",2)
			PFOLIO.SECONDARY2 = FIELD(Y.PFOLIO.KEY,":",3)
			PFOLIO.SECONDARY3 = FIELD(Y.PFOLIO.KEY,":",4)
			PFOLIO.SECONDARY4 = FIELD(Y.PFOLIO.KEY,":",5)
			
			
			ISA.STATUS = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.AC.STATUS.POS>
			CHANGE @SM TO @FM IN ISA.STATUS
            Y.TP.ACCT.NO = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS>
            CHANGE @SM TO @FM IN Y.TP.ACCT.NO
            TP.ACCT.CNT = DCOUNT(Y.TP.ACCT.NO,@FM)
            CALL OCOMO("Processing SAM Record ID :":Y.SAM.ID)
			Y.WL.FLG = R.SAM<SC.SAM.LOCAL.REF,Y.LR.WLTH.LND.IND.POS>
			CUS.NO = R.SAM<SC.SAM.CUSTOMER.NUMBER>
			
			CUS.ID = CUS.NO
            GOSUB CUSTOMER.PROCESS    ;*read customer to get sector detail if business or individual
            IF Y.SECTOR EQ "23" THEN
                Y.SEGMENT.CODE = "Business Banking"
*	GOSUB CORP.ISA
            END
            ELSE
                Y.SEGMENT.CODE ="Individual"
                GOSUB INDIV.ISA
            END
            
        END   ;*end FOR first IF

    REPEAT

    Y.FILE.NAME = "SAM.ISA.FILE.csv"
    Y.ARRAY = Y.SAM.ARRAY
    GOSUB FILE.WRITE.PROCESS
    CALL OCOMO("SAM Records processing completed")
RETURN
*********************
CUSTOMER.PROCESS:
********************

    CALL F.READ(FN.CUSTOMER,CUS.ID,R.CUSTOMER,F.CUSTOMER,CUS.ERR)
    Y.SECTOR =R.CUSTOMER<EB.CUS.SECTOR>
    Y.PP.CODE = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.PP.CODE.POS>		;*Used to get PP CODE FOR SM
    
RETURN
**************************
CORP.ISA:
*************************


*    IF TP.ACCT.CNT LE 1 THEN
*
*        Y.SAM.ARRAY<-1> = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS
*
*    END
*    ELSE
*        I = 1
*        LOOP
*        WHILE I LE TP.ACCT.CNT
*
*            Y.SAM.ARRAY<-1> = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO<I>:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS<I>
*
*            I+=1
*        REPEAT
*    END
RETURN
**************
INDIV.ISA:
*************
    IF TP.ACCT.CNT LE 1 THEN
        FINDSTR Y.TP.ACCT.NO IN ISA.LISTS SETTING TP.POS ELSE   ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed
			
            Y.SAM.ARRAY<-1> = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS:',':Y.WL.FLG
        END
    END
    ELSE
        I = 1
        LOOP
        WHILE I LE TP.ACCT.CNT
            FINDSTR Y.TP.ACCT.NO<I> IN ISA.LISTS SETTING TP.POS ELSE   ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed

		
                Y.SAM.ARRAY<-1> = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO<I>:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS<I>:',':Y.WL.FLG
            END
            I+=1
        REPEAT
    END
RETURN
********************
FILE.WRITE.PROCESS:
********************
    CALL F.WRITE(FN.SL,Y.FILE.NAME,Y.ARRAY)
RETURN

END