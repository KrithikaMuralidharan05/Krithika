$PACKAGE All.ScbRbPackage
* @ValidationCode : MjotMTA1MDY0NjA1ODpDcDEyNTI6MTU1MTA5MTQ3NjY5MzoxNTcxODc4Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTcxMS42Oi0xOi0x
* @ValidationInfo : Timestamp         : 25 Feb 2019 16:14:36
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1571878
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201711.6
* $PACKAGE SC.ScbEbbs
SUBROUTINE B.SCB.RB.RE.BLK.RETRY.PREPROCESS.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Revathi G        24-May-2022        CPSGMIG-565        Settle MF Trade: Cash Debit / Credit in Client's Account 
*-----------------------------------------------------------------------------
     $INSERT I_COMMON
     $INSERT I_EQUATE
     $INSERT I_F.BATCH
     $INSERT I_F.DATES
     $INSERT I_F.SCB.CASH.BLK.SETT
     $INSERT I_B.SCB.RB.RE.BLK.RETRY.PREPROCESS.COMMON

    SEL.CMD = ''; SEL.LIST = ''; NO.OF.RECS = ''; ERR.LIST = ''; Y.DATE = ''
    Y.DATE = TODAY
    
    SEL.CMD = "SELECT ":FN.APP:" WITH @ID LIKE SCTRSC... AND BLOCK.STATUS EQ TO_BE_BLOCKED AND VALUE.DATE LE ":Y.DATE
    CALL EB.READLIST(SEL.CMD, SEL.LIST, "", NO.OF.RECS, ERR.LIST)
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN

END
