* @ValidationCode : MjoxMjkyMjYyMzQ2OklTTy04ODU5LTE6MTcwNDg5MjI5NDc2Mzo4MTg5OTg3Oi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 10 Jan 2024 18:41:34
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 8189987
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CONFIRM.ORDER.REP(YCONFREC)
*-----------------------------------------------------------------------------
* Project Name                   :      CPSGMIG-34072
* Developed By                   :      1670271
* Developed On                   :      07-Sep-2023
*------------------------------------------------------------------------------
* Description:
*-------------
* Batch report to generate the confirmed order from SEC.TRADE & SECURITY.TRANSFER
*-------------------------------------------------------------------------------
* Modification History :
*-------------------------------------------------------------------------------
* 11-9-2023  1663000  CPSGMIG-34235 - Change comma character to space to avoid column misalignment issue
* 20-9-2023  1670271  CPSGMIG-34031 - Month to date Transaction report similar to Daily Transaction Confirmed R2W report MTD reports
* 29-Sep-2023   1670271          CPSGMIG-34479 - Reports - Mapping Change
* 25-Oct-2023   1663000          1790769       - For MF Channel Info , Send TAP Ref if exists , else send OMF Ref
* 10-Jan-2024   8189987          ADO-2360270   - Inaccurate Infor reflected under Account Holders, instead of EBBS rel ID the PfolioKey field is mapped
* 23-May-2025   8212847          ADO-8342318   - Converting the Comma in the Ordering_id column of the file into null,so system should not move the data to next column.
* 16-Jul-2025   8212847          ADO-8729382   - Converting the Comma in the fieldsLr Referral Id, Lr Sourcing Id, Lr Closing Id of the file into null,so system should not move the data to next column
* 10607079 - 1526956 - SN-Swift - Exclusion of Aggregated Security Transfer transaction as part of the downstream reporting_PVB & RBSG
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
        $INSERT I_TSA.COMMON
	$INSERT I_BATCH.FILES
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_F.DATES
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_B.SCB.RB.CONFIRM.ORDER.REP.COMMON
*-----------------------------------------------------------------------------
    
    Y.TXN.ID = FIELD(YCONFREC,'*',2,1)
    
    
    GOSUB RESET.VARIABLES
    BEGIN CASE
        CASE Y.TXN.ID[1,6] EQ 'SCTRSC'
            GOSUB SEC.TRADE.DET           ;* Process Sec Trade
                    
        CASE Y.TXN.ID[1,6] EQ 'SECTSC'
            GOSUB SECURITY.TRANSFER.DET   ;* Process Security Transfer
    END CASE

RETURN
*-------------*
RESET.VARIABLES:
*-------------*
   
    Y.ISOC.OPERATOR  = ""  ;   Y.BRANCH.CODE    = "" ; Y.PAYMENT.TYPE   = "" ; Y.CHANNEL.REF    = "" ; Y.ARRAY = ''
    Y.ACCOUNT.HOLDER = ""  ;   Y.LR.RSP.REF     = "" ;   Y.LR.OMF.REF.NO  = "" ;  Y.TAP.REF.NO     = "" ; Y.REL.CIF.NO     = ""
    Y.DELIM          = ","
    
    Y.ORDER.CLOSE.ID = '' ; Y.CO.CODE     = '' ; Y.SALES.STAFF.NAME  = '' ; Y.ACCT.TYPE      = '' ; Y.ACCT.NO    = '' ; Y.START.DATE = '' ; Y.LR.LIEN.CODE = '' ; Y.LR.REMARKS  = '' ; Y.SEC.OPEN.ORD.ID = '' ; Y.ORD.DATE         = '' ; Y.ORD.TYPE   = ''
    Y.TXN.STATUS  = '' ; Y.PRVDR.NAME     = '' ; Y.SM.ID       = '' ; Y.ASSET.NAME        = '' ; Y.ORDER.CURRENCY = '' ; Y.TRANS.AMT  = '' ; Y.REMARKS    = '' ; Y.LR.EBBS.REL = '' ; Y.LWM.EDP.REF.NUM  = '' ; Y.TAP.REF.NO = ''
    Y.ISIN        = '' ; Y.RATING         = '' ; Y.CLIENT.IDENTIFIER = '' ; Y.PRI.ACC.HOLDER = '' ; Y.TRADE.DATE = '' ; Y.LR.REF.ID  = '' ; Y.TRD.CCY      = '' ; Y.REL.ID.ARR  = '' ; R.SEC.OPEN.ORDER  = '' ; Y.DEPO = ''
    Y.CU.NET.AMT = ''; Y.BR.NET.AMT = ''; Y.CHARGE.AMT=''; SOO.CHARGE.TAX =''; SEC.CHARGE.TAX=''
RETURN
*------------*
SEC.TRADE.DET:
*------------*
    CALL F.READ(FN.SEC.TRADE,Y.TXN.ID,R.SEC.TRADE,F.SEC.TRADE,Y.ST.ERR)
    IF R.SEC.TRADE EQ "" THEN
        Y.HISTRADE.ID = '' ; Y.HISTRADE.ID = Y.TXN.ID
        CALL EB.READ.HISTORY.REC(F.SEC.TRADE.HIS,Y.HISTRADE.ID,R.SEC.TRADE,SECTRHIS.ERR)
    END
    
    Y.CUS.ID = R.SEC.TRADE<SC.SBS.CUSTOMER.NO>
    GOSUB GET.CUS.LOB
   
    IF Y.L.O.B MATCHES Y.ALLOWED.LOB THEN
        GOSUB GET.CUSTOMER.DET                      ;* Get Customer DAO
        Y.SM.ID            = R.SEC.TRADE<SC.SBS.SECURITY.CODE>
        Y.CO.CODE          = R.SEC.TRADE<SC.SBS.CO.CODE>
        Y.TRADE.DATE       = R.SEC.TRADE<SC.SBS.TRADE.DATE>
        Y.SOO.ID           = R.SEC.TRADE<SC.SBS.CU.ORDER.NOS>
        Y.ACCT.NO          = R.SEC.TRADE<SC.SBS.CUST.SEC.ACC>
        Y.TRANS.AMT        = R.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>
        Y.TRANS.CODE       = R.SEC.TRADE<SC.SBS.CUST.TRANS.CODE>
    
        Y.REMARKS          = R.SEC.TRADE<SC.SBS.CU.NARRATIVE>
        CHANGE @SM TO '' IN Y.REMARKS
        Y.REMARKS          = EREPLACE(Y.REMARKS, ",", " ")
	
        Y.ORDER.CLOSE.ID   = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.ORD.CLOSE.ID.POS>

        Y.ORDER.CLOSE.ID   = EREPLACE(Y.ORDER.CLOSE.ID, ",", "")

        Y.LR.OMF.REF.NO    = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.OMF.REF.NO.POS>
        Y.LWM.EDP.REF.NUM  = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LWM.EDP.REF.NUM.POS>
        Y.TAP.REF.NO       = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.TAP.REF.NO.POS>
        Y.LR.REF.ID        = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.REF.POS>
*8729382 - S
        Y.LR.REF.ID        = EREPLACE(Y.LR.REF.ID, ",", "")
*8729382 - E
        Y.TRD.CCY          = R.SEC.TRADE<SC.SBS.TRADE.CCY>
        Y.DEPO             = R.SEC.TRADE<SC.SBS.DEPOSITORY>
        Y.CU.NET.AMT       = R.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>
        Y.BR.NET.AMT       = R.SEC.TRADE<SC.SBS.BR.NET.AM.TRD>
        Y.CHARGE.AMT       = Y.CU.NET.AMT - Y.BR.NET.AMT

        Y.SEC.OPEN.ORD.ID  = Y.SOO.ID     ;* ID append with curr number when calling the EB.READ.HISTORY.REC
        Y.ORD.DATE         = ''
        
        CALL F.READ(FN.SEC.OPEN.ORDER,Y.SOO.ID,R.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER,Y.SOO.ERR)
        IF NOT(R.SEC.OPEN.ORDER) THEN
            CALL EB.READ.HISTORY.REC(F.SEC.OPEN.ORDER.HIS,Y.SOO.ID,R.SEC.OPEN.ORDER,Y.SOO.ERR)
        END
        IF R.SEC.OPEN.ORDER THEN
            Y.LR.RSP.REF = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.LR.RSP.REF.POS>
        END
				
        GOSUB MAPPING.VAL.DETS
		
        IF (MTH.DAILY.FLAG EQ "MTD") AND (Y.ACCT.TYPE EQ 'MF') THEN
            Y.CHARGE.AMT = ''
            SOO.CHARGE.TAX = R.SEC.OPEN.ORDER<SC.SOO.CU.CHARGE.TAX.TYPE>
            SEC.CHARGE.TAX = R.SEC.TRADE<SC.SBS.CU.CHARGE.TAX.TYPE>
            LOCATE "UPFRONT.FEE" IN SOO.CHARGE.TAX<1,1,1> SETTING SOO.TAX.POS THEN
                Y.CHARGE.AMT = R.SEC.OPEN.ORDER<SC.SOO.CU.CHARGE.TAX.AMT><1,1,SOO.TAX.POS>
            END ELSE
                LOCATE "UPFRONT.FEE" IN SEC.CHARGE.TAX<1,1,1> SETTING SEC.TAX.POS THEN
                    Y.CHARGE.AMT = R.SEC.TRADE<SC.SBS.CU.CHARGE.TAX.AMT><1,1,SEC.TAX.POS>
                END
            END
        END
		
        GOSUB FORM.ARRAY
    END
        
RETURN
*--------------------*
SECURITY.TRANSFER.DET:
*--------------------*

    CALL F.READ(FN.SECURITY.TRANSFER,Y.TXN.ID,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,Y.SEC.TRANS.ERR)
    IF R.SECURITY.TRANSFER EQ "" THEN
        Y.SECHIS.ID = '' ; SECHIS.ERR = '' ; Y.SECHIS.ID = Y.TXN.ID
        CALL EB.READ.HISTORY.REC(F.SECURITY.TRANSFER.HIS,Y.SECHIS.ID,R.SECURITY.TRANSFER,SECHIS.ERR)
    END
    
    Y.CUS.ID = R.SECURITY.TRANSFER<SC.STR.CUSTOMER.NO>
***10607079 -S
	Y.RET.POS = ''
	LOCATE Y.CUS.ID IN RB.SG.CUST<1,1> SETTING Y.RET.POS THEN
		RETURN
	END
***10607079 -E
    GOSUB GET.CUS.LOB

    IF ( Y.L.O.B MATCHES Y.ALLOWED.LOB ) THEN
        GOSUB GET.CUSTOMER.DET                      ;* Get Customer DAO
        Y.SM.ID           = R.SECURITY.TRANSFER<SC.STR.SECURITY.NO>
        Y.CO.CODE         = R.SECURITY.TRANSFER<SC.STR.CO.CODE>
        Y.ACCT.NO         = R.SECURITY.TRANSFER<SC.STR.SECURITY.ACC>
        Y.TRADE.DATE      = R.SECURITY.TRANSFER<SC.STR.TRADE.DATE>
        Y.ORDER.CLOSE.ID  = ''
        Y.TRANS.AMT       = R.SECURITY.TRANSFER<SC.STR.NET.AMT.SEC.CCY>
        Y.LWM.EDP.REF.NUM = R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,Y.LWM.EDP.REF.NUM.ST.POS>
        Y.TRANS.CODE      = R.SECURITY.TRANSFER<SC.STR.TRANSACTION.TYPE>
        
        Y.REMARKS         = R.SECURITY.TRANSFER<SC.STR.CUST.REMARKS>
        CHANGE @VM TO '' IN Y.REMARKS
        Y.REMARKS         = EREPLACE(Y.REMARKS, ",", " ")
		
        Y.DEPO            = R.SECURITY.TRANSFER<SC.STR.DEPOSITORY>
        Y.SOO.ID          = ''
        Y.ORD.DATE        = ''
        
        GOSUB MAPPING.VAL.DETS
        Y.TRD.CCY         = Y.ORDER.CURRENCY
        GOSUB FORM.ARRAY
    END
    
RETURN
*----------*
GET.CUS.LOB:
*----------*
        
    R.CUSTOMER = ''  ;   Y.CUS.ERR = ''
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUSTOMER,F.CUSTOMER,Y.CUS.ERR)
    Y.L.O.B = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
    
RETURN
*---------------*
GET.CUSTOMER.DET:
*---------------*

    Y.DAO             = R.CUSTOMER<EB.CUS.ACCOUNT.OFFICER>
    Y.SECTOR          = R.CUSTOMER<EB.CUS.SECTOR>
    Y.LR.EBBS.REL     = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.EBBS.REL.POS>
    Y.STAFF.IND       = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.STAFF.IND.POS>
    Y.PRI.ACC.HOLDER  = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
    Y.LRSIGN.MDATE    = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.SIGN.MANDT.POS>

    CHANGE @SM TO @FM IN Y.LRSIGN.MDATE
    CHANGE @VM TO @FM IN Y.LR.EBBS.REL
    CHANGE @SM TO @FM IN Y.LR.EBBS.REL
    
    Y.CLIENT.IDENTIFIER = ""
    BEGIN CASE
        CASE Y.SECTOR EQ "21"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE Y.SECTOR EQ "51" AND Y.STAFF.IND EQ "Y"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE Y.SECTOR EQ "23"
            Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
        
    Y.LR.PFOLIO.ARR = Y.PRI.ACC.HOLDER ; Y.REL.ID.ARR = '' ; PFOLIO.IDX = 0
    CHANGE ':' TO @FM IN Y.LR.PFOLIO.ARR
    
    LOOP
        REMOVE Y.PFOLIO.ID FROM Y.LR.PFOLIO.ARR SETTING Y.LR.PFOLIO.POS1
    WHILE Y.PFOLIO.ID : Y.LR.PFOLIO.POS1
        IF PFOLIO.IDX LE 4 THEN
            LOCATE Y.PFOLIO.ID IN Y.LR.EBBS.REL SETTING Y.LR.PFOLIO.POS2 THEN
                PFOLIO.IDX += 1
                IF NOT(Y.REL.ID.ARR) THEN
                    Y.REL.ID.ARR = Y.LRSIGN.MDATE<Y.LR.PFOLIO.POS2>
                END ELSE
                    Y.REL.ID.ARR := Y.DELIM: Y.LRSIGN.MDATE<Y.LR.PFOLIO.POS2>
                END
            END
        END
    REPEAT
	
    LOOP
        PFOLIO.IDX = PFOLIO.IDX + 1
    WHILE PFOLIO.IDX LE 4
        Y.REL.ID.ARR : = Y.DELIM
    REPEAT
	    
RETURN
*---------------*
MAPPING.VAL.DETS:
*---------------*
    
    R.SECURITY.MASTER = '' ;   SM.ERR = '' ; Y.SUB.ASSET.TYPE  = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,SM.ERR)
    Y.ASSET.NAME     = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.UTS.DESC.POS>
	Y.SUB.ASSET.TYPE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
    IF Y.ASSET.NAME EQ '' THEN
        Y.ASSET.NAME     = R.SECURITY.MASTER<SC.SCM.DESCRIPT>
    END
    
    CHANGE @VM TO '' IN Y.ASSET.NAME
    CHANGE @SM TO ' ' IN Y.ASSET.NAME
    
    Y.ORDER.CURRENCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
    Y.COMPANY.NAME   = R.SECURITY.MASTER<SC.SCM.COMPANY.NAME>
    CHANGE @VM TO ' ' IN Y.COMPANY.NAME
    
    Y.ISIN           = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
    Y.RATING         = R.SECURITY.MASTER<SC.SCM.RATING>
    CALL SCB.WM.GET.PRODUCT.TYPE(Y.SM.ID,Y.ACCT.TYPE)
    
    Y.PRVDR.NAME = '' ; Y.TR.ISSUER = ''
    Y.TR.ISSUER = R.SECURITY.MASTER<SC.SCM.TR.ISSUER>
    IF Y.TR.ISSUER AND (Y.ACCT.TYPE EQ 'MF') THEN
        R.ISSUER.CUST = '' ; ISS.CUST.ERR = ''
        CALL F.READ(FN.CUSTOMER,Y.TR.ISSUER,R.ISSUER.CUST,F.CUSTOMER,ISS.CUST.ERR)
        Y.NAME.1 = '' ; Y.NAME.2 = '' ; NAME.DL = ''
        IF R.ISSUER.CUST THEN
            Y.NAME.1 = R.ISSUER.CUST<EB.CUS.NAME.1>
            Y.NAME.2 = R.ISSUER.CUST<EB.CUS.NAME.2>
            NAME.DL = ' '
            Y.PRVDR.NAME = Y.NAME.1:NAME.DL:Y.NAME.2
            CONVERT @VM TO '' IN Y.PRVDR.NAME
        END
    END

    IF Y.ACCT.TYPE EQ 'MF' THEN
        Y.ORD.DATE   = R.SEC.OPEN.ORDER<SC.SOO.ORDER.DATE>
        Y.ORDER.CLOSE.ID = '' ; Y.ORDER.CLOSE.ID = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.LR.CLOSING.ID.POS.SO>
        Y.ORDER.CLOSE.ID = EREPLACE(Y.ORDER.CLOSE.ID, ",", "")
        Y.LR.REF.ID = ''      ; Y.LR.REF.ID = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.REFERRAL.ID.POS>
    END

    Y.ORD.TYPE = ''
    IF Y.LR.RSP.REF THEN
        Y.ORD.TYPE = "Savings Plan"
    END ELSE
        CALL F.READ(FN.SC.TRANS.NAME,Y.TRANS.CODE,R.SC.TRANS.NAME,F.SC.TRANS.NAME,Y.SC.TRANS.NAME.ERR)
        IF R.SC.TRANS.NAME THEN
            Y.ORD.TYPE = R.SC.TRANS.NAME<SC.TNM.SHORT.NAME,1>
        END
    END

    Y.TXN.STATUS = ""
    CALL SCB.C.GET.TXN.STATUS(Y.TXN.ID,Y.TXN.STATUS)  ;* To get Transaction status
    
    R.SEC.ACC.MASTER = ''    ;  Y.SAM.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.ACCT.NO,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,Y.SAM.ERR)
    Y.START.DATE   = R.SEC.ACC.MASTER<SC.SAM.START.DATE>
    GOSUB GET.LIEN.CODE.VAL
    
    BEGIN CASE
        CASE Y.LWM.EDP.REF.NUM NE ""
            Y.CHANNEL.REF = Y.LWM.EDP.REF.NUM
            
        CASE Y.LR.OMF.REF.NO NE ""
            Y.CHANNEL.REF = Y.LR.OMF.REF.NO
            
        CASE Y.TAP.REF.NO NE ""
            Y.CHANNEL.REF = Y.TAP.REF.NO
    END CASE

    IF Y.TXN.ID[1,6] EQ 'SCTRSC' THEN
        LOCATE Y.SUB.ASSET.TYPE IN Y.FI.SAT.CODES<1,1> SETTING FI.POS THEN ;* BONDS - FI
            Y.SEC.OPEN.ORD.ID = ''; Y.SEC.OPEN.ORD.ID = Y.LWM.EDP.REF.NUM
            Y.CHANNEL.REF = '' ; Y.CHANNEL.REF = Y.TAP.REF.NO
        END ELSE
            IF Y.ACCT.TYPE EQ 'MF' THEN
                Y.CHANNEL.REF = '' ; Y.CHANNEL.REF = Y.TAP.REF.NO
                IF Y.CHANNEL.REF EQ '' THEN
                    Y.CHANNEL.REF = Y.LR.OMF.REF.NO
                END
            END
        END
    END
	
RETURN

*----------------*
GET.LIEN.CODE.VAL:
*----------------*

* Get Security Position based on Portfolio
    SEL.CMD    = "SELECT RECID FROM ":Y.VIEW.NAME:" WHERE SECURITY_ACCOUNT = '":Y.ACCT.NO:"' AND SECURITY_NUMBER = '":Y.SM.ID:"'"
    SEL.CMD    := "AND DEPOSITORY = '":Y.DEPO:"' ORDER BY SECURITY_NUMBER"
    SEL.CMD    = TRIM(SEL.CMD)

    TRANSLATE.QUERY = '' ; RESULT.SET = "" ; ERR.CODE   = "" ; ERR.MSG    = "" ; UNIQUE.ID = OPERATOR:"-":TNO:"-LIENREP-":TIME()
    CALL SCB.CALL.ORACLE.SQL(TRANSLATE.QUERY, UNIQUE.ID, SEL.CMD, RESULT.SET, ERR.CODE, ERR.MSG)
    LOOP
        REMOVE Y.SP.ID FROM RESULT.SET SETTING SP.POS
    WHILE Y.SP.ID : SP.POS
        R.SECURITY.POSITION = '' ; SECURITY.POSITION.ERR = '' ; Y.NOM.CODE = ''
        CALL F.READ(FN.SECURITY.POSITION,Y.SP.ID,R.SECURITY.POSITION,F.SECURITY.POSITION,SECURITY.POSITION.ERR)
        Y.NOM.CODE     = R.SECURITY.POSITION<SC.SCP.NOMINEE.CODE>
        IF Y.NOM.CODE EQ '1' THEN
            Y.LR.LIEN.CODE = 'ESPD'
        END
        GOSUB GET.LIEN.CODE.VAL1
    REPEAT
    IF Y.LR.LIEN.CODE EQ '' THEN
        GOSUB GET.LIEN.CODE.VAL1
    END

RETURN
*------------------*
GET.LIEN.CODE.VAL1:
*------------------*

    IF Y.LR.LIEN.CODE EQ '' THEN
        Y.LR.LIEN.CODE = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.LR.LIEN.CODE.POS>
        IF Y.LR.LIEN.CODE EQ '' THEN
            R.SC.SCB.RB.BLOCK = ''   ; Y.SC.SCB.RB.BLOCK.ERR = ''
            CALL F.READ(FN.SC.SCB.RB.BLOCK,Y.SP.ID,R.SC.SCB.RB.BLOCK,FN.SC.SCB.RB.BLOCK,Y.SC.SCB.RB.BLOCK.ERR)
            Y.LR.LIEN.CODE = R.SC.SCB.RB.BLOCK<RB.BLK.LR.LIEN.CODE>
        END
    END

    IF Y.LR.LIEN.CODE THEN
        R.SC.SCB.LIEN.CODE = ''  ;  Y.SC.SCB.LIEN.CODE.ERR = ''
        CALL F.READ(FN.SC.SCB.LIEN.CODE,Y.LR.LIEN.CODE,R.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE,Y.SC.SCB.LIEN.CODE.ERR)
        Y.LR.REMARKS = R.SC.SCB.LIEN.CODE<SC.SCBL.DESC>
        Y.LR.REMARKS  = EREPLACE(Y.LR.REMARKS, ",", " ")
    END

RETURN
*---------*
FORM.ARRAY:
*---------*
    
    Y.ARRAY = Y.TXN.ID                               ;* 1.Transaction Reference
    Y.ARRAY := Y.DELIM:Y.ISOC.OPERATOR               ;* 2.ISOC Operator
    Y.ARRAY := Y.DELIM:Y.ORDER.CLOSE.ID              ;* 3.Order Closing Id
    Y.ARRAY := Y.DELIM:Y.CO.CODE[1,2]                ;* 4.Country Code
    Y.ARRAY := Y.DELIM:Y.SALES.STAFF.NAME            ;* 5.Sales Staff Name
    Y.ARRAY := Y.DELIM:Y.ACCT.TYPE                   ;* 6.Account Type
    Y.ARRAY := Y.DELIM:Y.ACCT.NO                     ;* 7.Account Number
    Y.ARRAY := Y.DELIM:Y.START.DATE                  ;* 8.Account Open Date
    Y.ARRAY := Y.DELIM:Y.LR.LIEN.CODE                ;* 9.Lien Reason Code
    Y.ARRAY := Y.DELIM:Y.LR.REMARKS                  ;* 10.Lien Reason Code Desc
    Y.ARRAY := Y.DELIM:Y.SEC.OPEN.ORD.ID             ;* 11.Order No.
    Y.ARRAY := Y.DELIM:Y.ORD.DATE                    ;* 12.Order Date
    Y.ARRAY := Y.DELIM:""                            ;* 13.Account Holder DOB
    Y.ARRAY := Y.DELIM:Y.ORD.TYPE                    ;* 14.Transaction Type
    Y.ARRAY := Y.DELIM:Y.ORD.TYPE                    ;* 15.Detail On Order Type
    Y.ARRAY := Y.DELIM:Y.ORD.TYPE                    ;* 16.Order Type
    Y.ARRAY := Y.DELIM:Y.TXN.STATUS                  ;* 17.Transaction Status
    Y.ARRAY := Y.DELIM:DQUOTE(Y.PRVDR.NAME)          ;* 18.Product Provider Name
    Y.ARRAY := Y.DELIM:Y.SM.ID                       ;* 19.Asset Code
    Y.ARRAY := Y.DELIM:DQUOTE(Y.ASSET.NAME)          ;* 20.Asset Name
    Y.ARRAY := Y.DELIM:Y.ORDER.CURRENCY              ;* 21.Asset Currency
    Y.ARRAY := Y.DELIM:Y.TRANS.AMT                   ;* 22.Transaction Amount
    Y.ARRAY := Y.DELIM:Y.REMARKS                     ;* 23.Remarks
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 1
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 25.ID Number 1
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<1>            ;* 26.PFolioKey 1	;*ADO-2360270 S/E
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 2
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 27.ID Number 2
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<2>            ;* 28.PFolioKey 2	;*ADO-2360270 S/E
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 3
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 29.ID Number 3
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<3>            ;* 30.PFolioKey 3	;*ADO-2360270 S/E
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 4
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 31.ID Number 4
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<4>            ;* 32.PFolioKey 4	;*ADO-2360270 S/E
    Y.ARRAY := Y.DELIM:Y.LR.RSP.REF                  ;* 33.RSP Plan ID
    Y.ARRAY := Y.DELIM:Y.ISIN                        ;* 34.ISIN
    Y.ARRAY := Y.DELIM:Y.RATING                      ;* 35.PRR [Risk]
    Y.ARRAY := Y.DELIM:Y.CHANNEL.REF                 ;* 36.Channel info
    Y.ARRAY := Y.DELIM:Y.CLIENT.IDENTIFIER           ;* 37.Client Identifier
    Y.ARRAY := Y.DELIM:Y.PRI.ACC.HOLDER              ;* 38.PrimaryAcctHolder
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 39.Account Holder DOB 2
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 40.Account Holder DOB 3
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 41.Account Holder DOB 4
    Y.ARRAY := Y.DELIM:Y.TRADE.DATE                  ;* 42.Transaction Date
    Y.ARRAY := Y.DELIM:Y.LR.REF.ID                   ;* 43.Referral ID
    Y.ARRAY := Y.DELIM:Y.TRD.CCY                     ;* 44.Transaction Ccy
    Y.ARRAY := Y.DELIM:Y.REL.ID.ARR                  ;* 45 - 48. Rel 1, Rel 2, Rel 3 & Rel 4
    
    IF MTH.DAILY.FLAG EQ "MTD" THEN
        Y.ARRAY := Y.DELIM:ABS(Y.CHARGE.AMT)                  ;* 49.Charge amount for MTD reports
    END
    
    IF Y.ARRAY THEN
        OPENSEQ AMEX.FILES,Y.TEMP.FILE TO FP.AMEX.FILES ELSE
        END
        WRITESEQ Y.ARRAY APPEND TO FP.AMEX.FILES ELSE
            CALL OCOMO("Unable to Write Confirmed Order Report")
        END
        CLOSESEQ FP.AMEX.FILES
    END
 
RETURN
END