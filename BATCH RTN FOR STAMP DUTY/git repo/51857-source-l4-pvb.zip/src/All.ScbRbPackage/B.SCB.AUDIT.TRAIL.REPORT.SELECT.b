$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.AUDIT.TRAIL.REPORT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-374 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       06 January 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Select Routine to extract Audit Trail report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.AUDIT.TRAIL.REPORT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.AUDIT.TRAIL.REPORT.COMMON
*
    IF ID.COMPANY[1,2] EQ 'SG' THEN
        Y.SEL.CMD   = "SELECT ":FN.SAM: " WITH CLOSURE.DATE EQ '' "
        Y.SEL.LIST  = ''
        Y.SEL.COUNT = ''
        Y.SEL.ERR   = ''
        CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST,'',Y.SEL.COUNT,Y.SEL.ERR)

*
        CALL BATCH.BUILD.LIST('',Y.SEL.LIST)
    END
*

END
