$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.EDM.RB.SAM.EXTRACT.LOAD
*-----------------------------------------------------------------------------  *
* Desc   - This routine will generate the SAM Dump in AMEX.FILES.
*Modification History:
************************
*18-Jul-2022 - CPSGMIG-4230 - Lavanya L - Copy of B.SCB.SW.RB.SAM.EXTRACT.LOAD to generate the report only for Retail customers.
* 03-Mar-2023 - CPSGMIG-20046 - Lavanya L - Retrofit changes for LR.REMARKS to LR.ISA.REMARKS
* 23-Mar- 2023 - CPSGMIG-18238 - Lakshmi PR- Parameterised the customer tranche records
*******************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.EDM.RB.SAM.EXTRACT.COMMON
	$INSERT I_F.DEPT.ACCT.OFFICER      ;* CPSGMIG-1871 - S/E
	$INSERT I_F.SCB.PORTFOLIO.REC.ACCT ;* CPSGMIG-1871 - S/E
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
*
    GOSUB INIT
*
RETURN
*******************************************************************************
INIT:
*****
    FN.SAM = ''
    F.SAM = ''
    FN.CUST = ''
    F.CUST = ''
    FN.CUS.SEC = ''
    F.CUS.SEC = ''
    Y.SAM.ID = ''
    Y.CUS.ID = ''
    Y.SEC.ID = ''
    Y.SAM.LIST = ''
    Y.CSV.FILE.ID = ''
*
    FN.SAM = 'F.SEC.ACC.MASTER'
    F.SAM = ''
    CALL OPF(FN.SAM,F.SAM)
*
    FN.CUST = 'F.CUSTOMER'
    F.CUST = ''
    CALL OPF(FN.CUST,F.CUST)
*
    FN.CUS.SEC = 'F.CUSTOMER.SECURITY'
    F.CUS.SEC = ''
    CALL OPF(FN.CUS.SEC, F.CUS.SEC)
*
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

* CPSGMIG-1871 - S
    FN.DEPT.ACCT.OFFICER = 'F.DEPT.ACCT.OFFICER'
    F.DEPT.ACCT.OFFICER = ''
    CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)

	FN.SCB.PORTFOLIO.REC.ACCT = 'F.SCB.PORTFOLIO.REC.ACCT'
	F.SCB.PORTFOLIO.REC.ACCT  = ''
	CALL OPF(FN.SCB.PORTFOLIO.REC.ACCT,F.SCB.PORTFOLIO.REC.ACCT)
	
	FN.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.LOC.PARAM = ''
    CALL OPF(FN.LOC.PARAM,F.LOC.PARAM)
	


	Y.APP = 'SEC.ACC.MASTER':@FM:'CUSTOMER':@FM:'DEPT.ACCT.OFFICER'
    Y.FIELD = 'GEN.COST.CENTRE':@VM:'LWM.PVB.IND':@VM:'LWM.CUST.CLASS':@VM:'FIS.Y.OR.N'
	Y.FIELD := @VM:'LR.WLTH.LND.IND':@VM:'LR.WL.EFF.DATE':@VM:'LR.LIEN.CODE':@VM:'LR.TP.ACCT.NO':@VM:'LR.TP.SYSTEM'
	Y.FIELD := @VM:'LR.TP.AC.OP.DT':@VM:'LR.TP.CURRENCY':@VM:'LR.TP.AC.STATUS':@VM:'LR.TP.LIEN.FLAG':@VM:'LR.PFOLIO.KEY':@VM:'LR.ISA.REMARKS':@VM:'LR.POS.MIG.DT'
	
	Y.FIELD := @FM:'L.O.B':@FM:'LR.ARM.CODE'
	;*CPSGMIG-18238- Start/End
* CPSGMIG-1871 - E
    Y.FIELD.POS = ''
*
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    Y.COS.POS = Y.FIELD.POS<1,1>
    Y.IND.POS = Y.FIELD.POS<1,2>
    Y.CLASS.POS = Y.FIELD.POS<1,3>
**** TAP Enable - Start
    Y.FIS.Y.OR.N.POS = Y.FIELD.POS<1,4>
**** TAP Enable - End

* CPSGMIG-1871 - S

    LR.WLTH.LND.IND.POS = Y.FIELD.POS<1,5>
    LR.WL.EFF.DATE.POS = Y.FIELD.POS<1,6>
    LR.LIEN.CODE.POS = Y.FIELD.POS<1,7>
    LR.TP.ACCT.NO.POS = Y.FIELD.POS<1,8>
    LR.TP.SYSTEM.POS = Y.FIELD.POS<1,9>
    LR.TP.AC.OP.DT.POS = Y.FIELD.POS<1,10>
    LR.TP.CURRENCY.POS = Y.FIELD.POS<1,11>
    LR.TP.AC.STATUS.POS = Y.FIELD.POS<1,12>
    LR.TP.LIEN.FLAG.POS = Y.FIELD.POS<1,13>
    LR.PFOLIO.KEY.POS = Y.FIELD.POS<1,14>
	LR.REMARKS.POS = Y.FIELD.POS<1,15>
	Y.MIG.DAT.POS = Y.FIELD.POS<1,16> ;*CPSGMIG-27037- Start/End
    LR.ARM.CODE.POS = Y.FIELD.POS<3,1>
* CPSGMIG-1871 - E

*CPSGMIG-1058 - Start
    Y.CUST.LOB.POS = Y.FIELD.POS<2,1>
    Y.PARAM.ID    = 'SCB.CUST.SEG'	
    Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
    Y.ALLOWED.LOB = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    CONVERT @VM TO ' ' IN Y.ALLOWED.LOB
*CPSGMIG-1058-End
FN.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.LOC.PARAM = ''
    CALL OPF(FN.LOC.PARAM,F.LOC.PARAM)
    
	*CPSGMIG-18238- Start
   Y.FILE.FLAG =  ''
   ID.LOC.PARAM = 'SCB.RB.CUST.FULL.TRANCHE'
   Y.FIND.FILE.NAME = 'SCB_SG_RB_EDM_SAM_EXTRACT'
   CALL F.READ(FN.LOC.PARAM,ID.LOC.PARAM,R.LOC.PARAM,F.LOC.PARAM,LOC.ERR)
   IF R.LOC.PARAM THEN
      Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
          LOCATE Y.FIND.FILE.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
           Y.FILE.FLAG = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>
           CONVERT SM TO VM IN Y.FILE.FLAG
           Y.FILE.FLAG = Y.FILE.FLAG<1,2>
          END
   END      
*CPSGMIG-18238- End


RETURN
*-------------------------------------------------------------------------------------------------------*
END
