$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>840</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.SPA.BLD.CLOSING(ID.SAM)
*-----------------------------------------------------------------------------------------------------*
* Description:
*--------------
* Multi threaded routine  will update only the closing balances. The
* day balances will be updated by a different job B.SCB.RB.SPA.BLD.DAY.
*-----------------------------------------------------------------------------------------------
* Modification History:
*-------------------------------------------------------------------------------------------------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- Daily job to update closing bal no nom in SCB.RB.SEC.POS.ACTIVITY.
* 13-Apr-2023 - CPSGMIG-312 - kalaikumaranp - CPF and SRS Exclusion for MF.
* 09-Jun-2023 - CPSGMIG-29137 - kalaikumaranp - Update Date as Last working day.
*--------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SCB.RB.SEC.POS.ACTIVITY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_SCB.RB.SPA.BLD.CLOSING.COMMON
*
    CALL F.READ(FN.SEC.POS.SAM.CONCAT,ID.SAM,R.SEC.POS.SAM.CONCAT,F.SEC.POS.SAM.CONCAT,Y.ERR)
*    R.PCS = R.POS.CON.SCAC
    IF R.SEC.POS.SAM.CONCAT THEN
        R.PCS = R.SEC.POS.SAM.CONCAT
    END
*
    READ R.SAM FROM F.SEC.ACC.MASTER, ID.SAM ELSE RETURN
*
    IF R.SAM<SC.SAM.CLOSURE.DATE> AND R.SAM<SC.SAM.CLOSURE.DATE> < PREV.MNTH:'01' THEN RETURN
*
    IF R.SAM<SC.SAM.DEALER.BOOK> THEN RETURN
    REF.CCY = R.SAM<SC.SAM.REFERENCE.CURRENCY>
    LOOP
        REMOVE ID.SC.POS FROM R.PCS SETTING Y.POS
    UNTIL ID.SC.POS = ""
*
* S - CPF and SRS exclusion for MF    	
    	GOSUB CHECK.MF.CPF.SRS.EXCLUDE
        IF Y.PAY.MODE NE 'CASH' THEN
            CONTINUE
        END
* E - CPF and SRS exclusion for MF
*
        ID.SC.ACT = FIELD(ID.SC.POS,".",1,2):"*":YLASTWRKDAY[1,6]
        READ R.SC.ACT FROM F.SCB.RB.SEC.POS.ACTIVITY, ID.SC.ACT ELSE
*
* Trying to find previous open balance from previous month
*
            ID.SC.ACT.PREV = FIELD(ID.SC.POS,".",1,2):"*"
            ID.SC.ACT.PREV := PREV.MNTH
            READ R.SC.ACT.PREV FROM F.SCB.RB.SEC.POS.ACTIVITY, ID.SC.ACT.PREV THEN
                R.SC.ACT<SC.AT.OPENING.BAL.NO.NOM> = R.SC.ACT.PREV<SC.AT.CLOSING.BAL.NO.NOM>
            END ELSE
                R.SC.ACT<SC.AT.OPENING.BAL.NO.NOM> = 0
            END
        END
*        IF R.SC.ACT<SC.AT.HELD.SINCE> = YTODAY THEN CONTINUE
*
* The field HELD.SINCE indicates that the record has already been
* updated. This might be a re-run due to a crash.
*
        READ R.SP FROM F.SECURITY.POSITION, ID.SC.POS THEN
        DATE.UPDATED = R.SC.ACT<SC.AT.DATE.UPDATED>
		CLOSE.BAL = R.SC.ACT<SC.AT.CLOSING.BAL.NO.NOM>
        IF DATE.UPDATED NE YLASTWRKDAY THEN
            R.SC.ACT<SC.AT.CLOSING.BAL.NO.NOM> = 0
            R.SC.ACT<SC.AT.DATE.UPDATED> = YLASTWRKDAY
        END
        NOMINAL = R.SP<SC.SCP.CLOSING.BAL.NO.NOM>
        SEC.NO = R.SP<SC.SCP.SECURITY.NUMBER>

        IF NOT(NOMINAL) THEN CONTINUE
*
        R.SC.ACT<SC.AT.CLOSING.BAL.NO.NOM> += NOMINAL
		WRITE R.SC.ACT TO F.SCB.RB.SEC.POS.ACTIVITY, ID.SC.ACT
		END
    REPEAT
*
	RETURN
*
*===============================================================
CHECK.MF.CPF.SRS.EXCLUDE:
*------------------------
	Y.SM.ID = FIELD(ID.SC.POS,'.',2,1)
    Y.DEPOSITORY = FIELD(ID.SC.POS,'.',3,1)
    Y.MF.FLAG = ''
    Y.PAY.MODE = 'CASH'
    R.SM = '' ; Y.SM.ERR = ''
	CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SM,F.SECURITY.MASTER,Y.SM.ERR)
	IF R.SM THEN
        Y.MF.FLAG = R.SM<SC.SCM.MUTUAL.FUND>
        IF Y.MF.FLAG EQ 'Y' THEN
    		GOSUB CHECK.DEPO
        END
    END
RETURN
*===============================================================
*----------------------------------------------------------------------------*
* =========
CHECK.DEPO:
* =========
	SEL.LIST = ''
	SEL.LIST = ''
	NO.OF.REC = ''
	ERR.SEL = ''
	CPF.POS = ''
	VAL.POS = ''
    Y.PAY.MODE = ''
	SEL.CMD = 'SELECT ':FN.AEB.SEC.PAR:' WITH DEPOSITORY EQ ':Y.DEPOSITORY
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.SEL)
	
	Y.CPF.ARR = 'CPF-15':@VM:'CPF-OA':@VM:'CPF-SA':@VM:'SRS'
	
	Y.CPF.VAL = FIELD(SEL.LIST,'.',4)
	LOCATE Y.CPF.VAL IN Y.CPF.ARR<1,1> SETTING VAL.POS THEN
		Y.PAY.MODE = Y.CPF.VAL
	END
	ELSE
		Y.PAY.MODE = 'CASH'
	END
RETURN
*----------------------------------------------------------------------
END
