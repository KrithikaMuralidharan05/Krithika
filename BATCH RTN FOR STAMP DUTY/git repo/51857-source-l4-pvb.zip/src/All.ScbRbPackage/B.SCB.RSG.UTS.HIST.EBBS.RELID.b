$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.UTS.HIST.EBBS.RELID(R.DETS.ARR)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------
* Multithread routine to load the EBBS.REL historical table post checking if the REL.ID exists or not.
* 17/01/2023 - Drafted by - Raja Prabhu S
*JIRA REF - CPSGMIG-17731
*----------------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.UTS.HIST.EBBS.RELID.COMMON
    $INSERT I_BATCH.FILES
       
    GOSUB PROCESS
    
RETURN
*-------------
PROCESS:
*-------------
    Y.CUR.PRD = ""
    Y.EBBS.PRD = ""
    
    Y.IN.ID = FIELD(R.DETS.ARR,'|',1)
    Y.PRD.APD = FIELD(R.DETS.ARR,'|',2)
    CHANGE '::' TO @FM IN Y.PRD.APD
    CALL F.READ(FN.SCB.UTS.HIST.EBBS.REL.ID,Y.IN.ID,R.EBBS.RELID,F.SCB.UTS.HIST.EBBS.REL.ID,ERR.PRD)
    IF R.EBBS.RELID THEN
        ISA.CNT = DCOUNT(Y.PRD.APD,@FM)
        FOR I = 1 TO ISA.CNT
            Y.CUR.PRD = Y.PRD.APD<I>
            FIND Y.CUR.PRD IN R.EBBS.RELID SETTING Y.EBBS.POS THEN
                Y.FILE.LOG = Y.CUR.PRD:" - ALREADY EXIST IN THE RECORD - ":Y.IN.ID
                GOSUB FILE.WRITE
            END ELSE
                Y.EBBS.PRD<-1> = Y.CUR.PRD
            END
        NEXT I
        IF Y.EBBS.PRD NE '' THEN
            R.EBBS.RELID = R.EBBS.RELID:@FM:Y.EBBS.PRD
           
            CALL F.WRITE(FN.SCB.UTS.HIST.EBBS.REL.ID,Y.IN.ID,R.EBBS.RELID)
       
            Y.FILE.LOG = Y.IN.ID:" - EXISTING RECORD APPEND TO THE TABLE"
            GOSUB FILE.WRITE
        END
    END ELSE
        R.EBBS.RELID = Y.PRD.APD
           
        CALL F.WRITE(FN.SCB.UTS.HIST.EBBS.REL.ID,Y.IN.ID,R.EBBS.RELID)

        Y.FILE.LOG = Y.IN.ID:" - NEW RECORD WRITTEN TO THE TABLE"
        GOSUB FILE.WRITE
    END
RETURN
*------------------------------------------------
FILE.WRITE:
*---------------------------
    WRITESEQ Y.FILE.LOG APPEND TO Y.NS.FILEPATH ELSE
        CALL OCOMO("WRITE EBBS RELID")
    END
RETURN

END
*------------------------------------------------------------------------------
