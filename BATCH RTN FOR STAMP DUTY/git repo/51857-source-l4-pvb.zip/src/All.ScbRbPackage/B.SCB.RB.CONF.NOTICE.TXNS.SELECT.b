* @ValidationCode : Mjo2MjIzMjk1NTk6SVNPLTg4NTktMToxNjkzOTAxODU5NTA5OjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 05 Sep 2023 13:47:39
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CONF.NOTICE.TXNS.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-34072
* Developed By                   :       1663000
* Developed On                   :       5-Sep-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to fetch transactions for which Contract notes are generated
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 19-Sep-23     1670271          R2W Confirmation Notice has duplicate records
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.DP.XML.ADV.STATUS
    $INSERT I_B.SCB.RB.CONF.NOTICE.TXNS.COMMON
    $INSERT I_F.DE.HEADER
*--------------------------------------------------------------------------------------------
* Select Today's transactions
    SEL.LIST = '' ; SEL.CNT = '' ; SEL.ERR = ''; FIND.DUP.POS=''; DUP.REF.NUMBER=''; FINAL.ARRAY =''
    SEL.CMD = "SELECT ":FN.SCB.DP.XML.ADV.STATUS:" WITH BANK.DATE EQ '":Y.LWD:"' AND COMPANY EQ '" :ID.COMPANY[1,2]:"' AND L.O.B EQ 'RET'"    ;*CPSGMIG-24870
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
	
	LOOP
        REMOVE Y.ADVICE.ID FROM SEL.LIST SETTING FIND.DUP.POS
	WHILE Y.ADVICE.ID:FIND.DUP.POS
        DE.O.HEADER.REC = '' ; DE.O.HEADER.ERR = ''
        CALL F.READ(FN.DE.O.HEADER, Y.ADVICE.ID, DE.O.HEADER.REC, F.DE.O.HEADER, DE.O.HEADER.ERR)
        IF DE.O.HEADER.REC THEN
            DUP.REF.NUMBER = FIELD(DE.O.HEADER.REC<DE.HDR.TRANS.REF>,' ',1)
            LOCATE DUP.REF.NUMBER IN FINAL.ARRAY SETTING REF.POS ELSE
                FINAL.ARRAY<-1> = DUP.REF.NUMBER
            END
        END
	REPEAT
     
	IF FINAL.ARRAY THEN
        CALL BATCH.BUILD.LIST('',FINAL.ARRAY)
	END
	
RETURN
END