$PACKAGE All.ScbRbPackage
*---------------------------------------------------------------------------
* <Rating>135</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE B.SCB.RB.EDM.SUPP.SP.POST
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This is newly introduced singlethreaded job to concatenate all the spring
*   files generated in different sessions under AMEX.FILES.
* Copy of existing SCB.SUPP.SP.DAVINCI.POST, include LOB logic for RB.
*-----------------------------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 28-Jul-2022        Lavanya L       CPSGMIG-4971       Initial Creation
* 01/05/2025 - 1386007 - Haris - Made the routine online by modifing the date.
* 19-May-2025		 Shan			 8115669			Additional CAPE file writing with two more columns
* 28-Nov-2025        Pawan Kr         11437551          CAPE request to map the External Swift message from clearstream with T24 Position

*--------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES

*
    GOSUB INIT
    GOSUB PROCESS
	GOSUB MERGE.CAPE.FILES									;*8115669
*
    RETURN
*
*----------------------------------------------------------------------------
INIT:
*----
*
    FN.AMEX.FILES = 'AMEX.FILES'
	FV.AMEX.FILES = ''
	CALL OPF(FN.AMEX.FILES,FV.AMEX.FILES)
*1386007-S
	FN.DATES='F.DATES'
	F.DATES=''
	CALL OPF(FN.DATES,F.DATES)
	CALL F.READ(FN.DATES,ID.COMPANY,R.DATES.REC,F.DATES,DATE.ERR)
	Y.TODAY=R.DATES.REC<EB.DAT.LAST.WORKING.DAY>
*1386007-E
* TAFJUPD(E)
*	
*	Y.NEXT.WORK.DAY = R.DATES(EB.DAT.NEXT.WORKING.DAY)
*    REP.NAME = 'SCB-':ID.COMPANY[1,2]:'-RB-EDM-SECPOS-':TODAY:'.CSV'				;*CPSGMIG-4971
    REP.NAME = 'SCB-':ID.COMPANY[1,2]:'-RB-EDM-SECPOS-':Y.TODAY:'.CSV'				;*CPSGMIG-4971
*    REP.NAME.ALL = 'SCB-':ID.COMPANY[1,2]:'-RB-EDM-SECPOS-':TODAY:'-'			;*CPSGMIG-4971
    REP.NAME.ALL = 'SCB-':ID.COMPANY[1,2]:'-RB-EDM-SECPOS-':Y.TODAY:'-'			;*CPSGMIG-4971
*   OPEN "AMEX.FILES" TO AMEX.FILES ELSE NULL       ;* TAFJUPD(S/E)

    Y.DELIM = CHAR(01)

    Y.HEADER = ''
*1386007-S/E
*    Y.HEADER = 'H':Y.DELIM:'T24':Y.DELIM:'SG':Y.DELIM:TODAY:@FM
    Y.HEADER = 'H':Y.DELIM:'T24':Y.DELIM:'SG':Y.DELIM:Y.TODAY:@FM
    Y.HEADER := 'D': Y.DELIM :'LinkID' : Y.DELIM : 'Security' : Y.DELIM : 'SAM' : Y.DELIM : 'SAMRefCcy' : Y.DELIM : 'Nominal' : Y.DELIM
    Y.HEADER := 'CostofInvestment' : Y.DELIM : 'AcquisitionDate' : Y.DELIM : 'AccruedInterest' : Y.DELIM
    Y.HEADER := 'CostPrice' : Y.DELIM : 'GrCostRefCcy'      ;* PIDF - S/E
*CPSGMIG-2776 - S	
	Y.HEADER :=  Y.DELIM : 'Value_Dated_Posn': Y.DELIM : 'Value_Dated_Cost': Y.DELIM : 'Val_Dat_Bkcost_Ref': Y.DELIM 
	Y.HEADER := 'Val_Dat_Bkcost_Bse' : Y.DELIM : 'Unsettled_Nom_Cr' : Y.DELIM : 'Unsettled_Nom_Cr'
	Y.HEADER := Y.DELIM :'Pendsubamt': Y.DELIM :'Pendredunit'				;*CPSGMIG-4971 - S/E
*CPSGMIG-2776 - E

*8115669_S
	Y.CAPE.EXT.FILE	= ''
	Y.CAPE.HEADER = ''
	Y.CAPE.EXT.FILE	= 'SCB-':ID.COMPANY[1,2]:'-RB-CAPE-SECPOS-':Y.TODAY:'.CSV'
	Y.CAPE.EXT.SUB.FILES = 'SCB-':ID.COMPANY[1,2]:'-RB-CAPE-SECPOS-':Y.TODAY:'-'
	Y.CAPE.HEADER = Y.HEADER:Y.DELIM:'SafekeepAcc':Y.DELIM:'PledgePosition':Y.DELIM:'DeliveryAdd'
*8115669_E

RETURN
*----------------------------------------------------------------------------
PROCESS:
*-------
*
* TAFJUPG - S - Changing conditional select
*   SEL.CMD = "SELECT AMEX.FILES LIKE ":REP.NAME.ALL:"..."
*   CALL EB.READLIST(SEL.CMD, FILE.LIST,'',FILES.SELECTED,SYS.RET.CODE)

    Y.UDFILE       = 'AMEX.FILES'
    Y.CRITERIA     = REP.NAME.ALL:"*"
    FILE.LIST      = ''
    FILES.SELECTED = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, FILE.LIST, FILES.SELECTED)
* TAFJUPG - E - Changing conditional select
*
    ALL.FILES = ""
    TEMP.ARRAY = ""
    TEMP.ARRAY.SORT = ""
    LOOP
        REMOVE FILE.ID FROM FILE.LIST SETTING MORE.IDS
    WHILE FILE.ID:MORE.IDS
*       READ R.REC FROM AMEX.FILES,FILE.ID ELSE NULL             ;* TAFJUPD(S/E)
* TAFJUPD(S)
        R.FILE.REC = '' ; Y.FILE.REC.ARR = '' 
		CALL F.READ(FN.AMEX.FILES,FILE.ID,R.FILE.REC,FV.AMEX.FILES,Y.FILE.REC.ARR)
		IF R.FILE.REC THEN
			TEMP.ARRAY<-1> = R.FILE.REC
		END
*       DELETE AMEX.FILES,FILE.ID ON ERROR NULL
        CALL F.DELETE(FN.AMEX.FILES,FILE.ID)
* TAFJUPD(E)		
    REPEAT
*
    CONVERT Y.DELIM TO '~' IN TEMP.ARRAY
    SORT.CMD = "-t~ +0 -1 -n"
    CALL SCB.SORT(SORT.CMD,TEMP.ARRAY,TEMP.ARRAY.SORT)
    CONVERT '~' TO Y.DELIM IN TEMP.ARRAY.SORT
*	
	Y.COUNT = DCOUNT(TEMP.ARRAY.SORT,@FM)
	Y.TRAILER = 'T':Y.DELIM:Y.COUNT
    FINAL.ARRAY = Y.HEADER:@FM:TEMP.ARRAY.SORT:@FM:Y.TRAILER

	FINAL.ARRAY = UTF8(FINAL.ARRAY)
     CALL F.WRITE(FN.AMEX.FILES,REP.NAME,FINAL.ARRAY)
* TAFJUPD(E)	 
*
     RETURN
*-----------------------------------------------------------------------------------------------------------------------------
MERGE.CAPE.FILES:
*----------------

    Y.UDFILE = 'AMEX.FILES'
    Y.CAPE.CRITERIA = Y.CAPE.EXT.SUB.FILES:"*"
    Y.CAPE.FILES = ''
    Y.CAPE.FILES.SELECTED = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CAPE.CRITERIA, Y.CAPE.FILES, Y.CAPE.FILES.SELECTED)
*
    Y.TEMP.ARRAY.CAPE = ''
    Y.TEMP.ARRAY.SORT.CAPE = ''
	Y.MORE.CAPE.IDS = ''
	Y.CAPE.FILE.ID = ''
	Y.CAPE.TRAILER = ''
	Y.CAPE.COUNT = ''
	Y.CAPE.FINAL.ARRAY = ''
	
    LOOP
        REMOVE Y.CAPE.FILE.ID FROM Y.CAPE.FILES SETTING Y.MORE.CAPE.IDS
    WHILE Y.CAPE.FILE.ID:Y.MORE.CAPE.IDS
        R.CAPE.FILE.REC = '' ; Y.CAPE.FILE.ERR = '' 
		CALL F.READ(FN.AMEX.FILES,Y.CAPE.FILE.ID,R.CAPE.FILE.REC,FV.AMEX.FILES,Y.CAPE.FILE.ERR)
		IF R.CAPE.FILE.REC THEN
			Y.TEMP.ARRAY.CAPE<-1> = R.CAPE.FILE.REC
		END
        CALL F.DELETE(FN.AMEX.FILES,Y.CAPE.FILE.ID)
    REPEAT
*
    CONVERT Y.DELIM TO '~' IN Y.TEMP.ARRAY.CAPE
    SORT.CMD = "-t~ +0 -1 -n"
    CALL SCB.SORT(SORT.CMD,Y.TEMP.ARRAY.CAPE,Y.TEMP.ARRAY.SORT.CAPE)
    CONVERT '~' TO Y.DELIM IN Y.TEMP.ARRAY.SORT.CAPE
*	
	Y.CAPE.COUNT = DCOUNT(Y.TEMP.ARRAY.SORT.CAPE,@FM)
	Y.CAPE.TRAILER = 'T':Y.DELIM:Y.CAPE.COUNT
    Y.CAPE.FINAL.ARRAY = Y.CAPE.HEADER:@FM:Y.TEMP.ARRAY.SORT.CAPE:@FM:Y.CAPE.TRAILER
	Y.CAPE.FINAL.ARRAY = UTF8(Y.CAPE.FINAL.ARRAY)
    * CHANGE Y.DELIM TO "|" IN Y.CAPE.FINAL.ARRAY
    CALL F.WRITE(FN.AMEX.FILES,Y.CAPE.EXT.FILE,Y.CAPE.FINAL.ARRAY)
	 
RETURN
*-------------------------------------------------------------------------------------------------
END
