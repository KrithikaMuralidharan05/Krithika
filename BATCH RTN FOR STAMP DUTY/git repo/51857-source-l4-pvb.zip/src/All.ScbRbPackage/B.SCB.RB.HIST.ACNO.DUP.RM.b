$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.HIST.ACNO.DUP.RM(SEL.IDS)
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Remove Duplicate Txn Ids from SCB.UTS.HIST.PROD.ACNO Table.
*
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 21-Nov-2023 - ADO-2100833 - kalaikumaranp- Remove Duplicate Txn Ids from SCB.UTS.HIST.PROD.ACNO Table.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.RB.HIST.ACNO.DUP.RM.COMMON
    CALL OCOMO("Processing ":SEL.IDS)
    GOSUB INIT
    GOSUB PROCESS
    
*    CLOSESEQ F.AMEX.FILES
    
 RETURN
 *-----------------------------------------------------------------------------
 INIT:
*---
	FILE.NAME = 'ISALIST.TXT-':SESSION.NO
*    TXN.FILE.NAME = 'DUPTXN.TXT-':SESSION.NO
*    OPENSEQ AMEX.FILES,TXN.FILE.NAME TO F.CCMS.FILES ELSE CREATE F.CCMS.FILES ELSE              ;*Dayzero Fix
*        CALL OCOMO("Error opening ":TXN.FILE.NAME)
*        CALL FATAL.ERROR("B.SCB.PRODTYPE.SPEED.EXT")
*    END
   
 RETURN
 *-----------------------------------------------------------------------------
 PROCESS:
 *-------
 			Y.HIS.PROD.ACC = SEL.IDS
 			GOSUB GET.HIST.PROD.AC.DETS
            R.HIS.PRD.TXN.DETS.DUP.RM = ''
            Y.ISA.ACC.NO=''
            Y.DUP.CHK = ''
            LOOP
            REMOVE Y.HIS.PRD.TXN.ID FROM R.SCB.HIS.PROD.AC.DETS SETTING HIS.TXN.POS
            WHILE Y.HIS.PRD.TXN.ID:HIS.TXN.POS
            	LOCATE Y.HIS.PRD.TXN.ID IN R.HIS.PRD.TXN.DETS.DUP.RM<1> SETTING TXN.POS THEN
                	IF Y.DUP.CHK EQ '' THEN
                        Y.DUP.CHK = '1'
                        CALL OCOMO("Duplicate ISA Found":Y.HIS.PROD.ACC)
                    END
            	END ELSE
                    R.HIS.PRD.TXN.DETS.DUP.RM<-1> = Y.HIS.PRD.TXN.ID
                END
            REPEAT
        	IF R.HIS.PRD.TXN.DETS.DUP.RM AND Y.DUP.CHK THEN
                WRITE R.HIS.PRD.TXN.DETS.DUP.RM TO F.SCB.UTS.HIST.PROD.ACNO,Y.HIS.PROD.ACC
                CALL OCOMO("Processing Actual File":Y.HIS.PROD.ACC)
                OPENSEQ AMEX.FILES,FILE.NAME TO F.CCMS.FILES ELSE CREATE F.CCMS.FILES ELSE              ;*Dayzero Fix
        			CALL OCOMO("Error opening ":FILE.NAME)
        			CALL FATAL.ERROR("B.SCB.RB.HIST.ACNO.DUP.RM")
     			END
            	WRITESEQ Y.HIS.PROD.ACC APPEND TO F.CCMS.FILES ELSE
    				CALL FATAL.ERROR('Unable to write ':F.CCMS.FILES)
    			END
            	CALL OCOMO("Duplicate ISA Written":Y.HIS.PROD.ACC)
            	CLOSESEQ F.CCMS.FILES
            END
 
 RETURN
 *-----------------------------------------------------------------------------
 GET.HIST.PROD.AC.DETS:
*---------------------
	R.SCB.HIS.PROD.AC.DETS = '' ; ERR.HIS.PROD.AC = ''
    
    CALL F.READ (FN.SCB.UTS.HIST.PROD.ACNO,Y.HIS.PROD.ACC,R.SCB.HIS.PROD.AC.DETS,F.SCB.UTS.HIST.PROD.ACNO,ERR.HIS.PROD.AC)
    
RETURN
*-----------------------------------------------------------------------------*
 END   