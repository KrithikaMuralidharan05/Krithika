$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.RB.ENT.ADVICE.1530(MAT HANDOFF.REC,ERR.MSG)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Vinothkumar M(1519171)
* CPSGMIG-775
* New Routine attached into DE.MAPPING of 1530.SC.003
* AEB.SET.SC.ISIN - Its an existing routine which is already attached into DE.MAPPING>1530.SC.003
* This routine will be triggered first and do the mapping as per PVB BAU.
* This new routine will execute the flow only if the customer is RB
* CPSGMIG-5868- Usage of LR.RB.EX.DATE field instead of EX.DATE for RB clients.
* Cross Compilation for CPSGMIG-775
* 10/10/22 - CPSGMIG -14110 -Ananthy.S - Convert UTS Description from @SM to null.
* 20/10/22-CPSGMIG-14695-1389710-Trans type is Populated if the Diary type is Coupon and Product is SN.
* 20/10/22-CPSGMIG-14870--1389710-Trans type is Populated if the Diary type is DIVIDEND and Product is funds.
* 23/10/22-CPSGMIG-14686-1389710-Formatting Y.FIN.DATE.
* 30/10/22-CPSGMIG-15075-1389710-DIVIDENDS for FI should pick FI Coupon Template
* 10/08/23-CPSGMIG-32375-1648769-Rel ID Delimiters needs to be fixed from '-' to ':' for Joint Accounts.
* 28/11/25 - ADO-10849423 - Prithi Koppolu - Removal of T24 security master code from Asset Name in RBSG Contract Notes
*-----------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.DIARY.TYPE
    $INSERT I_F.DIARY
    $INSERT I_F.DE.HEADER
    
* PVB mapping routine as is
    CALL AEB.SET.SC.ISIN(MAT HANDOFF.REC,ERR.MSG)
*
    IF ID.COMPANY[1,2] NE "SG" THEN
        RETURN    ;*  to be impacted only from Singapore company
    END
* Below mapping change applys to only SNG company trades
    IF HANDOFF.REC(10)<1> EQ '1530.SC.003' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
RETURN
*----*
INIT:
*-----
    Y.CUSTOMER.NO = FIELD(R.NEW(SC.ENT.PORTFOLIO.NO),'-',1)
    Y.SECURITY.NO = R.NEW(SC.ENT.SECURITY.NO)
*
    FnClientOutputParam= 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    FClientOutputParam = ''
    CALL OPF(FnClientOutputParam,FClientOutputParam)
*
    FnSecAccMaster = 'F.SEC.ACC.MASTER'
    FSecAccMaster  = ''
    CALL OPF(FnSecAccMaster,FSecAccMaster)
*
    FN.DIARY.TYPE = 'F.DIARY.TYPE'
    F.DIARY.TYPE  = ''
    CALL OPF(FN.DIARY.TYPE,F.DIARY.TYPE)
*
    FN.DIARY = 'F.DIARY'
    F.DIARY  = ''
    CALL OPF(FN.DIARY,F.DIARY)
*
    FnSecMaster = 'F.SECURITY.MASTER'
    FSecMaster = ''
    CALL OPF(FnSecMaster,FSecMaster)
    

*
    YAppName = 'CUSTOMER':@FM:'SECURITY.MASTER':@FM:'ENTITLEMENT':@FM:'DIARY'
    YFldName = 'L.O.B':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.EBBS.REL':@FM:'LR.UTS.INS.DESC':@FM:'LR.REC.CASA.ACC':@FM:'LR.RB.EX.DATE':@VM:'LR.COUP.PRD.FRM':@VM:'LR.COUP.PRD.TO'
    YFldPos = ""
    CALL MULTI.GET.LOC.REF(YAppName,YFldName,YFldPos)
    YLobPos          = YFldPos<1,1>
    YStfPos          = YFldPos<1,2>
    YPfolPos         = YFldPos<1,3>
    YEbbsRelIdpos    = YFldPos<1,4>
    YUtsPos          = YFldPos<2,1>
    YRecCasaAccPos   = YFldPos<3,1>
    Y.RB.EX.DATE.POS = YFldPos<4,1>
    Y.COUP.FROM.POS  = YFldPos<4,2>
    Y.COUP.TO.POS    = YFldPos<4,3>
*
* Nullify the values
    ClientIdentifier  = ''
    AdviceId          = ''
    ConsolId          = ''
    R2wFolder         = ''
    DelMode           = ''
    DisclaimerId      = ''
    ConfNotice        = ''
    ReversalFlag      = ''
    PriAcctHolder     = ''
    JntHolder         = ''
    yDescName         = ''
    Y.TRANS.TYPE      = ''
    Y.QUALIFY.HOLDING = ''
    Y.NOMINAL         = ''
    Y.ISIN            = ''
    Y.PAY.DATE        = ''
    Y.EX.DATE         = ''
    Y.TRANS.TYPE      = ''
    Y.DIARY.TYPE      = ''
    Y.ENT.ID          = ''
    Y.CURRENCY        = ''
    Y.NET.AMOUNT      = ''
    Y.PRICE           = ''
    Y.VALUE.DATE      = ''
    Y.DIARY.RATE      = ''
    Y.ACCR.START.DATE = ''
    Y.INT.PAY.DATE    = ''
    Y.FIN.DATE        = ''
    Y.TAX.CREDIT      = ''
    Y.GROSS.AMT       = ''
    Y.COUP.DIV.RATE   = ''
    Y.DIARY.PERC      = ''
* Fetch LOB value
    FN.CUST = 'F.CUSTOMER'
    F.CUST = ''
    CALL OPF(FN.CUST,F.CUST)
*
    CALL F.READ(FN.CUST,Y.CUSTOMER.NO,R.CUST,F.CUST,CUST.ERR)
    L.O.B             = R.CUST<EB.CUS.LOCAL.REF,YLobPos>
    LR.PFOLIO.KEY.VAL = R.CUST<EB.CUS.LOCAL.REF,YPfolPos>
    PriAcctHolder     = FIELD(LR.PFOLIO.KEY.VAL,':',1)
    JntHolder         = LR.PFOLIO.KEY.VAL
    CHANGE ':' TO '|' IN JntHolder
* As per the new logic for cleint Identifier provided as on 20220208
    STAFF.IND = R.CUST<EB.CUS.LOCAL.REF,YStfPos>
*
    BEGIN CASE
        CASE R.CUST<EB.CUS.SECTOR> EQ "21"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "23"
            YY.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
*
RETURN
*------*
PROCESS:
*------*
* Get the list of PVB LOB
    Y.PARAM.ID =''; Y.ALLOW.SEG ='PVB'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    IF L.O.B MATCHES Y.ALLOWED.LOB THEN
        RETURN   ;* As the customer is private return, no need of further processing and mapping
    END ELSE
        ERR.MSG = ''           ;*If any error w.r.t PVB mapping routine can be ignored as we have all tags mapping below which r not liasing with Pb rtn
    END
    GOSUB GET.REQ.FIELDS        ;* Fetch the necessary field values from trade sm and param tables
*
    IF YNomineeCode EQ '' THEN
        Lending = 'No'
    END ELSE
        Lending = 'Yes'
    END
*
    Y.ENT.REC = HANDOFF.REC(2)
    Y.DEL.KEY = Y.ENT.REC<146>
Y.DEL.KEY = FIELD(Y.DEL.KEY,@VM,1)    
Y.BANK.DATE = Y.DEL.KEY[2,8]
*
    Y.RECORD.STATUS = R.NEW(SC.ENT.RECORD.STATUS)
    IF (YRevFlg EQ '1') OR (Y.RECORD.STATUS[1,1] EQ "R") THEN
        YRevFlgValue = 'REVE'
        BEGIN CASE
            CASE Y.BANK.DATE EQ TODAY
                ReversalFlag = 'SAME'
            CASE Y.BANK.DATE NE TODAY
                ReversalFlag = 'NEXT'
        END CASE
    END ELSE
        YRevFlgValue ='AUTH'
    END
*
    IF ProductGrp NE '' THEN
        GOSUB GET.ADVICE.FIELD.VALUE
        BEGIN CASE
            CASE ProductGrpValue EQ 'FIXEDINCOME'
                YAssetName = yDescName
            CASE  ProductGrpValue EQ 'FUNDS'            ;* Fetch values w.r.t to MF
                GOSUB GET.FUND.VALUE
            CASE  ProductGrpValue EQ 'STRUCTUREDPRODUCTS'               ;*Fetch values w.r.t to SN
                YAssetName = yDescName
        END CASE
    END
    GOSUB UPDATE.USR.DEF.VALUE                     ;*Assign the values arrived to Handoff record
RETURN
*-------------*
GET.REQ.FIELDS:
*--------------*
** Values from Entitlement
    Y.ENT.ID          = ID.NEW
    YNomineeCode      = FIELD(Y.ENT.ID,'.',4)
    Y.QUALIFY.HOLDING = R.NEW(SC.ENT.QUALIFY.HOLDING)
    Y.CURRENCY        = R.NEW(SC.ENT.CURRENCY)
    Y.NET.AMOUNT      = R.NEW(SC.ENT.NET.AMOUNT)
    Y.LR.REC.CASA.ACC = R.NEW(SC.ENT.LOCAL.REF)<1,YRecCasaAccPos>
    Y.NOMINAL         = R.NEW(SC.ENT.NOMINAL)<1,1>
    Y.PRICE           = R.NEW(SC.ENT.PRICE)<1,1>
    Y.VALUE.DATE      = R.NEW(SC.ENT.VALUE.DATE)
    Y.TAX.CREDIT      = R.NEW(SC.ENT.TAX.CREDIT)
    Y.GROSS.AMT       = Y.NET.AMOUNT - Y.TAX.CREDIT
*
** Logic to form the Asset Name
    CALL F.READ(FnSecMaster,Y.SECURITY.NO,RSecurityMaster,FSecMaster,YSecErr)
    Y.SM.DESCRIPTION  = RSecurityMaster<SC.SCM.DESCRIPT>
    YSmNewDescription = RSecurityMaster<SC.SCM.LOCAL.REF,YUtsPos>
    Y.ACCR.START.DATE = RSecurityMaster<SC.SCM.ACCRUAL.START.DATE>
    Y.INT.PAY.DATE    = RSecurityMaster<SC.SCM.INT.PAYMENT.DATE>
*
    *IF Y.ACCR.START.DATE AND Y.INT.PAY.DATE THEN
    *   Y.FIN.DATE = OCONV(ICONV(Y.ACCR.START.DATE,"D"),"D"):' TO ': OCONV(ICONV(Y.INT.PAY.DATE,"D"),"D") ; * CPSGMIG-14686(S/E)
    *END
*
	IF YSmNewDescription THEN
        yDescName = YSmNewDescription                  ;* As per new mapping on 21 Feb 2022 Client Advice impacts
    END ELSE
*CPSGMIG -14110(S)
*        Y.DESC.CNT = DCOUNT(Y.SM.DESCRIPTION,@VM)
*        CNT = 1
*        LOOP
*        WHILE CNT LE Y.DESC.CNT
*            yDescName<-1> = Y.SM.DESCRIPTION<1,CNT,1>
*            CNT = CNT + 1
*        REPEAT
*        CHANGE @FM TO ' ' IN yDescName
        yDescName = Y.SM.DESCRIPTION
    END

    CHANGE @SM TO '' IN yDescName
*CPSGMIG -14110(E)
*
    Y.ISIN = RSecurityMaster<SC.SCM.I.S.I.N.>
    YInvestType = RSecurityMaster<SC.SCM.INVEST.OPTION.TYPE>
*
** Logic to get the Product Group
    CALL SCB.GET.PRODUCT.API(Y.SECURITY.NO, ProductGrp) ;* Get the Product Type FI SN or Funds
*
** Get the Diary Details
    R.DIARY = ''; ERR.DIARY = ''
    Y.DIARY.ID     = FIELD(Y.ENT.ID,'.',1)
    CALL F.READ(FN.DIARY,Y.DIARY.ID,R.DIARY,F.DIARY,ERR.DIARY)
    Y.PAY.DATE     = R.DIARY<SC.DIA.PAY.DATE>
    Y.EX.DATE      = R.DIARY<SC.DIA.LOCAL.REF><1,Y.RB.EX.DATE.POS>  ;* CPSGMIG-5868(S/E)
    Y.DIARY.TYPE   = R.DIARY<SC.DIA.EVENT.TYPE>
    Y.DIARY.RATE   = R.DIARY<SC.DIA.RATE,1>
    Y.DIARY.PERC   = R.DIARY<SC.DIA.PERCENTAGE>
    Y.COUP.FR.DATE = R.DIARY<SC.DIA.LOCAL.REF><1,Y.COUP.FROM.POS>
    Y.COUP.TO.DATE = R.DIARY<SC.DIA.LOCAL.REF><1,Y.COUP.TO.POS>

    IF Y.COUP.FR.DATE AND Y.COUP.TO.DATE THEN
       	Y.FIN.DATE = OCONV(ICONV(Y.COUP.FR.DATE,"D"),"D"):' TO ': OCONV(ICONV(Y.COUP.TO.DATE,"D"),"D") ; * CPSGMIG-18087(S/E)
    END

    IF Y.DIARY.TYPE THEN
        R.DIARY.TYPE = ''; ERR.DIARY.TYPE = ''
        CALL F.READ(FN.DIARY.TYPE,Y.DIARY.TYPE,R.DIARY.TYPE,F.DIARY.TYPE,ERR.DIARY.TYPE)
        Y.TRANS.TYPE = R.DIARY.TYPE<SC.DRY.EVENT.DESC,1>
    END
*
** Other Values
    YRevFlg = HANDOFF.REC(4)<1> ;* Hold the reversal Flag
*
RETURN
*---------------------*
GET.ADVICE.FIELD.VALUE:
*---------------------*
    ProductGrpValue = TRIM(ProductGrp," ","A")
    ProductGrpValue = UPCASE(ProductGrpValue)
*CPSGMIG-15075(S)
    IF ProductGrpValue EQ 'FIXEDINCOME' AND Y.DIARY.TYPE EQ 'DIVIDENDS' THEN
        Y.DIARY.TYPE = 'COUPON'
        Y.TRANS.TYPE = Y.DIARY.TYPE
    END
*CPSGMIG-15075(E)
    YRecID = APPLICATION:"-":ProductGrpValue:"-":Y.DIARY.TYPE
    CALL F.READ(FnClientOutputParam,YRecID,RClientOutputParam,FClientOutputParam,YAdviceErr)
    EventTypeArr = RClientOutputParam<SC.CO.EVENT.TYPE>
    CHANGE @VM TO @FM IN EventTypeArr
*
    LOCATE YRevFlgValue IN EventTypeArr SETTING AdvPos THEN
        AdviceId     = RClientOutputParam<SC.CO.ADVICE.ID,AdvPos>
        ConsolId     = RClientOutputParam<SC.CO.CONSOL.ID,AdvPos>
        DisclaimerId = RClientOutputParam<SC.CO.DISCLAMIER.ID,AdvPos>
        ConfNotice   = RClientOutputParam<SC.CO.CONFIRMATION.NOTICE,AdvPos>
        DelMode      = RClientOutputParam<SC.CO.DELIVERY.MODE,AdvPos>
    END
    CALL SCB.CLIENTIDEN.R2WFOLD.RTN(YY.CLIENT.IDENTIFIER,R2wFolder)
RETURN
*-------------*
GET.FUND.VALUE:
*--------------*
    IF YInvestType NE '' THEN
        YInvestOption = 'INVEST.OPTION'
        CALL F.READ(FnClientOutputParam,YInvestOption,RInvestLocalParam,FClientOutputParam,YInvestErr)
        InvestFieldName = RInvestLocalParam<SC.CO.FIELD.NAME>

        LOCATE YInvestType IN InvestFieldName<1,1> SETTING YInvestPos THEN
            YDepoAsset = RInvestLocalParam<SC.CO.FIELD.SUB.VALUE,YInvestPos>
        END
    END
*
    IF YDepoAsset NE '' THEN
        YAssetName = yDescName:' ':YDepoAsset
    END ELSE
        YAssetName = yDescName
    END

RETURN
*--------------------*
UPDATE.USR.DEF.VALUE:
*--------------------*
*
    *YAssetName = Y.SECURITY.NO:' ':YAssetName ;* Asset name should be prefixed with Security No CPSGMIG-4914
	YAssetName = YAssetName ;* ADO-10849423 - (s/e)
    HANDOFF.REC(9)<1> = YY.CLIENT.IDENTIFIER
    HANDOFF.REC(9)<2> = ConsolId
    HANDOFF.REC(9)<3> = AdviceId
    HANDOFF.REC(9)<4> = ConfNotice
    HANDOFF.REC(9)<5> = R2wFolder
    HANDOFF.REC(9)<6> = PriAcctHolder
    HANDOFF.REC(9)<7> = JntHolder
    HANDOFF.REC(9)<8> = Y.ENT.ID
    HANDOFF.REC(9)<9> = Y.TRANS.TYPE
    HANDOFF.REC(9)<10> = YAssetName
    HANDOFF.REC(9)<11> = Y.ISIN
    HANDOFF.REC(9)<12> = ProductGrp
    HANDOFF.REC(9)<13> = Lending
    HANDOFF.REC(9)<18> = DisclaimerId
    HANDOFF.REC(9)<19> = "TNO"
*
    BEGIN CASE
        CASE Y.DIARY.TYPE EQ 'DIVIDENDS'
            HANDOFF.REC(9)<14> = Y.VALUE.DATE
            HANDOFF.REC(9)<15> = Y.QUALIFY.HOLDING
            HANDOFF.REC(9)<16> = Y.DIARY.RATE
            HANDOFF.REC(9)<17> = Y.CURRENCY
            HANDOFF.REC(9)<20> = Y.NET.AMOUNT
            HANDOFF.REC(9)<21> = Y.LR.REC.CASA.ACC
*CPSGMIG-14870(S)
            IF ProductGrpValue EQ 'FUNDS' THEN
                HANDOFF.REC(9)<9> = 'Cash Dividend'
            END
*CPSGMIG-14870(E)
        CASE Y.DIARY.TYPE EQ 'COUPON'
            IF ProductGrpValue EQ 'STRUCTUREDPRODUCTS' THEN
                HANDOFF.REC(9)<22> = Y.VALUE.DATE
                HANDOFF.REC(9)<23> = Y.QUALIFY.HOLDING
                HANDOFF.REC(9)<24> = Y.CURRENCY
                HANDOFF.REC(9)<25> = Y.NET.AMOUNT
                HANDOFF.REC(9)<26> = Y.LR.REC.CASA.ACC
                HANDOFF.REC(9)<9> = "INTEREST PAYMENT" ;*CPSGMIG-14695(S/E)
            END
            IF ProductGrpValue EQ 'FIXEDINCOME' THEN
                IF Y.DIARY.PERC EQ 'NO' THEN
                    Y.COUP.DIV.RATE = Y.DIARY.RATE/100
                END ELSE
                    Y.COUP.DIV.RATE = Y.DIARY.RATE
                END
                HANDOFF.REC(9)<27> = Y.CURRENCY
                HANDOFF.REC(9)<28> = Y.VALUE.DATE
                HANDOFF.REC(9)<29> = Y.FIN.DATE
                HANDOFF.REC(9)<30> = Y.QUALIFY.HOLDING
                HANDOFF.REC(9)<31> = Y.COUP.DIV.RATE
                HANDOFF.REC(9)<32> = Y.GROSS.AMT
                HANDOFF.REC(9)<33> = Y.TAX.CREDIT
                HANDOFF.REC(9)<34> = Y.NET.AMOUNT
                HANDOFF.REC(9)<35> = Y.LR.REC.CASA.ACC
            END
    END CASE
    HANDOFF.REC(9)<36> = ReversalFlag
RETURN
END