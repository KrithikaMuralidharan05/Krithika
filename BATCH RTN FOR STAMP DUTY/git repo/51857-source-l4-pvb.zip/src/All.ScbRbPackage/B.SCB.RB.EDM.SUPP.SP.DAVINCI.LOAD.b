$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------------------------------------------------------
   SUBROUTINE B.SCB.RB.EDM.SUPP.SP.DAVINCI.LOAD
*-----------------------------------------------------------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This is a new multithreaded job introduced for improving the COB performance
*  as the replacement of the single threaded routine SCB.SUPPLEMENTARY.SP.DAVINCI.
* Copy of existing SCB.SUPPLEMENTARY.SP.DAVINCI.LOAD, include LOB logic for RB.
*-----------------------------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 28-Jul-2022        Lavanya L       CPSGMIG-4971       Initial Creation
* 01/05/2025         Haris -          1386007           Made the routine online by modifing the date.
* 19-May-2025	     Shan             8115669		Included two additional fields for CAPE
* 28-Nov-2025        Pawan Kr         11437551          CAPE request to map the External Swift message from clearstream with T24 Position
*-----------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.DATES
    $INSERT I_B.SCB.RB.EDM.SUPP.SP.DAVINCI.COMMON
    
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM ;*11437551_S/E
*
    GOSUB INIT
    GOSUB OPEN.FILES
*
    RETURN
*-----------------------------------------------------------------------------------------------------------------------------
INIT:
*----
*
    Y.COMPANY.ID = ID.COMPANY[1,2]
    IF ID.COMPANY EQ 'CH2920660' THEN
        Y.COMPANY.ID = 'MC'
    END
    F.OUT.FILE = ''
    Y.DELIM = CHAR(01)
*CPSGMIG-4971 - S
*1386007-S	
	FN.DATES='F.DATES'
	F.DATES=''
	CALL OPF(FN.DATES,F.DATES)
	CALL F.READ(FN.DATES,ID.COMPANY,R.DATES.REC,F.DATES,DATE.ERR)
	Y.TODAY=R.DATES.REC<EB.DAT.LAST.WORKING.DAY>
*    REP.NAME = 'SCB-':Y.COMPANY.ID:'-RB-EDM-SECPOS-':TODAY:'-':SESSION.NO:'.CSV'
    REP.NAME = 'SCB-':Y.COMPANY.ID:'-RB-EDM-SECPOS-':Y.TODAY:'-':SESSION.NO:'.CSV'
*1386007-E
	Y.APP = 'CUSTOMER'
	Y.FLD = 'L.O.B'
	Y.POS = ''
	CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)
	Y.LOB.POS = Y.POS<1,1>
	
	Y.PARAM.ID    = 'SCB.CUST.SEG'	
    Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
    Y.ALLOWED.LOB = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
	
	Y.SATPARAM.ID    = 'SCB.CRES.SAT'	
    Y.ALLOW.SNSAT  = 'SN'			;* Only FI SAT codes
    Y.ALLOWED.SNSAT = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.SATPARAM.ID,Y.ALLOW.SNSAT,Y.ALLOWED.SNSAT)
	
	Y.ALLOW.FISAT  = 'FI'			;* Only FI SAT codes
    Y.ALLOWED.FISAT = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.SATPARAM.ID,Y.ALLOW.FISAT,Y.ALLOWED.FISAT)
**CPSGMIG-4971 - E

*8115669_S
	Y.CAPE.OUT.FILE = ''
	Y.CAPE.EXT.FILE	= ''
	Y.CAPE.EXT.FILE	= 'SCB-':Y.COMPANY.ID:'-RB-CAPE-SECPOS-':Y.TODAY:'-':SESSION.NO:'.CSV'
*8115669_E

    RETURN
*-----------------------------------------------------------------------------
OPEN.FILES:
*----------
*
    FN.SC.POS.ASSET = 'F.SC.POS.ASSET'
    F.SC.POS.ASSET = ''
    CALL OPF(FN.SC.POS.ASSET,F.SC.POS.ASSET)
*
    FN.SECURITY.POSITION = 'F.SECURITY.POSITION'
    F.SECURITY.POSITION = ''
    CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)
*
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
    FN.SUB.ASSET.TYPE = 'F.SUB.ASSET.TYPE'
    F.SUB.ASSET.TYPE = ''
    CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
**CPSGMIG-4971 - S
	FN.CUSTOMER = 'F.CUSTOMER'
	F.CUSTOMER = ''
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)
	
	FN.PEND.TRANS = 'F.SCB.RB.PENDING.TRANSACTION'
	F.PEND.TRANS = ''
	CALL OPF(FN.PEND.TRANS,F.PEND.TRANS)
*CPSGMIG-4971 - E

    AMEX.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME('AMEX.FILES','',AMEX.PATH)

*11437551_S
  fnScbWmHLocalParam = "F.SCB.WM.H.LOCAL.PARAM"
  fScbWmHLocalParam = ""
  CALL OPF(fnScbWmHLocalParam,fScbWmHLocalParam)
  
  yParamId = "CAPE.DEPO.SUBACCOUNT"
  CALL F.READ(fnScbWmHLocalParam,yParamId,rLocalRec,fScbWmHLocalParam,paramError)

        yDepoSubAcntValue = RAISE(rLocalRec<SCBWM.PRM.FIELD.VALUE>)
        yDepoCode = RAISE(rLocalRec<SCBWM.PRM.FIELD.NAME>)

  fnDeAddress = "F.DE.ADDRESS"
  fDeAddress = ""
  CALL OPF(fnDeAddress,fDeAddress)

*11437551_E
  RETURN
*------------------------------------------------------------------------------------------------------------------------------  
END
