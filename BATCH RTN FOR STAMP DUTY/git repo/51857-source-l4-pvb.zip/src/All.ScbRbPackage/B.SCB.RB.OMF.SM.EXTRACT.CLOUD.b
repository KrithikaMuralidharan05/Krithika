$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.OMF.SM.EXTRACT.CLOUD
*--------------------------------------------------------------------------------------------
* Project Name  : BAU
* Developed By  : 1602155
* Developed On  : 19 Nov 2024
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Routine to handle the PCAT file transfer, based on the flow identifier mentioned in the
* BATCH record.
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES

    GOSUB INITIALISE
	GOSUB FILE.TRANSFER
	 
RETURN
*---------*
INITIALISE:
*---------*
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    Y.SM.FILE.ID    = 'T24_SG_PCAT_File_'
*   Y.TIMEDATE.STP = TIMEDATE()
	L.WORK.DATE = OCONV(DATE(),'D-') ;*MM-DD-YYYY
    Y.DATE = L.WORK.DATE[7,4]:L.WORK.DATE[1,2]:L.WORK.DATE[4,2]
*   Y.TIMESTAMP = Y.DATE:Y.TIMEDATE.STP[1,8]
*	CHANGE ":" TO "" IN  Y.TIMESTAMP
    FILE.ID1 = Y.SM.FILE.ID:Y.DATE
*   Y.FINAL.FILE.ID = Y.SM.FILE.ID:Y.TIMESTAMP:".csv"
*
    Y.UDFILE = ''; Y.CRITERIA = '';FILE.LIST = '';FILES.SELECTED = ''
    K = '' ; L = '' ; Y.F = '' ; Y.F1 = '' ; Y.F2 = ''
    Y.UDFILE = 'F.AMEX.FILES'
    Y.CRITERIA = FILE.ID1:'*'
    
    CALL SCB.UDLIST(Y.UDFILE,Y.CRITERIA, FILE.LIST, FILES.SELECTED)

	FOR K = 1 TO FILES.SELECTED
		Y.F = FIELD(FILE.LIST<K>,'_',5)
		Y.F1 = FIELD(Y.F,'.',1)
        Y.F1 = Y.F1[6]
		IF Y.F1 GT Y.F2 THEN
		    Y.F2 = Y.F1
			L = K
		END
	NEXT K

    Y.FINAL.FILE.ID = FILE.LIST<L>
*
RETURN
*---------------------------------------------------------------------------------------------------------------------------------
FILE.TRANSFER:
*-------------
*
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = '';Y.CNT = '';
    AMEXPATH = '';EXE.CMD = '';TMP.COPY.PATH = ''
*
    Y.CNT = DCOUNT(BATCH.DETAILS<3,1>, @SM)
*
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
    FILE.NAME = AMEXPATH
    RECORD.NAME = Y.FINAL.FILE.ID
    TARGET.FILE.NAME = Y.FINAL.FILE.ID
    
* Take a copy of the original PCAT file before encryption

    TMP.COPY.PATH = "/t24/prod/Temenos/T24/bnk/bnk.interface/mwaredupfiles"
    EXE.CMD = "SH -c 'cp ":AMEXPATH:"/":Y.FINAL.FILE.ID:" ":TMP.COPY.PATH:"/":Y.FINAL.FILE.ID:"'"
    CALL OCOMO("Copy command from T24 Src path to Temporary Path :- ":EXE.CMD)
    EXECUTE EXE.CMD
*
    FOR I = 1 TO Y.CNT
		FLOW.IDENTIFER.ID = BATCH.DETAILS<3,1,I>
        CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'')
        SLEEP 60
	NEXT I
*
RETURN
END