* @ValidationCode : MjotMjcyNzAxODk4OklTTy04ODU5LTE6MTY4MjQyNDIxMzc3MDoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 25 Apr 2023 17:33:33
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.MTM.BOOKBUILD.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14087 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       16 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .POST Routine to extract Unsettled Trades
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 13-Mar-2023   1663000          CPSGMIG-21143 - Include ClientIdentifier & PrimaryAccountHolder columns
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename Change
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
	GOSUB PROCESS
	 
RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.TXN.FINAL.FILE    = BATCH.DETAILS<3,1>
    
    Y.LWD            = R.DATES(EB.DAT.LAST.WORKING.DAY)            ;* CPSGMIG-21498
    Y.TXN.FINAL.FILE = EREPLACE(Y.TXN.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498

RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.TXN.ARR = '' ; Y.FINAL.TXN.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = "SCBMTMBOOKBUILD-" :TODAY:"-*.csv*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    LOOP
        REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
    WHILE Y.SEL.ID : SEL.POS
        
        R.AMEX.FILE = '' ; AMEX.ERR = ''
        CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
        IF NOT(R.TXN.ARR) THEN
            R.TXN.ARR = R.AMEX.FILE
        END ELSE
            R.TXN.ARR<-1> = R.AMEX.FILE
        END
        CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
    REPEAT

    IF R.TXN.ARR THEN

        Y.TXN.HDR  = 'Transaction Reference,Customer Name,Asset Code,Trade Date,Value Date,Branch Code,ISA,Transaction Type,Currency,Amount'
        Y.TXN.HDR := ',ClientIdentifier,PrimaryAcctHolder'                                 ;*CPSGMIG-21143
        Y.FINAL.TXN.ARR     = Y.TXN.HDR
        Y.FINAL.TXN.ARR<-1> = R.TXN.ARR
    
	    WRITE Y.FINAL.TXN.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
        
    END ELSE
        CALL OCOMO("MTM Bookbuild Report not generated")
    END

RETURN
END