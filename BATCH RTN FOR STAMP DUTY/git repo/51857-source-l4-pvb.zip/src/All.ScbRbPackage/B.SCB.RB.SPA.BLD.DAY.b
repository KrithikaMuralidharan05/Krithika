$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>355</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.SPA.BLD.DAY(ID.POS)
*-------------------------------------------------------------------------------------------------------------*
* Description:
*-------------------------------------------------------------------------------------------------------------
* Multi threaded routine  will update the day wise balance in SCB.RB.SEC.POS.ACTIVITY.
*-------------------------------------------------------------------------------------------------------------
* Modification History:
*-------------------------------------------------------------------------------------------------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- Daily job to update Day wise balance nominal in SCB.RB.SEC.POS.ACTIVITY.
* 09-Jun-2023 - CPSGMIG-29137 - kalaikumaranp - Update Date as Last working day.
*-------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SCB.RB.SEC.POS.ACTIVITY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_SCB.RB.SPA.BLD.DAY.COMMON
**
    READ R.SC.ACT FROM F.SCB.RB.SEC.POS.ACTIVITY, ID.POS ELSE RETURN
    YLAST.VAL = DCOUNT(R.SC.ACT<SC.ACT.DAY.NO>,@VM)
    
        SEC.NO = ID.POS["*",1,1][".",2,1]
        SAM.ID = ID.POS["*",1,1][".",1,1]
        READV REF.CCY FROM F.SEC.ACC.MASTER, SAM.ID, SC.SAM.REFERENCE.CURRENCY ELSE REF.CCY = BASE.CCY
        NOMINAL = R.SC.ACT<SC.AT.CLOSING.BAL.NO.NOM>
	R.SECURITY.MASTER = '' ; Y.SECURITY.MASTER.ERR = ''
	CALL F.READ(FN.SECURITY.MASTER,SEC.NO,R.SECURITY.MASTER,F.SECURITY.MASTER,Y.SECURITY.MASTER.ERR)
	IF R.SECURITY.MASTER THEN
	MARKET.PRICE = R.SECURITY.MASTER<SC.SCM.LAST.PRICE>
	END
*
        IF R.SC.ACT<SC.AT.DAY.NO> THEN
            Y.DAY.NO = YLASTWRKDAY[2]
            Y.POS = ''
        LOCATE Y.DAY.NO IN R.SC.ACT<SC.AT.DAY.NO,1> SETTING Y.POS THEN
            R.SC.ACT<SC.AT.DAY.NO,Y.POS> = YLASTWRKDAY[2]
            R.SC.ACT<SC.AT.NO.NOMINAL,Y.POS> = NOMINAL
            R.SC.ACT<SC.AT.MARKET.PRICE,Y.POS> = MARKET.PRICE
        END ELSE
        	R.SC.ACT<SC.AT.DAY.NO> := @VM:YLASTWRKDAY[2]
            R.SC.ACT<SC.AT.NO.NOMINAL> := @VM:NOMINAL
            R.SC.ACT<SC.AT.MARKET.PRICE> := @VM:MARKET.PRICE
        END
        END ELSE
            R.SC.ACT<SC.AT.DAY.NO> = YLASTWRKDAY[2]
            R.SC.ACT<SC.AT.NO.NOMINAL> = NOMINAL
            R.SC.ACT<SC.AT.MARKET.PRICE> = MARKET.PRICE
        END
*
    R.SC.ACT<SC.AT.HELD.SINCE> = YLASTWRKDAY
    WRITE R.SC.ACT TO F.SCB.RB.SEC.POS.ACTIVITY, ID.POS
*
RETURN
*
END
