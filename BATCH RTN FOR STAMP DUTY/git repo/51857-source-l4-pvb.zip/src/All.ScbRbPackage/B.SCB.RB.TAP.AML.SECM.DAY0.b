$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.AML.SECM.DAY0
*---------------------------------------------------------------------------------------------
* This mainline routine is attached to the Batch SNG/SCB.RB.TAP.AML.SECM. This routine
* extracts the details of Security transactions and writes into a txt file.
*----------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*----------------------------------------------------------------------------------------------
*
* 05/08/2022 - Shreekantha. G - CPSGMIG-5348 - Copy of the existing routine B.SCB.RB.AML.SECM
*
*----------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.POSITION.TRANSFER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.SECURITY.TRANS
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.COMPANY.CHECK
    $INSERT I_F.AEB.PRODUCT.PARAM
    $INSERT I_F.SCB.CTP2.PROD.PARAM
    $INSERT I_F.SECURITY.SUPP
    $INSERT I_F.CUSTOMER
	
    
*
*----------------------------------------------------------------------------------------------
*    
    GOSUB INITIALISE
    GOSUB OPEN.FILES
    GOSUB FORM.HEADER
    GOSUB SELECT.SEC.TXN.TODAY
    GOSUB MAIN
*	GOSUB SEL.DAILY				;*TEST
* Writes the data to flat file
    GOSUB AML.SEC.WRITE
	
*	CALL F.WRITE(FN.SCB.TRADE.DAILY,TODAY,R.SCB.TRD.DAILY)				;**CPSGMIG-5348 - S/E

	GOSUB FILE.TRANSFER
*
    RETURN
*
*----------------------------------------------------------------------------------------------
INITIALISE:
*---------*
* Initialise the variables
*
    Y.TIMEDATE.STP = TIMEDATE()
    Y.TIMESTAMP = TODAY:Y.TIMEDATE.STP[1,8]
    CHANGE ":" TO "" IN  Y.TIMESTAMP

    DL = "|"
    CR = "CR"
    AML.REC.WRITE = ''
    SORTED.TXN.KEYS=''
    BRANCH.ID = ''
*
    Y.GROSS.AMT.SEC.CCY = ''
    Y.CHARGES = ''
    Y.LOCAL.TAX = ''
    Y.CU.COMMISSION = ''
    Y.CU.TAX = ''
    Y.INTEREST.AMT = ''
    Y.DEPOSITORY = ''
    SEC.STATUS = ''
*
    Y.CU.ACCOUNT.NO = ''
    Y.PRODTYPE = ''
*
    Y.CU.TAX.LCY = ''
    Y.CU.TAX.TCY = ''
    Y.MAN.TAX.TCY = ''
    Y.MAN.TAX.LCY = ''
    Y.CGT.TAX.AMT = ''
*
    Y.BR.NET.AMT = ''
*
    Y.COST = '' ; Y.NET.AMT.SEC = ''; Y.SEC.EXCH.RATE = '' ; Y.INTEREST.RATE = '' ;Y.LED.ORIG.MUREX = '' ;Y.LED.ASSOC.MUREX = ''
*
    RETURN
*------------------------------------------------------------------------------------------
OPEN.FILES:
*---------*
* opens the required files
*
    F.CUST = ""
    FN.CUST = 'F.CUSTOMER'
    CALL OPF(FN.CUST,F.CUST)
*
    F.SEC.TODAY = ""
    FN.SEC.TODAY = 'F.SEC.TRADES.TODAY'
    CALL OPF(FN.SEC.TODAY,F.SEC.TODAY)
*
    F.SEC.TRANSFER = ""
    FN.SEC.TRANSFER = 'F.SECURITY.TRANSFER'
    CALL OPF(FN.SEC.TRANSFER,F.SEC.TRANSFER)
*
    F.POS.TRANSFER = ""
    FN.POS.TRANSFER = 'F.POSITION.TRANSFER'
    CALL OPF(FN.POS.TRANSFER,F.POS.TRANSFER)
*
    F.SEC.TRANS = ""
    FN.SEC.TRANS = 'F.SECURITY.TRANS'
    CALL OPF(FN.SEC.TRANS,F.SEC.TRANS)
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
    FN.AEB.PRODUCT.PARAM = 'F.AEB.PRODUCT.PARAM'
    F.AEB.PRODUCT.PARAM = ''
    CALL OPF(FN.AEB.PRODUCT.PARAM, F.AEB.PRODUCT.PARAM)
*
    FN.SEC.SUPP = 'F.SECURITY.SUPP'
    F.SEC.SUPP = ''
    CALL OPF(FN.SEC.SUPP,F.SEC.SUPP)
*
    FN.SCB.CTP2.PROD.PARAM = 'F.SCB.CTP2.PROD.PARAM'
    F.SCB.CTP2.PROD.PARAM = ''
    CALL OPF(FN.SCB.CTP2.PROD.PARAM,F.SCB.CTP2.PROD.PARAM)
*
    FN.SEC.REV.TODAY = 'F.SEC.REVERSAL.TODAY'
    F.SEC.REV.TODAY = ''
    CALL OPF(FN.SEC.REV.TODAY,F.SEC.REV.TODAY)
*
    F.SEC.TRANSFER.HIS = ""
    FN.SEC.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS'
    CALL OPF(FN.SEC.TRANSFER.HIS,F.SEC.TRANSFER.HIS)
*
    F.POS.TRANSFER.HIS = ""
    FN.POS.TRANSFER.HIS = 'F.POSITION.TRANSFER$HIS'
    CALL OPF(FN.POS.TRANSFER.HIS,F.POS.TRANSFER.HIS)
*
    FN.SCB.TRADE.DAILY = 'F.SCB.TRADE.DAILY'
    F.SCB.TRADE.DAILY = ''
    CALL OPF(FN.SCB.TRADE.DAILY,F.SCB.TRADE.DAILY)
	
*	FN.SEC.TXN.DAILY = 'F.SCB.TXN.DAILY'
*	F.SCB.TXN.DAILY = ''
*	CALL OPF(FN.SCB.TXN.DAILY,F.SCB.TXN.DAILY)
	
    FN.AEB.SEC.PAR = 'F.AEB.SEC.PAR'
	F.AEB.SEC.PAR = ''
	CALL OPF(FN.AEB.SEC.PAR,F.AEB.SEC.PAR)
    
    Y.IM.USER = ''
    LOC.REF.APP = '' ; LOC.REF.FLD = '' ; LOC.REF.POS = ''
*
*LOC.REF.APP = 'SECURITY.SUPP':@FM:'SECURITY.TRANSFER':@FM:'POSITION.TRANSFER'
*
    LOC.REF.APP = 'SECURITY.SUPP':@FM:'SECURITY.TRANSFER':@FM:'SECURITY.MASTER':@FM:'CUSTOMER'
*    
    LOC.REF.FLD = 'LED.OP.PROD.TYP'
    LOC.REF.FLD := @FM:'LED.TICKET.TYPE':@VM:'TAP.REF.NO'  
    LOC.REF.FLD := @FM:'SETTLEMENT.METHOD':@VM:'TDS.GLOBAL.ID':@VM:'CASH.OR.REINV'
    LOC.REF.FLD := @FM:'L.O.B'
*
    CALL MULTI.GET.LOC.REF(LOC.REF.APP,LOC.REF.FLD,LOC.REF.POS)
*
    Y.PRODTYP.POS = LOC.REF.POS<1,1>
*
    Y.TICK.TYPE.POS = LOC.REF.POS<2,1>
    Y.TAP.REF.NO.POS = LOC.REF.POS<2,2>
*    
    Y.SETTLEMENT.METHOD.POS = LOC.REF.POS<3,1>
    Y.TDS.GLOBAL.ID.POS = LOC.REF.POS<3,2>
    Y.CASH.OR.REINV.POS = LOC.REF.POS<3,3>
*
    Y.LOB.POS = LOC.REF.POS<4,1>
*
    CALL F.READ(FN.AEB.PRODUCT.PARAM,'SYSTEM',RE.PROD.PARAM,F.AEB.PRODUCT.PARAM,REPROD.ERR)
    Y.AQDQ.KEY = RE.PROD.PARAM<AEB.PPR.KEY.NAME>
    LOCATE 'AQDQ.SAT' IN Y.AQDQ.KEY<1,1> SETTING AQDQ.POS THEN
        Y.AQDQ.SAT = RE.PROD.PARAM<AEB.PPR.VALUE,AQDQ.POS>
    END
*
    CALL AEB.GET.VAL('SYSTEM','MXG.SAT',PARAM.VAL.OUT1,PARAM.CNT.OUT1,ERR.PARAM.OUT1)     
    Y.MXG.SAT = PARAM.VAL.OUT1          
*
    BEGIN CASE
        CASE ID.COMPANY EQ "SG1090400"
            BRANCH.ID = "SG"
        CASE ID.COMPANY EQ "SG1090401"
            BRANCH.ID = "SG"
    END CASE
*
    SEQ.FILE = 'T24-':BRANCH.ID:'-RB-TAP-SECM-':Y.TIMESTAMP:'.txt'					;*CPSGMIG-4971					
*
* Open the directory where the csv fiel to be written
    OPEN '','AMEX.FILES' TO AMEX.FILES.AML ELSE
    END
*	
    COUNTER = 0
*
    RETURN
*------------------------------------------------------------------------------------------
SELECT.SEC.TXN.TODAY:
*-------------------*
* Selects records from SEC.TRADE.TODAY for the company , loops through each id and
* sorts the transaction based on transaction key
	SEL.CMD = '' ; ID.LIST = '' ;
	Y.PILOT.DATE = '20221205'
    Y.COMP.ID = ID.COMPANY
	SEL.CMD = 'SSELECT ':FN.POS.TRANSFER:' WITH VALUE.DATE GE ':Y.PILOT.DATE
    CALL EB.READLIST(SEL.CMD,ID.LIST.POST,'','',ER)
	ID.LIST<-1> = ID.LIST.POST
	SEL.CMD = 'SSELECT ':FN.SEC.TRANSFER:' WITH VALUE.DATE GE ':Y.PILOT.DATE
	CALL EB.READLIST(SEL.CMD,ID.LIST.SECT,'','',ER)
	ID.LIST<-1> = ID.LIST.SECT
	
    IF ID.LIST THEN
        LOOP
            REMOVE TODAY.TRADE.ID FROM ID.LIST SETTING MARKER
        WHILE TODAY.TRADE.ID:MARKER
 *           CALL F.READ(FN.SEC.TODAY,TODAY.TRADE.ID,TXN.KEYS,F.SEC.TODAY,ETEXT)
 			TXN.KEYS = TODAY.TRADE.ID
            GOSUB SORT.STORE.TXNS
        REPEAT
    END
*
    SEL.CMD = '' ; ID.LIST = '' ;
    SEL.CMD = 'SSELECT ':FN.POS.TRANSFER.HIS:' WITH VALUE.DATE GE ':Y.PILOT.DATE
    CALL EB.READLIST(SEL.CMD,ID.LIST.POST,'','',ER)
	ID.LIST<-1> = ID.LIST.POST
	SEL.CMD = 'SSELECT ':FN.SEC.TRANSFER.HIS:' WITH VALUE.DATE GE ':Y.PILOT.DATE
	CALL EB.READLIST(SEL.CMD,ID.LIST.SECT,'','',ER)
	ID.LIST<-1> = ID.LIST.SECT
    IF ID.LIST THEN
        LOOP
            REMOVE TODAY.TRADE.ID FROM ID.LIST SETTING MARKER
        WHILE TODAY.TRADE.ID:MARKER
            TXN.KEYS = FIELD(TODAY.TRADE.ID,";",1)
            GOSUB SORT.STORE.TXNS
        REPEAT
    END
	
    RETURN
*-------------------------------------------------------------------------------------------
SORT.STORE.TXNS:
*--------------*

* Sorts the transactions based on Transaction Key
    LOOP
        REMOVE TXN.KEY FROM TXN.KEYS SETTING MORE
    WHILE TXN.KEY
        TXN.TYPE = TXN.KEY[1,4]
        BEGIN CASE
            CASE TXN.KEY[1,4] = 'POST' OR TXN.KEY[1,4] = 'SECT'                
                GOSUB TRADE.TXN
            CASE 1
                NULL
        END CASE
    REPEAT
*
    RETURN
*------------------------------------------------------------------------------------------
TRADE.TXN:
*--------*
* Sorts the transactions based on Transaction Key
    IF SORTED.TXN.KEYS = "" THEN
        SORTED.TXN.KEYS<1> = TXN.KEY
    END ELSE
        LOCATE TXN.KEY IN SORTED.TXN.KEYS<1> BY 'AR' SETTING POS ELSE POS = -1
        SORTED.TXN.KEYS = INSERT(SORTED.TXN.KEYS,1,POS,0,TXN.KEY)
    END
*
    RETURN
*------------------------------------------------------------------------------------------
MAIN:
*---*
* Loops through each id and extracts the details
    LOOP
		
        TXN.KEY = SORTED.TXN.KEYS<1,1>
        Y.CU.ACCOUNT.CCY = ''
        Y.CUST.NET.AMT   = ''
        Y.PRICE          = ''
        BEGIN CASE
            CASE TXN.KEY[1,4] = 'POST'
                GOSUB PROCESS.POS.TRANSFER
            CASE TXN.KEY[1,4] = 'SECT'
                GOSUB PROCESS.SEC.TRANSFER
            CASE 1
                NULL
        END CASE
        DEL SORTED.TXN.KEYS<1,1>
    WHILE SORTED.TXN.KEYS DO REPEAT
*

*
    RETURN
*------------------------------------------------------------------------------------------
SEL.DAILY:
*---------
	ID.LIST = ''
	Y.FILE.FLG = 0
	Y.INT = 1
	SEL.CMD = 'SSELECT ':FN.SCB.TRADE.DAILY
	CALL EB.READLIST(SEL.CMD,ID.LIST,'',NO.OF.REC,ER)
	
	CALL F.READ(FN.SCB.TRADE.DAILY,ID.LIST,R.TRD.DAILY,F.SCB.TRADE.DAILY,ERR.DAILY)
	CONVERT FM TO VM IN R.TRD.DAILY
	SORTED.TXN.KEYS<-1,-1> = R.TRD.DAILY
	Y.FILE.FLG = 1
    GOSUB MAIN
   
    
	RETURN
*------------------------------------------------------------------------------------------
PROCESS.SEC.TRANSFER:
*-------------------*

    CALL F.READ(FN.SEC.TRANSFER,TXN.KEY,EXTRACT.REC,F.SEC.TRANSFER,ETEXT)
*
    IF EXTRACT.REC THEN
        SEC.STATUS = "ACTIVE"
    END ELSE
        CALL EB.READ.HISTORY.REC(F.SEC.TRANSFER.HIS,TXN.KEY,EXTRACT.REC,ETEXT)
*        TXN.KEY = FIELD(TXN.KEY,';',1)
        SEC.STATUS = "REVERSED"
    END
* * S --Exclude if INPUTTER is DMUSER for SECURITY.TRANSFER
	INPUTTER.NAME = EXTRACT.REC<SC.STR.INPUTTER>
    IF INDEX(INPUTTER.NAME,'DMUSER',1) THEN
        RETURN
    END
* E --Exclude if INPUTTER is DMUSER for SECURITY.TRANSFER
    COMPANY.CODE=EXTRACT.REC<SC.STR.CO.CODE>
    NARRATIVE.1=EXTRACT.REC<SC.STR.CUST.REMARKS,1>
    NARRATIVE.2=''
*
    
    Y.ST.TICK.TYPE = EXTRACT.REC<SC.STR.LOCAL.REF,Y.TICK.TYPE.POS>
    Y.INPUTTER = EXTRACT.REC<SC.STR.INPUTTER,1>
    Y.INPUTTER = FIELD(Y.INPUTTER,'_',2,1)
    Y.AUTHORISER = EXTRACT.REC<SC.STR.AUTHORISER>
    Y.AUTHORISER = FIELD(EXTRACT.REC<SC.STR.AUTHORISER>,'_',2,1)
    FOR J=2 TO DCOUNT(EXTRACT.REC<SC.STR.CUST.REMARKS>,@VM)
        IF NARRATIVE.2 THEN
            NARRATIVE.2=NARRATIVE.2:'///'
            EXIT
        END
        NARRATIVE.2=NARRATIVE.2:EXTRACT.REC<SC.STR.CUST.REMARKS,J>
    NEXT J
*
    Y.GROSS.AMT.SEC.CCY = EXTRACT.REC<SC.STR.GROSS.AMT.SEC.CCY>
    Y.CHARGES = EXTRACT.REC<SC.STR.CHARGES>
    Y.LOCAL.TAX = EXTRACT.REC<SC.STR.LOCAL.TAX>
    Y.CU.COMMISSION = EXTRACT.REC<SC.STR.CU.COMMISSION>
    Y.CU.TAX = EXTRACT.REC<SC.STR.CU.TAX>
    Y.INTEREST.AMT = EXTRACT.REC<SC.STR.INTEREST.AMT>
    Y.DEPOSITORY = ''
*
    Y.CU.ACCOUNT.NO = EXTRACT.REC<SC.STR.CU.ACCOUNT.NO>
*
    Y.CU.TAX.LCY = EXTRACT.REC<SC.STR.CU.TAX.LCY>
    CONVERT @VM TO "^" IN Y.CU.TAX.LCY
    Y.CU.TAX.TCY = EXTRACT.REC<SC.STR.CU.TAX.TCY>
    CONVERT @VM TO "^" IN Y.CU.TAX.TCY
    Y.MAN.TAX.TCY = EXTRACT.REC<SC.STR.MAN.TAX.TCY>
    CONVERT @VM TO "^" IN Y.MAN.TAX.TCY
    Y.MAN.TAX.LCY = EXTRACT.REC<SC.STR.MAN.TAX.LCY>
    CONVERT @VM TO "^" IN Y.MAN.TAX.LCY
    Y.CGT.TAX.AMT = EXTRACT.REC<SC.STR.CGT.TAX.AMT>
    CONVERT @VM TO "^" IN Y.CGT.TAX.AMT
*
    Y.CU.ACCOUNT.CCY = EXTRACT.REC<SC.STR.CU.ACCOUNT.CCY>
    Y.CUST.NET.AMT   = EXTRACT.REC<SC.STR.CUST.NET.AMT>
*
    GOSUB PROCESS.SEC.TRANS
*
RETURN
*------------------------------------------------------------------------------------------
PROCESS.POS.TRANSFER:
*-------------------*
* Extracts the details from POSITION.TRANSFER

	CALL F.READ(FN.POS.TRANSFER,TXN.KEY,EXTRACT.REC,F.POS.TRANSFER,ER)
*
	IF EXTRACT.REC THEN
		SEC.STATUS = "ACTIVE"
	END ELSE
		CALL EB.READ.HISTORY.REC(F.POS.TRANSFER.HIS,TXN.KEY,EXTRACT.REC,ETEXT)
*		TXN.KEY = FIELD(TXN.KEY,';',1)
		SEC.STATUS = "REVERSED"
	END
* * S --Exclude if INPUTTER is DMUSER for POSITION.TRANSFER
	INPUTTER.NAME = EXTRACT.REC<SC.PST.INPUTTER>
    IF INDEX(INPUTTER.NAME,'DMUSER',1) THEN
        RETURN
    END
* E --Exclude if INPUTTER is DMUSER for POSITION.TRANSFER
    Y.INPUTTER = EXTRACT.REC<SC.PST.INPUTTER,1>
    Y.INPUTTER = FIELD(Y.INPUTTER,'_',2,1)
    Y.AUTHORISER = EXTRACT.REC<SC.PST.AUTHORISER>
    Y.AUTHORISER = FIELD(Y.AUTHORISER,'_',2,1)

    COMPANY.CODE=EXTRACT.REC<SC.PST.CO.CODE>
    NARRATIVE.1=EXTRACT.REC<SC.PST.CUST.NARRATIVE,1>
    NARRATIVE.2=''
    FOR J=2 TO DCOUNT(EXTRACT.REC<SC.PST.CUST.NARRATIVE>,@VM)
        IF NARRATIVE.2 THEN
            NARRATIVE.2=NARRATIVE.2:'///'
            EXIT
        END
        NARRATIVE.2=NARRATIVE.2:EXTRACT.REC<SC.PST.CUST.NARRATIVE,J>
    NEXT J
*
    Y.GROSS.AMT.SEC.CCY = ''
    Y.CHARGES = ''
    Y.LOCAL.TAX = ''
    Y.CU.COMMISSION = ''
    Y.CU.TAX = ''
    Y.INTEREST.AMT = ''
*   
    Y.CU.TAX.LCY = ''
    Y.CU.TAX.TCY = ''
    Y.MAN.TAX.TCY = ''
    Y.MAN.TAX.LCY = ''
    Y.CGT.TAX.AMT = ''
*
    GOSUB PROCESS.SEC.TRANS
*
    RETURN
*------------------------------------------------------------------------------------------
PROCESS.SEC.TRANS:
*----------------*

    TXN.ID=TXN.KEY
	
    GOSUB FIND.SEC.TRANS.ID
	Y.CNT = DCOUNT(SEC.TRANS.IDS,@FM)
    FOR I=1 TO Y.CNT
        Y.PRODTYPE = ''       
        TRANS.REC=''
        TXN.ID.NEW=SEC.TRANS.IDS<I> 

        CALL F.READ(FN.SEC.TRANS,SEC.TRANS.IDS<I>,TRANS.REC,F.SEC.TRANS,ER)
        TRADE.DATE=TRANS.REC<SC.SCT.TRADE.DATE>
        VALUE.DATE=TRANS.REC<SC.SCT.VALUE.DATE>
        TXN.TYPE=TRANS.REC<SC.SCT.TRANS.TYPE>
        SECURITY.ACC=TRANS.REC<SC.SCT.SECURITY.ACCOUNT>
        
        CUSTOMER.ID=SECURITY.ACC['-',1,1]

*CPSGMIG-5348 - S
		Y.NOMINEE = TRANS.REC<SC.SCT.NOMINEE.CODE>
        
		Y.PARAM.ID    = 'SCB.CUST.SEG'	
		Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
		Y.ALLOWED.LOB = ''
		CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
		R.CUST = ''
		ERR.CUST = ''
		CALL F.READ(FN.CUST,CUSTOMER.ID,R.CUST,F.CUST,ERR.CUST)
		Y.CUST.LOB = R.CUST<EB.CUS.LOCAL.REF,Y.LOB.POS>
		LOBPOS = ''
		
*CPSGMIG-5348 - E
	
	Y.SECTOR = R.CUST<EB.CUS.SECTOR>
	IF Y.CUST.LOB EQ '8' AND (Y.SECTOR EQ '21' OR Y.SECTOR EQ '51') THEN
		
        !muli value field each occurrence to be processed as separate transfer
        SECURITY.NO=TRANS.REC<SC.SCT.SECURITY.NUMBER>
        R.SECURITY.MASTER = ''          
        Y.ERR = ''
        CALL F.READ(FN.SECURITY.MASTER,SECURITY.NO,R.SECURITY.MASTER,F.SECURITY.MASTER,Y.ERR)
*
        Y.SAT = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
*
		!To skipp the depository records -999
        IF SECURITY.ACC MATCHES '...-999' THEN CONTINUE
        IF Y.SAT EQ Y.AQDQ.SAT OR Y.SAT MATCHES Y.MXG.SAT THEN        
*
            R.SEC.SUPP = ''
            CALL F.READ(FN.SEC.SUPP,SECURITY.NO,R.SEC.SUPP,F.SEC.SUPP,SUPP.ERR)
            IF R.SEC.SUPP THEN
                Y.PRODTYPE = R.SEC.SUPP<SC.SSP.LOCAL.REF,Y.PRODTYP.POS>
            END
*
            R.PROD.PARAM = ''
            CALL F.READ(FN.SCB.CTP2.PROD.PARAM,'SYSTEM',R.PROD.PARAM,F.SCB.CTP2.PROD.PARAM,PROD.ERR)
            IF R.PROD.PARAM THEN
                Y.PROD.PARAM = R.PROD.PARAM<CTP2.PROD.OPT.PROD.TYPE>
            END
*
            LOCATE Y.PRODTYPE IN Y.PROD.PARAM<1,1> SETTING PROD.POS THEN
                Y.PROD.IMREQ = R.PROD.PARAM<CTP2.PROD.IM.REQUIRED,PROD.POS>
            END
            Y.IM.USER = ''
*
            IF ((Y.ST.TICK.TYPE EQ 'SEC.TRANSFER-AQDQ' OR Y.ST.TICK.TYPE = 'SEC.TRADE-OPT') OR (Y.ST.TICK.TYPE EQ 'SECURITY.TRANSFER' OR Y.ST.TICK.TYPE EQ 'SEC.TRADE')) THEN
                Y.IM.USER = 'Y'
            END
        END
*  
        SECURITY.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME,1>        
*
        SECURITY.CURRENCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>         
        NOMINAL=TRANS.REC<SC.SCT.NO.NOMINAL.TOTAL>
        TRANSACTION.VALUE=FMT(TRANS.REC<SC.SCT.NET.AMT.TRADE>,"R2")
        !SECURITY.TRANS needs to be accessed
        AMOUNT.TO.CONVERT = TRANSACTION.VALUE
        CCY.TO.CONVERT = SECURITY.CURRENCY
        GOSUB CONVERT.AMT
        AMOUNT.USD = FMT(AMT2,"R2")
*
        GOSUB CONVERT.AMT.LCY
        AMOUNT.VAL.LCY = FMT(AMT2,"R2")
*
        !To deliberately excluded from the extract
*
        Y.DEPOSITORY = TRANS.REC<SC.SCT.DEPOSITORY>
*
        Y.PRICE      = TRANS.REC<SC.SCT.PRICE>
        CONVERT @VM TO "^" IN Y.PRICE
*
        GOSUB AML.SEC.EXTRACT
        GOSUB AML.APPEND.WRITE.EXTRACT

	END
	
    NEXT I
*
    RETURN
*------------------------------------------------------------------------------------------
FIND.SEC.TRANS.ID:
*----------------*
    SEC.TRANS.IDS=''
    SEC.TR.ID=TXN.ID:'.1'
    I=2
    LOOP
        SEC.REC=''
        CALL F.READ(FN.SEC.TRANS,SEC.TR.ID,SEC.REC,F.SEC.TRANS,ER)
    WHILE SEC.REC DO
        SEC.TRANS.IDS<-1>=SEC.TR.ID
        SEC.TR.ID=TXN.ID:'.':I
        I=I+1
    REPEAT
*
	RETURN
*
*------------------------------------------------------------------------------------------
FORM.HEADER:
*----------*
*
    Y.HEADER = ''			
    Y.HEADER := "COMPANY_CODE":"|":"REFERENCE_NO":"|":"TRADE_DATE":"|":"VALUE_DATE":"|":"TRANSACTION_TYPE"
    Y.HEADER := "|":"CUSTOMER":"|":"SSEC_ACCOUNT":"|":"SEC_NO":"|":"SHORT_NAME":"|":"SEC.CCY"
    Y.HEADER := "|":"NOMINAL":"|":"GROSS_AMOUNT":"|":"AMOUNT_USD":"|":"CUST_REMARKS1":"|":"CUST_REMARKS2"
    Y.HEADER := "|":"IM_USER":"|":"INPUTTER":"|":"AUTHORISER":"|":"GROSS_AMT_SEC_CCY":"|":"CHARGES"
    Y.HEADER := "|":"LOCAL_TAX":"|":"CU_COMMISSION":"|":"CU_TAX":"|":"INTEREST_AMT":"|":"DEPOSITORY"
    Y.HEADER := "|":"STATUS":"|":"total_value_lcy":"|":"st_tick_type":"|":"SUB_ASSET_TYPE":"|":"CU_ACCOUNT_NO"
    Y.HEADER := "|":"LED_PROD_TYPE":"|":"CU_TAX_LCY":"|":"CU_TAX_TCY":"|":"MAN_TAX_TCY":"|":"MAN_TAX_LCY"
    Y.HEADER := "|":"CGT_TAX_AMT":"|":"PRICE":"|":"CU_ACCOUNT_CCY":"|":"CUST_NET_AMT":"|":"TAP_Order_Ref"
    Y.HEADER := "|":"NOMINEE":"|":"SETTLEMENT_METHOD":"|":"TDS_GLOBAL_ID":"|":"CASH_OR_REINV"
*		
    AML.REC.WRITE = Y.HEADER
*
    RETURN
*
*------------------------------------------------------------------------------------------
AML.SEC.EXTRACT:
*---------------*
* Constructs the output array
    AML.REC = ''
    AML.REC = COMPANY.CODE:DL   			;! CO.CODE
    AML.REC:= TXN.ID.NEW:DL     			;! REFERENCE.NO
    AML.REC:= TRADE.DATE:DL   					;! TRADE.DATE
    AML.REC:= VALUE.DATE:DL   					;! VALUE.DATE
    AML.REC:= TXN.TYPE:DL       			;! TRANSACTION.TYPE
    AML.REC:= CUSTOMER.ID:DL    			;! CUSTOMER.NO
    AML.REC:= SECURITY.ACC:DL   			;! SECURITY.ACC
    AML.REC:= SECURITY.NO:DL    			;! SECURITY.NO - SECURITY.CODE
    	SECURITY.NAME=EREPLACE(SECURITY.NAME, '"', "'")
    AML.REC:= SECURITY.NAME:DL  			;! SECURITY.NO - SECURITY.MASTER field SHORT.NAME
    AML.REC:= SECURITY.CURRENCY:DL        		;! SECURITY.CCY
    AML.REC:= NOMINAL:DL      						;! NO.NOMINAL
    AML.REC:= ABS(TRANSACTION.VALUE):DL 			;! GROSS.AMT.SEC.CCY
    AML.REC:= ABS(AMOUNT.USD):DL        			;! USD equivalent of TRANSACTION.VALUE
    	NARRATIVE.1=EREPLACE(NARRATIVE.1, '"', "'")
    	NARRATIVE.1=EREPLACE(NARRATIVE.1, ',', "")    		;* QC588 - S/E
    AML.REC:= NARRATIVE.1:DL    			;! CUST.REMARKS (1st line)
    	NARRATIVE.2=EREPLACE(NARRATIVE.2, '"', "'")
    	NARRATIVE.2=EREPLACE(NARRATIVE.2, ',', "")    		;* QC588 - S/E
    AML.REC:= NARRATIVE.2       			;! CUST.REMARKS (2st line)
    AML.REC:= DL:Y.IM.USER:DL
    AML.REC:= Y.INPUTTER:DL       			;! Y.INPUTTER
    AML.REC:= Y.AUTHORISER        			;! Y.AUTHORISER
    AML.REC:= DL:Y.GROSS.AMT.SEC.CCY
    AML.REC:= DL:Y.CHARGES
    AML.REC:= DL:Y.LOCAL.TAX
    AML.REC:= DL:Y.CU.COMMISSION
    AML.REC:= DL:Y.CU.TAX
    AML.REC:= DL:Y.INTEREST.AMT
    AML.REC:= DL:Y.DEPOSITORY
    AML.REC:= DL:SEC.STATUS
    AML.REC:= DL:ABS(AMOUNT.VAL.LCY)     		;! LCCY equivalent of TRANSACTION.VALUE
    AML.REC:= DL:Y.ST.TICK.TYPE
    AML.REC:= DL:Y.SAT				;! SUB.ASSET.TYPE
    AML.REC:= DL:Y.CU.ACCOUNT.NO
    AML.REC:= DL:Y.PRODTYPE               		;! LED.PROD.TYPE
    AML.REC:= DL:Y.CU.TAX.LCY
    AML.REC:= DL:Y.CU.TAX.TCY
    AML.REC:= DL:Y.MAN.TAX.TCY
    AML.REC:= DL:Y.MAN.TAX.LCY
    AML.REC:= DL:Y.CGT.TAX.AMT
    AML.REC:= DL:Y.PRICE
    AML.REC:= DL:Y.CU.ACCOUNT.CCY
    AML.REC:= DL:Y.CUST.NET.AMT
    AML.REC:= DL:EXTRACT.REC<SC.STR.LOCAL.REF,Y.TAP.REF.NO.POS>
*CPSGMIG-5348 - S
    CALL F.READ(FN.SECURITY.MASTER,SECURITY.NO,R.SEC.MAS,F.SECURITY.MASTER,SM.ERR)
    Y.TDS.GLOBAL.ID = R.SEC.MAS<SC.SCM.LOCAL.REF,Y.TDS.GLOBAL.ID.POS>			
*    Y.CASH.OR.REINV = R.SEC.MAS<SC.SCM.LOCAL.REF,Y.CASH.OR.REINV.POS>
    AML.REC:= DL:Y.NOMINEE
    CALL SCB.RB.GET.DEPO.DETAILS(Y.DEPOSITORY,SECURITY.NO,'','',Y.CASH.OR.REINV,'')
    GOSUB CHECK.DEPO
    AML.REC:= DL:Y.PAY.MODE
    AML.REC:= DL:Y.TDS.GLOBAL.ID
    AML.REC:= DL:Y.CASH.OR.REINV
*CPSGMIG-5348 - E
    RETURN
*-----------------------------------------------------------------------
CHECK.DEPO:
*----------
    SEL.LIST = '' ;	NO.OF.REC = '' ; ERR.SEL = '' ;	CPF.POS = '' ; VAL.POS = ''
	Y.CPF.ARR = 'CPF-15':@VM:'CPF-OA':@VM:'CPF-SA':@VM:'SRS'
*
	SEL.CMD = 'SELECT ':FN.AEB.SEC.PAR:' WITH DEPOSITORY EQ ':Y.DEPOSITORY
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.SEL)
*
	Y.PAY.MODE = ''
    Y.CPF.VAL = ''
	Y.CPF.VAL = FIELD(SEL.LIST,'.',4)
	LOCATE Y.CPF.VAL IN Y.CPF.ARR<1,1> SETTING VAL.POS THEN
		Y.PAY.MODE = Y.CPF.VAL
	END ELSE
		Y.PAY.MODE = 'CASH'
	END
*
RETURN
*------------------------------------------------------------------------------------------
AML.APPEND.WRITE.EXTRACT:
*-----------------------*
* Stores the data in output array
    IF NOT(AML.REC) THEN RETURN
    AML.REC.WRITE<-1> = AML.REC
    COUNTER = COUNTER + 1
*
    RETURN
*------------------------------------------------------------------------------------------
AML.SEC.WRITE:
*------------*
* Write the data to flat file
    DT = OCONV(DATE(),"D-")
    TM = OCONV(TIME(),'MT')
    DT.TIME = DT:"/":TM
*   AML.REC = BRANCH.ID:DL:DT.TIME:DL:COUNTER
    AML.REC = 'T':',':COUNTER											
    AML.REC.WRITE<-1> = AML.REC											;*CPSGMIG-4971
*
	WRITE AML.REC.WRITE ON AMEX.FILES.AML,SEQ.FILE ON ERROR
        GOTO FATAL.ERROR
    END
*
RETURN
*------------------------------------------------------------------------------------------
CONVERT.AMT:
*----------*
* Converts the amt to USD
    E="" ; ETEXT="" ; RET.CODE=""
    Y3 = '' ; Y5 = '' ; Y6 = ''
    XCHANGE = '' ; AMT1 = '' ; AMT2 = ''
    CCY1 = CCY.TO.CONVERT
    AMT1 = AMOUNT.TO.CONVERT
    CCY2 = 'USD'
    IF NOT(AMT1) THEN
        AMT2 = 0
        Y6 = 0
        RETURN
    END
    CALL EXCHRATE(1,CCY1,AMT1,CCY2,AMT2,Y3,XCHANGE,Y5,Y6,RET.CODE)
    IF ETEXT THEN TEXT = ETEXT ; GOTO FATAL.ERROR
*
	RETURN
*------------------------------------------------------------------------------------------
CONVERT.AMT.LCY:
*--------------*
* Converts the amt to LCY
    E="" ; ETEXT="" ; RET.CODE=""
    Y3 = '' ; Y5 = '' ; Y6 = ''
    XCHANGE = '' ; AMT1 = '' ; AMT2 = ''
    CCY1 = CCY.TO.CONVERT
    AMT1 = AMOUNT.TO.CONVERT
    CCY2 = LCCY
    IF NOT(AMT1) THEN
        AMT2 = 0
        Y6 = 0
        RETURN
    END
    CALL EXCHRATE(1,CCY1,AMT1,CCY2,AMT2,Y3,XCHANGE,Y5,Y6,RET.CODE)
    IF ETEXT THEN TEXT = ETEXT ; GOTO FATAL.ERROR
*
	RETURN
*------------------------------------------------------------------------------------------
FATAL.ERROR:
*----------*
    CALL FATAL.ERROR('B.SCB.RB.TAP.AML.SECM - ':ID.COMPANY)
*	
	RETURN
*------------------------------------------------------------------------------------------
FILE.TRANSFER:
*-------------
*
	AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''
*    
    FLOW.IDENTIFER.ID = 'T24-RBTAP-SG'
*    
    FILE.NAME = AMEX.FILES
    RECORD.NAME = SEQ.FILE
    TARGET.FILE.NAME = EREPLACE(SEQ.FILE,"-","_") 
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'')

RETURN
END
*------------------------------------------------------------------------------------------
