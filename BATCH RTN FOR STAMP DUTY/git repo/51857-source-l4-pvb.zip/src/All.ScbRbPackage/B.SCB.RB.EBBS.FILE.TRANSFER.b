$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-51</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EBBS.FILE.TRANSFER
*-----------------------------------------------------------------------------
* Description
* Author                       	Loganathan G
* EPACC/Story/Sub task Ref     	CPSGMIG-565
* Routine Type                 	Single Thread Routine
* Attached To                  	Batch 
*				SNG/SCB.RB.OUT.BLK.CREATE.REQ.EBBS
*				SNG/SCB.RB.OUT.BLK.DELETION.REQ.EBBS
*				SNG/SCB.RB.OUT.BLK.REL.SETT.REQ.EBBS
*				SNG/SCB.RB.OUT.SETT.REQUEST.EBBS
* Workflow                     	T24 to EBBS File Transfer through FILEIT 
*-----------------------------------------------------------------------------
* Modification :
* CPSGMIG-14876 	Soruce file is copied to arc folder with prefix T24
*-----------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY	
    $INSERT I_F.DATES    
    
    GOSUB INITIALISE
    GOSUB PROCESS	

RETURN

*----------
INITIALISE:
*----------

    SOURCE.PATH 	= ''
    SOURCE.FILE.NAME	= ''
    TARGET.FILE.NAME	= ''
    FLOW.IDENTIFER.ID 	= ''
    EBBS.OUT.ARC	= ''
    Y.UDFILE		= ''
    Y.CRITERIA		= ''
    SEL.LIST		= ''
    RECORD.NAME		= ''
    Y.EBBS.ARC		= ''
    Y.EBBS.ARC.PATH	= ''
    Y.EBBS.SOURCE.PATH	= ''
    Y.TOTAL.FILE.CNT	= ''
    Y.CNT		= ''
	
RETURN

*-------
PROCESS:
*-------
    
    SOURCE.PATH 	= FIELD(BATCH.DETAILS<3, 1, 1>, '*', 1)
    SOURCE.FILE.NAME	= FIELD(BATCH.DETAILS<3, 1, 1>, '*', 2)
    TARGET.FILE.NAME	= FIELD(BATCH.DETAILS<3, 1, 1>, '*', 3)
    FLOW.IDENTIFER.ID 	= FIELD(BATCH.DETAILS<3, 1, 1>, '*', 4)
    EBBS.OUT.ARC 	= FIELD(BATCH.DETAILS<3, 1, 1>, '*', 5)

    ARG1 = SOURCE.PATH
    ARG2 = ''
    ARG3 = ''
    CALL SCB.GET.ORACLE.FILENAME(ARG1, ARG2, ARG3)	
    Y.EBBS.SOURCE.PATH = ARG3

    ARG1 = EBBS.OUT.ARC
    ARG2 = ''
    ARG3 = ''
    CALL SCB.GET.ORACLE.FILENAME(ARG1, ARG2, ARG3)	
    Y.EBBS.ARC.PATH = ARG3    
    
    Y.UDFILE		= SOURCE.PATH
    Y.CRITERIA  	= '*txt*' 
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, SEL.LIST, SEL.ERR)
    
    IF SEL.LIST THEN
        Y.TOTAL.FILE.CNT = DCOUNT(SEL.LIST,@FM)
        Y.CNT = 1
        LOOP
        WHILE Y.CNT LE Y.TOTAL.FILE.CNT
            RECORD.NAME = SEL.LIST<Y.CNT>
            CALL OCOMO("EBBS Outward File ID ":RECORD.NAME)

*Actual File will moved to ARC folder with Prefix T24
*CPSGMIG-14876-Start
            Y.ACTUAL.FILE.NAME = "T24.":RECORD.NAME
            CALL OCOMO("EBBS Outward Source File ID ":Y.ACTUAL.FILE.NAME)
            EXE.MOVE.CMD1 = "SH -c 'cp ":Y.EBBS.SOURCE.PATH:"/":RECORD.NAME:" ":Y.EBBS.ARC.PATH:"/":Y.ACTUAL.FILE.NAME:"'"
            CRT EXE.MOVE.CMD1
            EXECUTE EXE.MOVE.CMD1 CAPTURING MVE.CMD.STATUS1
            CALL OCOMO(MVE.CMD.STATUS1)
*CPSGMIG-14876-End
            
            CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,SOURCE.PATH,RECORD.NAME,TARGET.FILE.NAME,'')
            
	    EXE.MOVE.CMD = "SH -c 'mv ":Y.EBBS.SOURCE.PATH:"/":RECORD.NAME:" ":Y.EBBS.ARC.PATH:"/":RECORD.NAME:"'"
            CRT EXE.MOVE.CMD
            EXECUTE EXE.MOVE.CMD CAPTURING MVE.CMD.STATUS
	    CALL OCOMO(MVE.CMD.STATUS)
            Y.CNT = Y.CNT + 1
        REPEAT       
    END

RETURN

END
