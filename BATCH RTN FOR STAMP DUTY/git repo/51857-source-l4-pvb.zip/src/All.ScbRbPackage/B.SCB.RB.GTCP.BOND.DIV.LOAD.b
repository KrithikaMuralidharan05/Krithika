$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.BOND.DIV.LOAD
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-BOND.DIVIDENDS-<start.date>-<end.date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.RB.GTCP.BOND.DIV.COMMON

    GOSUB INITIALISE
    GOSUB OPEN.ALL.FILES

RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*----------
	FILE.NAME = ID.COMPANY[1,2]:"-MFU-BOND-DIVIDENDS-":TODAY:".txt-":SESSION.NO
    DL = ','

RETURN
*-----------------------------------------------------------------------------
OPEN.ALL.FILES:
*--------------
    FN.ENTITLEMENT = 'F.ENTITLEMENT' ; F.ENTITLEMENT = ''
    CALL OPF(FN.ENTITLEMENT,F.ENTITLEMENT)
*
	FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER' ; F.SEC.ACC.MASTER = ''
	CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
	FN.DIARY = 'F.DIARY' ; F.DIARY = ''
	CALL OPF(FN.DIARY,F.DIARY)
*
	FN.SCB.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM' ; F.SCB.LOC.PARAM = ''
	CALL OPF(FN.SCB.LOC.PARAM,F.SCB.LOC.PARAM)
*
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
	CONVERT @VM TO ' ' IN Y.ALLOWED.LOB
* PVB/RB Customer Demarkation
*
    Y.APP.NAME<1> = 'SEC.ACC.MASTER'
    Y.FLD.NAME<1> = 'LR.TP.ACCT.NO':@VM:'LR.PFOLIO.KEY'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
	LR.TP.ACCT.NO.POS = Y.FLD.POS<1,1>
	LR.PFOLIO.KEY.POS = Y.FLD.POS<1,2>
*
	Y.STEND.DATE = BATCH.DETAILS<3,1,2>
	Y.START.DATE = FIELD(Y.STEND.DATE,'-',1)
	Y.END.DATE   = FIELD(Y.STEND.DATE,'-',2,1)
*
	LOC.PARAM.ID = 'GTCP.DIARY.TYPE'
	R.LOC.PARAM.REC = '' ; E.LOC.PARAM.ERR = '' ; Y.DIARY.TYPES = ''
	CALL F.READ(FN.SCB.LOC.PARAM,LOC.PARAM.ID,R.LOC.PARAM.REC,F.SCB.LOC.PARAM,E.LOC.PARAM.ERR)
	IF R.LOC.PARAM.REC THEN
        Y.FLD.NAME = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.NAME>
		LOCATE 'DIARY.TYPES' IN Y.FLD.NAME<1,1> SETTING Y.NAME.POS THEN
            Y.DIARY.TYPES = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.VALUE,Y.NAME.POS>
			CHANGE @SM TO @FM IN Y.DIARY.TYPES
        END
	END
*
RETURN
*-----------------------------------------------------------------------------
END
