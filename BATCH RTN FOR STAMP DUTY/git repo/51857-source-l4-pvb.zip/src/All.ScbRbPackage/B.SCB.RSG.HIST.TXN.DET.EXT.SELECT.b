$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgHistTxnDetsExtSelect
* Modification History: 30th May 2023 - Pawan - To Extract SCB.UTS.HIST.TXN.DETS table to check the data available or not
*                     : 04th Jul 2023 - Mithun - To select the table SCB.UTS.HIST.TXN.DETS and build the batch list

* JIRA ID: CPSGMIG-17731

SUBROUTINE B.SCB.RSG.HIST.TXN.DET.EXT.SELECT

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.HIST.TXN.DET.EXT.COMMON
    $INSERT I_BATCH.FILES
    
  
    CALL OCOMO("Start check common variable")

    GOSUB SELECT.FILE
    
RETURN
***************
SELECT.FILE:

    SEL.CMD = "SELECT ":FN.HIST.TXN.DET
    CALL OCOMO(SEL.CMD)
    CALL OCOMO("Start check common variable ": FN.HIST.TXN.DET)
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.REC,RET.CODE)
    CALL OCOMO(NO.REC: " SELECTED")
    CALL BATCH.BUILD.LIST('',SEL.LIST)

RETURN
******************
END
