$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CLIENT.HOLDING.EXT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5321 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       13 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* SELECT Routine to merge the client portfolio details and generate final report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CLIENT.HOLDING.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.SECURITY.POSITION
    $INSERT I_B.SCB.CLIENT.HOLDING.EXT.COMMON
    
*
    GOSUB SEC.POS
*
    IF TRANS.ID.LIST THEN
        CALL BATCH.BUILD.LIST('',TRANS.ID.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
SEC.POS:
*-------
    SEL.SECPOS = '' ; SECPOS.LIST = '' ; NO.OF.SECPOS = '' ; SECPOS.ERR = ''
    SEL.SECPOS = "SELECT ":FN.SECURITY.POSITION
*
    CALL EB.READLIST(SEL.SECPOS,SECPOS.LIST,'',NO.OF.SECPOS,SECPOS.ERR)
    TRANS.ID.LIST<-1> = SECPOS.LIST
*
RETURN
*-----------------------------------------------------------------------------
    
END
