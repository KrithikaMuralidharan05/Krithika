$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-158</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.MF.SESO.T24.VESTIMA
*-----------------------------------------------------------------------------
* Description
* Singlethread routine to send the R2W reports to VESTIMA from SCB.SEC.OPEN.ORD.TRD.STATUS
* JIRA Ref no : CPSGMIG-3860
* Author : Loganathan G (1548187)
* Modification History:
*----------------------
* Loganathan G		CPSGMIG-13149	ISIN and Order Trade currency
* Loganathan G		CPSGMIG-14093	MasterRef SESO>COM.ORDER.REF
* Loganathan G		CPSGMIG-4875	Outbound file contains only Vestima Order based on AEB.SEC.PAR>DEPO
* Loganathan G 		CPSGMIG-15233	Update in the ReqNavCurr, PlaceOfTrade and FEBELoadRate
* 07/03/23 - PVBCOREBAU-1998 - Prabhu.L - Add BATCH>DATA.1 as EXCLUDE*179 , to exclude extraction
*based on SOO>STP.ORDER = "YES", If NO or null then include in extraction
* 04/08/2025 - - Manigandan P - Removed the File Transfer to R2W and including the File Transfer to ECARS as per scope.
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SC.EXE.SEC.ORDERS
    $INSERT I_F.SCB.SEC.OPEN.ORD.TRD.STATUS
    
    GOSUB INITIALISE
    GOSUB OPEN.FILE
    GOSUB HEADER.NAME
    GOSUB SELECT.MF.SESO
    
    IF SEL.CNT THEN
        GOSUB PROCESS
    END
    
    GOSUB AMEX.WRITE
*    GOSUB FILE.TRANSFER.R2W
	GOSUB FILE.TRANSFER.ECARS

RETURN

*----------
INITIALISE:
*----------

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''

    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''

    FN.SCB.SEC.OPEN.ORD.TRD.DETS = 'F.SCB.SEC.OPEN.ORD.TRD.STATUS'
    F.SCB.SEC.OPEN.ORD.TRD.DETS = ''

    FN.SEC.OPEN.ORDER = 'F.SEC.OPEN.ORDER'
    F.SEC.OPEN.ORDER = ''

*CPSGMIG-15233-Start
    FN.SEC.OPEN.ORDER.HIS = 'F.SEC.OPEN.ORDER$HIS'
    F.SEC.OPEN.ORDER.HIS = ''
*CPSGMIG-15233-End

    FN.SC.EXE.SEC.ORDERS = 'F.SC.EXE.SEC.ORDERS'
    F.SC.EXE.SEC.ORDERS = ''

    FN.SC.EXE.SEC.ORDERS.HIS = 'F.SC.EXE.SEC.ORDERS$HIS'
    F.SC.EXE.SEC.ORDERS.HIS = ''

    AMEX.FILES.PATH = 'AMEX.FILES'
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    FN.AMEX.FILES  = AMEX.FILES
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES ,F.AMEX.FILES)

    CUS.LOB.POS = ''
    Y.APPLICATION = 'CUSTOMER':@FM:'SEC.OPEN.ORDER'
    Y.FIELD = 'L.O.B':@FM:'LR.NET.SAL.PERC'
    Y.LOCAL.REF.POS = ''

    CALL MULTI.GET.LOC.REF(Y.APPLICATION,Y.FIELD,Y.LOCAL.REF.POS)
    CUS.LOB.POS = Y.LOCAL.REF.POS<1,1>
    SOO.NET.SAL.PERC.POS = Y.LOCAL.REF.POS<2,1>

    SEL.CMD = ''; SEL.LIST = ''; SEL.CNT = ''; MF.SEL.ERR = ''

    Y.LAST.COLUMN  = 'z'
* * PVBCOREBAU-1998 - S/E
   Y.BATCH.DET=''
   Y.BATCH.DET =  BATCH.DETAILS<3,1,1>

RETURN

**********
OPEN.FILE:
**********

    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    CALL OPF(FN.SCB.SEC.OPEN.ORD.TRD.DETS,F.SCB.SEC.OPEN.ORD.TRD.DETS)
    CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)	;*CPSGMIG-15233-S/E
    CALL OPF(FN.SC.EXE.SEC.ORDERS,F.SC.EXE.SEC.ORDERS)
    CALL OPF(FN.SC.EXE.SEC.ORDERS.HIS,F.SC.EXE.SEC.ORDERS.HIS)
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    Y.DATE.TIME = TIMEDATE()
    Y.DT.VALUE  = Y.DATE.TIME
    Y.TIME      = EREPLACE(FIELD(Y.DATE.TIME,' ',1),':','')
    Y.DATE      = FIELD(Y.DATE.TIME,' ',2,99)
    Y.DATE      = EREPLACE(OCONV(ICONV(Y.DATE,'D'),'D2c'),'c','')
    Y.DATETIME  = Y.DATE:Y.TIME
    Y.TIMESTAMP = Y.DATETIME:".ASC"
    Y.TIMESTAMP.R = TODAY[7,2]:TODAY[5,2]:TODAY[1,4]:'_':"230000"	
		
	IF ID.COMPANY[1,2] EQ 'SG' THEN
	PREFIX = 'SGR'
	END

    Y.FILE.NAME =  "DATA.":ID.COMPANY[7,3]:".RBSG_Vestima_Fund_Orders_":ID.COMPANY[1,2]:".csv":"_":Y.TIMESTAMP
	NAME.TO = PREFIX:"_VestimaOutboundfile_":Y.TIMESTAMP.R:".csv"
    

RETURN

***************
SELECT.MF.SESO:
***************

*CPSGMIG-4875-Start select the record for TRADE ID
    SEL.CMD = "SELECT ":FN.SCB.SEC.OPEN.ORD.TRD.DETS:" WITH EXECUTION.DATE NE ''"
    SEL.CMD := " AND (REPORT.STATUS EQ '')"
*CPSGMIG-4875-End

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,MF.SEL.ERR)

RETURN

********
PROCESS:
********
    
    LOOP
        REMOVE Y.MF.SOO.ID FROM SEL.LIST SETTING POS.ID
    WHILE Y.MF.SOO.ID:POS.ID
        GOSUB NULL.INT
		Y.SOO.ID=''
        Y.SOO.ID = Y.MF.SOO.ID
         R.SCB.SOO.REC='' ; ERR1=''
        CALL F.READ(FN.SCB.SEC.OPEN.ORD.TRD.DETS,Y.MF.SOO.ID,R.SCB.SOO.REC,F.SCB.SEC.OPEN.ORD.TRD.DETS,ERR1)
         R.SESO.REC='' ; ERR2='';ERR3=''
        CALL F.READ(FN.SC.EXE.SEC.ORDERS,Y.MF.SOO.ID,R.SESO.REC,F.SC.EXE.SEC.ORDERS,ERR2)
        IF NOT(R.SESO.REC) THEN
            CALL EB.READ.HISTORY.REC(F.SC.EXE.SEC.ORDERS.HIS,Y.MF.SOO.ID,R.SESO.REC,ERR3)
            Y.MF.SOO.ID = FIELD(Y.MF.SOO.ID,';',1)
        END
        R.SOO.REC='' ; ERR4='' ; ERR5=''
        CALL F.READ(FN.SEC.OPEN.ORDER,Y.MF.SOO.ID,R.SOO.REC,F.SEC.OPEN.ORDER,ERR4)
        IF NOT(R.SOO.REC) THEN
            CALL EB.READ.HISTORY.REC(F.SEC.OPEN.ORDER.HIS,Y.MF.SOO.ID,R.SOO.REC,ERR5)
            Y.MF.SOO.ID = FIELD(Y.MF.SOO.ID,';',1)			
        END
* * PVBCOREBAU-1998 - S/E
        Y.STP.FLAG = R.SOO.REC<SC.SOO.STP.ORDER>
	BEGIN CASE
	CASE Y.BATCH.DET NE ''
		IF Y.STP.FLAG EQ "YES" THEN
		    R.SCB.SOO.REC<SCB.REPORT.STATUS> = "BATCH-01 ":Y.DT.VALUE
            WRITE R.SCB.SOO.REC TO F.SCB.SEC.OPEN.ORD.TRD.DETS,Y.SOO.ID 
		END ELSE	
            IF R.SESO.REC THEN		
            GOSUB SESO.DETAIL
            IF Y.VESTIMA.FLAG EQ 'Y' THEN
            	GOSUB WRITE.ARRAY	
            END
			END
		END
	CASE Y.BATCH.DET EQ ''
            IF R.SESO.REC THEN	
            GOSUB SESO.DETAIL
            IF Y.VESTIMA.FLAG EQ 'Y' THEN
            	GOSUB WRITE.ARRAY
	        END
		    END
	END	CASE
 * * PVBCOREBAU-1998 - S/E
    REPEAT
RETURN
************
SESO.DETAIL:
************
    
    Y.CO.CODE = R.SESO.REC<SC.ESO.CO.CODE>
    BEGIN CASE
    CASE Y.CO.CODE EQ 'SG1090400'
        Y.ORD.REF = "SNG":Y.SOO.ID[7,10]
    CASE Y.CO.CODE EQ 'SG1090401'
        Y.ORD.REF = "ACU":Y.SOO.ID[7,10]
    END CASE

    Y.TXN.CODE = R.SESO.REC<SC.ESO.TRANSACTION.CODE>
    Y.ORD.TYPE = R.SESO.REC<SC.ESO.ORDER.TYPE>
    Y.DEPO.ID = R.SESO.REC<SC.ESO.DEPOSITORY>

*CPSGMIG-4875-Start Vestima Check
    IF Y.DEPO.ID THEN
	CALL SCB.RB.VEST.FLAG(Y.DEPO.ID,Y.VESTIMA.FLAG)
    END 	
*CPSGMIG-4875-End
    
    R.DEPO.CUST = ''
    CALL F.READ(FN.CUSTOMER,Y.DEPO.ID,R.DEPO.CUST,F.CUSTOMER,DEPO.CUST.ERR)
    IF R.DEPO.CUST THEN
        Y.DEPO.DESC = R.DEPO.CUST<EB.CUS.EXTERN.CUS.ID>
    END

    IF (Y.TXN.CODE EQ 'FPR' OR Y.TXN.CODE EQ 'FSI') AND (Y.ORD.TYPE NE 'CANC') THEN
        Y.ORDER.TYPE = 'SUBS'
    END
    IF (Y.TXN.CODE EQ 'FRD' OR Y.TXN.CODE EQ 'FSO') AND (Y.ORD.TYPE NE 'CANC') THEN
        Y.ORDER.TYPE = 'REDM'
    END
    IF Y.TXN.CODE EQ 'FRD' AND Y.ORD.TYPE EQ 'CANC' THEN
        Y.ORDER.TYPE = 'XXX-1'
    END
    IF Y.TXN.CODE EQ 'SWI' THEN
        Y.ORDER.TYPE 	= 'SWIT'
        Y.MASTER.REF 	= R.SESO.REC<SC.ESO.COM.ORDER.REF>
        Y.PERCENTAGE 	= '100'
*       Y.ORDERED.QTY 	= R.SESO.REC<SC.ESO.CUST.NOMINAL>
    END
    IF Y.TXN.CODE EQ 'SWO' THEN
        Y.ORDER.TYPE 	= 'SWIF'
        Y.MASTER.REF 	= R.SESO.REC<SC.ESO.COM.ORDER.REF>
        Y.ORDERED.QTY	= R.SESO.REC<SC.ESO.CUST.NOMINAL>
    END
    
    IF Y.TXN.CODE EQ 'FRD' OR Y.TXN.CODE EQ 'FSO' OR Y.TXN.CODE EQ 'SWO' THEN
        Y.ORDERED.QTY 	= R.SESO.REC<SC.ESO.CUST.NOMINAL>
    END
*CPSGMIG-15233-Start
    Y.TRADE.CCY 	= R.SESO.REC<SC.ESO.TRADE.CCY>
    Y.PLACE.OF.TRADE 	= 'XVES'
    IF R.SOO.REC AND (Y.TXN.CODE EQ 'SWI') THEN
	Y.FEBE.LOAD.RATE = R.SOO.REC<SC.SOO.LOCAL.REF><1,SOO.NET.SAL.PERC.POS>
    END
*CPSGMIG-15233-End
    IF Y.TXN.CODE EQ 'FPR' OR Y.TXN.CODE EQ 'FSI' THEN
        Y.ORDER.AMOUNT = R.SESO.REC<SC.ESO.CUST.NOMINAL>
        Y.ORDERED.AMT.CCY = R.SESO.REC<SC.ESO.TRADE.CCY>
    END
    Y.SM.ID = R.SESO.REC<SC.ESO.SECURITY.NO>
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,SM.ERR)
    Y.ISIN = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>

RETURN

*********
NULL.INT:
*********

    R.SCB.SOO.REC = ''
    R.SESO.REC = ''
    R.SOO.REC = ''
    Y.DEPO.ID = ''
    Y.EXE.DATE = ''
    Y.REPORT.STATUS = ''

    Y.ORD.AMT = ''
    Y.ORD.AMT.VAL = ''
    Y.ORD.AMT.DEC = ''
    
    Y.SESO.QTY.TYPE = ''
    Y.SESO.COM.TYPE = ''
    Y.VEST.QTY.AMT = ''
    Y.VEST.NARR = ''

    Y.ORD.REF = ''
    Y.ORDER.TYPE = ''
    Y.DEPO.DESC = ''
    Y.VEST.NARR = ''
    Y.ORDERED.QTY = ''
    Y.PERCENTAGE = ''
    Y.ORDERED.AMT.CCY = ''
    Y.ORDER.AMOUNT = ''
    Y.ISIN = ''
    Y.TRADE.CCY = ''
    Y.VESTIMA.FLAG = ''
    Y.MASTER.REF = ''
    Y.PLACE.OF.TRADE = ''
    Y.FEBE.LOAD.RATE = ''

RETURN

************
WRITE.ARRAY:
************

    R.SCB.SOO.REC<SCB.REPORT.STATUS> = "BATCH-01 ":Y.DT.VALUE
    WRITE R.SCB.SOO.REC TO F.SCB.SEC.OPEN.ORD.TRD.DETS,Y.SOO.ID    

    BLD.ARR = ''

    BLD.ARR = Y.ORD.REF         :DL
    BLD.ARR:= Y.ORDER.TYPE      :DL
    BLD.ARR:= Y.MASTER.REF      :DL:DL:DL:DL
    BLD.ARR:= Y.DEPO.DESC       :DL:DL:DL
    BLD.ARR:= Y.ORDERED.QTY     :DL
    BLD.ARR:= Y.PERCENTAGE      :DL
    BLD.ARR:= Y.ORDERED.AMT.CCY :DL
    BLD.ARR:= Y.ORDER.AMOUNT    :DL:DL
    BLD.ARR:= Y.ISIN            :DL
    BLD.ARR:= Y.TRADE.CCY       :DL
    BLD.ARR:= Y.PLACE.OF.TRADE  :DL
    BLD.ARR:= DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL
    BLD.ARR:= Y.FEBE.LOAD.RATE	:DL
    BLD.ARR:= DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL:DL
    BLD.ARR:= 'z'

    ARRAY.LIST<-1> = BLD.ARR

RETURN

************
HEADER.NAME:
************

    DL = ','

    HDR.ARR ="OrderOIRef":DL
    HDR.ARR:="OrderType":DL
    HDR.ARR:="MasterRef":DL
    HDR.ARR:="MasgNumber":DL
    HDR.ARR:="SeqNumber":DL
    HDR.ARR:="SettleCurr":DL
    HDR.ARR:="Portfolio":DL
    HDR.ARR:="InternalNarr":DL
    HDR.ARR:="ExternalNarr":DL
    HDR.ARR:="OrderedQty":DL
    HDR.ARR:="Percentage":DL
    HDR.ARR:="OrderedAmntCurr":DL
    HDR.ARR:="OrderAmnt":DL
    HDR.ARR:="CommonCd":DL
    HDR.ARR:="Isin":DL
    HDR.ARR:="ReqNavCurr":DL
    HDR.ARR:="PlaceOfTrade":DL
    HDR.ARR:="RestrictType":DL
    HDR.ARR:="LimitPriceCurr":DL
    HDR.ARR:="LimitPriceAmnt":DL
    HDR.ARR:="StopPriceCurr":DL
    HDR.ARR:="StopPriceAmnt":DL
    HDR.ARR:="ExpiryDate":DL
    HDR.ARR:="TimeLimits":DL
    HDR.ARR:="AppliedCommCurr":DL
    HDR.ARR:="AppliedComAmnt":DL
    HDR.ARR:="AppliedComRate":DL
    HDR.ARR:="OtherComCurr":DL
    HDR.ARR:="OtherComAmnt":DL
    HDR.ARR:="OtherComRate":DL
    HDR.ARR:="FEBELoadCurr":DL
    HDR.ARR:="FEBELoadAmnt":DL
    HDR.ARR:="FEBELoadRate":DL
    HDR.ARR:="DiscountCurr":DL
    HDR.ARR:="DiscountAmnt":DL
    HDR.ARR:="DiscountRate":DL
    HDR.ARR:="STBRbic":DL
    HDR.ARR:="STBRnameAddr":DL
    HDR.ARR:="STBRacct":DL
    HDR.ARR:="CBLRbic":DL
    HDR.ARR:="CBLRNameAddr":DL
    HDR.ARR:="CBLRAcct":DL
    HDR.ARR:="INVEbic":DL
    HDR.ARR:="INVENameAddr":DL
    HDR.ARR:="INVEAcct":DL
    HDR.ARR:="INVECommContract":DL
    HDR.ARR:="h"

    ARRAY.LIST = HDR.ARR

RETURN
***********
AMEX.WRITE:
***********

    WRITE ARRAY.LIST TO F.AMEX.FILES,Y.FILE.NAME

RETURN

******************
FILE.TRANSFER.R2W:
******************

    FLOW.IDENTIFER.ID = ''; FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''

    FLOW.IDENTIFER.ID = "T24_RBR2W_SG"

    FILE.NAME = FN.AMEX.FILES
    RECORD.NAME = Y.FILE.NAME
    TARGET.FILE.NAME = Y.FILE.NAME
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'CONVFND2U')

RETURN

******************
FILE.TRANSFER.ECARS:
******************

			HM = "../bnk.interface/"
			ECARS.PATH.ORG = "ECARS.REPORT.RBSG/IN"
			SRC.PATH = HM:AMEX.FILES.PATH:"/":Y.FILE.NAME
			ECARS.PATH = HM:ECARS.PATH.ORG
			DES.PATH = ECARS.PATH:"/":NAME.TO
			GOSUB FILE.SIZE.CHECK
			DUP.CPY = 'SH -c "cp ':SRC.PATH:' ./mwaredupfiles/':NAME.TO:'"'
			EXECUTE DUP.CPY
            CALL OCOMO("File Transfer for mwaredupfiles - ":DUP.CPY)
            ECARS.CPY = 'SH -c "cp ':SRC.PATH:' ':DES.PATH:'"'
			EXECUTE ECARS.CPY
            CALL OCOMO("File Transfer for Destination path - ":ECARS.CPY)


RETURN

****************
FILE.SIZE.CHECK:
****************
    FILE.MISMATCH = 0
    FTP.FLAG = 1
    CTR = 0
    FINDSTR "&" IN DES.PATH SETTING POS THEN   
        DES.PATH = EREPLACE(T.FILE.NAME,"&","'&'")
    END
    	FILE.SIZE.PREV = 0
    FILE.SIZE = 0
    SIZE.CHK.CMD = ''
    LOOP
    WHILE FTP.FLAG
        CTR = CTR + 1
        FILE.SIZE = ""
        SIZE.CHK.CMD = "SH -c stat --format='%s' ":DES.PATH
        EXECUTE SIZE.CHK.CMD CAPTURING FILE.SIZE
        IF CTR GT 1 THEN
                FTP.FLAG = ""
                CALL OCOMO("Source File size (prev) :- ":DES.PATH :":-":FILE.SIZE.PREV )
                CALL OCOMO("Source File size (curr) :- ":DES.PATH :":-":FILE.SIZE )
		IF FILE.SIZE.PREV EQ FILE.SIZE THEN
			CALL OCOMO("File size matched ":FILE.SIZE.PREV:"#":FILE.SIZE )
		END ELSE
			FILE.MISMATCH = 1
			CALL OCOMO("File size mismatched ":FILE.SIZE.PREV:"#":FILE.SIZE )
		END                
        END ELSE
            	FILE.SIZE.PREV = ""
            	FILE.SIZE.PREV = FILE.SIZE
            SLEEP 2
        END
    REPEAT
RETURN
END