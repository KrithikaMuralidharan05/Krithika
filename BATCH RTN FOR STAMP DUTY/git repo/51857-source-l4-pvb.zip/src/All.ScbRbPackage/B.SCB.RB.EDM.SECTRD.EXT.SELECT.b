$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EDM.SECTRD.EXT.SELECT
**--------------------------------------------------------------------------------------------------------------------
    ! DESCRIPTION : THIS IS A SELECT FILE WHICH WILL SELECT ALL THE TRADE TRASACTION HAPPENED ON A DAY TO DAY BASIS
    !               FOR EXTRACTION.
**--------------------------------------------------------------------------------------------------------------------
*
* 25/07/2022 - Shreekantha. G - CPSGMIG-4971 - Copy of Existing Routine B.SCB.ST.PBDW.EXTRACT.SELECT.b
*
*---------------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.EDM.SECTRD.EXTRACT.COMMON
*
    IF ID.COMPANY EQ "SG1090400" THEN   
        SEL.CMD = "SSELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":COUNTRY.NAME:"...*SCTRSC..."
    END ELSE        
        SEL.CMD = "SSELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":ID.COMPANY:"...*SCTRSC..."          
    END
*
    CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
*
    CALL BATCH.BUILD.LIST('ST.LIST',SEC.ID)
*
    RETURN
*
*---------------------------------------------------------------------------------------------------------------------
END
*---------------------------------------------------------------------------------------------------------------------
