$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.RECON.ICM.ATT.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*Jira Reference:CPSGMIG-17414
*Developer : Raja Prabhu S
*Date : 14-APR-2023
*Description : Used to extract the details from ICM  for recon against the data from t24
*O/p : NA
*-------------------------------------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.RECON.ICM.ATT.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT
    
    
    GOSUB INIT
   

RETURN
*---------------------
INIT:
*--------------------


    FN.DEST.PATH = "./DATA.IN"
    F.DEST.PATH  = ''
    CALL OPF(FN.DEST.PATH,F.DEST.PATH)
	
    FN.EBBS.CONCAT = "F.ST.SCB.RSG.EBBS.REL.CONCAT"
	F.EBBS.CONCAT  = ""
	CALL OPF(FN.EBBS.CONCAT,F.EBBS.CONCAT)

    
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.SCB.WM.H.LOCAL.PARAM  = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)

    Y.ID = "MIG.MT.POST.PARAM"
 
    Y.BATCH.DATA = BATCH.DETAILS<3,1,1>

    
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.ID,R.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.PARAM.ERR)
    Y.BATCH.ID = R.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.FILE.NAMES = R.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>

    LOCATE Y.BATCH.DATA IN Y.BATCH.ID<1,1> SETTING Y.BATCH.POS THEN


        Y.PATH.FILE.SET = Y.FILE.NAMES<1,Y.BATCH.POS>

        Y.PATH.FILE = RAISE(Y.PATH.FILE.SET)
        Y.PATH.FILE.CNT = DCOUNT(Y.PATH.FILE,@VM)

        FOR I = 1 TO Y.PATH.FILE.CNT

            Y.FILE.CHECK = ''; Y.FILE.CHECK = Y.PATH.FILE<1,I>;*SRC need to be defined as first SV  in MIG.MT.POST.PARAM

            IF I = '1' THEN
                Y.SRC.FLD.PATH = FIELD(Y.FILE.CHECK,'>',1)
                Y.SRC.FILE.NAME = FIELD(Y.FILE.CHECK,'*',2)
                CALL OPF(Y.SRC.FLD.PATH,Y.SRC.FILEPATH)
            END ELSE
                BEGIN CASE
                    CASE I = 2
                        Y.DEST.FLD.PATH = FIELD(Y.FILE.CHECK,'>',1)
                        Y.DEST.FILE.NAME = FIELD(Y.FILE.CHECK,'>',2):'.':SESSION.NO ;*Filename.SESSION.NO
                        GOSUB DEST.FILE.BUILD

                    CASE I = 3
                        Y.LOG.FLD.PATH = FIELD(Y.FILE.CHECK,'>',1)
                        Y.LOG.FILE.NAME = FIELD(Y.FILE.CHECK,'>',2):'.':SESSION.NO ;*Filename.SESSION.NO
                        GOSUB EXP.FILE.BUILD
                END CASE
            END

        NEXT I

    END

	
RETURN
*----------------
DEST.FILE.BUILD:
*---------------

    Y.ICM.RECON.FILEPATH =  Y.DEST.FLD.PATH
    Y.ICM.RECON.FILENAME = Y.DEST.FILE.NAME

    OPENSEQ Y.ICM.RECON.FILEPATH,Y.ICM.RECON.FILENAME TO Y.NS.FILEPATH ELSE
    END

RETURN
*------------------
EXP.FILE.BUILD:
*------------------

    OPENSEQ Y.LOG.FLD.PATH,Y.LOG.FILE.NAME TO Y.EXP.FILEPATH ELSE
    END

RETURN
*---------------------------------------------------------------------------------------------
END

