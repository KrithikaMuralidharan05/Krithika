* @ValidationCode : Mjo5Njk4Mjg4MTE6SVNPLTg4NTktMToxNjgyNTExMjA5NjI2OjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 26 Apr 2023 17:43:29
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CLIENT.HOLDING.EXT.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5321 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       13 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* LOAD Routine to merge the client portfolio details and generate final report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CLIENT.HOLDING.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 30-Nov-2022 - CPSGMIG-17507 - Sandhya K - Updating mapping for CASH OR REINVEST
* 24-Apr-2023 - CPSGMIG-22844 - 1) New field "Position Migration flag"[ LR.POS.MIG.DT]to be introduced in Reports for users to filter the migrated positions.
*				2) Existing column RM Name can be mapped as CUSTOMER > ACCOUNT.OFFICE > DAO > NAME
*                               3) ARM Code - Mapping should be CUSTOMER > ACCOUNT.OFFICE > DAO > LR.ARM.CODE
* 26-Apr-2023   CPSGMIG-21498   1663000   - Filename/Date Change
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.COUNTRY
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.SCB.WM.H.GEN.PARAM
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_B.SCB.CLIENT.HOLDING.EXT.COMMON
    $INSERT I_F.SCB.RB.PENDING.TRANSACTION
    $INSERT I_F.DEPT.ACCT.OFFICER ;* CPSGMIG-22844(S/E)
    $INSERT I_F.DATES   ;*CPSGMIG-21498
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.SECURITY.POSITION	= "F.SECURITY.POSITION"
    F.SECURITY.POSITION		= ""
    CALL OPF(FN.SECURITY.POSITION, F.SECURITY.POSITION)
*
    FN.SECURITY.MASTER		= "F.SECURITY.MASTER"
    F.SECURITY.MASTER 		= ""
	CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
	FN.CUSTOMER = "F.CUSTOMER"
    F.CUSTOMER 	= ''
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    
    FN.COUNTRY 	= "F.COUNTRY"
    F.COUNTRY 	= ''
    CALL OPF(FN.COUNTRY,F.COUNTRY)

*
    FN.SCB.RB.PENDING.TRANSACTION 	= "F.SCB.RB.PENDING.TRANSACTION"
    F.SCB.RB.PENDING.TRANSACTION 	= ''
	CALL OPF(FN.SCB.RB.PENDING.TRANSACTION,F.SCB.RB.PENDING.TRANSACTION)
*
    FN.SEC.ACC.MASTER 	= "F.SEC.ACC.MASTER"
    F.SEC.ACC.MASTER 	= ''
	CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    
    FN.SCB.WM.H.LOCAL.PARAM = "F.SCB.WM.H.LOCAL.PARAM"
    F.SCB.WM.H.LOCAL.PARAM  = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
*CPSGMIG-22844-S
    FN.DAO = 'F.DEPT.ACCT.OFFICER'
    F.DAO  = ''
    CALL OPF(FN.DAO,F.DAO)
*CPSGMIG-22844-E
    FN.SCB.WM.H.GEN.PARAM = "F.SCB.WM.H.GEN.PARAM"
    F.SCB.WM.H.GEN.PARAM = ''
    CALL OPF(FN.SCB.WM.H.GEN.PARAM,F.SCB.WM.H.GEN.PARAM)
    Y.PARAM.ID = "SCB.CLIENT.HOLDING"
    CALL F.READ(FN.SCB.WM.H.GEN.PARAM,Y.PARAM.ID,R.GEN.PARAM,FN.SCB.WM.H.GEN.PARAM,Y.GEN.ERR)
    Y.OUT.DIR		= R.GEN.PARAM<SCBWM.GEN.OUT.DIR>
    Y.FILE.NAME 	= R.GEN.PARAM<SCBWM.GEN.FILE.NAME>
    FN.FILE.PATH 	= Y.OUT.DIR
    F.FILE.PATH		= ''
*CPSGMIG-22844-S
    Y.APP = 'CUSTOMER':@FM:'SEC.ACC.MASTER':@FM:'SECURITY.MASTER':@FM:'DEPT.ACCT.OFFICER'
    Y.FIELD = 'L.O.B':@VM:'LR.SIGN.MANDATE':@VM:'LR.PFOLIO.KEY':@VM:'LR.STAFF.IND':@FM:'LR.TP.AC.STATUS':@VM:'LR.POS.MIG.DT':@FM:'CASH.OR.REINV':@VM:'LR.RETAIL.DEPO':@VM:'LR.UTS.INS.DESC':@VM:'LM.RET.DEPO.INV':@FM:'LR.ARM.CODE'
*CPSGMIG-22844-E
    Y.FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    L.O.B.CUS.POS = Y.FIELD.POS<1,1>
    LR.SIGN.MANDATE.POS = Y.FIELD.POS<1,2>
    LR.PFOLIO.KEY.POS = Y.FIELD.POS<1,3>
    LR.STAFF.IND.POS = Y.FIELD.POS<1,4>
    LR.TP.AC.STATUS.POS 	= Y.FIELD.POS<2,1>
    LR.POS.MIG.DT.POS           = Y.FIELD.POS<2,2> ;*CPSGMIG-22844-S/E
    Y.CASH.OR.REINV.POS 	= Y.FIELD.POS<3,1>
    Y.LR.RETAIL.DEPO.POS 	= Y.FIELD.POS<3,2>
    LR.UTS.INS.DESC.POS 	= Y.FIELD.POS<3,3>
    LM.RET.DEPO.INV.POS		= Y.FIELD.POS<3,4> ;*CPSGMIG-17507(S/E)
    LR.ARM.CODE.POS             = Y.FIELD.POS<4,1> ;*CPSGMIG-22844-S/E
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
* PVB/RB Customer Demarkation
    
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
	AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE.NAME = "ClientDetailsPerUTCode-":TODAY:"-":SESSION.NO:".csv"
    
    Y.LWD            = R.DATES(EB.DAT.LAST.WORKING.DAY)            ;* CPSGMIG-21498
    
RETURN
END
