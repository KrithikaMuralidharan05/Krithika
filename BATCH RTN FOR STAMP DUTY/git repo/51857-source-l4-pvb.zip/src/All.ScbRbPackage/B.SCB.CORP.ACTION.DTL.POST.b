* @ValidationCode : MjoxNzAyMTI5NTg5OklTTy04ODU5LTE6MTY4MjMzMzY2Nzc0NjoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 24 Apr 2023 16:24:27
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CORP.ACTION.DTL.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14066 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       08 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Main Routine to extract Daily corporate action details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CORP.ACTION.DTL.LOAD
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename Change
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_B.SCB.CORP.ACTION.DTL.COMMON
    
    GOSUB INIT
    GOSUB PROCESS
RETURN

*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX.FILES,F.AMEX.FILES,AMEXPATH)
*
    R.CORP.ACT.DTL.FINAL.ARR = '' ; R.CORP.ACT.DTL.FINAL = ''
    Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.FINAL.FILE.NAME = BATCH.DETAILS<3,1>
    
    Y.FINAL.FILE.NAME = EREPLACE(Y.FINAL.FILE.NAME,"<LWD>",Y.LAST.WRK.DAY,-1) ;* CPSGMIG-21498
*
RETURN

*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
    
    Y.UDFILE = 'AMEX.FILES'
    SEL.CMD  = 'SCBCORPACTIONDTL-':TODAY:'*.csv' ;*"SCBCORPACTIONDTL-":TODAY:"-":SESSION.NO:".csv"
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)

    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.CORP.ACT.DTL.FINAL.ARR EQ '' THEN
                R.CORP.ACT.DTL.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.CORP.ACT.DTL.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT

        DELIM = ","
        Y.UTS.HDR  = "Vestima":DELIM:"Branch Code":DELIM:"Branch Name":DELIM:"Dividend Instruction":DELIM:"Confirmation Date":DELIM:
        Y.UTS.HDR  := "Order Date - Book Close Date":DELIM:"Corporate Post Date-Dist. Date":DELIM:"Account Number":DELIM:"Account Holder 1":DELIM:
        Y.UTS.HDR  := "Account Holder 2":DELIM:"Account Holder 3":DELIM:"Account Holder 4":DELIM:"Address #1":DELIM:"Address #2":DELIM:"Address #3":DELIM:
        Y.UTS.HDR  := "Address #4":DELIM:"City":DELIM:"Postal Code":DELIM:"PO BOX":DELIM:"Country Full Name":DELIM:"Asset Type":DELIM:"Asset Code":DELIM:
        Y.UTS.HDR  := "Asset Currency":DELIM:"Asset Name":DELIM:"Dividend Entitlement":DELIM:"Corporate Action Rate":DELIM:"Dividend Amount":DELIM:
        Y.UTS.HDR  := "Asset Price":DELIM:"Amount/Unit Allocated":DELIM:"Settlement Account":DELIM:"ISA Status":DELIM:"Distribution Run No":DELIM:
        Y.UTS.HDR  := "DIARY Ref":DELIM:"Event Type":DELIM:"Islamic Flag":DELIM:"Officer Name":DELIM:"ARM Code":DELIM:"Lien Reason Description":DELIM:
        Y.UTS.HDR  := "ClientIdentifier":DELIM:"PrimaryAcctHolder"
        
        R.CORP.ACT.DTL.FINAL = Y.UTS.HDR
        R.CORP.ACT.DTL.FINAL<-1> = R.CORP.ACT.DTL.FINAL.ARR

        WRITE R.CORP.ACT.DTL.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME

    END
RETURN

END
