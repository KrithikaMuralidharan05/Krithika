$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GST.ENTRIES.PROCESS.LOAD
*------------------------------------------------------------------------------
*
* Author                       Loganathan G
* EPACC/Story/Sub task Ref     CPSGMIG-3231
* Routine Type                 Batch process routine
* Attached To                  BATCH>SNG/SCB.RB.STATIC.ENTRY
* Workflow                     To update SCB.GST.RBSG.EXTRACT table for GST Amount
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*
*
*----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES	
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SCB.GST.RBSG.PARAM
    $INSERT I_B.SCB.RB.GST.ENTRIES.PROCESS.COMMON

    GOSUB OPEN.FILE
    GOSUB PROCESS

    RETURN

**********
OPEN.FILE:
**********

    FN.CURRENCY = 'F.CURRENCY'

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.SEC.TRADE = 'F.SEC.TRADE'
    F.SEC.TRADE = ''
    CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)

    FN.SEC.TRADE.HIS = 'F.SEC.TRADE$HIS'
    F.SEC.TRADE.HIS = ''
    CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)

    FN.CATEG.INT.ACCT = 'F.CATEG.INT.ACCT'
    F.CATEG.INT.ACCT = ''
    CALL OPF(FN.CATEG.INT.ACCT,F.CATEG.INT.ACCT)

    FN.ACCT.ENT.TODAY = 'F.ACCT.ENT.LWORK.DAY'
    F.ACCT.ENT.TODAY = ''
    CALL OPF(FN.ACCT.ENT.TODAY,F.ACCT.ENT.TODAY)

    FN.STMT.ENTRY = 'F.STMT.ENTRY'
    F.STMT.ENTRY = ''
    CALL OPF(FN.STMT.ENTRY,F.STMT.ENTRY)

    FN.SCB.GST.RBSG.PARAM = 'F.SCB.GST.RBSG.PARAM'
    F.SCB.GST.RBSG.PARAM = ''
    CALL OPF(FN.SCB.GST.RBSG.PARAM,F.SCB.GST.RBSG.PARAM)

    FN.SCB.GST.RBSG.EXTRACT = 'F.SCB.GST.RBSG.EXTRACT'
    F.SCB.GST.RBSG.EXTRACT = ''
    CALL OPF(FN.SCB.GST.RBSG.EXTRACT,F.SCB.GST.RBSG.EXTRACT)
  
    Y.APPLICATION = 'CUSTOMER'
    Y.FIELD = 'L.O.B'
    Y.LOCAL.REF.POS = ''

    CALL MULTI.GET.LOC.REF(Y.APPLICATION,Y.FIELD,Y.LOCAL.REF.POS)
    CUS.LOB.POS       	= Y.LOCAL.REF.POS<1,1>
    
    RETURN

********
PROCESS:
********

    Y.PARAM.ID 		= ''
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB 	= ''

    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)

    Y.RB.GST.CATEGORY = ''
    Y.SCB.RBSG.GST.PARAM.ID = 'SG1090400*SEC.TRADE'
    R.SCB.GST.RBSG.PARAM = ''
    CALL F.READ(FN.SCB.GST.RBSG.PARAM,Y.SCB.RBSG.GST.PARAM.ID,R.SCB.GST.RBSG.PARAM,F.SCB.GST.RBSG.PARAM,ST.PARAM.ERR)

    IF R.SCB.GST.RBSG.PARAM THEN
        Y.GST.INT.CATEG = R.SCB.GST.RBSG.PARAM<RB.PARAM.GST.INT.CATEG>
    END
    
    RETURN

END
