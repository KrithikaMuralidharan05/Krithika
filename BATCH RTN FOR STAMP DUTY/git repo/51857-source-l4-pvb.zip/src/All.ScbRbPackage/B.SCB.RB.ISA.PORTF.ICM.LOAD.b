$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ISA.PORTF.ICM.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13848 - JEWEL_T24_PROJECT
* Developed By                   :       Chandru Sampath
* Developed On                   :       19 October 2022
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract Day0 File for ICM
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/B.SCB.RB.ISA.PORTF.ICM
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_B.SCB.RB.ISA.PORTF.ICM.COMMON

   GOSUB INIT
   GOSUB PROCESS
   
   RETURN

*===================================================================================   
INIT:
*===================================================================================    

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER  = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
	
	FN.CUSTOMER ="F.CUSTOMER"
	F.CUSTOMER =""
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)
	
	FN.SCB.WM.H.LOCAL.PARAM ="F.SCB.WM.H.LOCAL.PARAM"
	F.SCB.WM.H.LOCAL.PARAM =""
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
    
    Y.APPL = "SEC.ACC.MASTER":@FM:"CUSTOMER"
    Y.FLD = "LR.TP.ACCT.NO":@VM:"LR.PFOLIO.KEY":@VM:"LR.TP.AC.STATUS":@FM:"LR.PP.CODE"
    Y.POS = ''

    CALL MULTI.GET.LOC.REF(Y.APPL, Y.FLD,Y.POS)
    
    Y.LR.TP.ACCT.NO.POS = Y.POS<1,1>
    Y.LR.PFOLIO.KEY.POS = Y.POS<1,2>
	Y.LR.TP.AC.STATUS.POS = Y.POS<1,3>
    
    Y.LR.PP.CODE.POS = Y.POS<3,1>
    
RETURN

*===================================================================================
PROCESS:
*===================================================================================

	Y.WM.ID ="RSG.PILOT.IND"
	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.WM.ID,R.SCB.WM.H.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOC.P)
    ISA.LISTS = R.SCB.WM.H.LOC.PARAM<SCBWM.PRM.FIELD.VALUE>		;*Get the list of Individual ISA lists from table SCB.WM.H.LOCAL.PARAM
    ISA.LISTS.CNT = DCOUNT(ISA.LISTS,@SM)
    CONVERT @SM TO @VM IN ISA.LISTS

    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE.NAME.SAM = "SAM.ISA.ICM-":TODAY:"-":SESSION.NO:".csv"
    
RETURN
END
