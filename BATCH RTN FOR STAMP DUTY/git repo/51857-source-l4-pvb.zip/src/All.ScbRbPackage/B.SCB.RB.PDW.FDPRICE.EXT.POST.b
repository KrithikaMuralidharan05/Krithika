$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.PDW.FDPRICE.EXT.POST
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 07/09/2022 - Lavanya L - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_FundPrice_YYYYMMDD.csv
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.FINAL.FILE.NAME = ''
    R.TXNDETS.RPT.FINAL.ARR = ''
    Y.FINAL.FILE.NAME = 'T24-SG-FundPrice-':TODAY:'.csv'
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = ID.COMPANY[1,2]:'*-FundPrice-*':TODAY:'.csv-*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.FINAL.ARR EQ '' THEN
                R.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
    END
    DL = CHAR(01)
	NO.OF.RECORDS = DCOUNT(R.FINAL.ARR,@FM)
    Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
	Y.FPRICE.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
	Y.FPRICE.HEADER<-1> = 'REC-IND':DL:'FUND-CODE':DL:'EFFECTIVEDATE':DL:'FUND-HOUSE':DL:'FUND-DESCRIPTION-1':DL:'FUND-HOUSE-DESC1':DL:'FUND-CURRENCY':DL:'BID-PRICE':DL:'OFF-PRICE':DL:'CUTOFF-TIME'
	Y.FPRICE.FOOTER = 'T':DL:NO.OF.RECORDS
	R.FINAL.VAL = Y.FPRICE.HEADER:@FM:R.FINAL.ARR:@FM:Y.FPRICE.FOOTER
*
	R.FINAL.VAL =UTF8(R.FINAL.VAL)
    WRITE R.FINAL.VAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
*
RETURN
*-----------------------------------------------------------------------------
END
