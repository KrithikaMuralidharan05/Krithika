$PACKAGE All.ScbRbPackage
	SUBROUTINE B.SCB.RB.SOO.TRD.UPD
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This routine is used to delete records from the local table SCB.SEC.OPEN.ORD.TRD.STATUS.
*----------------------------------------------------------------------------------------
* Attached To : BATCH>SNG/SCB.RB.PEND.TRANS.UPD
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 128-Jul-2023       Lavanya L       CPSGMIG-4913       Initial Creation
*----------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
    $INSERT I_F.SCB.SEC.OPEN.ORD.TRD.STATUS
	
	GOSUB INIT
	GOSUB DEL.HIST.LIST
	GOSUB DEL.LIVE.LIST
	
	RETURN
*-----------------------------------------------------------------------------------------------------
INIT:
*---
	FN.SOO.TRD = 'F.SCB.SEC.OPEN.ORD.TRD.STATUS'
	F.SOO.TRD = ''
	CALL OPF(FN.SOO.TRD,F.SOO.TRD)

	FN.SOO.TRD.HIS = 'F.SCB.SEC.OPEN.ORD.TRD.STATUS$HIS'
	F.SOO.TRD.HIS = ''
	CALL OPF(FN.SOO.TRD.HIS,F.SOO.TRD.HIS)
    
    FROM.DATE = '' ; TO.DATE = ''
    FROM.DATE = TODAY
    CALL CDT("",FROM.DATE,"-30C")
    
	RETURN
*-----------------------------------------------------------------------------------------------------------------------
DEL.HIST.LIST:
*------------

	SEL.CMD = ''
	SEL.LIST = ''
	NO.OF.REC = ''
	ERR.LIST = ''
	Y.INT = 1
	SEL.CMD = "SELECT ":FN.SOO.TRD.HIS:" WITH (VALUE.DATE NE '' AND VALUE.DATE LT ":FROM.DATE:")" 
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.LIST)
    LOOP
	WHILE Y.INT LE NO.OF.REC
    	CALL F.DELETE(FN.SOO.TRD.HIS,SEL.LIST<Y.INT>)
        Y.INT++
    REPEAT
RETURN
*---------------------------------------------------------------------------------------------------------------------------
DEL.LIVE.LIST:
*-------------
	SEL.CMD = ''
	SEL.LIST = ''
	NO.OF.REC = ''
	ERR.LIST = ''
	Y.INT = 1
	SEL.CMD = "SELECT ":FN.SOO.TRD:" WITH (VALUE.DATE NE '' AND VALUE.DATE LT ":FROM.DATE:")" 
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.LIST)
    LOOP
	WHILE Y.INT LE NO.OF.REC
    	CALL F.DELETE(FN.SOO.TRD,SEL.LIST<Y.INT>)
        Y.INT++
    REPEAT
	RETURN
END