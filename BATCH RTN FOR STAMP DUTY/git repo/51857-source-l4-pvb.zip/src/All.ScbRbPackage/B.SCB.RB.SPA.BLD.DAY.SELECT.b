$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-5</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.SPA.BLD.DAY.SELECT
*-------------------------------------------------------------------------------------------------------------*
* Description:
*----------------------------------------------------------------------------------------
* Multi thread select routine for the 2nd part of SCB.RB.SC.POS.ACTIVITY which builds the day wise
* updates into SCB.RB.SC.POS.ACTIVITY table
*-------------------------------------------------------------------------------------------------------------
* Modification History:
*-------------------------------------------------------------------------------------------------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- Daily job to update the day wise nominal in SCB.RB.SEC.POS.ACTIVITY.
*-------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_SCB.RB.SPA.BLD.DAY.COMMON
*
    YSEL = "SELECT ":YF.SCB.RB.SEC.POS.ACTIVITY:" WITH @ID LIKE ...":YLASTWRKDAY[1,6]

    YT.POS.IDS = ""
    YC.POS.IDS = ""
    SRC = ""
    CALL EB.READLIST(YSEL,YT.POS.IDS,"",YC.POS.IDS,SRC)

    Y.FIN.IDS = SORT(YT.POS.IDS)

    CALL BATCH.BUILD.LIST("AEB.SPA.IDS",Y.FIN.IDS)
*

RETURN
END
