$PACKAGE All.ScbRbPackage
*---------------------------------------------------------------------------
* <Rating>135</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE B.SCB.RB.SUPP.SP.DAVINCI.POST
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This is newly introduced singlethreaded job to concatenate all the spring
*   files generated in different sessions under AMEX.FILES.
* Copy of existing SCB.SUPP.SP.DAVINCI.POST, include LOB logic for RB.
*-----------------------------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 29-Apr-2022       Lavanya L       CPSGMIG-2776        Initial Creation
*--------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.SUPP.SP.DAVINCI.COMMON
*
    GOSUB INIT
    GOSUB PROCESS
*
    RETURN
*
*----------------------------------------------------------------------------
INIT:
*----
*
*    REP.NAME = 'SCB-':Y.COMPANY.ID:'-SP-SECPOS-':TODAY:'.txt'
*    REP.NAME.ALL = 'SCB-':Y.COMPANY.ID:'-SP-SECPOS-':TODAY:'-'
* TAFJUPD(S)
    FN.AMEX.FILES = 'AMEX.FILES'
	FV.AMEX.FILES = ''
	CALL OPF(FN.AMEX.FILES,FV.AMEX.FILES)
* TAFJUPD(E)
*	
    REP.NAME = 'SCB-':ID.COMPANY[1,2]:'-SP-RB-SECPOS-':TODAY:'.txt'				;*CPSGMIG-2776
    REP.NAME.ALL = 'SCB-':ID.COMPANY[1,2]:'-SP-RB-SECPOS-':TODAY:'-'			;*CPSGMIG-2776
*   OPEN "AMEX.FILES" TO AMEX.FILES ELSE NULL       ;* TAFJUPD(S/E)

    Y.DELIM = CHARX(9)

    Y.HEADER = ''
    Y.HEADER = 'LinkID' : Y.DELIM : 'Security' : Y.DELIM : 'SAM' : Y.DELIM : 'SAMRefCcy' : Y.DELIM : 'Nominal' : Y.DELIM
    Y.HEADER := 'CostofInvestment' : Y.DELIM : 'AcquisitionDate' : Y.DELIM : 'AccruedInterest' : Y.DELIM
    Y.HEADER := 'CostPrice' : Y.DELIM : 'GrCostRefCcy'      ;* PIDF - S/E
*CPSGMIG-2776 - S	
	Y.HEADER :=  Y.DELIM :'GrCostBseCcy' : Y.DELIM : 'Value Dated Posn': Y.DELIM : 'Value Dated Cost': Y.DELIM : 'Val Dat Bkcost Ref': Y.DELIM 
	Y.HEADER := 'Val Dat Bkcost Bse' : Y.DELIM : 'Unsettled Nom Cr' : Y.DELIM : 'Unsettled Nom Dr'
*CPSGMIG-2776 - E
RETURN
*----------------------------------------------------------------------------
PROCESS:
*-------
*
* TAFJUPG - S - Changing conditional select
*   SEL.CMD = "SELECT AMEX.FILES LIKE ":REP.NAME.ALL:"..."
*   CALL EB.READLIST(SEL.CMD, FILE.LIST,'',FILES.SELECTED,SYS.RET.CODE)

    Y.UDFILE       = 'AMEX.FILES'
    Y.CRITERIA     = REP.NAME.ALL:"*"
    FILE.LIST      = ''
    FILES.SELECTED = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, FILE.LIST, FILES.SELECTED)
* TAFJUPG - E - Changing conditional select
*
    ALL.FILES = ""
    TEMP.ARRAY = ""
    TEMP.ARRAY.SORT = ""
    LOOP
        REMOVE FILE.ID FROM FILE.LIST SETTING MORE.IDS
    WHILE FILE.ID:MORE.IDS
*       READ R.REC FROM AMEX.FILES,FILE.ID ELSE NULL             ;* TAFJUPD(S/E)
* TAFJUPD(S)
        R.FILE.REC = '' ; Y.FILE.REC.ARR = '' 
		CALL F.READ(FN.AMEX.FILES,FILE.ID,R.FILE.REC,FV.AMEX.FILES,Y.FILE.REC.ARR)
		IF R.FILE.REC THEN
			TEMP.ARRAY<-1> = R.FILE.REC
		END
*       DELETE AMEX.FILES,FILE.ID ON ERROR NULL
        CALL F.DELETE(FN.AMEX.FILES,FILE.ID)
* TAFJUPD(E)		
    REPEAT
*
    CONVERT Y.DELIM TO '~' IN TEMP.ARRAY
    SORT.CMD = "-t~ +0 -1 -n"
    CALL SCB.SORT(SORT.CMD,TEMP.ARRAY,TEMP.ARRAY.SORT)
    CONVERT '~' TO Y.DELIM IN TEMP.ARRAY.SORT
*
    FINAL.ARRAY = Y.HEADER:@FM:TEMP.ARRAY.SORT
*   FINAL.ARRAY = Y.HEADER:FM:TEMP.ARRAY
* TAFJUPD(S)
*   WRITE FINAL.ARRAY ON AMEX.FILES,REP.NAME ON ERROR
*       CRT "Unable to write to Supplementary spring file"
*    END
*
     CALL F.WRITE(FN.AMEX.FILES,REP.NAME,FINAL.ARRAY)
* TAFJUPD(E)	 
*
     RETURN
*-----------------------------------------------------------------------------------------------------------------------------
END
