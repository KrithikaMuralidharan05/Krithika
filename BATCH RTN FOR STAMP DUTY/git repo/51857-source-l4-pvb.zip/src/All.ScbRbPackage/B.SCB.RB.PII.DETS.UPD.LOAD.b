$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PII.DETS.UPD.LOAD
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* ADO Ref				       CPSGMIG-12313
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.PII.DETS.UPD
* Workflow                     This Multi Thread Service will select the SCB.RSG.PARTY.DETAILS table with PII.DETAILS LIKE …FAILED…
*                              and look into the concat table SCB.RSG.EBBS.REL.CONCAT and update the correct value.
*
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        06/Nov/2023     TBD        Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_B.SCB.RB.PII.DETS.UPD.COMMON
	
	GOSUB INIT

	RETURN
*--------------------------------------------------------------------------------------------------------
INIT:
*****

	FN.PARTY.DETS = 'F.SCB.RSG.PARTY.DETAILS'
	F.PARTY.DETS = ''
	CALL OPF(FN.PARTY.DETS,F.PARTY.DETS)

	FN.REL.CONCAT = 'F.ST.SCB.RSG.EBBS.REL.CONCAT'
	F.REL.CONCAT = ''
	CALL OPF(FN.REL.CONCAT,F.REL.CONCAT)
	
	FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
	F.SEC.ACC.MASTER = ''
	CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
		
	RETURN
*--------------------------------------------------------------------------------------------------------
END