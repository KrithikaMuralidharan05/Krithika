$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgHistTxnDetsExt
* Modification History: 30th May 2023 - Pawan - To Extract SCB.UTS.HIST.TXN.DETS table to check the data available or not
*                     : 04th Jul 2023 - Mithun - To locate the ids from the table in the file using grep

* JIRA ID: CPSGMIG-17731

SUBROUTINE B.SCB.RSG.HIST.TXN.DET.EXT(Y.HIST.TXN)
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.HIST.TXN.DET.EXT.COMMON
    $INSERT I_BATCH.FILES
    
    GOSUB INIT
*
RETURN
********
INIT:
********

  Y.UTS.TXN.ID = Y.HIST.TXN
  Y.FILE.ID = Y.SRC.FILE.NAME
  Y.FILE = Y.SRC.FILEPATH:"/":Y.FILE.ID
*
  Y.GREP.CMD = 'SH -c "grep ':Y.UTS.TXN.ID:' ':Y.FILE:'"'
  EXECUTE Y.GREP.CMD CAPTURING Y.RESPONSE
    IF Y.RESPONSE EQ "" OR Y.RESPONSE[1,2] EQ 'gr' THEN
        CALL OCOMO("Record for ":Y.UTS.TXN.ID :" SCB.UTS.HIST.TXN.DETS TXN Id not found in the processed file")
        Y.ARR.EXCP = Y.UTS.TXN.ID:"| SCB.UTS.HIST.TXN.DETS TXN Id not found in the processed file"
        GOSUB EXCEPWRITE
    END ELSE
        Y.SCS.ARR = Y.UTS.TXN.ID:" | Loaded in t24 SCB.UTS.HIST.TXN.DETS table."
        CALL OCOMO("Loaded in t24 SCB.UTS.HIST.TXN.DETS table ":Y.UTS.TXN.ID)
        GOSUB FILE.WRITE
    END

RETURN

*----------------
FILE.WRITE:

    WRITESEQ Y.SCS.ARR APPEND TO Y.SL.FILEPATH ELSE
        CALL OCOMO("UNABLE TO WRITE DMD LOAD FILE forICM status")
    END
RETURN

*---------------------
EXCEPWRITE:
***********

    WRITESEQ Y.ARR.EXCP APPEND TO Y.EXCP.FILEPATH ELSE
        CALL OCOMO("UNABLE TO WRITE missing file to data in path")
    END
RETURN
**************
END