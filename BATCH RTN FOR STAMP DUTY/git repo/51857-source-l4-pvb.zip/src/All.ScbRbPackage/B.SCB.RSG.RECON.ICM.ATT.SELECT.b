$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.RECON.ICM.ATT.SELECT
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*--------------------------------------------------------------------------------
*Jira Reference:CPSGMIG-17414
*Developer : Raja Prabhu S
*Date : 14-APR-2023
*Description : Used to extract the details from ICM  for recon against the data from t24
*O/p : NA
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.RECON.ICM.ATT.COMMON
    
    GOSUB READ.FILE
    
RETURN
*--------------
READ.FILE:
*-----------------
 
    READ R.DETS.ARR1 FROM Y.SRC.FILEPATH, Y.SRC.FILE.NAME THEN
        
        CALL BATCH.BUILD.LIST("", R.DETS.ARR1)
    END
    
RETURN
*------------------------------------------------------------

END
