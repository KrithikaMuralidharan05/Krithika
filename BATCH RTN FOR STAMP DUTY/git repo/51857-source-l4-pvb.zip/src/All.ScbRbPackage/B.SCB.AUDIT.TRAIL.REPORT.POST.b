$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.AUDIT.TRAIL.REPORT.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-374 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       06 January 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Post Routine to extract Audit Trail report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.AUDIT.TRAIL.REPORT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 25-Apr-2023 - CPSGMIG-19027 & 22843  1667095 - Additional Columns Included
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.AUDIT.TRAIL.REPORT.COMMON
    
    GOSUB INITIALISE
    GOSUB PROCESS
    
RETURN

*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;
    F.AMEX.FILES = '' ;
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    AMEXPATH=''
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX.FILES,F.AMEX.FILES,AMEXPATH)
    
    Y.UTS.FINAL.FILE    = BATCH.DETAILS<3,1>
    Y.UTS.FINAL.FILE = EREPLACE(Y.UTS.FINAL.FILE,"<TODAY>",TODAY) ;*CPSGMIG-19027 & 22843
    YDL = ','

RETURN
*------*

*------*
PROCESS:
*------*

    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.UTS.ARR = '' ; Y.FINAL.UTS.ARR = ''
*
    Y.UDFILE    = 'AMEX.FILES'
    SEL.CMD     = "AddressAuditTrailReport-":TODAY:"*.csv*"
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN

        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS

            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)

            IF NOT(R.UTS.ARR) THEN
                R.UTS.ARR = R.AMEX.FILE
            END ELSE
                R.UTS.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)

        REPEAT
* Include the Header part
        DELIM = ","
        Y.UTS.HDR  = "Portfolio":DELIM:"Portfolio Name":DELIM:"Portfolio Status":DELIM:"Address Line 1":DELIM:
        Y.UTS.HDR  := "Address Line 2":DELIM:"Address Line 3":DELIM:"Address Line 4":DELIM:"Postal Code":DELIM:
        Y.UTS.HDR  := "Country":DELIM:"City":DELIM:"State":DELIM:"ClientIdentifier":DELIM:"PrimaryAcctHolder":DELIM:"Advice Index":DELIM:
        Y.UTS.HDR  := "Client NRIC":DELIM:"Portfolio Remarks":DELIM:"Mobile No":DELIM:"Position Migration flag" ;*CPSGMIG-19027 & 22843
       
        Y.FINAL.UTS.ARR     = Y.UTS.HDR
        Y.FINAL.UTS.ARR<-1> = R.UTS.ARR

        WRITE Y.FINAL.UTS.ARR TO F.AMEX.FILES,Y.UTS.FINAL.FILE
    END
RETURN
END
