$PACKAGE All.ScbRbPackage
* @ValidationCode : MjotNzgxMDQ5MjYyOkNwMTI1MjoxNTg3NTU3NzI4MDE5OjE1OTk5NjY6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxODA5Ljc6LTE6LTE=
* @ValidationInfo : Timestamp         : 22 Apr 2020 17:45:28
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1599966
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201809.7*

*$PACKAGE SC.ScbClientOutput

SUBROUTINE D.SCB.DE.COXML.OUT(MSG.NO, R.MESSAGE, GENERIC.DATA, ERR.MSG )
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
 
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.DE.HEADER
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.SC.SCB.ADVICES.LOG
    $INSERT I_DEOCOM    
    $INSERT I_DE.FORMATTING.SERVICE.COMMON
    $INSERT I_DE.GENERIC.DATA
    $INSERT I_F.DE.MSG.AUDIT
    $INSERT I_F.SPF

    EXITFLAG = ''
    CALL SCB.API.SUB.EXIT.RTN(EXITFLAG)
    IF EXITFLAG ELSE
        RETURN
    END

    GOSUB INIT
    GOSUB OPEN.PARENT.DIR
    GOSUB PROCESS
	
RETURN
*------------------------------------------------------------------------------
INIT:
*----
    
    FN.ADVICES.LOG = 'F.SC.SCB.ADVICES.LOG'
    F.ADVICES.LOG = ''
    CALL OPF(FN.ADVICES.LOG,F.ADVICES.LOG)
		
    FN.LOCAL.PARAM = 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    F.LOCAL.PARAM = ''
    CALL OPF(FN.LOCAL.PARAM,F.LOCAL.PARAM)

    FN.DE.O.HEADER = 'F.DE.O.HEADER'
    F.DE.O.HEADER = ''
    CALL OPF(FN.DE.O.HEADER, F.DE.O.HEADER)


*
    Y.REC.ID = R.KEY
    CALL F.READ(FN.DE.O.HEADER, Y.REC.ID, R.DE.HEADER, F.DE.O.HEADER, ERR.HDR )

	
   * MSG.DISP=DE.Outward.getRHead(DE.HDR.MSG.DISP)
     MSG.DISP=R.DE.HEADER(DE.HDR.MSG.DISP) 
    AV1 = AV
    ADVICE.DATE = TODAY
    Y.GET.TIME.DATE = ''
    Y.GET.TIME.DATE = TRIM(TIMEDATE())
    Y.TIME.STAMP    = TIMESTAMP()
    Y.TIME.VAL      = Y.GET.TIME.DATE[1,6]
    Y.MILLI.SECONDS = FIELD(Y.TIME.STAMP,'.',2)
    TMP.STAMP.TIME  = Y.GET.TIME.DATE[1,8]
    CHANGE ':' TO '' IN Y.TIME.VAL
    Y.PARAM.XML.ID = 'CLIENT.ADVICE.XML.PATH'
    XML.SRC.PATH   = 'PARENT.PATH'
    Y.OUT.XML.ID   = 'T24_SG_RB_ADVICE_':ADVICE.DATE:Y.TIME.VAL:Y.MILLI.SECONDS:'.xml'
    Y.T24.HOME = GETENV('T24_HOME')
*//
    Y.PATH.POS = INDEX(Y.T24.HOME,'/t24',1)
    Y.T24.HOME = Y.T24.HOME[1,Y.PATH.POS+3]
*//
RETURN
*-------------------------------------------------------------------------------
PROCESS:
*-------
    Y.MESSAGE = R.MESSAGE
    CALL DSGetTagValue(Y.MESSAGE,'<ClientIdentifier>','</ClientIdentifier>',ClientValue,1)
    CALL DSGetTagValue(Y.MESSAGE,'<AdviceID>','</AdviceID>',AdviceIdValue,1)
    CALL DSGetTagValue(Y.MESSAGE,'<AddressRef>','</AddressRef>',AddressRef,1)
    CALL DSGetTagValue(Y.MESSAGE,'<ProductType>','</ProductType>',ProductType,1)
    CALL DSGetTagValue(Y.MESSAGE,'<PortfolioNo>','</PortfolioNo>',PortValue,1)
    CALL DSGetTagValue(Y.MESSAGE,'<TransID>','</TransID>',TransRef,1)
    CALL DSGetTagValue(Y.MESSAGE,'<ConsolID>','</ConsolID>',ConsolId,1)
    CALL DSGetTagValue(Y.MESSAGE,'<ConfirmationNotice>','</ConfirmationNotice>',ConfirmNot,1)
    CALL DSGetTagValue(Y.MESSAGE,'<R2WFolder>','</R2WFolder>',R2WFold,1)
*	
    IF MSG.DISP<1,1> EQ 'FORMATTED' THEN
        ERR.CODE  = 0
        CALL F.WRITE(F.FILE.OUT, Y.OUT.XML.ID, Y.MESSAGE)
    END ELSE
        ERR.CODE  = 1
    END
*
    CALL F.READ(FN.ADVICES.LOG,Y.REC.ID,R.ADVICES.LOG,F.ADVICES.LOG,ADVICE.ERR)
    IF R.ADVICES.LOG EQ '' THEN
        GOSUB NEW.RECORD.UPDATE
    END ELSE
        GOSUB EXISTING.RECORD.UPDATE
    END
    IF R.ADVICES.LOG THEN
	CALL F.WRITE(FN.ADVICES.LOG,Y.REC.ID, R.ADVICES.LOG)
    END
*
RETURN
*-------------------------------------------------------------------------------
NEW.RECORD.UPDATE:
*----------------
   
	R.ADVICES.LOG<SC.ADV.LOG.CLIENT.IDENTIIFER>  = ClientValue
	R.ADVICES.LOG<SC.ADV.LOG.PORTFOLIO.NO> = PortValue
	R.ADVICES.LOG<SC.ADV.LOG.ADVICE.ID>   = AdviceIdValue
	R.ADVICES.LOG<SC.ADV.LOG.TRANS.REF>    = TransRef
	R.ADVICES.LOG<SC.ADV.LOG.PRODUCT.TYPE> = ProductType
	R.ADVICES.LOG<SC.ADV.LOG.T24.MSG.STATUS>  = MSG.DISP<1,1>
	R.ADVICES.LOG<SC.ADV.LOG.T24.SYS.DATE> = ADVICE.DATE
*
    IF ERR.CODE EQ '0' THEN
        R.ADVICES.LOG<SC.ADV.LOG.T24.MSG.STATUS> = 'SUCCESS'
        R.ADVICES.LOG<SC.ADV.LOG.RESPOSNE>   = ''
    END ELSE
        R.ADVICES.LOG<SC.ADV.LOG.T24.MSG.STATUS> = 'FAILURE'
        R.ADVICES.LOG<SC.ADV.LOG.RESPOSNE>   = ERR.CODE
        R.HEAD<DE.HDR.MSG.ERROR.CODE> = ERR.CODE
    END
    R.ADVICES.LOG<SC.ADV.LOG.MSG.POST.TIME> = TMP.STAMP.TIME
    R.ADVICES.LOG<SC.ADV.LOG.T24.SYS.DATE> = ADVICE.DATE
*
RETURN
*-----------------------------------------------------------------------------------
EXISTING.RECORD.UPDATE:
*----------------------
    
    RECORD.ARR = R.ADVICES.LOG<SC.ADV.LOG.T24.SYS.DATE>
    RECORD.ARR.VALUE = DCOUNT(RECORD.ARRr,'@VM') + 1
*
    R.ADVICES.LOG<SC.ADV.LOG.T24.MSG.STATUS,RECORD.ARR.VALUE> = MSG.DISP<1,1>
    R.ADVICES.LOG<SC.ADV.LOG.T24.SYS.DATE,RECORD.ARR.VALUE>   = ADVICE.DATE
*
    IF ERR.CODE EQ '0' THEN
        R.ADVICES.LOG<SC.ADV.LOG.T24.MSG.STATUS,RECORD.ARR.VALUE> = 'SUCCESS'
        R.ADVICES.LOG<SC.ADV.LOG.RESPOSNE,RECORD.ARR.VALUE>   = ''
    END ELSE
        R.ADVICES.LOG<SC.ADV.LOG.T24.MSG.STATUS,RECORD.ARR.VALUE> = 'FAILURE'
        R.ADVICES.LOG<SC.ADV.LOG.RESPOSNE,RECORD.ARR.VALUE>   = ERR.CODE
        TMPERR<1,AV1> = ERR.CODE
        R.HEAD<DE.HDR.MSG.ERROR.CODE> = ERR.CODE 
    END
*
    R.ADVICES.LOG<SC.ADV.LOG.MSG.POST.TIME,RECORD.ARR.VALUE> = TMP.STAMP.TIME
    R.ADVICES.LOG<SC.ADV.LOG.MSG.POST.DATE,RECORD.ARR.VALUE> = ADVICE.DATE
*
RETURN
*---------------------------------------------------------------------------------
OPEN.PARENT.DIR:
*---------------
    CALL F.Read(FN.LOCAL.PARAM,Y.PARAM.XML.ID,R.XML.PARAM,F.LOCAL.PARAM,LOCAL.ERR)
    XML.FIELD.NAME = R.XML.PARAM<SC.CO.FIELD.NAME>
    XML.FIELD.VAL = R.XML.PARAM<SC.CO.FIELD.VALUE>
    XML.FIELD.SUB.VAL = R.XML.PARAM<SC.CO.FIELD.SUB.VALUE>
    CHANGE @VM TO @FM IN XML.FIELD.NAME
    LOCATE XML.SRC.PATH IN XML.FIELD.NAME SETTING POS THEN
        Y.PARENT.DIR = Y.T24.HOME:XML.FIELD.VAL<1,POS>:XML.FIELD.SUB.VAL<1,POS,1>
    END
    OPEN Y.PARENT.DIR TO F.FILE.OUT ELSE
        OUT.ERR = "MISSING"
    END
	
RETURN
*---------------------------------------------------------------------------------
END
