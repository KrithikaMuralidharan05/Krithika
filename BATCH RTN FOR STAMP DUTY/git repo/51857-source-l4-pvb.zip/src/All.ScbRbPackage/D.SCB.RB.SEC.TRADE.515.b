$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.RB.SEC.TRADE.515(MAT HANDOFF.REC, ERR.MSG)
*-----------------------------------------------------------------------------
* CPSGMIG-802 / 801 / 803 / 804 / 805 Trade Advices confirmation for FI SN MF
* Date 04-02-2022
* By   Jewel 2 sprint 2
* Routine is attached to DE.MAPPING>515.SC.0002
* PVB mapping routine is called as is if LOB is of RB further mapping continues
* In Arguments  : HEADER.REC
* Out Arguments : HANDOFF.REC, ERR.MSG
*-----------------------------------------------------------------------------
* Modification History :
* CPSGMIG-2417   20220524     XML tags enhancement on RBSG trades
* CPSGMIG-5724 New Mapping for SettleAccount SOO>CPFSRS.ACCT.NO and SettlementAcctCcy(TRADE.CCY)
* CPSGMIG-12136 - For CPF Trades SOO>CPFSRS.ACCT.NO is mapped to settle Account where as for other 
* Trades the LR.CASA Account is mapped to settle account.  
* CPSGMIG-14420- Advice - Settlementaccount tag missing for SN Sell trade.
* CPSGMIG-15184-SwitchIntAmt & SwitchOutAmt tag added.
*
*CPSGMIG-15301 - NetCharge should be mapped to CU.CHARGE.TAX.AMT for MF redemption.
*CPSGMIG-15175 -1389710-Removing space in Asset Description.
*CPSGMIG-17663 -1389710-Asset name issue in client advices.
* 23/01/2023 - CPSGMIG-17871 - kalaikumaranp - Fx rate mapping for SWI contracts.
* 03-Feb-2023 - CPSGMIG-6140 - kalaikumaranp - OMF Reference no is appended to T24 Trade id for MF.
* 08-Feb-2023 - CPSGMIG-14977- Loganathan G  - MF Exit Fee handling for YNetPerc and NetCharge.
* 14-Feb-2023 - CPSGMIG-19289 - kalaikumaranp - OMF reference is mapped from Sec Open Order.
* 28-Feb-22 -CPSGMIG-19407-1667095-ReversalFlag passed SAME/NEXT
* 02-Mar-2023 - CPSGMIG-19993 - kalaikumaranp - Populate Omf Reference for Switch In transactions.
* 18-Jul-2023 - CPSGMIG-32382 - 1657186 - FxRate should be 1 if Trade and Accccy same.
* 27-Jul-2023 - CPSGMIG-32537 - 1657186	- FxRate should be 1 for FSI and FSO.
* 10-Aug-2023 - CPSGMIG-32375 - 1648769 - Rel ID Delimiters needs to be fixed from '-' to ':' for Joint Accounts.
* 22-Oct-2025 - ADO-10849423  - Prithi Koppolu - Removal of T24 security master code from Asset Name in RBSG Contract Notes
*-------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER      ;*CPSGMIG-2417 s/e
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.SECURITY.SUPP
    $INSERT I_F.SEC.OPEN.ORDER
*CSPGMIG-15301(S)
    $INSERT I_F.SUB.ASSET.TYPE
*CSPGMIG-15301(E)
*CPSGMIG-14977(S)
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
*CPSGMIG-14977(E)

* PVB mapping routine as is
    CALL AEB.DE.SC.515(MAT HANDOFF.REC, ERR.MSG)

    IF ID.COMPANY[1,2] NE "SG" THEN
        RETURN    ;*  to be impacted only from Singapore company
    END
* Below mapping change applys to only SNG company trades

    GOSUB INIT
    GOSUB PROCESS

RETURN

INIT:

    YTransArr = HANDOFF.REC(1)
    YDetArr = HANDOFF.REC(4)
    YRevArr = HANDOFF.REC(3)
    YSecurityNo = YTransArr<9>
    YCustTransCode = YTransArr<6>
    YCustNo = YTransArr<1>
    YPortNo = YTransArr<47>
    YNetPerc = YDetArr<272,121>                  ;*LR.NET.SAL.PERC
    YEffPrice = YDetArr<272,122>                 ;*LR.EFF.UT.PRICE
    YInvestType = YDetArr<252>
    YDepository = YTransArr<59>
    YNomineeCode = YDetArr<22>
    YCompanyCode = YTransArr<31>
    CU.AMT.DUE = YDetArr<56>
    NOMINAL =  YDetArr<24>
    YSooId = YDetArr<66>
    YRevFlg = YRevArr<1>
    YTransId = YTransArr<5>
 
    FnSecMaster = 'F.SECURITY.MASTER'
    FSecMaster = ''
    CALL OPF(FnSecMaster,FSecMaster)
 
    FnClientOutputParam= 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    FClientOutputParam = ''
    CALL OPF(FnClientOutputParam,FClientOutputParam)
 
    FnSecuritySupp = 'F.SECURITY.SUPP'
    FSecuritySupp = ''
    CALL OPF(FnSecuritySupp,FSecuritySupp)
 
    FnSooHis = 'F.SEC.OPEN.ORDER$HIS'
    FSooHis = ''
    CALL OPF(FnSooHis,FSooHis)
 
    FnSoo = "F.SEC.OPEN.ORDER"
    FSoo = ''
    CALL OPF(FnSoo,FSoo)
*CPSGMIG-15301(S)
    FnSat = "F.SUB.ASSET.TYPE"
    FSat = ''
    CALL OPF(FnSat,FSat)
*CPSGMIG-15301(E)
*CPSGMIG-14977(S)
    FN.LOCAL.PARAM = "F.SCB.WM.H.LOCAL.PARAM"
    F.LOCAL.PARAM = ''
    CALL OPF(FN.LOCAL.PARAM,F.LOCAL.PARAM)
*CPSGMIG-14977(E)

* CPSGMIG-2417 s addition n correction of LT
    YAppName = APPLICATION:@FM:'CUSTOMER':@FM:'SECURITY.MASTER':@FM:'SEC.OPEN.ORDER':@FM:'SEC.ACC.MASTER'
    YFldName = 'LR.PAY.CASA.ACC':@VM:'LR.PAY.CASA.CCY':@VM:'LR.YIELD':@VM:"LR.PAYMENT.TYPE":@VM:"CPFSRS.ACCT.NO":@VM:"LR.NET.SAL.PERC":@VM:'LR.REC.CASA.ACC':@VM:'LR.REC.CASA.CCY':@VM:'LR.SWI.BR.FX.RT':@VM:'LR.OMF.REF.NO'
    YFldName<-1> = 'L.O.B':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.EBBS.REL'
    YFldName<-1> = 'LR.UTS.INS.DESC'
    YFldName<-1> = "CPFSRS.AGNT.BNK":@VM:"CPFSRS.ACCT.NO":@VM:"LR.OMF.REF.NO"
    YFldName<-1> = "LR.PFOLIO.KEY"
    YFldPos = ""
    CALL MULTI.GET.LOC.REF(YAppName,YFldName,YFldPos)
    YPayCasaAccPos = YFldPos<1,1>
    YPayCasaCcyPos = YFldPos<1,2>
    YYieldPos = YFldPos<1,3>
    YCpfSrsPymtMthPos = YFldPos<1,4>
    YCpfSrsAccNoPos = YFldPos<1,5>
    YNetSalPercPos = YFldPos<1,6>
    YRecCasaAccPos = YFldPos<1,7>
    YRecCasaCcyPos = YFldPos<1,8>
    YSwiBrFxRatePos = YFldPos<1,9> ;* Fx Rate mapping for SWI Contracts
    YOmfRefNoPos = YFldPos<1,10>
    YLobPos =  YFldPos<2,1>
    YStfPos =  YFldPos<2,2>
    YPfolPos = YFldPos<2,3>
    YEbbsRelIdpos = YFldPos<2,4>
    YUtsPos  = YFldPos<3,1>
	YCpfSrsAgntBnkPos = YFldPos<4,1>
    YCpfSrsAcctNo = YFldPos<4,2>
    YOmfRefOrdNoPos = YFldPos<4,3>
    YSamPfolPos = YFldPos<5,1>
*
    IF NOT(YNetPerc) THEN
        YNetPerc = R.NEW(SC.SBS.LOCAL.REF)<1,YNetSalPercPos>
    END
    IF NOT(YPortNo) THEN
        YPortNo = R.NEW(SC.SBS.CUST.SEC.ACC)
    END
     
    FnSecAccMaster = 'F.SEC.ACC.MASTER'
    FSecAccMaster = ''
    CALL OPF(FnSecAccMaster,FSecAccMaster)
        
*    CPSGMIG-2417 e
*API-Retrofit -e
    ClientIdentifier = ''
    AdviceId = ''
    ConsolId = ''
    R2wFolder = ''
    DelMode = ''
    DisclaimerId = ''
    ConfNotice = ''
    ReversalFlag = ''
    PriAcctHolder = ''
    JntHolder = ''
    NetCharge = ''
    NxtCall = ''
    RiskParamId = 'PRINCIPAL.RISK'
    SegmentId = 'SEGMENT'
    CpfTransId = 'SC.PRD.TRANS.CODE'
    AdviceDate = TODAY
    Y.CPF.FLAG = '' ; *CPSGMIG-5724(S/E)
* CPSGMIG-18415
    YRecCasaAcc = ''
    YRecCasaCcy = ''
* CPSGMIG-18415
* Fetch LOB value
    FN.CUST = 'F.CUSTOMER'
    F.CUST = ''
    CALL OPF(FN.CUST,F.CUST)
    CALL F.READ(FN.CUST,YCustNo,R.CUST,F.CUST,CUST.ERR)
    L.O.B = R.CUST<EB.CUS.LOCAL.REF,YLobPos>
    LR.PFOLIO.KEY.VAL = R.CUST<EB.CUS.LOCAL.REF,YPfolPos>
    YEbbsRelId = R.CUST<EB.CUS.LOCAL.REF,YEbbsRelIdpos>      ;*CPSGMIG-2417 S/E
* As per the new logic for cleint Identifier provided as on 20220208
    STAFF.IND = R.CUST<EB.CUS.LOCAL.REF,YStfPos>

    BEGIN CASE
        CASE R.CUST<EB.CUS.SECTOR> EQ "21"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "23"
            YY.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
*
RETURN
 
PROCESS:
* Get the list of PVB LOB
    Y.PARAM.ID =''; Y.ALLOW.SEG ='PVB'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    IF L.O.B MATCHES Y.ALLOWED.LOB THEN
        RETURN   ;* As the customer is private return, no need of further processing and mapping
    END ELSE
        ERR.MSG = ''           ;*If any error w.r.t PVB mapping routine can be ignored as we have all tags mapping below which r not liasing with Pb rtn
    END
    GOSUB GET.REQ.FIELDS        ;* Fetch the necessary field values from trade sm and param tables
  
    CHANGE @VM TO @FM IN SegFieldName
    LOCATE YCompanyCode IN SegFieldName SETTING SegPos THEN
        SegParamValue = RSegLocalParam<SC.CO.FIELD.VALUE,SegPos>
    END
    IF YNomineeCode EQ '' THEN
        Lending = 'No'
    END ELSE
        Lending = 'Yes'
    END
*CPSGMIG-19407(S)
    Y.DEL.KEY = YDetArr<65>
    IF Y.DEL.KEY THEN
        Y.BANK.DATE = Y.DEL.KEY[2,8]
    END
    Y.REC.STATUS = R.NEW(SC.SBS.RECORD.STATUS)
    IF (YRevFlg NE '') OR (Y.REC.STATUS[1,1] EQ "R")  THEN
        YRevFlgValue ='REVE'
        BEGIN CASE
            CASE Y.BANK.DATE EQ TODAY
                ReversalFlag = 'SAME'
            CASE Y.BANK.DATE NE TODAY
                ReversalFlag = 'NEXT'
        END CASE
    END ELSE
        YRevFlgValue ='AUTH'
        END
*CPSGMIG-19407(E)

    IF ProductGrp NE '' THEN
        GOSUB GET.ADVICE.FIELD.VALUE

        BEGIN CASE
            CASE ProductGrpValue EQ 'FIXEDINCOME'
                GOSUB GET.FI.VALUE                      ;* Fetch the values w.r.t to FI
            CASE  ProductGrpValue EQ 'FUNDS'            ;* Fetch values w.r.t to MF
                GOSUB GET.FUND.VALUE
            CASE  ProductGrpValue EQ 'STRUCTUREDPRODUCTS'               ;*Fetch values w.r.t to SN
                GOSUB GET.SP.VALUE
        END CASE
    END
    
    GOSUB UPDATE.USR.DEF.VALUE                     ;*Assign the values arrived to Handoff record

RETURN
 
*-----------------------------------------------------------------------------
GET.REQ.FIELDS:
    IF YPayCasaAccPos THEN
        YPayCasaAcc = R.NEW(SC.SBS.LOCAL.REF)<1,YPayCasaAccPos>
    END
    IF YPayCasaCcyPos THEN
        YPayCasaCcy = R.NEW(SC.SBS.LOCAL.REF)<1,YPayCasaCcyPos>
    END
* CPSGMIG-18415    
    IF YRecCasaAccPos THEN
        YRecCasaAcc = R.NEW(SC.SBS.LOCAL.REF)<1,YRecCasaAccPos>
    END
    IF YRecCasaCcyPos THEN
        YRecCasaCcy = R.NEW(SC.SBS.LOCAL.REF)<1,YRecCasaCcyPos>
    END
* CPSGMIG-18415    
    IF YYieldPos THEN
        YYieldValue = R.NEW(SC.SBS.LOCAL.REF)<1,YYieldPos>
    END
    IF YYieldValue THEN
        YYieldValue = FMT(YYieldValue,"R2"):"(YTM)"
    END
    CALL F.READ(FnSecMaster,YSecurityNo,RSecurityMaster,FSecMaster,YSecErr)

    YSmDescription = RSecurityMaster<SC.SCM.DESCRIPT>
    YSmNewDescription = RSecurityMaster<SC.SCM.LOCAL.REF,YUtsPos>
    IF YSmNewDescription THEN
        yDescName = YSmNewDescription                  ;* As per new mapping provided by Srinivasan sa on 21 Feb 2022 Client Advice impacts
    END ELSE
* CPSGMIG-17663(S)
*       yDescCnt = DCOUNT(YSmDescription,@VM)
*       Cnt = 1
*       LOOP
*       WHILE Cnt LE yDescCnt
*           yDescName<-1> = YSmDescription<1,Cnt,1>
*           Cnt = Cnt + 1
*       REPEAT
* CPSGMIG-17663(E)
    yDescName = YSmDescription ; *CPSGMIG-17663(S/E)   
    END
    CHANGE @SM TO '' IN yDescName ; *CPSGMIG-15175(S/E)
    YSubAssetTypeValue = RSecurityMaster<SC.SCM.SUB.ASSET.TYPE>
    YRiskValue = RSecurityMaster<SC.SCM.CAPITAL.PROTECTION>
    YIsinCode = RSecurityMaster<SC.SCM.I.S.I.N.>
    YOptionDepositoryArr = RSecurityMaster<SC.SCM.OPTION.DEPOSITORY>

    CALL SCB.GET.PRODUCT.API(YSecurityNo, ProductGrp)            ;* Get the Product Type FI SN or Funds
    CALL F.READ(FnSecuritySupp,YSecurityNo,RSecuritySupp,FSecuritySupp,YSecSuppErr)
    CallDatesArr = RSecuritySupp<SC.SSP.CALL.DATES>
    YldMat = RSecuritySupp<SC.SSP.YIELD.TO.MAT>
    YldPercent=""
    YldCall = RSecuritySupp<SC.SSP.YIELD.TO.CALL>
    
	CALL F.READ(FnClientOutputParam,RiskParamId,RRiskLocalParam,FClientOutputParam,YRiskErr)
    RiskFieldName = RRiskLocalParam<SC.CO.FIELD.NAME>
    
	CALL F.READ(FnClientOutputParam,SegmentId,RSegLocalParam,FClientOutputParam,YSegErr)
    SegFieldName = RSegLocalParam<SC.CO.FIELD.NAME>
   
    CALL F.READ(FnClientOutputParam,CpfTransId,RTransLocalParam,FClientOutputParam,YCpfErr)
    CpfFieldName = RTransLocalParam<SC.CO.FIELD.NAME>
    YCuChrgTaxAmtList = R.NEW(SC.SBS.CU.CHARGE.TAX.AMT)
    YBrkrComm = R.NEW(SC.SBS.CU.BRKR.COMM)
    
 *CPSGMIG-14977-(S)	
	Y.EXIT.LOAD = RSecurityMaster<SC.SCM.EXIT.LOAD>
	Y.EXIT.LOAD.METHOD = RSecurityMaster<SC.SCM.EXIT.LOAD.METHOD>
	Y.ST.CHARGE.TYPE = ''
	Y.ST.CHARGE.AMT = ''
*CPSGMIG-14977-(E)
 
RETURN
*-----------------------------------------------------------------------------
GET.ADVICE.FIELD.VALUE:

    ProductGrpValue = TRIM(ProductGrp," ","A")
    ProductGrpValue = UPCASE(ProductGrpValue)
    YRecID = APPLICATION:"-":ProductGrpValue:"-":YCustTransCode
    CALL F.READ(FnClientOutputParam,YRecID,RClientOutputParam,FClientOutputParam,YAdviceErr)
    EventTypeArr = RClientOutputParam<SC.CO.EVENT.TYPE>
    CHANGE @VM TO @FM IN EventTypeArr
    LOCATE YRevFlgValue IN EventTypeArr SETTING AdvPos THEN
        AdviceId = RClientOutputParam<SC.CO.ADVICE.ID,AdvPos>
        ConsolId = RClientOutputParam<SC.CO.CONSOL.ID,AdvPos>
        DisclaimerId = RClientOutputParam<SC.CO.DISCLAMIER.ID,AdvPos>
        ConfNotice = RClientOutputParam<SC.CO.CONFIRMATION.NOTICE,AdvPos>
        DelMode = RClientOutputParam<SC.CO.DELIVERY.MODE,AdvPos>
*        SC.ScbClientOutput.scbClientidenR2wfoldRtn(YCustNo,YPortNo,ProductGrpValue,YCustTransCode,ClientIdentifier,R2wFolder)  :* Returns Client Identifier and R2W folder values if parameterised any
*        SC.ScbClientOutput.scbAcctHolderRtn(YPortNo,ClientIdentifier,PriAcctHolder,JntHolder)    ;* Returns Primary and joint account holder of Portfolio sent
*        CALL SCB.ACCT.HOLDER.RTN(YPortNo,ClientIdentifier,PriAcctHolder,JntHolder)   ;* CPSGMIG-2417 S
    END

*CPSGMIG-14420(S)
   Y.CI.FLAG = ''
*CPSGMIG-14420(E)
    IF ProductGrp EQ 'STRUCTUREDPRODUCTS' AND YCustTransCode EQ 'BUY' THEN
     Y.CLI.TEMP  = YY.CLIENT.IDENTIFIER
     YY.CLIENT.IDENTIFIER = 'SN.BUY'
*CPSGMIG-14420(S)
     Y.CI.FLAG = 1  
*CPSGMIG-14420(E)
    END
    CALL SCB.CLIENTIDEN.R2WFOLD.RTN(YY.CLIENT.IDENTIFIER,R2wFolder)
*CPSGMIG-14420(S)
    IF Y.CI.FLAG EQ 1 THEN
    YY.CLIENT.IDENTIFIER =  Y.CLI.TEMP
    END
*CPSGMIG-14420(E)

    GOSUB GET.PRI.JNT.HOLDERS                                            ;* CPSGMIG-2417 E
RETURN
*-----------------------------------------------------------------------------
GET.PRI.JNT.HOLDERS:                                            ;* CPSGMIG-2417 S/E

*    CALL F.READ(FnSecAccMaster,YPortNo,RSecAccMaster,FSecAccMaster,YErr)

*    IF RSecAccMaster THEN
*        PriAcctHolder = PriAcctHolder<SC.SAM.LOCAL.REF,YSamPfolPos>
*        PriAcctHolder = CHANGE(PriAcctHolder,"-","|")
*    END
*    IF NOT(PriAcctHolder) AND LR.PFOLIO.KEY.VAL THEN
*        PriAcctHolder = LR.PFOLIO.KEY.VAL
*        PriAcctHolder = CHANGE(PriAcctHolder,"-","|")
*    END
*    IF COUNT(PriAcctHolder,"|") GE 1 THEN
*        PriAcctHolder = FIELD(PriAcctHolder,'|',1)
*    END
*    JntHolder = PriAcctHolder
*    IF YEbbsRelId THEN
*        CHANGE @SM TO "|" IN YEbbsRelId
*        CHANGE "||" TO "|" IN YEbbsRelId
*        JntHolder = JntHolder:"|":YEbbsRelId
*    END
    PriAcctHolder = FIELD(LR.PFOLIO.KEY.VAL,':',1)
    JntHolder = LR.PFOLIO.KEY.VAL
    CHANGE ':' TO '|' IN JntHolder

RETURN
*-----------------------------------------------------------------------------
GET.FI.VALUE:

    YAssetName = yDescName

    GOSUB NXT.CALL.CONV
    BEGIN CASE
        CASE YCustTransCode EQ 'BUY'
            YPayCasaAcc = R.NEW(SC.SBS.LOCAL.REF)<1,YPayCasaAccPos>
            YPayCasaCcy = R.NEW(SC.SBS.LOCAL.REF)<1,YPayCasaCcyPos>

        CASE YCustTransCode EQ 'SEL'
            YPayCasaAcc = R.NEW(SC.SBS.LOCAL.REF)<1,YRecCasaAccPos>
            YPayCasaCcy = R.NEW(SC.SBS.LOCAL.REF)<1,YRecCasaCcyPos>
    END CASE
    IF HANDOFF.REC(4)<13> NE '' THEN ;* FX.RATE is not required in FI Advices.
        HANDOFF.REC(4)<13> = ''
    END
    IF HANDOFF.REC(1)<15> NE '' THEN ;* GROSS.AMOUNT is not required in FI Advices.
        HANDOFF.REC(1)<15> = ''
    END
    
RETURN
*-----------------------------------------------------------------------------
GET.FUND.VALUE:


*CPSGMIG-15301(S)
     CALL F.READ(FnSat,YSubAssetTypeValue,RSat,FSat,YSatErr)
      Y.ASSET.TYPE = RSat<SC.CSG.ASSET.TYPE.CODE>
     IF YInvestType EQ '' AND Y.ASSET.TYPE EQ 50 THEN
         YInvestType = RSecurityMaster<SC.SCM.INVEST.OPTION.TYPE>
     END 
*CPSGMIG-15301(E)
    IF YInvestType NE '' THEN
        YInvestOption = 'INVEST.OPTION'
        CALL F.READ(FnClientOutputParam,YInvestOption,RInvestLocalParam,FClientOutputParam,YInvestErr)
        InvestFieldName = RInvestLocalParam<SC.CO.FIELD.NAME>

        LOCATE YInvestType IN InvestFieldName<1,1> SETTING YInvestPos THEN
            YDepoAsset = RInvestLocalParam<SC.CO.FIELD.SUB.VALUE,YInvestPos>
        END

    END

    IF YDepoAsset NE '' AND Y.ASSET.TYPE EQ 50 THEN ; * CPSGMIG - 15301 - if asset.type eq 50 then only description appended with depository name.
      IF YCustTransCode EQ "SWI" OR YCustTransCode EQ "SWO" OR YCustTransCode EQ "SCF" OR YCustTransCode EQ "BCF" OR YCustTransCode EQ "FRD" OR YCustTransCode EQ "FPR" THEN
        YAssetName = yDescName:' ':YDepoAsset
      END
    END ELSE
         YAssetName = yDescName
    END
	
    IF YCuChrgTaxAmtList NE '' THEN
        NetCharge = SUM(YCuChrgTaxAmtList)
    END
	
    IF YCustTransCode EQ 'FRD' THEN
*CPSGMIG-15301(S)
*        NetCharge = YBrkrComm
         NetCharge = SUM(YCuChrgTaxAmtList) 
*CPSGMIG-15301(E)
    END

    IF NOT(YEffPrice) THEN
        IF YCustTransCode EQ "SWI" OR YCustTransCode EQ "SWO" OR YCustTransCode EQ "SCF" OR YCustTransCode EQ "BCF" OR YCustTransCode EQ "FRD" OR YCustTransCode EQ "FPR" THEN
          
            YEffPrice = CU.AMT.DUE / NOMINAL

        END
    END
* Fx Rate mapping for SWI Contracts
    IF YCustTransCode EQ "SWI" THEN
        YFxRate = R.NEW(SC.SBS.LOCAL.REF)<1,YSwiBrFxRatePos>
        IF YFxRate THEN
        HANDOFF.REC(4)<13,1> = YFxRate
        END
    END
*
* CPSGMIG-6140
* CPSGMIG-19289
		Y.SOO.ID = R.NEW(SC.SBS.CU.ORDER.NOS)<1,1> ; Y.SOO.ERR = '' ; R.SEC.OPEN.ORDER = ''
        Y.OMF.ORD.REFNO = ''
		CALL F.READ(FnSoo,Y.SOO.ID,R.SEC.OPEN.ORDER,FSoo,Y.SOO.ERR)
        IF NOT(R.SEC.OPEN.ORDER) THEN
            CALL EB.READ.HISTORY.REC(FSooHis,Y.SOO.ID,R.SEC.OPEN.ORDER,Y.SOO.ERR)
        END
* CPSGMIG-19993    
        IF R.SEC.OPEN.ORDER THEN
            Y.OMF.ORD.REFNO = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,YOmfRefOrdNoPos>
            IF INDEX(Y.OMF.ORD.REFNO,'-1',1) THEN
                Y.OMF.ORD.REFNO = FIELD(Y.OMF.ORD.REFNO,'-',1,1)
        	END
        END
* CPSGMIG-19993    
* CPSGMIG-19289 
    IF Y.OMF.ORD.REFNO NE '' THEN
	    IF YCustTransCode EQ "SWI" OR YCustTransCode EQ "SWO" OR YCustTransCode EQ "FSI" OR YCustTransCode EQ "FSO" OR YCustTransCode EQ "FRD" OR YCustTransCode EQ "FPR" THEN
	    	YTradeId = HANDOFF.REC(1)<5,1>
	    	YTradeId = YTradeId:' (':Y.OMF.ORD.REFNO:')'
	        HANDOFF.REC(1)<5,1> = YTradeId
	    END
    END
* CPSGMIG-6140
*
* CPSGMIG-18415 - Start
	IF YCustTransCode EQ "FRD" OR YCustTransCode EQ "FSO" THEN
        YPayCasaAcc = YRecCasaAcc
		YPayCasaCcy = YRecCasaCcy
    END
* CPSGMIG-18415 - End
*
    CHANGE @VM TO @FM IN CpfFieldName
    LOCATE "CPF.TRANS.CODE" IN CpfFieldName SETTING FieldTransPos THEN
        CpfTransValue = RTransLocalParam<SC.CO.FIELD.SUB.VALUE,FieldTransPos>
    END
    CHANGE @SM TO @FM IN CpfTransValue

    LOCATE YCustTransCode IN CpfTransValue SETTING CpfPos THEN
        YCpfPayMethod = R.NEW(SC.SBS.LOCAL.REF)<1,YCpfSrsPymtMthPos>
        IF (YCustTransCode EQ "FRD") OR (YCustTransCode EQ "SEL") THEN       ;*Redemption
            YCpfSettleAcct = R.NEW(SC.SBS.LOCAL.REF)<1,YRecCasaAccPos>
        END
        IF (YCustTransCode EQ "FPR") OR (YCustTransCode EQ "BUY") THEN    ;* Subscription
            YCpfSettleAcct = R.NEW(SC.SBS.LOCAL.REF)<1,YPayCasaAccPos>
        END

        GOSUB READ.SOO.REC
       
        IF NOT(YCpfAgentBank) AND NOT(YSooId) THEN
            YSooId = R.NEW(SC.SBS.CU.ORDER.NOS)<1,1>
            GOSUB READ.SOO.REC
        END
        IF (YCustTransCode EQ "BCF") OR (YCustTransCode EQ "SCF") THEN    ;* Subscription
            YCpfSettleAcct = YCpfAcctNo
        END
* CPSGMIG-5724(S)
        IF YCpfAcctNo THEN
          Y.CPF.FLAG = 'Y' 
        END
* CPSGMIG-5724(E)        
* YPayCasaAcc = YCpfSettleAcct
    END

*CPSGMIG-14977(S)
    R.LOCAL.PARAM = ''
    Y.FIELD.NAME.VALUE = ''
    RED.TYPE.POS = ''
    CALL F.READ(FN.LOCAL.PARAM,"SCB.RB.MF.SEC.TRADE.515",R.LOCAL.PARAM,F.LOCAL.PARAM,LOC.PAR.ERR)
    Y.FIELD.NAME.VALUE = R.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
    LOCATE YCustTransCode IN Y.FIELD.NAME.VALUE<1,1,1> SETTING RED.TYPE.POS THEN
    	IF Y.EXIT.LOAD THEN
	    	YNetPerc = Y.EXIT.LOAD
		END
		Y.CHG.POS = ''
		Y.ST.CHARGE.AMT = ''
		Y.ST.CHARGE.TYPE = R.NEW(SC.SBS.CU.CHARGE.TAX.TYPE)
		LOCATE "EXIT.FEE.CU" IN Y.ST.CHARGE.TYPE<1,1,1> SETTING Y.CHG.POS THEN
	   		Y.ST.CHARGE.AMT = R.NEW(SC.SBS.CU.CHARGE.TAX.AMT)<1,1,Y.CHG.POS>
	   		IF Y.ST.CHARGE.AMT THEN
	       		NetCharge = Y.ST.CHARGE.AMT
	   		END
		END
    END
*CPSGMIG-14977(E)
* CPSGMIG-32382 - Start CPSGMIG-32537
	IF YCustTransCode EQ "FPR" OR YCustTransCode EQ "FRD" OR YCustTransCode EQ "FSI" OR YCustTransCode EQ "FSO" THEN
        IF YPayCasaCcy EQ R.NEW(SC.SBS.TRADE.CCY) THEN
        	HANDOFF.REC(4)<13,1> = '1'
        END
    END
* CPSGMIG-32382 - End    
RETURN
*-----------------------------------------------------------------------------
READ.SOO.REC:
*-----------------------------------------------------------------------------
    IF NOT(YSooId) THEN
        RETURN
    END
    R.Soo = ''
    soo.err = ''
    CALL F.READ(FnSoo,YSooId,R.Soo,FSoo,soo.err)
    IF R.Soo THEN
        YCpfAgentBank = R.Soo<SC.SOO.LOCAL.REF,YCpfSrsAgntBnkPos>
        YCpfAcctNo = R.Soo<SC.SOO.LOCAL.REF,YCpfSrsAcctNo>
    END ELSE
        HIS.ID = YSooId
        YERROR = ''
        HIST.FILE = FSooHis
        CALL EB.READ.HISTORY.REC(HIST.FILE, HIS.ID, HIST.REC, YERROR)
        YCpfAgentBank = HIST.REC<SC.SOO.LOCAL.REF,YCpfSrsAgntBnkPos>
        YCpfAcctNo = HIST.REC<SC.SOO.LOCAL.REF,YCpfSrsAcctNo>
    END
    
RETURN
*-----------------------------------------------------------------------------
GET.SP.VALUE:
*-----------------------------------------------------------------------------
    YAssetName = yDescName
    CHANGE @VM TO @FM IN RiskFieldName
    LOCATE "RISK.VALUE" IN RiskFieldName SETTING FieldPos THEN
        RiskParamValue = RRiskLocalParam<SC.CO.FIELD.VALUE,FieldPos>
    END
    IF YRiskValue EQ RiskParamValue THEN
        PrincipalRisk =  "No"
    END ELSE
        PrincipalRisk = "Yes"
    END
*CPSGMIG-14420(S)
     BEGIN CASE
        CASE YCustTransCode EQ 'BUY'
            YPayCasaAcc = R.NEW(SC.SBS.LOCAL.REF)<1,YPayCasaAccPos>
            YPayCasaCcy = R.NEW(SC.SBS.LOCAL.REF)<1,YPayCasaCcyPos>

        CASE YCustTransCode EQ 'SEL'
            YPayCasaAcc = R.NEW(SC.SBS.LOCAL.REF)<1,YRecCasaAccPos>
            YPayCasaCcy = R.NEW(SC.SBS.LOCAL.REF)<1,YRecCasaCcyPos>
    END CASE
*CPSGMIG-14420(E)
RETURN

NXT.CALL.CONV:
    CallSorted = SORT(CallDatesArr)
    CHANGE @VM TO @FM IN CallSorted
    LOOP
        REMOVE CallDatesValue FROM CallSorted SETTING Pos
    WHILE CallDatesValue:Pos
        IF AdviceDate < CallDatesValue THEN
            NxtCall =  CallDatesValue
            RETURN
        END
    REPEAT
RETURN
*Mapping of logical variables to HANDOFF record arrive with above logics
*-----------------------------------------------------------------------------
UPDATE.USR.DEF.VALUE:

   *YAssetName = YSecurityNo:' ':YAssetName ;* Asset name should be prefixed with Security No CPSGMIG-4914
     YAssetName = YAssetName ;* ADO-10849423(S/E)
*    IF YY.CLIENT.IDENTIFIER THEN
        HANDOFF.REC(9)<38,1> = YY.CLIENT.IDENTIFIER
*    END ELSE
*        HANDOFF.REC(9)<38,1> = ClientIdentifier
*    END
    HANDOFF.REC(9)<39,1> = AdviceId
    HANDOFF.REC(9)<40,1> = ConsolId
    HANDOFF.REC(9)<41,1> = DisclaimerId
    HANDOFF.REC(9)<42,1> = R2wFolder
    HANDOFF.REC(9)<43,1> = ConfNotice
    HANDOFF.REC(9)<44,1> = ReversalFlag
    HANDOFF.REC(9)<45,1> = DelMode
    HANDOFF.REC(9)<46,1> = ProductGrp
    HANDOFF.REC(9)<47,1> = PriAcctHolder
    HANDOFF.REC(9)<48,1> = JntHolder
    HANDOFF.REC(9)<49,1> = NxtCall
    HANDOFF.REC(9)<50,1> = YNetPerc
    HANDOFF.REC(9)<51,1> = YEffPrice
    HANDOFF.REC(9)<52,1> = Lending
    HANDOFF.REC(9)<53,1> = PrincipalRisk
    HANDOFF.REC(9)<54,1> = YYieldValue
    HANDOFF.REC(9)<55,1> = NetCharge
    HANDOFF.REC(9)<56,1> = SegParamValue
    HANDOFF.REC(9)<57,1> = YIsinCode
    HANDOFF.REC(9)<58,1> = YAssetName
    HANDOFF.REC(9)<59,1> = YCpfSettleAcct
    HANDOFF.REC(9)<60,1> = YCpfPayMethod
    HANDOFF.REC(9)<61,1> = YCpfAgentBank

*   HANDOFF.REC(9)<62,1> = YPayCasaAcc ;* CPSGMIG-12136(S/E)
*CPSGMIG-5724(S)    
    BEGIN CASE
    CASE NOT(Y.CPF.FLAG)
    HANDOFF.REC(9)<63,1> = YPayCasaCcy
    HANDOFF.REC(9)<62,1> = YPayCasaAcc ;* CPSGMIG-12136(S/E)
    CASE Y.CPF.FLAG
    HANDOFF.REC(9)<63,1> = R.NEW(SC.SBS.TRADE.CCY)
    HANDOFF.REC(9)<62,1> = YCpfSettleAcct ;* CPSGMIG-12136(S/E)
    END CASE 
*CPSGMIG-5724(E)    
    HANDOFF.REC(9)<64,1> = "TNO"
*
*CPSGMIG-15184(S)
    Y.CU.AMT.DUE = R.NEW(SC.SBS.CU.AMOUNT.DUE) 
    IF YCustTransCode EQ "SWI" THEN        
     HANDOFF.REC(9)<65,1> = Y.CU.AMT.DUE   
    END ELSE
     IF YCustTransCode EQ "SWO" THEN
     HANDOFF.REC(9)<66,1> = Y.CU.AMT.DUE
     END
    END
*CPSGMIG-15184(E)


RETURN
*-----------------------------------------------------------------------------
END