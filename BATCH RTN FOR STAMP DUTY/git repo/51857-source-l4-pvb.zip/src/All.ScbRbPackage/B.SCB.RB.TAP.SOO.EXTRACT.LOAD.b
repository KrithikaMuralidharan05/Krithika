$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.SOO.EXTRACT.LOAD
*---------------------------------------------------------------------------------------------------------------------------------------------
*
* This load routine is used for the file generation of T24_SG_RB_TAP_SOO_<yymmddhhmmss> to TAP
*
***---------------------------------------------------------------------------------------------------------------------------------------------------
*
* Modification History : 
*
* 14/07/2022 - Lavanya L - CPSGMIG-4869
*-------------------------------------------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.RB.TAP.SEC.OPEN.COMMON
	$INSERT I_TSA.COMMON
    $INSERT I_F.SEC.OPEN.ORDER
    
    GOSUB INITIALISE
    GOSUB GET.LOC.REF.POS
*
RETURN
*
*--------------------------------------------------------------------------------------------------------------------------------------------
INITIALISE:
*----------

* Initialise and open all the required application
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)

	FN.SEC.OPEN.ORDER.HIS = 'F.SEC.OPEN.ORDER$HIS'
	F.SEC.OPEN.ORDER.HIS = ''
	CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
	
    FN.SEC.OPEN.ORDER = 'F.SEC.OPEN.ORDER'
	F.SEC.OPEN.ORDER = ''
	CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    
	FN.SCB.SEC.OPEN.ORD.TRD.STAT = 'F.SCB.SEC.OPEN.ORD.TRD.STATUS'
	F.SCB.SEC.OPEN.ORD.TRD.STAT = ''
	CALL OPF(FN.SCB.SEC.OPEN.ORD.TRD.STAT,F.SCB.SEC.OPEN.ORD.TRD.STAT)
	
    FN.SCB.SEC.OPEN.ORD.TRD.STAT.HIS = 'F.SCB.SEC.OPEN.ORD.TRD.STATUS$HIS'
	F.SCB.SEC.OPEN.ORD.TRD.STAT.HIS = ''
	CALL OPF(FN.SCB.SEC.OPEN.ORD.TRD.STAT.HIS,F.SCB.SEC.OPEN.ORD.TRD.STAT.HIS)
    
	FN.CUSTOMER = 'F.CUSTOMER'
	F.CUSTOMER = ''
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)

	FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    
     FN.SC.TRA.CODE = 'F.SC.TRA.CODE'
    F.SC.TRA.CODE = ''
    CALL OPF(FN.SC.TRA.CODE,F.SC.TRA.CODE)

    FN.SC.TRANS.TYPE = 'F.SC.TRANS.TYPE'
    F.SC.TRANS.TYPE = ''
    CALL OPF(FN.SC.TRANS.TYPE,F.SC.TRANS.TYPE)
	
	AMEX.FILES.PATH = 'AMEX.FILES'
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, Y.APPEND.FILE)
	
RETURN
*
* ------------------------------------------------------------------
GET.LOC.REF.POS:
*---------------
*	
    Y.FIELD = 'TAP.REF.NO':@VM:'LR.OMF.REF.NO':@VM:'LR.PAY.CASA.ACC':@VM:'LR.REC.CASA.ACC'
    Y.FIELD := @VM:'LR.PAY.CASA.CCY':@VM:'LR.REC.CASA.CCY':@VM:'LR.RM.DISC.PERC'
    Y.FIELD := @VM:'LR.NET.SAL.PERC':@VM:'LR.CUTOFF.TIME':@VM:'LR.RSP.REF'
    Y.FIELD := @VM:'LR.PAYMENT.TYPE'
    Y.FIELD := @VM:'LR.OMF.REF.NO':@VM:'LR.MAX.SAL.PERC':@VM:'LR.TXN.DATE':@VM:'L.SWITCH.ORDER':@VM:'CPFSRS.AGNT.BNK':@VM:'LR.LEVERAGE.IND':@VM:'LR.SWI.SEC.NO':@VM:'LR.TXN.DATE'	;*CPSGMIG-14682 - S/E
    Y.FIELD := @FM:'TDS.GLOBAL.ID'
    Y.FIELD := @FM:'L.O.B'
	
    Y.APPLICATION = 'SEC.OPEN.ORDER':@FM:'SECURITY.MASTER':@FM:'CUSTOMER'

    CALL MULTI.GET.LOC.REF(Y.APPLICATION,Y.FIELD,Y.LOC.REF.POS)

    
* AQDQ - 20130228(E)

    Y.TAP.REF.NO.POS = Y.LOC.REF.POS<1,1>
    Y.LR.OMF.REF.NO.POS = Y.LOC.REF.POS<1,2>
    Y.LR.PAY.CASA.ACC.POS = Y.LOC.REF.POS<1,3>
    Y.LR.REC.CASA.ACC.POS = Y.LOC.REF.POS<1,4>
    Y.LR.PAY.CASA.CCY.POS = Y.LOC.REF.POS<1,5>
    Y.LR.REC.CASA.CCY.POS = Y.LOC.REF.POS<1,6>
    Y.LR.RM.DISC.PERC.POS = Y.LOC.REF.POS<1,7>
    Y.LR.NET.SAL.PERC.POS = Y.LOC.REF.POS<1,8>
    Y.LR.CUT.OFF.TIME.POS = Y.LOC.REF.POS<1,9>
    Y.LR.RSP.REF.POS = Y.LOC.REF.POS<1,10>
    Y.LR.PAYMENT.TYPE.POS = Y.LOC.REF.POS<1,11>
*CPSGMIG-14682 - S    
    Y.LR.OMF.REF.NO.POS = Y.LOC.REF.POS<1,12>
    Y.LR.MAX.SAL.PERC.POS = Y.LOC.REF.POS<1,13>
    Y.LR.TXN.DATE.POS = Y.LOC.REF.POS<1,14>
    Y.L.SWITCH.ORDER.POS = Y.LOC.REF.POS<1,15>
    Y.CPFSRS.AGNT.BNK.POS = Y.LOC.REF.POS<1,16>
    Y.LR.LEVERAGE.IND.POS = Y.LOC.REF.POS<1,17>
    Y.LR.SWI.SEC.NO.POS = Y.LOC.REF.POS<1,18>
    Y.LR.TXN.DATE.POS = Y.LOC.REF.POS<1,19>
*CPSGMIG-14682 - E
	Y.TDS.GLOBAL.ID.POS = Y.LOC.REF.POS<2,1>
    
	Y.LOB.POS = Y.LOC.REF.POS<3,1>
	
    Y.FILE.NAME = 'RB.TAP.SOO':AGENT.NUMBER:'.txt'					

RETURN
*
* -----------------------------------------------------------------------------------------
END
