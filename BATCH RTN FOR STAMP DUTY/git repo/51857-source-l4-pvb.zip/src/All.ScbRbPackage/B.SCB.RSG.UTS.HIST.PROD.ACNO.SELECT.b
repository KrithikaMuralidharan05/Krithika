$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.UTS.HIST.PROD.ACNO.SELECT
*----------------------------------------------------------------------------------------
*
* Modification History :
*------------------------------------------------------------------------------------
* Routine attached in the DMD record for Position Migration attached in SECURITY.TRANSFER

* 17/02/2023 - Drafted by - Raja Prabhu S
*----------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.UTS.HIST.PROD.ACNO.COMMON
    
    
    GOSUB READ.FILE
    
RETURN
*--------------
READ.FILE:
*-----------------
 
    READ R.DETS.ARR1 FROM Y.SRC.FILEPATH, Y.SRC.FILE.NAME THEN
        
        CALL BATCH.BUILD.LIST("", R.DETS.ARR1)
    END
RETURN

*----------------------------------------------------------
END