$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.PDW.FDPRICE.EXT.LOAD
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 07/09/2022 - Lavanya L - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_FundPrice_YYYYMMDD.csv
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.RB.PDW.FDPR.EXT.COMMON
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER, F.SECURITY.MASTER)

*
	FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    
	Y.APP = 'SECURITY.MASTER':@FM:'CUSTOMER'
    Y.FIELD = 'MF.ISSUER.NAME':@VM:'LR.RETAIL.DEPO':@VM:'LM.RET.DEPO.INV'
    Y.FIELD := @FM:'LR.PP.CODE'
    Y.FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    Y.MF.ISSUR.NAME.POS = Y.FIELD.POS<1,1>
    Y.LR.RET.DEPO.POS = Y.FIELD.POS<1,2>
    Y.RET.DEPO.INV.POS = Y.FIELD.POS<1,3>
    
    LR.PP.CODE.POS = Y.FIELD.POS<2,1>
    
    AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
	FILE.NAME = ID.COMPANY[1,2]:"-FundPrice-":TODAY:".csv-":SESSION.NO
*
*

RETURN
*-----------------------------------------------------------------------------
END
