$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.CAPE.ADVICE.MAPPING(MAT HANDOFF.REC, ERR.MSG)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*Author               Date             Reference                 Description
*-----------------------------------------------------------------------------
*Pawan kr             18-Feb-2026        9634277                DE.MAPPING routine attached in DE.MAPPING>998.FM.1 to generate delivery advice 

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.CUSTOMER
	$INSERT I_F.EB.FREE.MESSAGE
     $INSERT I_F.SCB.CAPE.EVENT.PARAM
    
    $INSERT I_F.SCB.L.CAPE.CA.REF
*
   
	GOSUB INIT
    GOSUB PROCESS
*	   
	RETURN
*-----------------------------------------------------------------------------	
INIT:
*----
      fnScbLCapeCaref = "F.SCB.L.CAPE.CA.REF"
   fvScbLCapeCaref = ""
    CALL OPF(fnScbLCapeCaref ,fvScbLCapeCaref)
     fnScbCapeEventParam = "F.SCB.CAPE.EVENT.PARAM"
     fvScbCapeEventParam = ""
    CALL OPF(fnScbCapeEventParam ,fvScbCapeEventParam )
    Y.CORE.MAP1 = HANDOFF.REC(1)
	Y.CORE.MAP2 = HANDOFF.REC(2)
	Y.CORE.MAP3 = HANDOFF.REC(3)
	Y.CORE.MAP4 = HANDOFF.REC(4)
	Y.CORE.MAP5 = HANDOFF.REC(5)
	Y.CORE.MAP6 = HANDOFF.REC(6)
	Y.CORE.MAP7 = HANDOFF.REC(7)
	Y.CORE.MAP8 = HANDOFF.REC(8)
	Y.LOCAL.MAP = HANDOFF.REC(9)
    yCapeTransId = R.NEW(EB.FM.TXN.REFERENCE)	
*	
RETURN
*-----------------------------------------------------------------------------	
PROCESS:
*-------
ftFlag  = ""
stFlag = ""
yCommonTransId = ""
yCommonFlag = ""
    CALL F.READ(fnScbLCapeCaref,yCapeTransId,CapeCaRefRecord,fvScbLCapeCaref,capeCaRefError)
   yApplication = CapeCaRefRecord<SCBCA.APPLICATION>
   yCapeEventDets = CapeCaRefRecord<SCBCA.CAPE.EVENT.DETS>
 LOCATE 'FUNDS.TRANSFER' IN yApplication<1,1> SETTING S.POS THEN 
   yFtTransId = CapeCaRefRecord<SCBCA.TXN.REF,S.POS,1>
   ftFlag = 1 
  END
 LOCATE 'SECURITY.TRANSFER' IN yApplication<1,1> SETTING V.POS THEN 
   yStTransId = CapeCaRefRecord<SCBCA.TXN.REF,V.POS>
 stFlag = 1 
  END

IF ftFlag AND stFlag THEN
 yCommonFlag = 1
 yCommonTransId =  yFtTransId :"*":yStTransId
END 

**************************
    BEGIN CASE

  CASE yCommonFlag

CALL F.READ(fnScbCapeEventParam,yCapeEventDets,rCapeEventParam,fvScbCapeEventParam,errorCapeEventParam)
 IF rCapeEventParam THEN
yClientOutputParamId = rCapeEventParam<SCBCE.CLIENT.PARAM.ID>

  IF yClientOutputParamId[1,3] EQ 'FUN' THEN 
      CALL D.SCB.CAPE.FT.ADV.MAPPING(yCommonTransId ,yFtTransId,MAT HANDOFF.REC)
  END
   ELSE
      CALL D.SCB.CAPE.ST.ADV.MAPPING(yCommonTransId ,yStTransId,MAT HANDOFF.REC)
  END
END
  CASE yFtTransId  
		CALL D.SCB.CAPE.FT.ADV.MAPPING(yCommonTransId ,yFtTransId,MAT HANDOFF.REC)
	
  CASE yStTransId 
           CALL D.SCB.CAPE.ST.ADV.MAPPING(yCommonTransId ,yStTransId,MAT HANDOFF.REC)
	END CASE


RETURN
*-----------------------------------------------------------------------------	
END