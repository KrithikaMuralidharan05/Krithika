$PACKAGE All.ScbRbPackage
	SUBROUTINE B.SCB.RB.SECTRADE.EXTRACT.SELECT
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This routine is used to generate a report based on the Authorise SEC.TRADE.
* Copy of existing B.SCB.ST.PBDW.EXTRACT.SELECT with change in select and include LOB logic for RB.
*-----------------------------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 13-Apr-2022       Lavanya L       CPSGMIG-2420        Initial Creation
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.SECTRADE.EXTRACT.COMMON
	$INSERT I_BATCH.FILES
	
	IF NOT(CONTROL.LIST) THEN
        GOSUB BUILD.CONTROL.LIST
    END
    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "SEC.TRADE"
            GOSUB UPDATE.SEC.TRADE
        CASE CONTROL.LIST<1,1> = "SEC.TRADE.NAU"
            GOSUB UPDATE.SEC.TRADE.NAU
    END CASE
	RETURN
*---------------------------------------------------------------------------
BUILD.CONTROL.LIST:
*------------------

	CONTROL.LIST<-1> = "SEC.TRADE"
    CONTROL.LIST<-1> = "SEC.TRADE.NAU"
	RETURN
*-------------------------------------------------------------------------------  
UPDATE.SEC.TRADE:
*----------------
	SEL.CMD = ''
	SEC.ID = ''
	NO.OF.IDS = ''
	SEC.ERR = ''
	
    SEL.CMD = 'SELECT ':FN.SEC.TRD.TODAY:' WITH @ID LIKE ':ID.COMPANY[1,2]:'...'
    
    CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)

    CALL BATCH.BUILD.LIST('',SEC.ID)
RETURN
*------------------------------------------------------------------------------
UPDATE.SEC.TRADE.NAU:
*---------------------
	SEL.CMD1 = ''
	SEC.ID1 = ''
	NO.OF.IDS1 = ''
	SEC.ERR1 = ''
	
	SEL.CMD1 = "SSELECT ":FN.SEC.TRADE.NAU:" WITH VALUE.DATE GT ":TODAY
    
    CALL EB.READLIST(SEL.CMD1,SEC.ID1,'',NO.OF.IDS1,SEC.ERR1)

    CALL BATCH.BUILD.LIST('',SEC.ID1)
	RETURN
END
