$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-27</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.ST.REV.EXTRACT.SELECT
**    ! DESCRIPTION : THIS IS A SELECT FILE WHICH  WILL SELECT ALL THE TRADE TRASACTION HAPPENED ON A DAY TO DAY BASIS
* Copy of existing B.SCB.ST.REV.PBDW.EXTRACT.SELECT with change in select and include LOB logic for RB.
* Revision History:
*------------------
*   Date               who           Reference            Description
* 27-Jul-2022        Lavanya L       CPSGMIG-4231       Initial Creation
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.ST.REV.EXTRACT.COMMON



    IF ID.COMPANY EQ "SG1090400" THEN   ;* QC-574 S/E For SNG, ACU transactions should be included.
        SEL.CMD = "SSELECT ":FN.SEC.TRD.REV :" WITH @ID LIKE ":COUNTRY.NAME:"...*SCTRSC..."
*
* QC-574 Start
*
    END ELSE        ;* For HKB, since COUNTRY.NAME based selection includes HKW transactions also
        SEL.CMD = "SSELECT ":FN.SEC.TRD.REV :" WITH @ID LIKE ":ID.COMPANY:"...*SCTRSC..." ;* ID.COMPANY is used instead
    END
*
* QC-574 End
*
    CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)

*ENABLE 1.2 Phase 2 changes- START
    Y.ARRAY.RET = ''
    CALL SCB.ST.REV.APPEND(Y.ARRAY.RET)
    IF Y.ARRAY.RET THEN
        IF SEC.ID THEN
            SEC.ID<-1> = Y.ARRAY.RET
        END ELSE
            SEC.ID     = Y.ARRAY.RET
        END
    END
*ENABLE 1.2 Phase 2 changes- END

    CALL BATCH.BUILD.LIST('ST.LIST',SEC.ID)

RETURN
END
