$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PII.HIS.PURGE(Y.REL.ID)
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* ADO Ref				       2653147
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.PII.HIS.PURGE
*
* Workflow                     This Multi Thread Service will first look for the file presence in SAVEDLISTS>PARTY.PURGE.REL.IDS
*
*                              - If above said file present in SL then service will execute only purging of underlying history
*                              records of those REL-IDS by keeping CURR.NO EQ "1" and no.of records parameterized.
*                               
*                              - If there is no file present in SL then service will select the SCB.RSG.PARTY.DETAILS table and
*                              proceed with the purging activity accordingly.
*
*                              - In both the cases, if the Live CURR.NO < Hist Retain Value (Param Value + 1) then purging activity
*                              aganist that RELID will be skipped and proceed with next in the loop.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        05/Jan/2024      2653147             Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SCB.RSG.PARTY.DETAILS
	$INSERT I_B.SCB.RB.PII.HIS.PURGE.COMMON

	GOSUB INIT
	GOSUB PROCESS

	RETURN
*--------------------------------------------------------------------------------------------------------
INIT:
*****

	R.PARTY.DETS = ''	; PARTY.DETS.READ.ERR = ''	; Y.CURR.NO = ''	; Y.LOOP.CNT = 0	; Y.HIS.ID = ''

	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********
* Read the PARTY details Table -

	CALL F.READ(FN.PARTY.DETS,Y.REL.ID,R.PARTY.DETS,F.PARTY.DETS,PARTY.DETS.READ.ERR)
	
	IF NOT(PARTY.DETS.READ.ERR) THEN
		CALL OCOMO(" ***** Processing the REL.ID and deleting related history records ***** ":Y.REL.ID)
		Y.CURR.NO = R.PARTY.DETS<PR.DETS.CURR.NO>
		IF Y.CURR.NO GT Y.HIST.RETAIN.VAL THEN
			Y.LOOP.CNT = Y.CURR.NO - Y.PARAM.VAL
			FOR I = 2 TO Y.LOOP.CNT
				Y.HIS.ID = Y.REL.ID:";":I
				DELETE F.PARTY.DETS.HIS,Y.HIS.ID
			NEXT I
		END
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END