$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.LIEN.MARK.SELECT
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 14/04/2023 - Sasi V - To create POSITION.TRANSFER records for Lien/Unlien request
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.LIEN.MARK.COMMON
*
    GOSUB SEL.PROCESS
*
RETURN
*-----------------------------------------------------------------------------
SEL.PROCESS:
*-----------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SCB.RB.LIEN.MARKING:" WITH STATUS EQ ''"
*
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
END
