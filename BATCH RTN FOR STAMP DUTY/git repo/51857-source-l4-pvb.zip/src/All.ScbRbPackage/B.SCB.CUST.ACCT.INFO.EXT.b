* @ValidationCode : MjotOTM0NjI1MDQxOklTTy04ODU5LTE6MTY3Nzc0NjgwNzMwMjoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 02 Mar 2023 14:16:47
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CUST.ACCT.INFO.EXT(Y.CUST.ID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13123 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       30 December 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Main Routine to extract Customer Info batch for iBanking from CUSTOMER and SAM
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CUST.ACCT.INFO.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 01-Mar-23     1663000          CPSGMIG-19959 - T24 to share all client details irrespective of Primary/secondary
* 23-Mar- 2023 - CPSGMIG-18238 - Lakshmi PR- Parameterised the customer tranche records
* 05-Apr-23     1667095          CPSGMIG-23264 -Remove duplicate entries
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_B.SCB.CUST.ACCT.INFO.EXT.COMMON
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM ;*CPSGMIG-18238- Start/End
	
    GOSUB INIT
    GOSUB PROCESS.REL.ID
RETURN

**************
INIT:
**************
    
    DETAIL.ID 	= '1' ; PROD.CD		=''
    SUBPROD.CD 	= '' ; REL.ACCT1 	= ''
    REL.CD.2 	= '' ; REL.ACCT2 	= ''
    REL.CD.3 	= '' ; REL.ACCT3 	= ''
    REL.CD.4 	= '' ; REL.ACCT4 	= ''
    ACCT.NUM 	= '' ; SETT.ACCT.PROD = ''
    SETT.ACCT.NUM = '' ; REF.BRANCH = ''

    
RETURN

**************
PROCESS.REL.ID:
**************
    R.CUSTOMER 	= '' ; ERR.CUSTOMER 	= ''
    Y.LOB 		= '' ; Y.LR.EBBS.REL 	= ''
    Y.EBBS.REL.VAL 	= '' ; Y.PRIM.SEC.VAL = ''
    Y.SIGN.MAND.VAL = '' ; Y.EBBS.PRIM = ''
    CALL F.READ(FN.CUSTOMER,Y.CUST.ID,R.CUSTOMER,F.CUSTOMER,ERR.CUSTOMER) ;*CPSGMIG-23264(S/E)
    Y.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
    IF (Y.LOB MATCHES Y.ALLOWED.LOB) THEN ;*CPSGMIG-19959
*CPSGMIG-18238- Start
        Y.MIG.DAT = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.MIG.DAT.POS>
        IF Y.FILE.FLAG EQ "TRANCHE" AND Y.MIG.DAT NE '' THEN
            REC.SEC.ACC.CUST = '' ; ERR.CSA = ''
            CALL F.READ(FN.SEC.ACC.CUST,Y.CUST.ID,REC.SEC.ACC.CUST,F.SEC.ACC.CUST,ERR.CSA)
            Y.SAM.POS = ''
            LOOP
                REMOVE Y.ACCOUNT.NO FROM REC.SEC.ACC.CUST SETTING Y.SAM.POS
            WHILE Y.ACCOUNT.NO:Y.SAM.POS
                GOSUB PROCESS
            REPEAT
        END ELSE
            IF Y.FILE.FLAG EQ "FULL" THEN
			    REC.SEC.ACC.CUST = '' ; ERR.CSA = ''
                CALL F.READ(FN.SEC.ACC.CUST,Y.CUST.ID,REC.SEC.ACC.CUST,F.SEC.ACC.CUST,ERR.CSA)
                Y.SAM.POS = ''
                LOOP
                    REMOVE Y.ACCOUNT.NO FROM REC.SEC.ACC.CUST SETTING Y.SAM.POS
                WHILE Y.ACCOUNT.NO:Y.SAM.POS
                    GOSUB PROCESS
                REPEAT
				
            END
        END
    END
*CPSGMIG-18238- End

RETURN

**************
PROCESS:
**************

    Y.AC.CLOSE.DT = '' ; Y.AC.BLK.DT= '' ; CURRENCY.CODE = ''
    ACCT.STS 	= '' ; ACCT.STS.DESC = ''
    R.SAM = '' ; ERR.SAM = '' ;
    Y.OUT.REL.ARRAY  = '' ; Y.OUT.SIGN.MAND.ARRAY = ''
    ACCT.NUM = Y.ACCOUNT.NO
 
    CALL F.READ(FN.SAM,Y.ACCOUNT.NO,R.SAM,FV.SAM,ERR.SAM)
    IF R.SAM THEN
        Y.AC.CLOSE.DT = R.SAM<SC.SAM.CLOSURE.DATE>
        Y.AC.BLK.DT = R.SAM<SC.SAM.BLOCKING.DATE>
        CURRENCY.CODE = R.SAM<SC.SAM.REFERENCE.CURRENCY>
    
        Y.LR.EBBS.REL = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS>
        REL.ID.COUNT = DCOUNT(Y.LR.EBBS.REL,@SM)
        START.CNT = 1
        LOOP
        WHILE START.CNT LE REL.ID.COUNT
            Y.EBBS.REL.VAL = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,START.CNT>
            Y.PRIM.SEC.VAL = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.PRIM.SEC.POS,START.CNT>
            Y.SIGN.MAND.VAL = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.SIGN.MANDATE.POS,START.CNT>
            IF Y.PRIM.SEC.VAL EQ 'Primary' THEN
                Y.EBBS.PRIM = Y.EBBS.REL.VAL
            END ELSE
                Y.OUT.REL.ARRAY<-1> = Y.EBBS.REL.VAL
                Y.OUT.SIGN.MAND.ARRAY<-1> = Y.SIGN.MAND.VAL
            END
            START.CNT = START.CNT + 1
        REPEAT

    
        BEGIN CASE
            CASE (Y.AC.CLOSE.DT NE '') AND (Y.AC.CLOSE.DT LE TODAY)
                ACCT.STS 	= '04'
                ACCT.STS.DESC = "CLOSED"
            CASE (Y.AC.BLK.DT NE '') AND (Y.AC.BLK.DT LE TODAY)
                ACCT.STS 	= '03'
                ACCT.STS.DESC = "SUSPENDED"
            CASE ACCT.STS EQ ''
                ACCT.STS = '01'
                ACCT.STS.DESC = "NORMAL"
        END CASE
        
        GOSUB FORM.ARRAY
        GOSUB WRITE.FILE
    END
RETURN

**************
FORM.ARRAY:
**************

    Y.SAM.REC = DETAIL.ID:FMT(PROD.CD,"3' 'L"):FMT(SUBPROD.CD,"2' 'L"):FMT(Y.EBBS.PRIM,"20' 'L"):FMT(Y.OUT.SIGN.MAND.ARRAY<1>,"3' 'L"):
    Y.SAM.REC := FMT(Y.OUT.REL.ARRAY<1>,"20' 'L"):FMT(Y.OUT.SIGN.MAND.ARRAY<2>,"3' 'L"):FMT(Y.OUT.REL.ARRAY<2>,"20' 'L"):
    Y.SAM.REC := FMT(Y.OUT.SIGN.MAND.ARRAY<3>,"3' 'L"):FMT(Y.OUT.REL.ARRAY<3>,"20' 'L"):
    Y.SAM.REC := FMT(ACCT.NUM,"R%23"):FMT(ACCT.STS,"6' 'L"):FMT(ACCT.STS.DESC,"150' 'L"):FMT(SETT.ACCT.PROD,"3' 'L"):
    Y.SAM.REC := FMT(SETT.ACCT.NUM,"R%20"):FMT(REF.BRANCH,"R%5"):FMT(CURRENCY.CODE,"3' 'L")
    
RETURN

**************
WRITE.FILE:
**************

    IF Y.SAM.REC THEN
        OPENSEQ AMEX.FILES,FILE.NAME TO F.AMEX.FILES ELSE CREATE F.AMEX.FILES ELSE
            CALL OCOMO("Error opening ":FILE.NAME)
        END
        WRITESEQ Y.SAM.REC APPEND TO F.AMEX.FILES ELSE
            CALL OCOMO('Unable to write ':F.AMEX.FILES)
        END
*
        CLOSESEQ F.AMEX.FILES
*
    END
RETURN

END
