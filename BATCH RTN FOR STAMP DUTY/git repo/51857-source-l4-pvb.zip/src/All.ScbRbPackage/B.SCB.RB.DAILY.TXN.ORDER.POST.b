* @ValidationCode : MjotMjIzMjQ0MzE6SVNPLTg4NTktMToxNjkzMjk3OTE3MTU3OjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 29 Aug 2023 14:01:57
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.DAILY.TXN.ORDER.POST
*-----------------------------------------------------------------------------
* Jira ref                       :      ADO-11887708
* Developed By                   :      8219622
* Developed On                   :      20-Feb-2026
*-----------------------------------------------------------------------------
* Description:
*-------------
* Batch report attached to SNG/SCB.RB.DAILY.TXN.ORDER inorder to generate report for daily transactions of SEC.TRADE,SEC.OPEN.ORDER AND SECURITY.TRANSFER 
* regardless of whether it is in authorized, unauthorized or hold status
*-------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_B.SCB.RB.DAILY.TXN.ORDER.COMMON
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
	GOSUB PROCESS
	GOSUB PURGE.TEMPLATE
	 
RETURN
*---------*
INITIALISE:
*---------*
*
    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
	
    Y.TXN.FINAL.FILE = FIELD(BATCH.DETAILS<3, 1, 1>, '*', 1)
	
    Y.LWD = '' ; Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.TXN.FINAL.FILE = EREPLACE(Y.TXN.FINAL.FILE,"<LWD>",Y.LWD,-1)
    
    YDL = ','
*
RETURN
*------*
PROCESS:
*------*
*    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.TXN.ARR = '' ; Y.FINAL.TXN.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD = "DAILYORDERTXN-":TODAY:"-*.csv*"	
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    LOOP
        REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
    WHILE Y.SEL.ID : SEL.POS
        
        R.AMEX.FILE = '' ; AMEX.ERR = ''
        CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)         
		Y.SEL.ID.START = Y.SEL.ID[1,22]
		Y.TEMP.FILE.START = "DAILYORDERTXN-":TODAY
		IF Y.SEL.ID.START EQ Y.TEMP.FILE.START THEN		 
         IF NOT(R.TXN.ARR) THEN
            R.TXN.ARR = R.AMEX.FILE
         END ELSE
            R.TXN.ARR<-1> = R.AMEX.FILE
         END
	      CALL OCOMO("Deleting the temporary file:- ":Y.SEL.ID)		 
          CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
		END            
    REPEAT
*
* Frame Header part
    Y.TXN.HDR = "Transaction Reference,ISOC Operator,Order Closing Id,Country Code,Sales Staff Name,"
    Y.TXN.HDR:= "Account Type,Account Number,Account Open Date,Lien Reason Code,Lien Reason Code Desc,"
    Y.TXN.HDR:= "Order No.,Order Date,Account Holder DOB,Transaction Type,Detail On Order Type,Order Type,"
    Y.TXN.HDR:= "Transaction Status,Product Provider Name,Asset Code,Asset Name,Asset Currency,"
    Y.TXN.HDR:= "Transaction Amount,Remarks,Account Holder 1,ID Number 1,EBBS Rel ID 1,Account Holder 2,ID Number 2,"
    Y.TXN.HDR:= "EBBS Rel ID 2,Account Holder 3,ID Number 3,EBBS Rel ID 3,Account Holder 4,ID Number 4,EBBS Rel ID 4,RSP Plan ID,ISIN,PRR [Risk],"
    Y.TXN.HDR:= "Channel info,ClientIdentifier,PrimaryAcctHolder,Account Holder DOB 2,Account Holder DOB 3,Account Holder DOB 4,"
    Y.TXN.HDR:= "Transaction Date,Referral ID,Transaction CCY,Rel 1,Rel 2,Rel 3,Rel 4"

    Y.FINAL.TXN.ARR     = Y.TXN.HDR
    Y.FINAL.TXN.ARR<-1> = R.TXN.ARR
        
    WRITE Y.FINAL.TXN.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
*
RETURN
*------*
PURGE.TEMPLATE:
*------*
*
    SEL.LIST = " "; SEL.CNT = " "; SEL.POS = " "; Y.SEL.ID = " "
	
	Y.PURGE.CALC = FIELD(BATCH.DETAILS<3, 1, 1>, '*', 2)
	Y.PURGE.CALC = "-":Y.PURGE.CALC
    Y.PURGE.DATE = TODAY
	
	CALL CDT("",Y.PURGE.DATE,Y.PURGE.CALC)
	
	SEL.CMD = " SELECT " :FN.SCB.RB.DAILY.TXN.DETAILS:" WITH DATE LT ": Y.PURGE.DATE
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,'')
	CALL OCOMO("Purging the Template SCB.RB.DAILY.TXN.DETAILS")
	
	IF SEL.LIST THEN
	 LOOP
       REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
     WHILE Y.SEL.ID:SEL.POS
	    CALL F.DELETE(FN.SCB.RB.DAILY.TXN.DETAILS,Y.SEL.ID)
     REPEAT
	END	
*
RETURN
*----------------------------------------------------------------------------*
END
