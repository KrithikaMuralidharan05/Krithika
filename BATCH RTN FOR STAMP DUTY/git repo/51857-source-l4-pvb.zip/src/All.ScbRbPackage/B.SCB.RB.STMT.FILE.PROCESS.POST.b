$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.STMT.FILE.PROCESS.POST
*
* This is BATCH routine which is attached to the SNG/SCB.RB.STMT.FILE.PROCESS. This routine
* loads the requested files and to process the EBBS incoming file.
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
**
* 05-Sep-2022 - kalaikumaranp - CPSGMIG-798 - Statement file generation
*
* 30-Jan-2023 - Loganathan G  - ADO-2339312 - Exception handling in case of incorrect /incomplete EBBS request file for RB SG Statement via Locking.
*-------------------------------------------------------------------------------
    	$INSERT I_COMMON
    	$INSERT I_EQUATE
        $INSERT I_F.DATES
        $INSERT I_F.LOCKING
    
    YF.LOCKING = 'F.LOCKING'
    FP.LOCKING = ''
    CALL OPF(YF.LOCKING,FP.LOCKING)
    Y.LOCK.ID = 'RBSG.INWARD.FILE.STATUS'
    R.LOCKING = ''
    Y.LOCK.VALUE = ''
    CALL F.READ(FN.LOCKING,Y.LOCK.ID,R.LOCKING,F.LOCKING,LOCK.ERR)
    Y.LOCK.VALUE = R.LOCKING<EB.LOK.CONTENT>

    IF Y.LOCK.VALUE EQ "MISMATCH" THEN
	CALL OCOMO("B.SCB.RB.STMT.FILE.PROCESS.POST is MISMATCH")
	RETURN
    END
        
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    L.WORK.DATE=R.DATES(EB.DAT.LAST.WORKING.DAY)
    
    Y.FINAL.ID = 'T24-CSE-STATEMENT-SG-':L.WORK.DATE:'.txt'

	AMEX.FILES.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME('AMEX.FILES', '', AMEX.FILES.PATH)
    
    EBBS.OUTFIL.PATH = 'EBBS.MMOUTFILE'
	CALL SCB.GET.ORACLE.FILENAME(EBBS.OUTFIL.PATH, '', OUTFILE.PATH)
	    
Y.UDFILE       = 'AMEX.FILES'
Y.ST.CRITERIA  = 'SG-RB-MMSTMT-':TODAY:'-*'
Y.FILE.ARRAY = ''
Y.FILE.ARRAY = 'H~UTS~':L.WORK.DATE:'~'
Y.FILE.ARRAY<-1> = 'S~eBBS Rel ID~Row Identifier~Product Account No.~Mutual Fund Name of security~Mutual Fund Currency~Mutual Fund No. of units~Mutual Fund Price~Mutual fund As of Date~Mutual Fund Currency Amount~Mutual Fund SGD Equivalent~Mutual Fund Total~Mutual Fund Transaction Name of security~Mutual fund transaction description~Mutual fund Transaction no of units~Mutual fund transction Price~Mutual fund transaction date~Mutual fund value date~Mutual fund pending settlement~Mutual fund transaction currency~Mutual fund transaction currency amount~Structure Notes Name of security~Structure Notes Currency~Structure Notes No. of units~Structure Notes Price~Structure Notes Unrealised P/L~Structure Notes As of Date~Structure Notes Currency Amount~Structure Notes SGD Equivalent~Structure Notes Total~Structure Notes Transaction Name of security~Structure Notes transaction description~Structure Notes Transaction no of units~Structure Notes transction Price~Structure Notes transaction date~Structure Notes value date~Structure Notes pending settlement~Structure Notes transaction currency~Structure Notes transaction currency amount~Structure Notes - Princ. at Risk Name of security~Structure Notes - Princ. at Risk Currency~Structure Notes - Princ. at Risk No. of units~Structure Notes - Princ. at Risk Price ~Structure Notes - Princ. at Risk Unrealised P/L~Structure Notes - Princ. at Risk As of Date~Structure Notes - Princ. at Risk Currency Amount~Structure Notes - Princ. at Risk SGD Equivalent~Structure Notes - Princ. at Risk Total~Structure Notes - Princ. at Risk Transaction Name of security~Structure Notes - Princ. at Risk transaction description~Structure Notes - Princ. at Risk Transaction no of units~Structure Notes - Princ. at Risk transction Price~Structure Notes - Princ. at Risk transaction date~Structure Notes - Princ. at Risk value date~Structure Notes - Princ. at Risk pending settlement~Structure Notes - Princ. at Risk transaction currency~Structure Notes - Princ. at Risk transaction currency amount~Fixed Income Name of security~Fixed Income Currency~Fixed Income No. of units~Fixed Income Price~Fixed Income As of Date~Fixed Income Currency Amount~Fixed Income SGD Equivalent~Fixed Income Total~Fixed Income Transaction Name of security~Fixed Income transaction description~Fixed Income Transaction no of units~Fixed Income transction Price~Fixed Income transaction date~Fixed Income value date~Fixed Income pending settlement~Fixed Income transaction currency~Fixed Income transaction currency amount~Product Code~Pledge position/transaction'

    SEL.FILE.ID    = ''
    Y.ST.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.CRITERIA, SEL.FILE.ID, Y.ST.CNT)

    Y.DEL.FILE.ID = SEL.FILE.ID
    LOOP
        REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
    WHILE Y.FILE.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.RBMMSTMT.REC,F.APPEND.FILES,APP.ERR)
        IF R.RBMMSTMT.REC NE  '' THEN
            Y.FILE.ARRAY<-1> = R.RBMMSTMT.REC
            LINE.COUNT = DCOUNT(R.RBMMSTMT.REC, @FM)
            TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
        LINE.COUNT = ''
    REPEAT
Y.FILE.ARRAY<-1> = 'T~':TOTAL.LINE.COUNT:'~'

WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID

SH.CMD = "SH -c cp -f ":AMEX.FILES.PATH:"/":Y.FINAL.ID:" ":OUTFILE.PATH
EXECUTE SH.CMD 

RETURN
END


