$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ISA.PORTF.ICM(YTRDID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13848 - JEWEL_T24_PROJECT
* Developed By                   :       Chandru Sampath
* Developed On                   :       19 October 2022
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract Day0 File for ICM
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/B.SCB.RB.ISA.PORTF.ICM
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*08-Aug-2023    1670271          CPSGMIG-32375 Rel ID Delimiters needs to be fixed for Joint Accounts
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.RB.ISA.PORTF.ICM.COMMON
 
    GOSUB DO.SAM.PROCESS
                
RETURN

*===================================================================================
DO.SAM.PROCESS:
*===================================================================================

    SEL.LIST = YTRDID
	LOOP
        REMOVE Y.SAM.ID FROM SEL.LIST SETTING Y.SAM.POS
    WHILE Y.SAM.ID:Y.SAM.POS
 
        CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,Y.SAM.POS)

        IF R.SAM THEN

            Y.PFOLIO.KEY = R.SAM<SC.SAM.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
            CHANGE ':' TO @FM IN Y.PFOLIO.KEY
	    PFOLIO.KEY.COUNT = DCOUNT(Y.PFOLIO.KEY,@FM)			
			
	    Y.PORTFOLIO.CCY = 'SGD'
            Y.PROFILE.ROLE = '' 
	    ISA.STATUS = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.AC.STATUS.POS>
	    CHANGE @SM TO @FM IN ISA.STATUS
                    
            Y.TP.ACCT.NO = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS>
            CHANGE @SM TO @FM IN Y.TP.ACCT.NO
            TP.ACCT.CNT = DCOUNT(Y.TP.ACCT.NO,@FM)            
	    CUS.NO = R.SAM<SC.SAM.CUSTOMER.NUMBER>
	    CUS.ID = CUS.NO
            GOSUB CUSTOMER.PROCESS    ;*read customer to get sector detail if business or individual
            IF Y.SECTOR NE "23" THEN               
                Y.SEGMENT.CODE ="Individual"
				GOSUB INDIV.ISA              
            END           
        END   ;*end FOR first IF

    REPEAT

RETURN

*=================================================================================== 
CUSTOMER.PROCESS:
*=================================================================================== 

    CALL F.READ(FN.CUSTOMER,CUS.ID,R.CUSTOMER,F.CUSTOMER,CUS.ERR)
    Y.SECTOR = R.CUSTOMER<EB.CUS.SECTOR>
    Y.PP.CODE = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.PP.CODE.POS>		;*Used to get PP CODE FOR SM

RETURN

*=================================================================================== 
INDIV.ISA:
*=================================================================================== 

    IF TP.ACCT.CNT LE 1 AND Y.TP.ACCT.NO MATCHES ISA.LISTS THEN   ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed		
        CALL OCOMO("Processing SAM Record ID for Individual segment :":Y.SAM.ID)
        J = 1
        LOOP
        WHILE J LE PFOLIO.KEY.COUNT
            IF J EQ '1' THEN
                Y.PROFILE.ROLE = 'PRI'
            END ELSE
                Y.PROFILE.ROLE = 'SEC'
            END
                    BEGIN CASE
                          CASE ISA.STATUS EQ 'NORMAL'
                              Y.STATUS = '01'
                          CASE ISA.STATUS EQ 'SUSPENDED'
                              Y.STATUS = '03'
                          CASE ISA.STATUS EQ 'CLOSED'
                              Y.STATUS = '05'
                          CASE 1
                              Y.STATUS = ''
                    END CASE  
            Y.SAM.ARRAY = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO:',':Y.PFOLIO.KEY<J>:',':Y.SEGMENT.CODE:',':ISA.STATUS:',':Y.PORTFOLIO.CCY:',':Y.STATUS:',':Y.PROFILE.ROLE
            GOSUB FILE.WRITE.PROCESS
            J++
        REPEAT
         
    END ELSE
        CALL OCOMO("Processing SAM Record ID for Individual segment :":Y.SAM.ID)
        I = 1
        LOOP
        WHILE I LE TP.ACCT.CNT
            IF Y.TP.ACCT.NO<I> MATCHES ISA.LISTS THEN    ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed	
                JJ = 1
                LOOP
                WHILE JJ LE PFOLIO.KEY.COUNT
                    IF JJ EQ '1' THEN
                         Y.PROFILE.ROLE = 'PRI'
                    END ELSE
                         Y.PROFILE.ROLE = 'SEC'
                    END   
                    BEGIN CASE
                          CASE ISA.STATUS<I> EQ 'NORMAL'
                              Y.STATUS = '01'
                          CASE ISA.STATUS<I> EQ 'SUSPENDED'
                              Y.STATUS = '03'
                          CASE ISA.STATUS<I> EQ 'CLOSED'
                              Y.STATUS = '05'
                          CASE 1
                              Y.STATUS = ''
                    END CASE    
                    Y.SAM.ARRAY = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO<I>:',':Y.PFOLIO.KEY<JJ>:',':Y.SEGMENT.CODE:',':ISA.STATUS<I>:',':Y.PORTFOLIO.CCY:',':Y.STATUS:',':Y.PROFILE.ROLE
                    GOSUB FILE.WRITE.PROCESS
                    JJ++
                REPEAT                     
            END
            I+=1
        REPEAT
    END
    
RETURN

*=================================================================================== 
FILE.WRITE.PROCESS:
*===================================================================================     
 
     IF Y.SAM.ARRAY THEN
        OPENSEQ AMEX.FILES,Y.TEMP.FILE.NAME.SAM TO FP.AMEX.FILES ELSE
        END
        WRITESEQ Y.SAM.ARRAY APPEND TO FP.AMEX.FILES ELSE
            CALL OCOMO("Unable to Write UT Trade Report")
        END
        CLOSESEQ FP.AMEX.FILES
        Y.SAM.ARRAY = ''
    END
    
    RETURN
END
