$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GST.ENTRIES.PROCESS.SELECT
*------------------------------------------------------------------------------
*
* Author                       Loganathan G
* EPACC/Story/Sub task Ref     CPSGMIG-3231
* Routine Type                 Batch process routine
* Attached To                  BATCH>SNG/SCB.RB.STATIC.ENTRY
* Workflow                     To update SCB.GST.RBSG.EXTRACT table For GST Amt
* Select the ACCT.ENT.TODAY with ID as RB.GST.CATEGORY from SCB.GST.RBSG.PARAM
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*
*
*
*----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.GST.RBSG.PARAM
    $INSERT I_B.SCB.RB.GST.ENTRIES.PROCESS.COMMON
    
    GOSUB PROCESS

    RETURN

********
PROCESS:
********
    
    Y.ARRAY = ''
    R.GST.ACCT = ''
    R.CATEG.INT.ACCT = ''
    Y.CATEG.ID = ''
    ACC.ID = ''
    ACC.POS = ''
    POS1 = ''
    Y.RB.GST.CATEGORY = Y.GST.INT.CATEG

    LOOP
       REMOVE Y.CATEG.ID FROM Y.RB.GST.CATEGORY SETTING POS1
    WHILE Y.CATEG.ID:POS1

        CALL F.READ(FN.CATEG.INT.ACCT,Y.CATEG.ID,R.CATEG.INT.ACCT,F.CATEG.INT.ACCT,ERR.CATEG.INT.ACCT)
        R.GST.ACCT = R.CATEG.INT.ACCT
    
        LOOP
            REMOVE ACC.ID FROM R.GST.ACCT SETTING ACC.POS
        WHILE ACC.ID:ACC.POS
            R.ENTRIES = ''
            CALL F.READ(FN.ACCT.ENT.TODAY,ACC.ID,R.ENTRIES,F.ACCT.ENT.TODAY,AC.ENT.ERR)
            IF R.ENTRIES THEN
                CONVERT @VM TO @FM IN R.ENTRIES
                IF Y.ARRAY THEN
                   Y.ARRAY<-1> = R.ENTRIES
                END ELSE
                   Y.ARRAY = R.ENTRIES
                END
            END
        REPEAT

    REPEAT

    IF (Y.ARRAY) THEN
         CALL BATCH.BUILD.LIST("", Y.ARRAY)
    END    

    RETURN

END
