* @ValidationCode : MjotMTMwNDM1MTM5NjpJU08tODg1OS0xOjE2ODE4MDQ1NzQxODE6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 18 Apr 2023 13:26:14
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SETT.UNSETT.TRADES.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14422 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       18 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .LOAD Routine to extract Daily Trasaction details for the current month.
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
* 04-Jan-2023 - 1404392          CPSGMIG-17782 - Vestima Flag introduction and new requirement changes
* 03-Apr-2023   1663000          CPSGMIG-18645 & 14067 - PII Column Included
* 18-Apr-2023   1663000          CPSGMIG-24521 - Price & OrderTxntype mapping
* 29-Sep-2023   1670271          CPSGMIG-34479 - Reports - Mapping Change
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.SETT.UNSETT.TRADES.COMMON
*--------------------------------------------------------------------------------------------
   
    GOSUB OPEN.FILES
    GOSUB GET.VALUES

RETURN
*---------*
OPEN.FILES:
*---------*

    FN.SEC.TRADES.MDAY       = 'F.SCB.SEC.TRADES.MDAY'   ; F.SEC.TRADES.MDAY       = ''  ; CALL OPF(FN.SEC.TRADES.MDAY,F.SEC.TRADES.MDAY)
    FN.CUSTOMER.SECURITY     = 'F.CUSTOMER.SECURITY'     ; F.CUSTOMER.SECURITY     = ''  ; CALL OPF(FN.CUSTOMER.SECURITY,F.CUSTOMER.SECURITY)
    FN.SCB.WM.H.LOCAL.PARAM  = 'F.SCB.WM.H.LOCAL.PARAM'  ; F.SCB.WM.H.LOCAL.PARAM  = ''  ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM, F.SCB.WM.H.LOCAL.PARAM)
    FN.SEC.TRADE             = 'F.SEC.TRADE'             ; F.SEC.TRADE             = ''  ; CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    FN.ENTITLEMENT           = 'F.ENTITLEMENT'           ; F.ENTITLEMENT           = ''  ; CALL OPF(FN.ENTITLEMENT,F.ENTITLEMENT)
	FN.SECURITY.TRANSFER     = 'F.SECURITY.TRANSFER'     ; F.SECURITY.TRANSFER     = ''  ; CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
	FN.POSITION.TRANSFER     = 'F.POSITION.TRANSFER'     ; F.POSITION.TRANSFER     = ''  ; CALL OPF(FN.POSITION.TRANSFER,F.POSITION.TRANSFER)
    FN.SECURITY.TRANS        = 'F.SECURITY.TRANS'        ; F.SECURITY.TRANS        = ''  ; CALL OPF(FN.SECURITY.TRANS,F.SECURITY.TRANS)
    FN.SECURITY.MASTER       = 'F.SECURITY.MASTER'       ; F.SECURITY.MASTER       = ''  ; CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SEC.OPEN.ORDER        = 'F.SEC.OPEN.ORDER'        ; F.SEC.OPEN.ORDER        = ''  ; CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    FN.SC.TRANS.NAME         = 'F.SC.TRANS.NAME'         ; F.SC.TRANS.NAME         = ''  ; CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
    FN.DIARY                 = 'F.DIARY'                 ; F.DIARY                 = ''  ; CALL OPF(FN.DIARY,F.DIARY)
    FN.CUSTOMER              = 'F.CUSTOMER'              ; F.CUSTOMER              = ''  ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.ENTITLEMENT.HIS       = 'F.ENTITLEMENT$HIS'       ; F.ENTITLEMENT.HIS       = ''  ; CALL OPF(FN.ENTITLEMENT.HIS,F.ENTITLEMENT.HIS)
	FN.POSITION.TRANSFER.HIS = 'F.POSITION.TRANSFER$HIS' ; F.POSITION.TRANSFER.HIS = ''  ; CALL OPF(FN.POSITION.TRANSFER.HIS,F.POSITION.TRANSFER.HIS)
    FN.SEC.TRADE.HIS         = 'F.SEC.TRADE$HIS'         ; F.SEC.TRADE.HIS         = ''  ; CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)
    FN.SEC.OPEN.ORDER.HIS    = 'F.SEC.OPEN.ORDER$HIS'    ; F.SEC.OPEN.ORDER.HIS    = ''  ; CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
    FN.SECURITY.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS' ; F.SECURITY.TRANSFER.HIS = ''  ; CALL OPF(FN.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS)
    FN.DEPT.ACCT.OFFICER     = 'F.DEPT.ACCT.OFFICER'     ; F.DEPT.ACCT.OFFICER     = ''  ; CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)    ;*CPSGMIG-18645 & 14067
    FN.SCB.WM.H.SEGMENT      = 'F.SCB.WM.H.SEGMENT'      ; F.SCB.WM.H.SEGMENT      = ""  ; CALL OPF(FN.SCB.WM.H.SEGMENT,F.SCB.WM.H.SEGMENT)      ;*CPSGMIG-18645 & 14067
    FN.DIARY.HIS             = 'F.DIARY$HIS'             ; F.DIARY.HIS             = ''  ; CALL OPF(FN.DIARY.HIS,F.DIARY.HIS)                    ;*CPSGMIG-24521
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE = "SCBSETTUNSETTMTHREPT-":TODAY:"-":SESSION.NO:".csv"
     
RETURN
*---------*
GET.VALUES:
*---------*
    
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
 
* Get LRF values
    APP.NAME    = 'SEC.OPEN.ORDER' :@FM:'SECURITY.MASTER':@FM:'SEC.TRADE':@FM:'SECURITY.TRANSFER':@FM:'CUSTOMER'
	FIELD.NAME  = 'LR.RSP.REF'     :@VM: 'LR.CLOSING.ID' :@FM:
	FIELD.NAME := 'CASH.OR.REINV'  :@VM:'MF.ISSUER.NAME' :@VM:'LR.UTS.INS.DESC':@VM:'LR.RETAIL.DEPO':@VM:'LM.RET.DEPO.INV' :@VM: 'LR.UT.CODE.ID' :@FM:   ;*CPSGMIG-18645 & 14067
	FIELD.NAME := 'LR.PAYMENT.TYPE':@VM:'LR.RM.DISC.PERC':@VM: 'LR.REFERRAL.ID':@VM:'LR.CLOSING.ID' :@FM:    ;*CPSGMIG-18645 & 14067
	FIELD.NAME := 'LR.PAYMENT.TYPE':@FM:
	FIELD.NAME := 'L.O.B'          :@VM:'LR.PFOLIO.KEY'  :@VM:'LR.STAFF.IND'  :@VM: 'LWM.PVB.IND'          ;*CPSGMIG-18645 & 14067
    FIELD.POS  = ''
    CALL MULTI.GET.LOC.REF(APP.NAME, FIELD.NAME, FIELD.POS)
    
	LR.RSP.REF.POS      = '' ; LR.RSP.REF.POS      = FIELD.POS<1,1>
        LR.SOO.CLOSEID.POS  = '' ; LR.SOO.CLOSEID.POS   = FIELD.POS<1,2>
	CASH.OR.REINV.POS   = '' ; CASH.OR.REINV.POS   = FIELD.POS<2,1>
	MF.ISSUER.NAME.POS  = '' ; MF.ISSUER.NAME.POS  = FIELD.POS<2,2>
	LR.UTS.INS.DESC.POS = '' ; LR.UTS.INS.DESC.POS = FIELD.POS<2,3>
*CPSGMIG-17782 Start
	LR.RETAIL.DEPO.POS  = '' ; LR.RETAIL.DEPO.POS  = FIELD.POS<2,4>
	LM.RET.DEPO.INV.POS = '' ; LM.RET.DEPO.INV.POS = FIELD.POS<2,5>
*CPSGMIG-17782 End
    LR.UTCODE.ID.POS    = '' ; LR.UTCODE.ID.POS    = FIELD.POS<2,6>  ;*CPSGMIG-18645 & 14067
    
	LRPAY.STRADE.POS    = '' ; LRPAY.STRADE.POS    = FIELD.POS<3,1>
    LR.RM.DISC.POS      = '' ; LR.RM.DISC.POS      = FIELD.POS<3,2>  ;*CPSGMIG-18645 & 14067 -S
    LR.REFID.POS        = '' ; LR.REFID.POS        = FIELD.POS<3,3>  ;*CPSGMIG-18645 & 14067 -E
    LR.SEC.CLOSEID.POS = ''  ; LR.SEC.CLOSEID.POS = FIELD.POS<3,4>

	LRPAY.STRFR.POS     = '' ; LRPAY.STRFR.POS     = FIELD.POS<4,1>
	L.O.B.POS           = '' ; L.O.B.POS           = FIELD.POS<5,1>
    Y.CUS.LRPFOLIO.POS  = '' ; Y.CUS.LRPFOLIO.POS  = FIELD.POS<5,2>  ;*CPSGMIG-18645 & 14067 -s
    Y.CU.STAFFIND.POS   = '' ; Y.CU.STAFFIND.POS   = FIELD.POS<5,3>
    Y.PVB.RB.POS        = '' ; Y.PVB.RB.POS        = FIELD.POS<5,4> ;*CPSGMIG-18645 & 14067 -e
    YD = ','
    
RETURN
END
