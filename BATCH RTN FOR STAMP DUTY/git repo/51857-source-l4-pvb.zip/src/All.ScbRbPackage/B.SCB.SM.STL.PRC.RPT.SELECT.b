$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SM.STL.PRC.RPT.SELECT
*-----------------------------------------------------------------------------
* CPSGMIG-1552 Stale Price Report
*              To view price and date last price for active Structured Note instruments
*              To  identify the Structured Note instrument with stale or missing price
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_B.SCB.SM.STL.PRC.RPT.COMMON
    
    SEL.CMD = 'SELECT ':FN.SECURITY.MASTER:' WITH SUB.ASSET.TYPE GE 185 AND SUB.ASSET.TYPE LE 285 AND MATURITY.DATE GE ':TODAY:" OR MATURITY.DATE EQ '' BY @ID" 
    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
RETURN
END
