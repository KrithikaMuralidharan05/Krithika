$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.STATICAL.ENTRIES.PROCESS.SELECT
*-----------------------------------------------------------------------------
*
* Author                       Loganathan G
* EPACC/Story/Sub task Ref     CPSGMIG-3231
* Routine Type                 Batch process routine
* Attached To                  BATCH>SNG/SCB.RB.STATIC.ENTRY
* Workflow                     To update SCB.GST.RBSG.EXTRACT table and raise RBSG Statical Entries
* Select the CATEG.ENT.TODAY with ID as both PL.CATEGORY and EXCL.PL.CATEGORY from SCB.GST.RBSG.PARAM
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*
*
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.GST.RBSG.PARAM
    $INSERT I_B.SCB.RB.STATICAL.ENTRIES.PROCESS.COMMON  
    
    GOSUB INT 
    GOSUB PROCESS
    GOSUB SELECT.CMD

    RETURN

****
INT:
****

    Y.CATEG.CNT = ''
    Y.CATEG.ARR = ''
    Y.PL.CATEG.ID = ''

    RETURN

********
PROCESS:
********
    
    SEL.CMD = 'SELECT ': FN.CATEG.ENT.TODAY
    
    Y.CATEG.CNT = DCOUNT(Y.CATEG.ID,@FM)

    FOR I = 1 TO Y.CATEG.CNT

        Y.PL.CATEG.ID = Y.CATEG.ID<I>
        
        LOCATE Y.PL.CATEG.ID IN Y.CATEG.ARR SETTING POS1 ELSE
            IF Y.CATEG.ARR THEN
	        Y.CATEG.ARR<-1> = Y.PL.CATEG.ID        
            END ELSE
	        Y.CATEG.ARR = Y.PL.CATEG.ID
            END

            BEGIN CASE

            CASE I = 1 

                SEL.CMD := ' WITH @ID LIKE ':Y.PL.CATEG.ID:'...'
        
            CASE 1

                SEL.CMD := ' OR WITH @ID LIKE ':Y.PL.CATEG.ID:'...'

            END CASE
        END
        
    NEXT I

    RETURN

***********
SELECT.CMD:
***********

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)

    IF (SEL.LIST) THEN
         CALL BATCH.BUILD.LIST("", SEL.LIST)
    END

    RETURN

END
