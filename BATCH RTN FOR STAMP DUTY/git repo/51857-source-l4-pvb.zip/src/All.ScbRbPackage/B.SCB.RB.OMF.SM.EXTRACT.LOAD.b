$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.OMF.SM.EXTRACT.LOAD
*--------------------------------------------------------------------------------------------
* Project Name  : CPSGMIG-309 - JEWEL_T24_PROJECT
* Developed By  : 1625136
* Developed On  : 03 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract SM details
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.OMF.SM.EXTRACT.COMMON 
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM

    GOSUB INITIALISE
    GOSUB OPENFILES
    GOSUB GET.SAT.TYPE
    
RETURN
*--------------------------------------------------------------------------------------------
INITIALISE:
***********
	L.WORK.DATE=OCONV(DATE(),'D-') ;*MM-DD-YYYY
    Y.DATE = L.WORK.DATE[7,4]:L.WORK.DATE[1,2]:L.WORK.DATE[4,2]
    
	Y.FILE.ID = 'RB_OMF_SG_PCAT_File_':Y.DATE:SESSION.NO
    Y.APP.NAME = "SECURITY.MASTER":@FM:"CUSTOMER"
    Y.FLD.NAME = "CASH.OR.REINV":@VM:"TDS.GLOBAL.ID":@VM:"MF.ISSUER.NAME":@VM:"LR.RETAIL.DEPO":@VM:"LM.RET.DEPO.INV"
	Y.FLD.NAME<-1> := "LR.PP.CODE"
    
    Y.FLD.POS = ""
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
    CASH.OR.REINV.POS = Y.FLD.POS<1,1>
	TDS.GLOBAL.ID.POS = Y.FLD.POS<1,2>
	MF.ISSUER.NAME.POS = Y.FLD.POS<1,3>
    LR.RETAIL.DEPO.POS  = Y.FLD.POS<1,4>
    LM.RET.DEPO.INV.POS = Y.FLD.POS<1,5>
	LR.PP.CODE.POS = Y.FLD.POS<2,1>

	Y.RESTRICTED.ARR = 'SUBSCRIPTION.RESTRICTED':@FM:'REDEMPTION.RESTRICTED':@FM:'TRANSFER-IN.RESTRICTED':@FM:'TRANSFER-OUT.RESTRICTED'
	Y.RESTRICTED.ARR<-1> = 'SWITCH-IN.RESTRICTED':@FM:'SWITCH-OUT.RESTRICTED':@FM:'CANCELLATION.RESTRICTED':@FM:'CASH.RESTRICTED':@FM:'OA.RESTRICTED'	
	Y.RESTRICTED.ARR<-1> = 'SA.RESTRICTED':@FM:'SRS.RESTRICTED':@FM:'15.RESTRICTED'
        
	RETURN
*--------------------------------------------------------------------------------------------
OPENFILES:
**********
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.SCB.WM.H.LOCAL.PARAM  = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)

    FN.SUB.ASSET.TYPE       = 'F.SUB.ASSET.TYPE'
    F.SUB.ASSET.TYPE        = ''
    CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)

    FN.SECURITY.MASTER      = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER       = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
     
    FN.SECURITY.CONST        = 'F.SC.SECURITY.CONSTRAINT'
    F.SECURITY.CONST           = ''
    CALL OPF(FN.SECURITY.CONST,F.SECURITY.CONST)
	
	FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ""
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)

RETURN
*--------------------------------------------------------------------------------------------
GET.SAT.TYPE:
*************
    Y.SAT.PARAM = 'SCB.CRES.SAT' ; R.SCB.WM.H.LOCAL.PARAM = '' ; Y.SCB.WM.H.LOCAL.PARAM.ERR = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.SAT.PARAM,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.SCB.WM.H.LOCAL.PARAM.ERR)
	
    IF R.SCB.WM.H.LOCAL.PARAM THEN
        Y.FIELD.NAME = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
        LOCATE "MF" IN Y.FIELD.NAME<1,1> SETTING MF.POS THEN
        	Y.ALL.SAT.CODE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE,MF.POS>
        	CHANGE @SM TO @VM IN Y.ALL.SAT.CODE
            CHANGE @VM TO ' ' IN Y.ALL.SAT.CODE
        END
    END
	
	

RETURN
END
