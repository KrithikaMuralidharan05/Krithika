$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.TRADE.DOMICILE.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14086 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       13 April 2023
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract the trade domicile details
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.B.TRADE.DOMICILE
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
	$INSERT I_B.SCB.TRADE.DOMICILE.COMMON


    IF Y.MODE.DET EQ 'M' THEN
        SEL.CMD1 = "SELECT ":FN.SEC.TRADES.MDAY :" WITH @ID LIKE SG...SCTRSC... OR @ID LIKE SG...SECTSC..."   ;* Select Sec Trades for the Previous day trades of the Current Month
        CALL EB.READLIST(SEL.CMD1,SEL.LIST1,'',SEL.CNT1,SEL.ERR1)
	
        IF SEL.LIST1 THEN
            SEL.LIST = SEL.LIST1
        END
    END
	
    IF Y.MODE.DET EQ 'D' THEN
        SEL.CMD2 = "SELECT ":FN.SCB.SEC.TRADES.LDAY :" WITH @ID LIKE SG...SCTRSC... OR @ID LIKE SG...SECTSC..."  ;* Select Sec Trades for Current day
        CALL EB.READLIST(SEL.CMD2,SEL.LIST2,'',SEL.CNT2,SEL.ERR2)
       
        IF SEL.LIST2 THEN
            SEL.LIST = SEL.LIST2
        END
    END

	CALL BATCH.BUILD.LIST('',SEL.LIST)
RETURN

END
