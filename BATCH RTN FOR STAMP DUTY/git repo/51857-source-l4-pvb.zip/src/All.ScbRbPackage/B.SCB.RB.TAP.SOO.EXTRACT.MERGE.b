$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>358</Rating>
*-----------------------------------------------------------------------------
	SUBROUTINE B.SCB.RB.TAP.SOO.EXTRACT.MERGE
* -------------------------------------------------------------------------------------
* Multithread routine for the file generation of T24_SG_RB_TAP_SOO_<yymmddhhmmss> to TAP
*
**---------------------------------------------------------------------------------------------------------------------------------------------------
*
* Modification History : 
*
* 14/07/2022 - Lavanya L - CPSGMIG-4869
*-------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES

    GOSUB INIT.PARA
    GOSUB FORM.HEADER
    GOSUB PROCESS.PARA
	 GOSUB FILE.TRANSFER
RETURN

* ----------------------------------------------------------------------------------------

INIT.PARA:
*---------

    Y.TDAY = TODAY
	Y.TIMEDATE.STP = TIMEDATE()
    Y.TIMESTAMP = TODAY:Y.TIMEDATE.STP[1,8]
    CHANGE ":" TO "" IN  Y.TIMESTAMP
	
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)

    IF ID.COMPANY[1,2] EQ 'SG' OR ID.COMPANY[1,2] EQ 'HK' THEN
        Y.T24.INSTANCE = 'APAC'
        Y.REGION = 'APA'
    END 
*TAFJUPG - E

    Y.FILE.NAME = 'RB.TAP.SOO'
*
* Form the final file name in the below format
    Y.FINAL.FILE.NAME = 'T24-':ID.COMPANY[1,2]:'-RB-TAP-SOO-':Y.TIMESTAMP:'.TXT'			

    Y.FILE.ARRAY = '' ; TOTAL.LINE.COUNT = 0

RETURN

* ----------------------------------------------------------------------------------------
FORM.HEADER:
*-----------
*
* Form all the SECURITY.MASTER header data as per the functional spec

    Y.HEADER = ''
    DL = '|'
    Y.HEADER = 'T24_ORDER_ID':DL:'CHANNEL_ORDERNO':DL:'PROD_ACNO':DL:'ASSET_CODE':DL:'DIVINSTR':DL:'ORDER_CCY'
    Y.HEADER := DL:'ORDER_AMOUNT':DL:'ORDER_TYPE':DL:'SETT_ACNO':DL:'SETT_AC_CCY':DL:'TRANSACTION_DATE'
    Y.HEADER := DL:'CHARGE_PERCENTAGE':DL:'DISCOUNT_PERCENTAGE':DL:'NETCHARGE_PERCENTAGE':DL:'CUTOFF_TIME':DL:'CLIENT_SETT_AMOUNT':DL:'PRICING_CODE'
    Y.HEADER := DL:'SYS_NET_CHGAMT_IN_FUNDCCY':DL:'SYS_NET_CHGAMT_IN_BASECCY':DL:'SUB_RED_INDICATOR':DL:'TRANSACTION_CODE':DL:'LIMIT_TYPE':
    Y.HEADER := DL:'CUST_NUMBER':DL:'NARRATIVE':DL:'LIMIT_EXPIRY_DATE':DL:'ORDER.STATUS':DL:'DEAL_STATUS':DL:'TDS_GLOBAL_ID':DL:'PAYMENT_MODE'
 *CPSGMIG-14682 - S  
	Y.HEADER := DL:'OMF_REF_NO':DL:'REDEEM_UNIT':DL:'PRICE':DL:'MAX_SALES_PERC':DL:'CU_CHARGE_TAX_TYPE':DL:'TRANS_CODE':DL:'FH_DATE':DL:'SWITCH_ORDER'
	Y.HEADER := DL:'SWITCH_QTY':DL:'COMM_ORDER_MASTER':DL:'COMM_ORDER_REF':DL:'SWITCHIN_ASSET_CODE':DL:'PERCENTAGE':DL:'CPFSRS_AGNT_BNK':DL:'SUB_ACC'
	Y.HEADER := DL:'NOMINEE_CODE':DL:'CANCEL_TRADE_REF':DL:'LEVERAGE_IND':DL:'SAT_CODE'
    *CPSGMIG-14682 - E
RETURN
* ----------------------------------------------------------------------------------------
PROCESS.PARA:
*------------
* Select all the files with file name like ...ID.COMPANY[1,2].RB.TAP.SOO...
* and consolidate into a single file.
* Footer of the file contains total record count, time stamp, and next working date

    Y.UDFILE    = 'AMEX.FILES'
    Y.CRITERIA  = Y.FILE.NAME:'*'
    SEL.FILE.ID = ''
    Y.SELECTED  = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, SEL.FILE.ID, Y.SELECTED)
*
	CALL OCOMO("SELECTED FILES":Y.SELECTED)
    IF SEL.FILE.ID THEN
        Y.FILE.ARRAY = Y.HEADER
        Y.DEL.FILE.ID = SEL.FILE.ID
        LOOP
            REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
        WHILE Y.FILE.ID:POS
            CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.AMEX.FILES,F.APPEND.FILES,APP.ERR)
			CALL OCOMO("AFTER READ OF FILE":Y.FILE.ID:"-STATUS":APP.ERR)
            ! Checking whether the file contains any record
            IF R.AMEX.FILES NE '' THEN
                Y.FILE.ARRAY := @FM:R.AMEX.FILES
* Count the number of records in the file to get the total count of CUSTOMER
                LINE.COUNT = 0
                LINE.COUNT = DCOUNT(R.AMEX.FILES,@FM)
                TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
            END
* Delete the file after forming the array
            CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
            CALL OCOMO("AFTER DELETE OF FILE":Y.FILE.ID)
            LINE.COUNT = ''
        REPEAT
    END

*QC2023-S
	CALL OCOMO("BEFORE WRITE OF FILE":Y.FINAL.FILE.NAME)
    WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME
    GOSUB REMOVE.DUP.LINE
    CALL OCOMO("AFTER REMOVE.DUP.LINE GOSUB")
    CALL OCOMO("BEFORE READ OF FILE":Y.FINAL.FILE.NAME)
    CALL F.READ(FN.APPEND.FILES,Y.FINAL.FILE.NAME,Y.FILE.ARRAY,F.APPEND.FILES,READ.ERR1)
    CALL OCOMO("AFTER READ OF FILE":Y.FINAL.FILE.NAME:"-STATUS":READ.ERR1)
    TOTAL.LINE.COUNT = DCOUNT(Y.FILE.ARRAY,@FM)-1
*QC2023-E

    !APPENDING INTO ONE MASTER FILE
*
* Change the time stamp to the external format
*
*    Y.STAMP = OCONV(TIME(),"MTS")
*
* Footer should be in the following format
* 'T', Total Record Count
    Y.FILE.ARRAY :=@FM:'T':'|':TOTAL.LINE.COUNT				;*CPSGMIG-3789 - S/E
* Finally write the single file to the AMEX.FILES path
*
    WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME
*
RETURN
*
*QC2023-S
REMOVE.DUP.LINE:
*===============

    ARG1 = 'AMEX.FILES'
    ARG2 = ''
    AMEX.FILES.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME(ARG1,ARG2,AMEX.FILES.PATH)
*TAFJUPG - E
    FILE.PATH.ORG = AMEX.FILES.PATH
    CALL SCB.REMOVE.DUPLICATE.LINE(FILE.PATH.ORG,Y.FINAL.FILE.NAME)
RETURN
*-------------------------------------
FILE.TRANSFER:
*-------------
*
	AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''
*    
    FLOW.IDENTIFER.ID = 'T24-RBTAP-SG'
*    
    FILE.NAME = AMEX.FILES
    RECORD.NAME = Y.FINAL.FILE.NAME
    TARGET.FILE.NAME = EREPLACE(Y.FINAL.FILE.NAME,'-','_')
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'')

RETURN
END
