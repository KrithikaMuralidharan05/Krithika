* @ValidationCode : MjotMjg3Njc0OTAzOklTTy04ODU5LTE6MTY4NDA2ODUxNTE2MToxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 14 May 2023 18:18:35
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FUND.HOLDING.EXT(Y.CUST.ID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17751 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       10 Jan 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* PROCESS Routine to extract iBanking Fund Holding details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.HOLDING.EXT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 7-Feb-23		1663000          CPSGMIG-19025 - To pass blank Asset type when SN Instruments doesn't have Capital Protection Updated
* 21-Feb-23		1663000          CPSGMIG-19670 - Position Mismatch
* 01-Mar-23     1663000          CPSGMIG-19959 - T24 to share all client details irrespective of Primary/secondary
* 03-Mar-2023 - CPSGMIG-19966 - Lavanya L - Changes to ignore the conditions for FI/SN/MF.
* 20-Mar-23     1667095          CPSGMIG-21066 - Changes to remove pledged position entry in extract
* 10-Apr-2023   1663000          CPSGMIG-23263 - To remove duplicates in Holding file
* 11-Apr-2023 - CPSGMIG-23277 - kalaikumaranp - To include VALUE.DATE GT TODAY for Order Transactions.

* 17-Apr-2023   1663000          CPSGMIG-24759 - Exclude CPF/SRS Position
* 17-Apr-2023   1663000          CPSGMIG-24767 - NonSGD to SGD currency conversion
* 19-Apr-2023   1663000          CPSGMIG-24880 - Suppress Negative Holdings
* 21-Apr-2023   1663000          CPSGMIG-24832 - NonSGD to SGD currency conversion using EXCHRATE
* 12-Jun-2023   1648769          CPSGMIG-25216 - To add one more column nominee code based on pledge and unpledged lines
* 30-Jun-2023   1648769          CPSGMIG-29571 - i)To include zero holding.
*                                                ii) To inculde no holdings to zero holdings, when ISA account is active for the asset type.
* 30-Jun-2023   1667095          CPSGMIG-29571 - To include zero holding for all ISA account irrespective of holdings.
* 02-Feb-2024   1645888          ADO-2561964   - Ibanking response file to be enhanced to consolidate the Security Holding Position at the Rel Ids & Instrument level.
* 09-Jul-2024   1548187	- Loga	 AOD-4939515   - Fix for unsettled amount in Ibanking.
* 10607079 - 1526956 - SN-Swift - Exclusion of Aggregated Security Transfer transaction as part of the downstream reporting_PVB & RBSG
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_DAS.COMMON
	$INSERT I_DAS.SECURITY.POSITION
    $INSERT I_F.CUSTOMER
    $INSERT I_F.CURRENCY
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SCB.RB.PENDING.TRANSACTION
    $INSERT I_B.SCB.FUND.HOLDING.EXT.COMMON
    $INSERT I_F.DATES
    $INSERT I_F.AEB.SEC.PAR                ;*CPSGMIG-24759
	$INSERT I_F.SCB.AT.SETT.DETAILS
    $INSERT I_F.SECURITY.TRANSFER
*--------------------------------------------------------------------------------------------
       
    GOSUB DO.PROCESS
    
    
RETURN
*---------*
DO.PROCESS:
*---------*
    Y.ALL.FUND.ARR = ''
    Y.LWD    = R.DATES(EB.DAT.LAST.WORKING.DAY)
   
    R.CUSTOMER = '' ; ERR.CUSTOMER = ''
    CALL F.READ(FN.CUSTOMER,Y.CUST.ID,R.CUSTOMER,F.CUSTOMER,ERR.CUSTOMER)
    Y.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
***10607079 -S
	IF Y.CUST.ID MATCHES RB.SG.CUST THEN
		RETURN
	END
***10607079 -E         
    IF (Y.LOB MATCHES Y.ALLOWED.LOB) THEN ;*CPSGMIG-19959
                
        R.SEC.ACC.CUST = '' ; ERR.SEC.ACC.CUST = ''
        CALL F.READ(FN.SEC.ACC.CUST,Y.CUST.ID,R.SEC.ACC.CUST,F.SEC.ACC.CUST,ERR.SEC.ACC.CUST)
                
        LOOP
            REMOVE Y.SAM.ID FROM R.SEC.ACC.CUST SETTING Y.SAM.POS
        WHILE Y.SAM.ID:Y.SAM.POS
            R.SAM = '' ; ERR.SAM = ''
            CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,ERR.SAM)
            IF R.SAM THEN
                GOSUB GET.MAPPING.DATA
            END
        REPEAT
        GOSUB WRITE.TO.FILE                   ;*CPSGMIG-23263 -S/E
    END
    
RETURN
*---------------*
GET.MAPPING.DATA:
*---------------*
* Get SecurityPosition by Portfolio and Security
    R.POS.CON.SCAC = dasSecurityPositionSecurityAccount
    THE.ARGS       = Y.SAM.ID
    TABLE.SUFFIX   = ''
    CALL DAS('SECURITY.POSITION', R.POS.CON.SCAC, THE.ARGS, TABLE.SUFFIX)
    REC.COUNT = 0 ; REC.COUNT = DCOUNT(R.POS.CON.SCAC,FM)

    Y.ZERO.SM.ARR = '' ; Y.NZ.UT.FLAG = '' ; Y.NZ.BOND.FLAG = '' ; Y.NZ.SN.FLAG = '' ; Y.NZ.SNPR.FLAG = ''
    Y.Z.UT.FLAG = '' ; Y.Z.BOND.FLAG = '' ; Y.Z.SN.FLAG = '' ; Y.Z.SNPR.FLAG = ''
          
    IF R.POS.CON.SCAC THEN                                        ;*Avaiable Holdings.
        LOOP
            REMOVE Y.SECPOS.ID FROM R.POS.CON.SCAC SETTING Y.POS
        WHILE Y.SECPOS.ID : Y.POS
        
            ERR.SECURITY.POS = '' ; R.SEC.POS = '' ; Y.NOM.FLAG.PLG = '' ; Y.NOM.FLAG = ''                     ;*CPSGMIG-21066 -s
* ADO-2561964 - S
*CALL F.READ(FN.SECURITY.POSITION,Y.SECPOS.ID,R.SEC.POS,F.SECURITY.POSITION,ERR.SECURITY.POS) ;*CPSGMIG-21066 -e
            Y.SAM.SM.VAL = FIELD(Y.SECPOS.ID,".",1,2)
            LOCATE Y.SAM.SM.VAL IN Y.SAM.SM.PROC.LIST<1> SETTING Y.SAM.POS THEN
                CONTINUE
            END
            Y.SAM.SM.PROC.LIST<-1> = Y.SAM.SM.VAL
            Y.SECPOS.PORT.NO = FIELD(Y.SECPOS.ID,'.',1,1)
            Y.SECPOS.SEC.CODE = FIELD(Y.SECPOS.ID,'.',2,1)
            Y.SECPOS.VALDT.POS.PLG = '0' ; Y.SECPOS.VALDT.POS = '0'
*
            SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
            SEL.CMD = "SELECT ":FN.SECURITY.POSITION:" WITH SECURITY.ACCOUNT EQ ":Y.SECPOS.PORT.NO:" AND WITH SECURITY.NUMBER EQ ":Y.SECPOS.SEC.CODE
*
            CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
*
            LOOP
                REMOVE Y.SEC.POSITION.ID FROM SEL.LIST SETTING SEC.POSITION.POS
            WHILE Y.SEC.POSITION.ID:SEC.POSITION.POS
                R.SECURITY.POSITION.TEMP = '' ; SECURITY.POSITION.ERR = ''
                CALL F.READ(FN.SECURITY.POSITION,Y.SEC.POSITION.ID,R.SECURITY.POSITION.TEMP,F.SECURITY.POSITION,SECURITY.POSITION.ERR)
                Y.SECPOS.DEPO = R.SECURITY.POSITION.TEMP<SC.SCP.DEPOSITORY>   
                LOCATE Y.SECPOS.DEPO IN Y.DEPOSITORY<1,1> SETTING DEPO.POS THEN
                    CONTINUE
                END
*                IF (R.SEC.POS<SC.SCP.VALUE.DATED.POSN> GT "0") THEN     ;*Non-Zero Holdings.
*GOSUB READ.SM
*GOSUB SECURITY.DETS
*GOSUB CHECK.CPF.SRS ;* CPSGMIG-24759 -s/e
*IF NOT(Y.CPF.SRS.FLAG) THEN ;*CPSGMIG-24759 -s/e
                IF R.SECURITY.POSITION.TEMP<SC.SCP.VALUE.DATED.POSN> GT "0" THEN
                Y.PLG.NO = FIELD(Y.SEC.POSITION.ID,'.',4,1)
                IF Y.PLG.NO EQ '1' THEN
                    Y.SECPOS.VALDT.POS.PLG = Y.SECPOS.VALDT.POS.PLG + R.SECURITY.POSITION.TEMP<SC.SCP.VALUE.DATED.POSN>
                END ELSE
                    Y.SECPOS.VALDT.POS = Y.SECPOS.VALDT.POS + R.SECURITY.POSITION.TEMP<SC.SCP.VALUE.DATED.POSN>
                END
            END
            REPEAT
*******IBANKING******
GOSUB FORM.SEC.TRANS
********IBANKING******

			
            IF Y.SECPOS.VALDT.POS.PLG GT "0" OR Y.SECPOS.VALDT.POS GT "0" THEN
                IF Y.SECPOS.VALDT.POS.PLG GT "0" THEN
                    Y.NOM.FLAG.PLG = 'Y'
                END
                IF Y.SECPOS.VALDT.POS GT "0" THEN
                    Y.NOM.FLAG = 'N'
                END                   
* ADO-2561964 - E
                R.SCB.RB.PENDING.TRANSACTION = ''; PEND.TXN.ERR = ''
                CALL F.READ(FN.SCB.RB.PENDING.TRANSACTION,Y.SAM.ID,R.SCB.RB.PENDING.TRANSACTION,F.SCB.RB.PENDING.TRANSACTION,PEND.TXN.ERR)
                Y.TRD.VAL.DT = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.VALUE.DATE>
                Y.TRD.STAT   = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TRADE.STATUS>
                Y.BUY.SELL   = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.BUY.SELL>
*
                MUL.VAL.COUNT = DCOUNT(R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TRADE.ID>,@VM)
*
                IF NOT(MUL.VAL.COUNT) AND R.SCB.RB.PENDING.TRANSACTION THEN
                    MUL.VAL.COUNT = DCOUNT(R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.ORDER.ID>,@VM)
                    IF NOT(MUL.VAL.COUNT) THEN
                        MUL.VAL.COUNT = 1
                    END
                END
*
                Y.PEND.SUB.AMT = '' ; Y.PEND.RED.AMT = ''
                Y.PEND.SUB.AMT.PLG = '' ; Y.PEND.RED.AMT.PLG = '' ;* ADO-2561964 - S/E
*
                Y.MUL.IDX = 1
                LOOP
                WHILE Y.MUL.IDX LE MUL.VAL.COUNT
                    OR.SEC.CODE     = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.SECURITY.CODE,Y.MUL.IDX>
                    OR.BUY.SELL.IND = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.BUY.SELL,Y.MUL.IDX>
                    TR.SEC.CODE     = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.SECURITY.CODE,Y.MUL.IDX>
                    TR.BUY.SELL.IND = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.BUY.SELL,Y.MUL.IDX>
                    VAL.DATE = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.VALUE.DATE,Y.MUL.IDX> ;* CPSGMIG-23277
* ADO-2561964 - S
                    PAYMENT.TYPE = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.PAYMENT.TYPE,Y.MUL.IDX>
* ADO-2561964 - E
                    IF (OR.SEC.CODE EQ Y.SECPOS.SEC.CODE) AND (R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TRADE.ID,Y.MUL.IDX> EQ '') AND VAL.DATE GT Y.LWD AND NOT(INDEX(PAYMENT.TYPE,"CPF",1)) AND NOT(INDEX(PAYMENT.TYPE,"SRS",1)) THEN
* ADO-2561964 - S
                        Y.NOM.CODE.OR = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.NOMINEE,Y.MUL.IDX> ;* * ADO-2561964 - S/E
* ADO-2561964 - E
                        BEGIN CASE
                            CASE OR.BUY.SELL.IND EQ 'BUY'
* ADO-2561964 - S
                                IF Y.NOM.CODE.OR EQ '1' THEN
                                    Y.PEND.SUB.AMT.PLG = Y.PEND.SUB.AMT.PLG + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.NET.AMT.TRADE.CCY,Y.MUL.IDX>
                                END ELSE
* ADO-2561964 - E
                                    Y.PEND.SUB.AMT = Y.PEND.SUB.AMT + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.NET.AMT.TRADE.CCY,Y.MUL.IDX>
                                END ;* ADO-2561964 - S/E
                            CASE OR.BUY.SELL.IND EQ 'SELL'
* ADO-2561964 - S
                                IF Y.NOM.CODE.OR EQ '1' THEN
                                    Y.PEND.RED.AMT.PLG = Y.PEND.RED.AMT.PLG + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.ORDER.NOMINALS,Y.MUL.IDX>
				    Y.PEND.RED.AMT.PLG = Y.PEND.RED.AMT.PLG + Y.PEND.SEC.RED.AMOUNT.PLG
                                END ELSE
* ADO-2561964 - E
                                    Y.PEND.RED.AMT = Y.PEND.RED.AMT + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.OR.ORDER.NOMINALS,Y.MUL.IDX>
				    Y.PEND.RED.AMT = Y.PEND.RED.AMT + Y.PEND.SEC.RED.AMOUNT
                                END ;* ADO-2561964 - S/E
                        END CASE
                    END
*
                    IF (TR.SEC.CODE EQ Y.SECPOS.SEC.CODE) THEN
* ADO-2561964 - S
                        Y.NOM.CODE.TR = R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.NOMINEE,Y.MUL.IDX> ;* * ADO-2561964 - S/E
* ADO-2561964 - E
*ADO-4939515-Start change conidtion from OR to AND
                        IF (R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TRADE.STATUS,Y.MUL.IDX> NE 'AUTH' AND R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TRADE.STATUS,Y.MUL.IDX> NE 'REVE') AND VAL.DATE GT Y.LWD AND NOT(INDEX(PAYMENT.TYPE,"CPF",1)) AND NOT(INDEX(PAYMENT.TYPE,"SRS",1)) THEN
*ADO-4939515-End
*
                            BEGIN CASE
                                CASE TR.BUY.SELL.IND EQ 'BUY'
* ADO-2561964 - S
                                    IF Y.NOM.CODE.TR EQ '1' THEN
                                        Y.PEND.SUB.AMT.PLG = Y.PEND.SUB.AMT.PLG + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.NET.AMT.TRADE.CCY,Y.MUL.IDX>
                                    END ELSE
* ADO-2561964 - E
                                        Y.PEND.SUB.AMT = Y.PEND.SUB.AMT + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.NET.AMT.TRADE.CCY,Y.MUL.IDX>
                                    END ;* * ADO-2561964 - S/E
                                CASE TR.BUY.SELL.IND EQ 'SELL'		;*ADO-4939515 S/E - Varaible change correctly for TR.BUY.SELL.IND
* ADO-2561964 - S
                                    IF Y.NOM.CODE.TR EQ '1' THEN
                                        Y.PEND.RED.AMT.PLG = Y.PEND.RED.AMT.PLG + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.ORDER.NOMINALS,Y.MUL.IDX>
					Y.PEND.RED.AMT.PLG = Y.PEND.RED.AMT.PLG + Y.PEND.SEC.RED.AMOUNT.PLG
                                    END ELSE
* ADO-2561964 - E
                                        Y.PEND.RED.AMT = Y.PEND.RED.AMT + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.ORDER.NOMINALS,Y.MUL.IDX>
					Y.PEND.RED.AMT = Y.PEND.RED.AMT + Y.PEND.SEC.RED.AMOUNT
                                    END ;* * ADO-2561964 - S/E
                            END CASE
                        END
    
                        IF (R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TRADE.STATUS,Y.MUL.IDX> EQ 'AUTH' AND R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.VALUE.DATE,Y.MUL.IDX> GT Y.LWD) AND NOT(INDEX(PAYMENT.TYPE,"CPF",1)) AND NOT(INDEX(PAYMENT.TYPE,"SRS",1)) THEN
                      
*                       LOCATE Y.SUB.ASSET.TYPE IN Y.FI.SAT.ARRAY<1,1> SETTING FI.POS THEN		;*CPSGMIG-19966
                            
                            BEGIN CASE
                                CASE TR.BUY.SELL.IND EQ 'BUY'
* ADO-2561964 - S
                                    IF Y.NOM.CODE.TR EQ '1' THEN
                                        Y.PEND.SUB.AMT.PLG = Y.PEND.SUB.AMT.PLG + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.NET.AMT.TRADE.CCY,Y.MUL.IDX>
                                    END ELSE
* ADO-2561964 - E
                                        Y.PEND.SUB.AMT = Y.PEND.SUB.AMT + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.NET.AMT.TRADE.CCY,Y.MUL.IDX>
                                    END ;* * ADO-2561964 - S/E
                                CASE TR.BUY.SELL.IND EQ 'SELL'
* ADO-2561964 - S
                                    IF Y.NOM.CODE.TR EQ '1' THEN
                                        Y.PEND.RED.AMT.PLG = Y.PEND.RED.AMT.PLG + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.ORDER.NOMINALS,Y.MUL.IDX>
					Y.PEND.RED.AMT.PLG = Y.PEND.RED.AMT.PLG + Y.PEND.SEC.RED.AMOUNT.PLG
                                    END ELSE
* ADO-2561964 - E
                                        Y.PEND.RED.AMT = Y.PEND.RED.AMT + R.SCB.RB.PENDING.TRANSACTION<SCB.PEND.TRANS.TR.ORDER.NOMINALS,Y.MUL.IDX>
					Y.PEND.RED.AMT = Y.PEND.RED.AMT + Y.PEND.SEC.RED.AMOUNT
                                    END ;* * ADO-2561964 - S/E
                            END CASE
                        END
                    END
                    Y.MUL.IDX += 1
                REPEAT
* ADO-2561964 - S
                GOSUB READ.SM
                GOSUB SECURITY.DETS
* ADO-2561964 - E
                Y.SKIP.VAL = 0                                       ;*CPSGMIG-24880 -S
                IF Y.PEND.SUB.AMT AND INDEX(Y.PEND.SUB.AMT,'-',1) THEN
                    Y.SKIP.VAL = '1'
                END
* ADO-2561964 - S
                IF Y.PEND.SUB.AMT.PLG AND INDEX(Y.PEND.SUB.AMT.PLG,'-',1) THEN
                    Y.SKIP.VAL.PLG = '1'
                END
                IF Y.PEND.RED.AMT.PLG AND INDEX(Y.PEND.RED.AMT.PLG,'-',1) THEN
                    Y.SKIP.VAL.PLG = '1'
                END
* ADO-2561964 - E
                IF Y.PEND.RED.AMT AND INDEX(Y.PEND.RED.AMT,'-',1) THEN
                    Y.SKIP.VAL = '1'
                END                                                  ;*CPSGMIG-24880 -E
            
                Y.PEND.SUB.AMT.OLD = '' ; Y.PEND.SUB.AMT.OLD = Y.PEND.SUB.AMT
                Y.PEND.SUB.AMT = FMT(Y.PEND.SUB.AMT,"R4%17")
                Y.PEND.SUB.AMT = EREPLACE(Y.PEND.SUB.AMT,'.','')
                Y.PEND.RED.AMT = FMT(Y.PEND.RED.AMT,"R4%17")
                Y.PEND.RED.AMT = EREPLACE(Y.PEND.RED.AMT,'.','')
* ADO-2561964 - S
                Y.PEND.SUB.AMT.OLD.PLG = '' ; Y.PEND.SUB.AMT.OLD.PLG = Y.PEND.SUB.AMT.PLG
                Y.PEND.SUB.AMT.PLG = FMT(Y.PEND.SUB.AMT.PLG,"R4%17")
                Y.PEND.SUB.AMT.PLG = EREPLACE(Y.PEND.SUB.AMT.PLG,'.','')
                Y.PEND.RED.AMT.PLG = FMT(Y.PEND.RED.AMT.PLG,"R4%17")
                Y.PEND.RED.AMT.PLG = EREPLACE(Y.PEND.RED.AMT.PLG,'.','')
* ADO-2561964 - E
                Y.ACCRUED.INT = "0"     ;* Accrued Interest
                Y.ACCRUED.INT.OLD = Y.ACCRUED.INT
                Y.ACCRUED.INT = FMT(Y.ACCRUED.INT,"R4%19")
                Y.ACCRUED.INT = EREPLACE(Y.ACCRUED.INT,'.','')
        
* Get Amount Held
                Y.AMT.HELD  = '' ; Y.MKT.VALUE = ''
                Y.MKT.VALUE    = Y.SECPOS.VALDT.POS.OLD * Y.PRICE
                Y.AMT.HELD     = Y.MKT.VALUE + Y.ACCRUED.INT.OLD + Y.PEND.SUB.AMT.OLD
                Y.AMT.HELD.OLD = Y.AMT.HELD
                Y.AMT.HELD     = FMT(Y.AMT.HELD,"R4%21")
                Y.AMT.HELD     = EREPLACE(Y.AMT.HELD,'.','')
* ADO-2561964 - S
                Y.AMT.HELD.PLG  = '' ; Y.MKT.VALUE.PLG = ''
                Y.MKT.VALUE.PLG    = Y.SECPOS.VALDT.POS.OLD.PLG * Y.PRICE
                Y.AMT.HELD.PLG     = Y.MKT.VALUE.PLG + Y.ACCRUED.INT.OLD + Y.PEND.SUB.AMT.OLD.PLG
                Y.AMT.HELD.OLD.PLG = Y.AMT.HELD.PLG
                Y.AMT.HELD.PLG     = FMT(Y.AMT.HELD.PLG,"R4%21")
                Y.AMT.HELD.PLG   = EREPLACE(Y.AMT.HELD.PLG,'.','')
* ADO-2561964 - E
                IF Y.AMT.HELD.OLD AND INDEX(Y.AMT.HELD.OLD,'-',1) THEN ;*CPSGMIG-24880 -S
                    Y.SKIP.VAL = '1'
                END                                                    ;*CPSGMIG-24880 -E
* ADO-2561964 - S
                IF Y.AMT.HELD.OLD.PLG AND INDEX(Y.AMT.HELD.OLD.PLG,'-',1) THEN ;*CPSGMIG-24880 -S
                    Y.SKIP.VAL.PLG = '1'
                END
* ADO-2561964 - E
* Get Local Amount
                Y.LOCAL.AMT = ''  ;*CPSGMIG-24832 -s
                IF Y.SEC.CCY EQ "SGD" THEN
                    Y.LOCAL.AMT = Y.AMT.HELD.OLD
                END ELSE
                    Y.BASECCY  = ''
                    Y.EXCH.RATE = ''
                    Y.DIFF      = ''
                    Y.LCY.AMT   = ''
                    RETURN.CODE = ''
                    CALL EXCHRATE('1',Y.SEC.CCY,Y.AMT.HELD.OLD,"SGD",Y.LOCAL.AMT,Y.BASECCY,Y.EXCH.RATE,Y.DIFF,Y.LCY.AMT,RETURN.CODE)  ;*CPSGMIG-24832 -e
                END
* ADO-2561964 - S
                Y.LOCAL.AMT.PLG = ''  ;*CPSGMIG-24832 -s
                IF Y.SEC.CCY EQ "SGD" THEN
                    Y.LOCAL.AMT.PLG = Y.AMT.HELD.OLD.PLG
                END ELSE
                    Y.BASECCY  = ''
                    Y.EXCH.RATE = ''
                    Y.DIFF      = ''
                    Y.LCY.AMT   = ''
                    RETURN.CODE = ''
                    CALL EXCHRATE('1',Y.SEC.CCY,Y.AMT.HELD.OLD.PLG,"SGD",Y.LOCAL.AMT.PLG,Y.BASECCY,Y.EXCH.RATE,Y.DIFF,Y.LCY.AMT,RETURN.CODE)  ;*CPSGMIG-24832 -e
                END
* ADO-2561964 - E
                IF Y.LOCAL.AMT.PLG AND INDEX(Y.LOCAL.AMT.PLG,'-',1) THEN ;*CPSGMIG-24880 -S
                    Y.SKIP.VAL.PLG = '1'
                END
                IF Y.LOCAL.AMT AND INDEX(Y.LOCAL.AMT,'-',1) THEN ;*CPSGMIG-24880 -S
                    Y.SKIP.VAL = '1'
                END                                                    ;*CPSGMIG-24880 -E
            
                Y.LOCAL.AMT  = FMT(Y.LOCAL.AMT,"R4%21") ;*CPSGMIG-19670
                Y.LOCAL.AMT  = EREPLACE(Y.LOCAL.AMT,'.','')
* ADO-2561964 - S
                Y.LOCAL.AMT.PLG  = FMT(Y.LOCAL.AMT.PLG,"R4%21") ;*CPSGMIG-19670
                Y.LOCAL.AMT.PLG  = EREPLACE(Y.LOCAL.AMT.PLG,'.','')
* ADO-2561964 - E
                GOSUB GET.ASSET.TYPE               ; *Get Asset Type
                GOSUB NON.ZERO.HLDS.FLAG           ; **Set flag for non-zero holding flag                  
                GOSUB FRAME.DATA
*END ;*CPSGMIG-24759 -s/e
            END ELSE                                   ; *Zero holdings.
                Y.SECPOS.DEPO.ID = FIELD(Y.SECPOS.ID,'.',3,1) 
                LOCATE Y.SECPOS.DEPO.ID IN Y.DEPOSITORY<1,1> SETTING DEPO.POS1 THEN                    
                END ELSE                
                GOSUB READ.SM
*            IF NOT(Y.CPF.SRS.FLAG) THEN
                GOSUB GET.ASSET.TYPE               ; *Get Asset Type

                GOSUB ZERO.HLDS.FLAG               ; *Set flag for zero holding flag
            END
            END
        REPEAT
        IF Y.NZ.UT.FLAG EQ '' OR Y.NZ.BOND.FLAG EQ '' OR Y.NZ.SN.FLAG EQ '' OR Y.NZ.SNPR.FLAG EQ '' THEN
            GOSUB BLD.ZERO.HLDS.ARR                    ; * Final array bulid for zero holding based on the non-zero/zero flag.
        END
    END ELSE                                         ; *No holdings.
        GOSUB NO.HOLDINGS.REC
    END
RETURN
*------*
READ.SM:
*------*
*Y.SECPOS.SEC.CODE  = R.SEC.POS<SC.SCP.SECURITY.NUMBER> ;* ADO-2561964 - S/E
    CALL F.READ(FN.SECURITY.MASTER,Y.SECPOS.SEC.CODE,R.SECURITY.MASTER,F.SECURITY.MASTER,SECURITY.MASTER.ERR)
    Y.SUB.ASSET.TYPE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
    Y.CAP.PROTECTION = R.SECURITY.MASTER<SC.SCM.CAPITAL.PROTECTION>
*Y.SECPOS.DEPO      = R.SEC.POS<SC.SCP.DEPOSITORY> ;* ADO-2561964 - S/E
RETURN
*------------*
SECURITY.DETS:
*------------*

    Y.PRICE = ''
* ADO-2561964 - S
* Y.SECPOS.PORT.NO   = R.SEC.POS<SC.SCP.SECURITY.ACCOUNT>
* Y.SECPOS.VALDT.POS = R.SEC.POS<SC.SCP.VALUE.DATED.POSN>
* ADO-2561964 - E
    Y.SECPOS.VALDT.POS.OLD = Y.SECPOS.VALDT.POS
    Y.SECPOS.VALDT.POS = FMT(Y.SECPOS.VALDT.POS,"R4%17")
    Y.SECPOS.VALDT.POS = EREPLACE(Y.SECPOS.VALDT.POS,'.','')
* ADO-2561964 - S
    Y.SECPOS.VALDT.POS.OLD.PLG = Y.SECPOS.VALDT.POS.PLG
    Y.SECPOS.VALDT.POS.PLG = FMT(Y.SECPOS.VALDT.POS.PLG,"R4%17")
    Y.SECPOS.VALDT.POS.PLG = EREPLACE(Y.SECPOS.VALDT.POS.PLG,'.','')
* ADO-2561964 - E
    Y.LAST.PRICE     = R.SECURITY.MASTER<SC.SCM.LAST.PRICE>
    Y.SEC.CCY        = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
    Y.MUTUAL.FUND.IND= R.SECURITY.MASTER<SC.SCM.MUTUAL.FUND>
        
    IF R.SECURITY.MASTER<SC.SCM.BOND.OR.SHARE> EQ 'B' THEN
        Y.PRICE = Y.LAST.PRICE/100
    END ELSE
        Y.PRICE = Y.LAST.PRICE
    END
      
RETURN
*---------*
FRAME.DATA:
*---------*

    IF NOT(Y.SKIP.VAL.PLG) THEN          ;*CPSGMIG-24880 -S/E
        Y.FUND.DATA.ARR  = ''
* ADO-2561964 - S
        IF Y.NOM.FLAG.PLG EQ 'Y' THEN
            Y.FUND.DATA.ARR  = FMT("1","1' 'L") : FMT(Y.SECPOS.PORT.NO,"23' 'L") : FMT(Y.SECPOS.SEC.CODE,"10' 'L") : Y.SECPOS.VALDT.POS.PLG : Y.PEND.SUB.AMT.PLG : Y.PEND.RED.AMT.PLG : Y.ACCRUED.INT :Y.AMT.HELD.PLG : Y.LOCAL.AMT.PLG : FMT(Y.ASSET.TYPE,"25' 'L") : FMT(Y.NOM.FLAG.PLG,"1' 'L")
    Y.ALL.FUND.ARR<-1> = Y.FUND.DATA.ARR
    END
    END
    IF NOT(Y.SKIP.VAL) THEN 
       Y.FUND.DATA.ARR = ''
        IF Y.NOM.FLAG EQ 'N' THEN
* ADO-2561964 - E
            Y.FUND.DATA.ARR  = FMT("1","1' 'L") : FMT(Y.SECPOS.PORT.NO,"23' 'L") : FMT(Y.SECPOS.SEC.CODE,"10' 'L") : Y.SECPOS.VALDT.POS : Y.PEND.SUB.AMT : Y.PEND.RED.AMT : Y.ACCRUED.INT :Y.AMT.HELD : Y.LOCAL.AMT : FMT(Y.ASSET.TYPE,"25' 'L") : FMT(Y.NOM.FLAG,"1' 'L")
        Y.ALL.FUND.ARR<-1> = Y.FUND.DATA.ARR
        END ;* * ADO-2561964 - S/E
    END                              ;*CPSGMIG-24880 -S/E
RETURN
*------------*
WRITE.TO.FILE:
*------------*

    IF Y.ALL.FUND.ARR THEN
        OPENSEQ AMEX.FILES,Y.FUND.TEMP.FILE TO F.AMEX.FILES ELSE CREATE F.AMEX.FILES ELSE
            CALL OCOMO("Error opening Fund Holding Temp File":Y.FUND.TEMP.FILE)
        END
        WRITESEQ Y.ALL.FUND.ARR APPEND TO F.AMEX.FILES ELSE
            CALL OCOMO('Unable to write Fund Holding Temp File':F.AMEX.FILES)
        END
*
        CLOSESEQ F.AMEX.FILES
    END

RETURN
*-------------*
GET.ASSET.TYPE:
*-------------*
    Y.ASSET.TYPE = ''
    BEGIN CASE
        CASE (Y.SUB.ASSET.TYPE MATCHES Y.MF.SAT.ARRAY)
            Y.ASSET.TYPE = "UT"
        CASE Y.SUB.ASSET.TYPE MATCHES Y.SN.SAT.ARRAY
            Y.ASSET.TYPE = ""               ;* CPSGMIG-19025
            BEGIN CASE
                CASE Y.CAP.PROTECTION EQ "99"
                    Y.ASSET.TYPE = "Non-Protected SN"
                CASE Y.CAP.PROTECTION EQ "100"
                    Y.ASSET.TYPE = "Protected SN"
            END CASE
        CASE Y.SUB.ASSET.TYPE MATCHES Y.FI.SAT.ARRAY
            Y.ASSET.TYPE = "Bond"
    END CASE

RETURN
*---------------*
NO.HOLDINGS.REC:
*---------------*
    IF R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS> NE '' THEN
        Y.LR.TP.ACCT.NO = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS>
        Y.LR.TP.SYSTEM = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.SYSTEM.POS>
        Y.LR.TP.AC.STATUS = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.AC.STATUS.POS>
	            
        CONVERT @SM TO @FM IN Y.LR.TP.ACCT.NO
        CONVERT @SM TO @FM IN Y.LR.TP.SYSTEM
        CONVERT @SM TO @FM IN Y.LR.TP.AC.STATUS
        Y.UT.FLAG = '' ; Y.BOND.FLAG = '' ; Y.SN.FLAG = '' ; Y.SNPR.FLAG = ''
        LOOP
            REMOVE Y.TP.ACCT.NO FROM Y.LR.TP.ACCT.NO SETTING TP.AC.POS
            REMOVE Y.TP.SYSTEM FROM Y.LR.TP.SYSTEM SETTING TP.SYS.POS
            REMOVE Y.TP.AC.STAT FROM Y.LR.TP.AC.STATUS SETTING TP.STAT.POS
        WHILE Y.TP.ACCT.NO:TP.AC.POS
            Y.ASSET.TYPE = '' ; Y.NOM.FLAG = ''
            IF Y.TP.SYSTEM EQ 'UTS' AND Y.TP.AC.STAT NE 'CLOSED' THEN
                Y.NOM.FLAG = 'N' ; Y.NOM.FLAG.PLG = ''
                BEGIN CASE
                    CASE (Y.TP.ACCT.NO[9,2] EQ '11') AND (Y.BOND.FLAG EQ '')
                        IF Y.Z.BOND.FLAG EQ '' AND Y.NZ.BOND.FLAG EQ '' THEN
                            Y.ASSET.TYPE = "Bond"
                            Y.BOND.FLAG = 'Y'
                            Y.Z.BOND.FLAG = 'Y'
                        END
                    CASE (Y.TP.ACCT.NO[9,2] EQ '05') AND (Y.BOND.FLAG EQ '')
                        IF Y.Z.BOND.FLAG EQ '' AND Y.NZ.BOND.FLAG EQ '' THEN
                            Y.ASSET.TYPE = "Bond"
                            Y.BOND.FLAG = 'Y'
                            Y.Z.BOND.FLAG = 'Y'
                        END
                    CASE (Y.TP.ACCT.NO[9,2] EQ '01') AND (Y.UT.FLAG EQ '')
                        IF Y.Z.UT.FLAG EQ '' AND Y.NZ.UT.FLAG EQ '' THEN
                            Y.ASSET.TYPE = "UT"
                            Y.UT.FLAG = 'Y'
                            Y.Z.UT.FLAG = 'Y'
                        END
                    CASE (Y.TP.ACCT.NO[9,2] EQ '04') AND (Y.SN.FLAG EQ '')
                        IF Y.Z.SN.FLAG EQ '' AND Y.NZ.SN.FLAG EQ '' THEN
                            Y.ASSET.TYPE = "Protected SN"
                            Y.SN.FLAG = 'Y'
                            Y.Z.SN.FLAG = 'Y'
                        END
                    CASE (Y.TP.ACCT.NO[9,2] EQ '06') AND (Y.SNPR.FLAG EQ '')
                        IF Y.Z.SNPR.FLAG EQ '' AND Y.NZ.SNPR.FLAG EQ '' THEN
                            Y.ASSET.TYPE = "Non-Protected SN"
                            Y.SNPR.FLAG = 'Y'
                            Y.Z.SNPR.FLAG = 'Y'
                        END
                END CASE

                IF (Y.ASSET.TYPE NE '') AND ((Y.UT.FLAG NE '') OR (Y.BOND.FLAG NE '') OR (Y.SN.FLAG NE '') OR (Y.SNPR.FLAG NE '')) THEN
                    GOSUB ZERO.HOLDINGS.VAL
                    GOSUB FRAME.DATA
                    Y.UT.FLAG = '' ; Y.BOND.FLAG = '' ; Y.SN.FLAG = '' ; Y.SNPR.FLAG = ''
                END
            END
        REPEAT
    END
RETURN
*----------------*
ZERO.HOLDINGS.VAL:
*----------------*
    Y.SECPOS.PORT.NO   =  Y.SAM.ID
    Y.SECPOS.SEC.CODE  = '000000-000'
    Y.SECPOS.VALDT.POS = '000000000000000000'
    Y.PEND.SUB.AMT     = '000000000000000000'
    Y.PEND.RED.AMT     = '000000000000000000'
    Y.ACCRUED.INT      = '000000000000000000'
    Y.AMT.HELD         = '00000000000000000'
    Y.LOCAL.AMT        = '00000000000000000'

RETURN
*-----------------*
NON.ZERO.HLDS.FLAG:
*-----------------*
    BEGIN CASE
        CASE (Y.ASSET.TYPE EQ 'UT') AND (Y.NZ.UT.FLAG EQ '')
            Y.NZ.UT.FLAG = 'Y'
        CASE (Y.ASSET.TYPE EQ 'Bond') AND (Y.NZ.BOND.FLAG EQ '')
            Y.NZ.BOND.FLAG = 'Y'
        CASE (Y.ASSET.TYPE EQ 'Protected SN') AND (Y.NZ.SN.FLAG EQ '')
            Y.NZ.SN.FLAG = 'Y'
        CASE (Y.ASSET.TYPE EQ 'Non-Protected SN') AND (Y.NZ.SNPR.FLAG EQ '')
            Y.NZ.SNPR.FLAG = 'Y'
    END CASE

RETURN
*-------------*
ZERO.HLDS.FLAG:
*-------------*
    BEGIN CASE
        CASE (Y.ASSET.TYPE EQ 'UT') AND (Y.Z.UT.FLAG EQ '') AND (Y.NZ.UT.FLAG EQ '')
            Y.Z.UT.FLAG = 'Y'
            Y.ZERO.SM.ARR<-1> = Y.SAM.ID:'*':Y.ASSET.TYPE
        CASE (Y.ASSET.TYPE EQ 'Bond') AND (Y.Z.BOND.FLAG EQ '') AND (Y.NZ.BOND.FLAG EQ '')
            Y.Z.BOND.FLAG = 'Y'
            Y.ZERO.SM.ARR<-1> = Y.SAM.ID:'*':Y.ASSET.TYPE
        CASE (Y.ASSET.TYPE EQ 'Protected SN') AND (Y.Z.SN.FLAG EQ '') AND (Y.NZ.SN.FLAG EQ '')
            Y.Z.SN.FLAG = 'Y'
            Y.ZERO.SM.ARR<-1> = Y.SAM.ID:'*':Y.ASSET.TYPE
        CASE (Y.ASSET.TYPE EQ 'Non-Protected SN') AND (Y.Z.SNPR.FLAG EQ '') AND (Y.NZ.SNPR.FLAG EQ '')
            Y.Z.SNPR.FLAG = 'Y'
            Y.ZERO.SM.ARR<-1> = Y.SAM.ID:'*':Y.ASSET.TYPE
    END CASE

RETURN
*----------------*
BLD.ZERO.HLDS.ARR:
*----------------*
    Y.ZERO.SM.COUNT = ''
    I = ''
    Y.ZERO.SM.COUNT = DCOUNT(Y.ZERO.SM.ARR,@FM)
    FOR I = 1 TO Y.ZERO.SM.COUNT
        Y.SAM.ID = ''
        Y.ASSET.TYPE = ''
        Y.SAM.ID = FIELD(Y.ZERO.SM.ARR<I>,'*',1)
        Y.ASSET.TYPE = FIELD(Y.ZERO.SM.ARR<I>,'*',2)
        Y.NOM.FLAG = 'N' ; Y.NOM.FLAG.PLG = ''
        BEGIN CASE
            CASE (Y.ASSET.TYPE EQ 'UT') AND (Y.NZ.UT.FLAG EQ '')
                IF Y.Z.UT.FLAG EQ 'Y' THEN
                    GOSUB ZERO.HOLDINGS.VAL            ; *Setting zero value
                    GOSUB FRAME.DATA
                END
            CASE (Y.ASSET.TYPE EQ 'Bond') AND (Y.NZ.BOND.FLAG EQ '')
                IF Y.Z.BOND.FLAG EQ 'Y' THEN
                    GOSUB ZERO.HOLDINGS.VAL            ; *Setting zero value
                    GOSUB FRAME.DATA
                END
            CASE (Y.ASSET.TYPE EQ 'Protected SN') AND (Y.NZ.SN.FLAG EQ '')
                IF Y.Z.SN.FLAG EQ 'Y' THEN
                    GOSUB ZERO.HOLDINGS.VAL            ; *Setting zero value
                    GOSUB FRAME.DATA
                END
            CASE (Y.ASSET.TYPE EQ 'Non-Protected SN') AND (Y.NZ.SNPR.FLAG EQ '')
                IF Y.Z.SNPR.FLAG EQ 'Y' THEN
                    GOSUB ZERO.HOLDINGS.VAL            ; *Setting zero value
                    GOSUB FRAME.DATA
                END
        END CASE
    NEXT I
    IF Y.Z.UT.FLAG EQ '' OR Y.NZ.UT.FLAG EQ '' OR Y.Z.BOND.FLAG EQ '' OR Y.NZ.BOND.FLAG EQ '' OR Y.Z.SN.FLAG EQ '' OR Y.NZ.SN.FLAG EQ '' OR Y.Z.SNPR.FLAG EQ '' OR Y.NZ.SNPR.FLAG EQ '' THEN
        GOSUB NO.HOLDINGS.REC					; *No holdings.
    END
RETURN
*-----------------------------------------------------------------------------------------------------------------
FORM.SEC.TRANS:
***************
	
Y.AT.SETT.ID = '' ; Y.STR.SERL.POSITION = '' ; Y.AT.SET.ID = '' ; Y.STR.BUY.POSITION = '' ; Y.SEL.LIST.ARR = '' ;
Y.AT.SETT.ID = FIELD(Y.SECPOS.ID,'.',1,3)
Y.SEL.CMD = '' ; Y.SEL.LIST = '' ; Y.NO.OF.RECS = '' ; RET.CODE= '' 
Y.PEND.SEC.RED.AMOUNT.PLG = '0' ; Y.PEND.SEC.RED.AMOUNT = '0' ;  
 Y.SEL.CMD = "SELECT ":FN.SCB.AT.SETT.DETAILS:" WITH @ID LIKE ":Y.AT.SETT.ID:"..."
CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST,'',Y.NO.OF.REC,RET.CODE)
Y.SEL.LIST.ARR = Y.SEL.LIST
LOOP
	  REMOVE Y.SET.ID FROM Y.SEL.LIST.ARR SETTING Y.ID.POS
	  WHILE Y.SET.ID:Y.ID.POS
R.SCB.AT.SETT.DETAILS = '' ; Y.SCB.AT.SETT.DETAILS.ERR = '' ; Y.AT.TRANS.ID = '' ; Y.TRS.CNT = '' ; Y.SET.DATE = '' ; Y.VALUE.DATE = '' ;
TRANS.KEY = '' ; R.SEC.TRANSFER = '' ; ETEXT = '' ;
	  CALL F.READ(FN.SCB.AT.SETT.DETAILS,Y.SET.ID,R.SCB.AT.SETT.DETAILS,F.SCB.AT.SETT.DETAILS,Y.SCB.AT.SETT.DETAILS.ERR)
CALL OCOMO("SCB.AT.SETT.DETAILS.ID ":Y.SET.ID)
	  IF (R.SCB.AT.SETT.DETAILS) THEN
Y.AT.TRANS.ID = R.SCB.AT.SETT.DETAILS<AT.SETT.AT.ID>
Y.TRS.CNT = DCOUNT(Y.AT.TRANS.ID,@VM)
I = '0' 
	LOOP
		I += 1
         WHILE I LE Y.TRS.CNT
		Y.SET.DATE = R.SCB.AT.SETT.DETAILS<AT.SETT.SETT.DATE,I>
		Y.VALUE.DATE = R.SCB.AT.SETT.DETAILS<AT.SETT.VALUE.DATE,I>
		IF NOT(Y.SET.DATE) THEN
			Y.AT.TYPE = R.SCB.AT.SETT.DETAILS<AT.SETT.AT.TYPE,I>
TRANS.KEY = R.SCB.AT.SETT.DETAILS<AT.SETT.AT.ID,I>
			IF TODAY GT Y.VALUE.DATE THEN
Y.TRANS.NOM.CODE = '' ;
CALL F.READ(FN.SEC.TRANSFER,TRANS.KEY,R.SEC.TRANSFER,F.SEC.TRANSFER,ETEXT)
IF TRANS.KEY[1,4] EQ 'SECT' THEN
IF R.SEC.TRANSFER THEN
Y.TRANS.NOM.CODE = R.SEC.TRANSFER<SC.STR.NOMINEE.CODE>
END ELSE
CALL EB.READ.HISTORY.REC(F.SEC.TRANSFER.HIS,TRANS.KEY,R.SEC.TRANSFER,ETEXT)
Y.TRANS.NOM.CODE = R.SEC.TRANSFER<SC.STR.NOMINEE.CODE>
END
END 
				IF Y.AT.TYPE EQ 'CR' THEN
					IF Y.TRANS.NOM.CODE EQ '1' THEN
						Y.SECPOS.VALDT.POS.PLG = Y.SECPOS.VALDT.POS.PLG - R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,I>
					END ELSE
						Y.SECPOS.VALDT.POS = Y.SECPOS.VALDT.POS - R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,I>
					END
CALL OCOMO("Y.AT.TYPE ":Y.AT.TYPE)
CALL OCOMO("Y.SECPOS.VALDT.POS.PLG ":Y.SECPOS.VALDT.POS.PLG)
CALL OCOMO("Y.SECPOS.VALDT.POS ":Y.SECPOS.VALDT.POS)
				END
				IF Y.AT.TYPE EQ 'DR' THEN
					IF Y.TRANS.NOM.CODE EQ '1' THEN
						Y.SECPOS.VALDT.POS.PLG = Y.SECPOS.VALDT.POS.PLG + R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,I>
						Y.PEND.SEC.RED.AMOUNT.PLG = Y.PEND.SEC.RED.AMOUNT.PLG + R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,I>
					END ELSE
						Y.SECPOS.VALDT.POS = Y.SECPOS.VALDT.POS + R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,I>
						Y.PEND.SEC.RED.AMOUNT = Y.PEND.SEC.RED.AMOUNT + R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,I>
					END
CALL OCOMO("Y.AT.TYPE ":Y.AT.TYPE)
CALL OCOMO("Y.SECPOS.VALDT.POS.PLG ":Y.SECPOS.VALDT.POS.PLG)
CALL OCOMO("Y.SECPOS.VALDT.POS ":Y.SECPOS.VALDT.POS)
				END
			END
		END
	REPEAT
END
REPEAT
RETURN
END