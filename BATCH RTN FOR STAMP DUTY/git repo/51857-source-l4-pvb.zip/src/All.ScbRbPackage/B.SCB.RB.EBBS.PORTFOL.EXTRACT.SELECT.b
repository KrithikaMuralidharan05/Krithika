$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.PORTFOL.EXTRACT.SELECT
*---------------------------------------------------------------------------------------------------------------
* 
* 
*-----------------------------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-----------------------------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864
*
** 21-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
*-----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.EBBS.PORTFOL.EXT.COMMON
    $INSERT I_F.SEC.ACC.MASTER
*
    SEL.CMD = 'SELECT ':FN.SEC.ACC.MAST
*CPSGMIG-13878(S)
*    SEL.CMD := " WITH SECTOR EQ 23"
*CPSGMIG-13878(E)
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
		CALL BATCH.BUILD.LIST('',SEL.LIST)
    END	
*
    RETURN
*
*-----------------------------------------------------------------------------------------------------------------
END
*-----------------------------------------------------------------------------------------------------------------