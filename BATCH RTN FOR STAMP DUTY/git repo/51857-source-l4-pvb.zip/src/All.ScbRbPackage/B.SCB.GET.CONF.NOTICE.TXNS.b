* @ValidationCode : MjotMTgzMzM4OTcwMTpJU08tODg1OS0xOjE2ODMyNzAwMzE2NTM6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 05 May 2023 12:30:31
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.GET.CONF.NOTICE.TXNS
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14078
* Developed By                   :       1663000
* Developed On                   :       10-Feb-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Single Threaded Routine to fetch transactions for which Contract notes are generated
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 15-Feb-2023   1663000          CPSGMIG-19402 - Column addition
* 02-Mar-2023   1663000          CPSGMIG-14078 - HeaderChange
* 19-Apr-2023   1663000          CPSGMIG-24870 - Today Selection changed to Last Working Day
* 24-Apr-2023   1663000          CPSGMIG-25002 - Invalid Syscode Desc
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename Change
* 04-May-2023   1663000          CPSGMIG-20042 - Include COMO message
* 02-Aug-2023   1667095          PVBCOREBAU-10461 - Removed COMO message
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.DE.HEADER
    $INSERT I_F.DIARY
    $INSERT I_F.DIARY.TYPE
    $INSERT I_F.SCB.DP.XML.ADV.STATUS
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.SEC.ACC.MASTER                    ;*CPSGMIG-19402
    $INSERT I_F.DATES                             ;*CPSGMIG-24870
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB DO.PROCESS

RETURN
*---------*
INITIALISE:
*---------*

* Get LOB Value by Segment
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)

* Open Files
   
    FN.DIARY                 = 'F.DIARY'                 ; F.DIARY                  = '' ; CALL OPF(FN.DIARY,F.DIARY)
    FN.DIARY.HIS             = 'F.DIARY$HIS'             ; F.DIARY.HIS              = '' ; CALL OPF(FN.DIARY.HIS,F.DIARY.HIS)
    FN.DIARY.TYPE            = 'F.DIARY.TYPE'            ; F.DIARY.TYPE             = '' ; CALL OPF(FN.DIARY.TYPE,F.DIARY.TYPE)
    FN.CONCAT.DIARY          = 'F.CONCAT.DIARY'          ; F.CONCAT.DIARY           = '' ; CALL OPF(FN.CONCAT.DIARY,F.CONCAT.DIARY)
    FN.SCB.DP.XML.ADV.STATUS = 'F.SCB.DP.XML.ADV.STATUS' ; F.SCB.DP.XML.ADV.STATUS  = '' ; CALL OPF(FN.SCB.DP.XML.ADV.STATUS,F.SCB.DP.XML.ADV.STATUS)
    FN.SEC.TRADE             = 'F.SEC.TRADE'             ; F.SEC.TRADE              = '' ; CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    FN.SEC.TRADE.HIS         = 'F.SEC.TRADE$HIS'         ; F.SEC.TRADE.HIS          = '' ; CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)
    FN.SECURITY.TRANSFER     = 'F.SECURITY.TRANSFER'     ; F.SECURITY.TRANSFER      = '' ; CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
    FN.SECURITY.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS' ; F.SECURITY.TRANSFER.HIS  = '' ; CALL OPF(FN.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS)
    FN.SEC.OPEN.ORDER        = 'F.SEC.OPEN.ORDER'        ; F.SEC.OPEN.ORDER         = '' ; CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    FN.SEC.OPEN.ORDER.HIS    = 'F.SEC.OPEN.ORDER$HIS'    ; F.SEC.OPEN.ORDER.HIS     = '' ; CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
    FN.CUSTOMER              = 'F.CUSTOMER'              ; F.CUSTOMER               = '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SC.TRANS.NAME         = 'F.SC.TRANS.NAME'         ; F.SC.TRANS.NAME          = '' ; CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
    FN.DE.O.HEADER           = 'F.DE.O.HEADER'           ; F.DE.O.HEADER            = '' ; CALL OPF(FN.DE.O.HEADER, F.DE.O.HEADER)
    FN.SCB.WM.H.LOCAL.PARAM  = 'F.SCB.WM.H.LOCAL.PARAM'  ; F.SCB.WM.H.LOCAL.PARAM   = '' ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
    FN.SECURITY.MASTER       = 'F.SECURITY.MASTER'       ; F.SECURITY.MASTER        = '' ; CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SEC.ACC.MASTER        = 'F.SEC.ACC.MASTER'        ; F.SEC.ACC.MASTER         = '' ; CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER) ;* CPSGMIG-19402

* Get the Output filename
    Y.TXN.FINAL.FILE         = BATCH.DETAILS<3,1>
    
    Y.LWD            = R.DATES(EB.DAT.LAST.WORKING.DAY)  ;*CPSGMIG-24870
    Y.TXN.FINAL.FILE = EREPLACE(Y.TXN.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
    
RETURN
*---------*
DO.PROCESS:
*---------*
    
* Select Today's transactions
    SEL.LIST = '' ; SEL.CNT = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SCB.DP.XML.ADV.STATUS:" WITH BANK.DATE EQ '":Y.LWD:"' AND COMPANY EQ '" :ID.COMPANY[1,2]:"' AND L.O.B EQ 'RET'"    ;*CPSGMIG-24870
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)

* Read SCB.DP.XML.ADV.STATUS

    LOOP
        REMOVE Y.DOH.ID FROM SEL.LIST SETTING Y.CN.POS
    WHILE Y.DOH.ID : Y.CN.POS
        
        Y.OUT.VAL = '' ; Y.ACCT.NO    = '' ; Y.ORD.ID = '' ; Y.TXN.ID  = '' ; Y.TRANS.DESC   = '' ; YY.CLIENT.IDENTIFIER = '' ; Y.MF.PROD.FLAG = ''
        Y.CUS.ID  = '' ; Y.TRANS.CODE = '' ; Y.SM.ID  = '' ; Y.DIA.ID  = '' ; Y.SAM.ADVINDEX = '' ; Y.LRPFOLIO.KEY       = '' ;*CPSGMIG-25002
        
        DE.O.HEADER.REC = '' ; DE.O.HEADER.ERR = ''
        CALL F.READ(FN.DE.O.HEADER, Y.DOH.ID, DE.O.HEADER.REC, F.DE.O.HEADER, DE.O.HEADER.ERR)
        Y.TXN.ID = FIELD(DE.O.HEADER.REC<DE.HDR.TRANS.REF>,' ',1)
        
        BEGIN CASE
            CASE Y.TXN.ID[1,6] EQ 'SCTRSC'     ;* Process Sec trade
                GOSUB SEC.TRADE.DET
            CASE Y.TXN.ID[1,6] EQ 'SECTSC'     ;* Process Security Transfer
                GOSUB SEC.TRFR.DET
            CASE Y.TXN.ID[1,6] EQ 'DIARSC'     ;* Process Entitlement
                GOSUB ENT.DET
        END CASE
        
    REPEAT

    IF Y.OUT.ARR THEN
        GOSUB WRITE.TO.FILE
    END

RETURN
*------------*
SEC.TRADE.DET:
*------------*

    CALL F.READ(FN.SEC.TRADE,Y.TXN.ID,R.SEC.TRADE,F.SEC.TRADE,Y.ST.ERR)
    IF R.SEC.TRADE EQ "" THEN
        Y.HISTRADE.ID = '' ; Y.HISTRADE.ID = Y.TXN.ID
        CALL EB.READ.HISTORY.REC(F.SEC.TRADE.HIS,Y.HISTRADE.ID,R.SEC.TRADE,SECTRHIS.ERR)
    END
    Y.CUS.ID      = R.SEC.TRADE<SC.SBS.CUSTOMER.NO>
    Y.SM.ID       = R.SEC.TRADE<SC.SBS.SECURITY.CODE>
    
    
    GOSUB GET.SM.DETS
    GOSUB GET.CUST.VALUES
    
    IF (Y.LOB MATCHES Y.ALLOWED.LOB) AND (Y.MF.PROD.FLAG EQ 'Y') THEN
        
        Y.ACCT.NO          = R.SEC.TRADE<SC.SBS.CUST.SEC.ACC>
        Y.ORD.ID           = R.SEC.TRADE<SC.SBS.CU.ORDER.NOS>
        Y.TRANS.CODE       = R.SEC.TRADE<SC.SBS.CUST.TRANS.CODE>
        GOSUB GET.SAM.DETS ;*CPSGMIG-19402
        GOSUB GET.TXN.DESC
        GOSUB FRAME.ARRAY
    END
 
RETURN
*-----------*
SEC.TRFR.DET:
*-----------*
    
    R.SECURITY.TRANSFER = '' ; SECURITY.TRANSFER.ERR = ''
    CALL F.READ(FN.SECURITY.TRANSFER,Y.TXN.ID,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,SECURITY.TRANSFER.ERR)
    IF R.SECURITY.TRANSFER EQ "" THEN
        Y.SECHIS.ID = '' ; SECHIS.ERR = '' ; Y.SECHIS.ID = Y.TXN.ID
        CALL EB.READ.HISTORY.REC(F.SECURITY.TRANSFER.HIS,Y.SECHIS.ID,R.SECURITY.TRANSFER,SECHIS.ERR)
    END
    
    Y.CUS.ID      = R.SECURITY.TRANSFER<SC.STR.CUSTOMER.NO>
    Y.SM.ID       = R.SECURITY.TRANSFER<SC.STR.SECURITY.NO>
    
    GOSUB GET.SM.DETS
    GOSUB GET.CUST.VALUES
    IF (Y.LOB MATCHES Y.ALLOWED.LOB) AND (Y.MF.PROD.FLAG EQ 'Y') THEN
        Y.ACCT.NO          = R.SECURITY.TRANSFER<SC.STR.SECURITY.ACC>
        Y.ORD.ID           = ""
        Y.TRANS.CODE       = R.SECURITY.TRANSFER<SC.STR.TRANSACTION.TYPE>
        GOSUB GET.SAM.DETS ;*CPSGMIG-19402
        GOSUB GET.TXN.DESC
        GOSUB FRAME.ARRAY
    END
        
RETURN
*------*
ENT.DET:
*------*
    
    Y.DIA.ID = Y.TXN.ID
    
* Get Event Type
    R.DIARY = '' ; DIARY.ERR = ''
    CALL F.READ(FN.DIARY,Y.DIA.ID,R.DIARY,F.DIARY,DIARY.ERR)
    IF R.DIARY EQ "" THEN
        Y.DIAHIS.ID = "" ; Y.DIAHIS.ID = Y.DIA.ID
        CALL EB.READ.HISTORY.REC(F.DIARY.HIS,Y.DIAHIS.ID,R.DIARY,DIAHIS.ERR)
    END
    Y.DIARY.TYPE = R.DIARY<SC.DIA.EVENT.TYPE>
    Y.SM.ID      = R.DIARY<SC.DIA.SECURITY.NO>
    
    GOSUB GET.SM.DETS
    GOSUB GET.TXN.DESC
    
    Y.ORD.ID = Y.DIA.ID
   
    IF (Y.MF.PROD.FLAG EQ 'Y') THEN
        
* Get Ent Details
        R.CONCAT.DIARY = '' ; CONCAT.DIARY.ERR = ''
        CALL F.READ(FN.CONCAT.DIARY,Y.DIA.ID,R.CONCAT.DIARY,F.CONCAT.DIARY,CONCAT.DIARY.ERR)
        LOOP
            REMOVE Y.TXN.ID FROM R.CONCAT.DIARY SETTING CONCAT.POS
        WHILE Y.TXN.ID : CONCAT.POS
    
            Y.ACCT.NO = FIELD(Y.TXN.ID,'.',2)
            Y.CUS.ID  = FIELD(Y.ACCT.NO,'-',1)
        
            GOSUB GET.CUST.VALUES
            IF (Y.LOB MATCHES Y.ALLOWED.LOB) THEN
                GOSUB GET.SAM.DETS ;*CPSGMIG-19402
                GOSUB FRAME.ARRAY
            END
        
        REPEAT
    END
    
RETURN
*-----------*
GET.SAM.DETS:
*-----------*
    
    R.SEC.ACC.MASTER = ''    ;  Y.SAM.ERR = ''           ;*CPSGMIG-19402 -S
    CALL F.READ(FN.SEC.ACC.MASTER,Y.ACCT.NO,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,Y.SAM.ERR)
    Y.SAM.ADVINDEX   = R.SEC.ACC.MASTER<SC.SAM.ADVICE.INDEX>   ;*CPSGMIG-19402 -E
    
RETURN
*----------*
GET.SM.DETS:
*----------*
    
    Y.SAT.PARAM = 'SCB.MF.ASSET.TYPES' ; R.SCB.WM.H.LOCAL.PARAM = '' ; Y.SCB.WM.H.LOCAL.PARAM.ERR = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.SAT.PARAM,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.SCB.WM.H.LOCAL.PARAM.ERR)
    IF R.SCB.WM.H.LOCAL.PARAM THEN
        Y.MF.PARAM.FLD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
        CHANGE @SM TO @VM IN Y.MF.PARAM.FLD.VALUE
    END

    R.SECURITY.MASTER = '' ; SM.ERR = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,SM.ERR)
    IF R.SECURITY.MASTER THEN
        Y.SAT.VAL     = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
        IF Y.SAT.VAL MATCHES Y.MF.PARAM.FLD.VALUE THEN
            Y.MF.PROD.FLAG = 'Y'
        END
    END
       
RETURN
*-----------*
GET.TXN.DESC:
*-----------*
  
    IF Y.DIA.ID THEN
        R.DIARY.TYPE = ''; ERR.DIARY.TYPE = ''
        CALL F.READ(FN.DIARY.TYPE,Y.DIARY.TYPE,R.DIARY.TYPE,F.DIARY.TYPE,ERR.DIARY.TYPE)
        Y.TRANS.DESC = R.DIARY.TYPE<SC.DRY.EVENT.DESC,1>
    END ELSE
        R.SC.TRANS.NAME = '' ; SC.TRANS.NAME.ERR = ''
        CALL F.READ(FN.SC.TRANS.NAME,Y.TRANS.CODE,R.SC.TRANS.NAME,F.SC.TRANS.NAME,Y.SC.TRANS.NAME.ERR)
        IF R.SC.TRANS.NAME THEN
            Y.TRANS.DESC = R.SC.TRANS.NAME<SC.TNM.SHORT.NAME,1>
        END
    END
    
RETURN
*--------------*
GET.CUST.VALUES:
*--------------*
        
    R.CUSTOMER = ''  ;   Y.CUS.ERR = ''
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUSTOMER,F.CUSTOMER,Y.CUS.ERR)
    
    Y.APP.NAME  = 'CUSTOMER'
    Y.FLD.NAME  = "L.O.B" :@VM:"LR.STAFF.IND":@VM: :"LR.PFOLIO.KEY" ;*CPSGMIG-19402
    Y.FLD.POS   = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)

    Y.LOB.POS  = Y.FLD.POS<1,1>
    Y.STF.POS  = Y.FLD.POS<1,2>
    Y.LRPF.POS = Y.FLD.POS<1,3>  ;*CPSGMIG-19402

    Y.LOB          = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
    STAFF.IND      = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.STF.POS>
    Y.LRPFOLIO.KEY = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LRPF.POS>     ;*CPSGMIG-19402
    
    BEGIN CASE
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ "21"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ "23"
            YY.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
    
RETURN
*----------*
FRAME.ARRAY:
*----------*
   
    Y.OUT.VAL     = Y.ACCT.NO                     ;* 1. ACA_AC_NO
    Y.OUT.VAL    := ',': Y.ORD.ID                 ;* 2. Order No/Diary ID
    Y.OUT.VAL    := ',': Y.TXN.ID                 ;* 3. Transaction Ref
    Y.OUT.VAL    := ',': Y.TRANS.DESC             ;* 4. SYS CODE DESC
    Y.OUT.VAL    := ',': YY.CLIENT.IDENTIFIER     ;* 5. Client Identifier
    Y.OUT.VAL    := ',':                          ;* 6. Country Code to be fetched from ICM/eBBS
    Y.OUT.VAL    := ',': Y.LRPFOLIO.KEY           ;* 7. PrimaryAcctHolder                                 ;*CPSGMIG-19402
    Y.OUT.VAL    := ',': Y.SAM.ADVINDEX           ;* 8. ADVICE.INDEX                                      ;*CPSGMIG-19402
    Y.OUT.ARR<-1> = Y.OUT.VAL
    
RETURN
*------------*
WRITE.TO.FILE:
*------------*

    Y.HDR.ARR       = 'ACA_AC_NO,ORDER NO/DIARY ID,Transaction Ref,SYS CODE DESC,ClientIdentifier,Country Code,PrimaryAcctHolder,ADVICE.INDEX'  ;*CPSGMIG-14087
    Y.FINAL.ARR     = Y.HDR.ARR
    Y.FINAL.ARR<-1> = Y.OUT.ARR

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
    
    AMEXPATH = ""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
    
    WRITE Y.FINAL.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
    
RETURN
END