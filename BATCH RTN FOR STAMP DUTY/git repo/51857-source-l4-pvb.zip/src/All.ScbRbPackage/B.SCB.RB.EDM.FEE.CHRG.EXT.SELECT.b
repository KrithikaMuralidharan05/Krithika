$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EDM.FEE.CHRG.EXT.SELECT
*--------------------------------------------------------------------------------------------------------
* Modification History :- 
* 07-Mar-2022 - Lavanya L  - NEW - CPSGMIG-1885
* Description 	:	The routine is used to send the daily dump of Fees & Charges 
*					configured for MF Instrument to Springwatch.
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SC.CHARGE.TAX.CALC.CREATE
	$INSERT I_F.FT.COMMISSION.TYPE
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_B.SCB.RB.EDM.FEE.CHRG.EXT.COMMON
*	
	SEL.CMD = 'SELECT ':FN.SC.CHARGE.TAX
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
		CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
*	
	RETURN
*--------------------------------------------------------------------------------------------------------
END
*--------------------------------------------------------------------------------------------------------
