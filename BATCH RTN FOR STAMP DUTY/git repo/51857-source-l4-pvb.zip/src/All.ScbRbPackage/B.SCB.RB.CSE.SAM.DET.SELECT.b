$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CSE.SAM.DET.SELECT

* Routine to extract the SM and SAM and its equivalent UTS and ISA Account details that were loaded
*Created by :- 1657186
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
* 02 Mar 2023 - CPSGMIG-19983 - kalaikumaranp - To send BB and Individual Client Feed to CSE.
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.CSE.SAM.DET.COMMON

    
    SEL.SAM.CMD = "SELECT ": FN.SEC.ACC.MASTER : " WITH LR.PFOLIO.KEY NE ''"
    CALL OCOMO("Selecting the SAM Records")

    CALL EB.READLIST(SEL.SAM.CMD,SEL.LIST,'',NO.REC,RET.CODE)

    CALL OCOMO(SEL.SAM.CMD)
    CALL OCOMO("No of Records Selected for Processing ":NO.REC)
    
    IF SEL.LIST THEN
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
RETURN
******
************************************************************
END