* @ValidationCode : MjotNTk2OTQzMTE0OklTTy04ODU5LTE6MTY3OTM4MjYzNDgwMjoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 21 Mar 2023 12:40:34
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PROD.PRVIDR.LIST(Y.CUS.ID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17784
* Developed By                   :       Senthil
* Developed On                   :       02-Feb-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* SELECT Routine to generate Extract file of Product Provide detail listing
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 06-Mar-23     1663000          CPSGMIG-20051 Remove non T24 columns
* 21-Mar-23	    1663000          CPSGMIG-21438 Remove JunkValues in Address columns
* 13-Jun-2023   1671073          CPSGMIG-24884 Identifier for PP or Depo to be introduced
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
    $INSERT I_B.SCB.RB.PROD.PRVIDR.LIST.COMMON
	$INSERT I_F.CUSTOMER.SECURITY

    GOSUB INIT
    GOSUB PROCESS

RETURN
*----------------------------------------------------------------------------------------------
INIT:
*----
    Y.PROD.PROV.CODE = ''
    Y.ID             = ''
    Y.SHORT.NAME     = ''
    Y.NAME1          = ''
    Y.NAME2          = ''
    Y.NAME           = ''
    Y.ADDRESS1       = ''
    Y.ADDRESS3       = ''
    Y.ADDRESS4       = ''
    Y.CONTACT.PERSON = ''
    Y.PHONE.NO       = ''
    Y.FAX.NO         = ''
    Y.ARRAY          = ''
    Y.DELIM          = ","
    R.CUS            = ''
    ERR.CUS          = ''
    Y.ARRAY          = ''
	Y.CUS.TYPE       = ''
	Y.FLAG.BROKER    = ''
	Y.FLAG.DEPO      = ''
	DEP.ACC.ID       = ''
	IDENTIFIER       = ''
    ERR.CUS.SEC      = ''
	R.CUS.SEC        = ''
RETURN
*------------------------------------------------------------------------------------------------
PROCESS:
*-------*
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUS,F.CUSTOMER,ERR.CUS)
	CALL F.READ(FN.CUSTOMER.SECURITY,Y.CUS.ID,R.CUS.SEC,F.CUSTOMER.SECURITY,ERR.CUS.SEC)

    IF R.CUS THEN
        Y.PROD.PROV.CODE = R.CUS<EB.CUS.LOCAL.REF,Y.LR.PP.CODE.POS>
        Y.ID             = Y.CUS.ID
        Y.SHORT.NAME     = R.CUS<EB.CUS.SHORT.NAME>
        Y.NAME.1         = R.CUS<EB.CUS.NAME.1>
        Y.NAME.2         = R.CUS<EB.CUS.NAME.2>
        Y.NAME           = Y.NAME.1:' ':Y.NAME.2
        Y.ADDRESS1       = R.CUS<EB.CUS.ADDRESS,1>
        Y.ADDRESS2       = R.CUS<EB.CUS.ADDRESS,2>
        Y.ADDRESS3       = R.CUS<EB.CUS.ADDRESS,3>
        Y.ADDRESS4       = R.CUS<EB.CUS.ADDRESS,4>
        Y.CONTACT.PERSON = R.CUS<EB.CUS.FURTHER.DETAILS>
        Y.PHONE.NO       = R.CUS<EB.CUS.PHONE.1>
        CHANGE @VM TO '/' IN Y.PHONE.NO
        Y.FAX.NO         = R.CUS<EB.CUS.FAX.1>
        CHANGE @VM TO '/' IN Y.FAX.NO
        CHANGE @SM TO ' ' IN Y.ADDRESS1     ;* CPSGMIG-21438 -s
        CHANGE @SM TO ' ' IN Y.ADDRESS2
        CHANGE @SM TO ' ' IN Y.ADDRESS3
        CHANGE @SM TO ' ' IN Y.ADDRESS4     ;* CPSGMIG-21438 -e
		
		GOSUB GET.IDENTIFIER.VALUE             	
        GOSUB WRITE.TO.TEMP.FILE
        RETURN
*---------------------------------------------------------------------------------------------------
GET.IDENTIFIER.VALUE:
*--------------------*
       BROKER.POS='' ; DEPO.POS=''
* Logic changed to check BROKER or DEPO in a MV set
       Y.CUS.TYPE       = R.CUS.SEC<SC.CSC.CUSTOMER.TYPE>
	   
       FINDSTR 'BROKER' IN Y.CUS.TYPE SETTING BROKER.POS THEN
        Y.FLAG.BROKER = "YES"
       END
	   
	   FINDSTR 'DEPOSITORY' IN Y.CUS.TYPE SETTING DEPO.POS THEN
        Y.FLAG.DEPO = "YES"
       END
	   
       DEP.ACC.ID = R.CUS.SEC<SC.CSC.DEP.EXT.ACC.ID>
	   
	   BEGIN CASE
	   CASE Y.FLAG.BROKER EQ "YES" AND Y.FLAG.DEPO EQ "YES"
	     IF DEP.ACC.ID NE "" THEN
		 IDENTIFIER = "DEPO"
		 END ELSE
		 IDENTIFIER = "PP"
		 END
	   
	   CASE Y.FLAG.BROKER EQ "YES" AND Y.FLAG.DEPO EQ ""
	     IDENTIFIER = "PP"
	   
	   CASE Y.FLAG.BROKER EQ "" AND Y.FLAG.DEPO EQ "YES"
	      IDENTIFIER = "DEPO"
		  
	   END CASE
	   	   	   
RETURN
*--------------------------------------------------------------------------------------------------
WRITE.TO.TEMP.FILE:
*---------------*

        Y.ARRAY  = Y.PROD.PROV.CODE                   ;* 1.Product Provider Code
        Y.ARRAY := Y.DELIM:Y.ID                       ;* 2.Id
        Y.ARRAY := Y.DELIM:DQUOTE(Y.SHORT.NAME)       ;* 3.Short Name
        Y.ARRAY := Y.DELIM:DQUOTE(Y.NAME)             ;* 4.Name
        Y.ARRAY := Y.DELIM:DQUOTE(Y.ADDRESS1)         ;* 5.Address#1
        Y.ARRAY := Y.DELIM:DQUOTE(Y.ADDRESS2)         ;* 6.Address#2
        Y.ARRAY := Y.DELIM:DQUOTE(Y.ADDRESS3)         ;* 7.Address#3
        Y.ARRAY := Y.DELIM:DQUOTE(Y.ADDRESS4)         ;* 8.Address#4
        Y.ARRAY := Y.DELIM:DQUOTE(Y.CONTACT.PERSON)   ;* 12.Contact Persion
        Y.ARRAY := Y.DELIM:Y.PHONE.NO                 ;* 13.Phone No
        Y.ARRAY := Y.DELIM:Y.FAX.NO                   ;* 14.Fax No
        Y.ARRAY := Y.DELIM:IDENTIFIER                 ;* 15.Identifier
* Write to Temp File
        OPENSEQ AMEX.FILES,Y.TEMP.FILE TO FP.AMEX.FILES ELSE
        END
        WRITESEQ Y.ARRAY APPEND TO FP.AMEX.FILES ELSE
            CALL OCOMO("Unable to Write Product Provide detail listing")
        END
        CLOSESEQ FP.AMEX.FILES

 
        RETURN
*-----------------------------------------------------------------------------------------------------
    END