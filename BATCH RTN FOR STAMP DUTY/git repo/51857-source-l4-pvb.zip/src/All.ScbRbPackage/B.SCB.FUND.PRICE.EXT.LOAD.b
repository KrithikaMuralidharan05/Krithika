$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FUND.PRICE.EXT.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13123 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       23 December 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Load Routine to extract price batch for iBanking from SECURITY.MASTER
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.PRICE.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 24-Apr-2023   1667095          CPSGMIG-24999 - Decimal value position increased for
*												 NAV price and offered price
* 06-Jun-2023   1648769          CPSGMIG-27441 - Adding retail SAT validation.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_B.SCB.FUND.PRICE.EXT.COMMON
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
*
    GOSUB INIT
    GOSUB GET.VALUES
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER, F.SECURITY.MASTER)
*
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.SCB.WM.H.LOCAL.PARAM  = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
*
    AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
*CPSGMIG-24999(S)
    Y.APP.NAME = 'SECURITY.MASTER'
    Y.FLD.NAME<1> = 'LR.UTS.INS.DESC'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
*SM LRT
    Y.LR.UTS.INS.DESC.POS = Y.FLD.POS<1,1>
*CPSGMIG-24999(E)
	FILE.NAME = "T24SGFUNDPRICE_":TODAY:"_":SESSION.NO:".txt"
*
RETURN
*---------*
GET.VALUES:
*---------*
  
    Y.LOCAL.PARAM.ID = 'SCB.CRES.SAT' ;  R.SCB.WM.H.LOCAL.PARAM = ''  ; LOCAL.PARAM.ERR = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.LOCAL.PARAM.ID,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,LOCAL.PARAM.ERR)
    
    Y.FIELD.NAME  = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.FIELD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>

    LOCATE "FI" IN Y.FIELD.NAME<1,1> SETTING FI.POS THEN
        Y.FI.SAT.ARRAY = Y.FIELD.VALUE<1,FI.POS>
        CONVERT @SM TO @VM IN Y.FI.SAT.ARRAY
    END
    
    LOCATE "SN" IN Y.FIELD.NAME<1,1> SETTING SN.POS THEN
        Y.SN.SAT.ARRAY = Y.FIELD.VALUE<1,SN.POS>
        CONVERT @SM TO @VM IN Y.SN.SAT.ARRAY
    END
    
    LOCATE "MF" IN Y.FIELD.NAME<1,1> SETTING MF.POS THEN
        Y.MF.SAT.ARRAY = Y.FIELD.VALUE<1,MF.POS>
        CONVERT @SM TO @VM IN Y.MF.SAT.ARRAY
    END
    
RETURN
*-----------------------------------------------------------------------------
END
