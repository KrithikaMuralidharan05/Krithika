$PACKAGE All.ScbRbPackage
*----------------------------------------------------------------------------------------------------------
* <Rating>-18</Rating>
*----------------------------------------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.TAP.DIARY.EXT.SELECT
*----------------------------------------------------------------------------------------------------------
* Modification History:
*---------------------*
* 05-Aug-2022 - CPSGMIG-5347 - Shreekantha. G - Copy of the existing routine SCB.B.EDM.DIARY.EXTRACT.SELECT
*----------------------------------------------------------------------------------------------------------
*
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.DIARY
    $INSERT  I_F.SECURITY.MASTER
    $INSERT  I_F.STOCK.EXCHANGE
    $INSERT  I_BATCH.FILES
    $INSERT  I_TSA.COMMON
    $INSERT  I_B.SCB.RB.TAP.DIARY.EXT.COMMON
*
    SEL.CMD = ''
    SEL.CMD = "SSELECT ":FN.STATIC.CHANGES:" WITH @ID LIKE DIARY*..."
*
    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
*
    IF SEL.LIST THEN
*
        CONVERT @FM TO CHARX(10) IN SEL.LIST
        CUT.CMD = "-d'*' -f3"
*
        CR.CMD = "SH -c echo '":SEL.LIST:"' > ":FN.ENABLE.TEMP.DIR
        EXECUTE CR.CMD
*
        SH.CMD = "SH -c cut ":CUT.CMD:" ":FN.ENABLE.TEMP.DIR
        EXECUTE SH.CMD CAPTURING Y.DIARY.ID.LIST
        EXECUTE "SH -c rm ":FN.ENABLE.TEMP.DIR
*
        SORT.CMD = "-u"
        FINAL.LIST = ''
*
        CALL SCB.SORT(SORT.CMD, Y.DIARY.ID.LIST, FINAL.LIST)
        CALL BATCH.BUILD.LIST('',FINAL.LIST)
*
    END
*
    RETURN
*
*----------------------------------------------------------------------------------------------------------
END
*----------------------------------------------------------------------------------------------------------
