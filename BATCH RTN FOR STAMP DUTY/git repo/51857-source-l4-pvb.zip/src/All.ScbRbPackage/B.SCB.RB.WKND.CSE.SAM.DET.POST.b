$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.WKND.CSE.SAM.DET.POST

* Routine to extract the SAM and its equivalent UTS and ISA Account details that were loaded
*Created by :- 1657186
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
**
* 02 Mar 2023 - CPSGMIG-19983 - kalaikumaranp - To send BB and Individual Client Feed to CSE.
* 06-Apr- 2023 - CPSGMIG-18238 - kalaikumaranp- Parameterised the customer tranche records.
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    
    AMEX.FILES.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME('AMEX.FILES', '', AMEX.FILES.PATH)
    
    L.WORK.DATE=OCONV(DATE(),'D-') ;*MM-DD-YYYY
    L.WORK.DATE= L.WORK.DATE[7,4]:L.WORK.DATE[1,2]:L.WORK.DATE[4,2]
    CALL CDT("",L.WORK.DATE,"-1C")
    
    Y.FINAL.ID = 'SAM.ISA.FILE-':L.WORK.DATE:'.txt'
	Y.FINAL.ID.BK = 'SAM-ISA-FILE-':L.WORK.DATE:'.txt'
    
	Y.UDFILE       = 'AMEX.FILES'
	Y.ST.CRITERIA  = 'SG.REL.PORTFOLIO.WKND.FILE.':TODAY:'-*'
	Y.FILE.ARRAY = ''
	Y.FILE.ARRAY = "Portfolio ID":",":"Customer ID":",":"ISA":",":"Rel ID(primary)":",":"Rel ID Secondary1":",":"Rel ID Secondary2":",":"Rel ID Secondary3":",":"Rel ID Secondary4":",":"Segment Code":",":"ISA Status"

    SEL.FILE.ID    = ''
    Y.ST.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.CRITERIA, SEL.FILE.ID, Y.ST.CNT)

    Y.DEL.FILE.ID = SEL.FILE.ID
    LOOP
        REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
    WHILE Y.FILE.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.SAM.REC,F.APPEND.FILES,APP.ERR)
        IF R.SAM.REC NE  '' THEN
            Y.FILE.ARRAY<-1> = R.SAM.REC
            LINE.COUNT = DCOUNT(R.SAM.REC, @FM)
            TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
        LINE.COUNT = ''
    REPEAT

	WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID
    
* Take the Backup Before Encryption
	WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID.BK
*	
	* CPSGMIG-17716
	*
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''
*    
    FLOW.IDENTIFER.ID = 'T24-RBSTMT-SG'
*    
    FILE.NAME = AMEX.FILES.PATH
    RECORD.NAME = Y.FINAL.ID
    TARGET.FILE.NAME = 'SAM.ISA.FILE_':L.WORK.DATE:'.txt'
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'') 
* CPSGMIG-17716
 
RETURN
*****************
END