$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.TRADE.DOMICILE.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14086 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       13 April 2023
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract the trade domicile details
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.B.TRADE.DOMICILE
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 10-May-2023	1667095			CPSGMIG-26838 Updated header
* 15/06/2023    1670271                 UT Trade domicile report-additional fields
* 12/07/2023    1663000                 To introduce a new variable to store LWD date
*---------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_B.SCB.TRADE.DOMICILE.COMMON
    
    GOSUB INIT
    GOSUB PROCESS
RETURN

*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX.FILES,F.AMEX.FILES,AMEXPATH)
*
    R.TRADE.DTL.FINAL.ARR = '' ; R.TRADE.DTL.FINAL = ''
*Get final filename from BATCH record

    Y.FINAL.FILE.NAME = BATCH.DETAILS<3,1>
    Y.FINAL.FILE.NAME = FIELD(Y.FINAL.FILE.NAME,'*', 2)
    
    Y.LWD = '' ; Y.LWD =  R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.FINAL.FILE.NAME = EREPLACE(Y.FINAL.FILE.NAME,"<LWD>",Y.LWD)
*
RETURN

*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
    
    Y.UDFILE = 'AMEX.FILES'
    SEL.CMD  = 'SGTRADESDOMICILE*':Y.LWD:'*.csv'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)

    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.TRADE.DTL.FINAL.ARR EQ '' THEN
                R.TRADE.DTL.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.TRADE.DTL.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
*Form header details
        DELIM = ","
        Y.UTS.HDR  = "Country Code":DELIM:"Account Type":DELIM:"Account Number":DELIM:"Settlement AC No":DELIM:"ID #":DELIM:
        Y.UTS.HDR  := "Account Holder Name":DELIM:"Order No.":DELIM:"Transaction Reference":DELIM:"Transaction Date":DELIM: ;*CPSGMIG-26838(s/e)
        Y.UTS.HDR  := "Order Date":DELIM:"Confirmation Date":DELIM:"Account Holder DOB":DELIM:"Order Transaction Type":DELIM:
        Y.UTS.HDR  := "Order Type":DELIM:"Transaction Status":DELIM:"Product Provider Code":DELIM:"Product Provider Name":DELIM:
        Y.UTS.HDR  := "Asset Code":DELIM:"Asset Name":DELIM:"Asset Currency":DELIM:"Order Settlement CCY":DELIM:"Order CCY":DELIM:
        Y.UTS.HDR  := "ISIN Code":DELIM:"Leverage Indicator (Y/N)":DELIM:"Transaction Amount":DELIM:"Referral ID":DELIM:"Closing ID":DELIM:
        Y.UTS.HDR  := "Settlement Date":DELIM:"Customer Price":DELIM:"Broker Price":DELIM:"Commission":DELIM:"Accrued Interest":DELIM:
        Y.UTS.HDR  := "Transaction Unit":DELIM:"Discount (%age)":DELIM:"SCB Charge (Amt CCY)":DELIM:"Confirm Asset Price":DELIM:
        Y.UTS.HDR  := "Account Opening Branch Code":DELIM:"Charge Percentage":DELIM:"Remarks":DELIM:"Payment Mode":DELIM:
        Y.UTS.HDR  := "GEN_LIEN_REASON_CODE":DELIM:"GEN_LIEN_REASON_DESC":DELIM:"Domicile Country":DELIM:
        Y.UTS.HDR  := 'Account Holder 1':DELIM:'Rel 1':DELIM:'EBBS REL ID 1':DELIM:'Mobile Phone 1':DELIM:
        Y.UTS.HDR  := 'Account Holder 2':DELIM:'Rel 2':DELIM:'EBBS REL ID 2':DELIM:'Mobile Phone 2':DELIM:
        Y.UTS.HDR  := 'Account Holder 3':DELIM:'Rel 3':DELIM:'EBBS REL ID 3':DELIM:'Mobile Phone 3':DELIM:
        Y.UTS.HDR  := 'Account Holder 4':DELIM:'Rel 4':DELIM:'EBBS REL ID 4':DELIM:'Mobile Phone 4':DELIM:
        Y.UTS.HDR  := 'ClientIdentifier':DELIM:'PrimaryAcctHolder':DELIM:"Account Open Date":DELIM:"Channel Info"
        R.TRADE.DTL.FINAL = Y.UTS.HDR
        R.TRADE.DTL.FINAL<-1> = R.TRADE.DTL.FINAL.ARR
        IF R.TRADE.DTL.FINAL THEN
            WRITE R.TRADE.DTL.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
        END
    END
RETURN

END
