$PACKAGE All.ScbRbPackage
***-----------------------------------------------------------------------------
* <Rating>-2</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.CUST.EXT.SELECT
* ----------------------------------------------------------------------------------------
**
* This SELECT routine is done as part of multiple elimination project for customer extract
* Select all the customer id to send the data to springwatch
* ----------------------------------------------------------------------------------------
**
* Modification History :- 
*--------------------------
* 18-Jul-2022 - Lavanya L - CPSGMIG-4230 - New routine
*							Copy of the existing routine B.SCB.RB.CUST.EXTRACT.SELECT for SG retail.
*
* 20-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
* --------------------------------------------------------------------------------------------------------------------------------------
**
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.RB.EDM.CUS.EXT.COMMON
*
*CPSGMIG-829 PVB/RB Customer Demarkation
    *SEL.CMD = 'SELECT ':FN.CUSTOMER

	IF ID.COMPANY[1,2] EQ 'SG' THEN
    		SEL.CMD = 'SELECT ':FN.CUSTOMER:' WITH L.O.B EQ ':Y.ALLOWED.LOB ;*CPSGMIG-1060 Select only Retail bank customers 
*CPSGMIG-13878(S)
*                SEL.CMD := " AND SECTOR EQ 23"
*CPSGMIG-13878(E)
	END ELSE
		SEL.CMD = 'SELECT ':FN.CUSTOMER
	END
*CPSGMIG-829 PVB/RB Customer Demarkation
*
    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
*
    IF SEL.LIST THEN
        CALL OCOMO("SEL.LIST before BATCH.BUILD.LIST: ":SEL.LIST)     ;* QC608 - S/E
        CALL BATCH.BUILD.LIST('',SEL.LIST)
        CALL OCOMO("SEL.LIST after BATCH.BUILD.LIST: ":SEL.LIST)      ;* QC608 - S/E
    END
*
RETURN
*
* ----------------------------------------------------------------------------------------
END
