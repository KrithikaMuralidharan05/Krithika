* @ValidationCode : MjotMzM2MDQ1NTM3OklTTy04ODU5LTE6MTY4MzEwNjE0MzY2NjoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 03 May 2023 14:59:03
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.LIEN.REP(YSAMID)
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14081 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       7 Mar 2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is the multi-threaded routine which generates the Lien Report
*-----------------------------------------------------------------------------
* Modification History :
* Date          Author           Description
* 11-Apr-2023   1663000          CPSGMIG-22842 - Include Position Migration flag column
* 03-May-2023   1663000          CPSGMIG-25189 - Include CurrNo>1 SAM in the report
* 22-May-2023   1648769          CPSGMIG-27284 - Asset name changes - To captured from SM>LR.UTS.INS.DESC, if value is empty in SM>LR.UTS.INS.DESC then display SM->DESC in the report.
* 07-Jun-2023   1648769          CPSGMIG-27390 - Changes;
*                                                 1. If SP>NOMINEE.CODE is 1 then default ESPD esle check SAM>LR.LIEN.CODE is value exist update else Check the 
*                                                 table SC.SCB.RB.BLOCK>selected portfolio record with SM and Depo combination.If record exist then pick the 
*                                                 value from SC.SCB.RB.BLOCK>LR.LIEN.CODE else the record should be removed from report extraction.
*                                                 2. Lien status should be updated as PLEDGED if any one of the above criteria point 1. is 
*                                                    met (NOMINEE.CODE/LR.LIEN.CODE from SAM or SC.SCB.RB.BLOCK)
*                                                 3. Lien Units - SECURITY.POSITION>VALUE.DATED.POSN ( Nominee code filter should be removed)
*                                                 4. Remarks, replace ',' to '' to not exceed to next columns.
*                                                 5. Lien Reason Description, replace ',' to '' to not exceed to next columns.
* 10-Jul-2023  1671073          CPSGMIG-32494     Column "Total Units/Holdings" is showing incorrect value in lien report because when the security code & security account is same , 
*                                                 value should be sum up instead showing in separate lines .
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_F.SCB.PORTFOLIO.REC.ACCT
    $INSERT I_B.SCB.RB.LIEN.REP.COMMON
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_F.SC.SCB.RB.BLOCK
*-----------------------------------------------------------------------------

    GOSUB CHECK.LOB.CONDITION

    IF Y.PROCEED.FLAG THEN
        GOSUB GET.CUS.SAM.DETS
        GOSUB DO.PROCESS
    END

RETURN
*------------------*
CHECK.LOB.CONDITION:
*------------------*

    Y.CUS.ID = '' ; Y.CUS.ID = FIELD(YSAMID,'-',1) ; R.CUST = '' ; CUS.ERR = ''
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUST,F.CUSTOMER,CUS.ERR)
    Y.CUS.LOB          = R.CUST<EB.CUS.LOCAL.REF,Y.CUS.LOB.POS>

    IF Y.CUS.LOB MATCHES Y.ALLOWED.LOB THEN
        Y.PROCEED.FLAG = '1'
    END ELSE
        Y.PROCEED.FLAG = ''
    END

RETURN
*---------*
DO.PROCESS:
*---------*

* Get Security Position based on Portfolio
    SEL.CMD    = "SELECT RECID FROM ":Y.VIEW.NAME:" WHERE SECURITY_ACCOUNT = '":YSAMID:"' ORDER BY SECURITY_NUMBER"
    SEL.CMD    = TRIM(SEL.CMD)

    TRANSLATE.QUERY = '' ; RESULT.SET = "" ; ERR.CODE   = "" ; ERR.MSG    = "" ; UNIQUE.ID = OPERATOR:"-":TNO:"-LIENREP-":TIME()
    CALL SCB.CALL.ORACLE.SQL(TRANSLATE.QUERY, UNIQUE.ID, SEL.CMD, RESULT.SET, ERR.CODE, ERR.MSG)

    Y.PREV.SECCODE = ''
    Y.SM.CNT       = 0                                            ;*CPSGMIG-25189

* Get Security Position based on Portfolio & Instrument wise
    LOOP
        REMOVE Y.SP.ID FROM RESULT.SET SETTING SP.POS
    WHILE Y.SP.ID : SP.POS
        Y.SP.SECCODE = '' ; Y.SP.SECCODE = FIELD(Y.SP.ID,'.',2)    ;* Get Instrument
        Y.SP.FLAG = ''    ; Y.SP.FLAG    = FIELD(Y.SP.ID,'.',4)          ;* Pledged Holding Flag

        IF (Y.PREV.SECCODE EQ Y.SP.SECCODE) OR (Y.PREV.SECCODE EQ '') THEN
            Y.SM.CNT += 1                                          ;*CPSGMIG-25189
            GOSUB GET.HOLDINGS
        END ELSE
            Y.CUR.SECCODE = Y.SP.SECCODE
            Y.SP.SECCODE  = Y.PREV.SECCODE
            GOSUB LIEN.CODE.WRITE  
         
            Y.SP.SECCODE = Y.CUR.SECCODE
            GOSUB RESET.VARIABLES
            GOSUB GET.HOLDINGS
            Y.SM.CNT += 1                                        ;*CPSGMIG-25189
        END
        Y.PREV.SECCODE = Y.SP.SECCODE
    REPEAT

    IF Y.SM.CNT THEN
        GOSUB LIEN.CODE.WRITE
    END  

RETURN
*--------------*
LIEN.CODE.WRITE:
*--------------*
      IF Y.SP.FLAG NE '1' THEN   
         GOSUB GET.LIEN.CODE.DESC
      END ELSE
          Y.LR.LIEN.CODE = 'ESPD'    
      END
      IF Y.LR.LIEN.CODE THEN
               R.SC.SCB.LIEN.CODE = ''  ;  Y.SC.SCB.LIEN.CODE.ERR = ''
               CALL F.READ(FN.SC.SCB.LIEN.CODE,Y.LR.LIEN.CODE,R.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE,Y.SC.SCB.LIEN.CODE.ERR)
               Y.LR.REMARKS = R.SC.SCB.LIEN.CODE<SC.SCBL.DESC>
               Y.LR.REMARKS  = EREPLACE(Y.LR.REMARKS, ",", " ")
               Y.LIEN.STATUS = "PLEDGED"
               GOSUB GET.SECURITY.DETS
               GOSUB WRITE.TO.FILE
      END

RETURN
*--------------*
RESET.VARIABLES:
*--------------*
    Y.SM.DESC    = '' ; Y.SM.CCY       = '' ; Y.SM.PRC       = '' ;  Y.LR.RET.DEPO  = ''  ;*CPSGMIG-22842-S/E
    Y.SM.PRC.DT  = '' ; 
    Y.UNIT.HLDG    = '' ; 
    Y.LIEN.UNITS   = '' ;  Y.LIEN.STATUS  = ''  ; Y.ISLAMIC.FLG = ''
    Y.NOM.CODE   = '' ; Y.LR.LIEN.CODE = '' ; Y.LR.REMARKS = ''
	Y.SM.CNT = 0

RETURN
*-----------*
GET.HOLDINGS:
*-----------*
    R.SECURITY.POSITION = '' ; SECURITY.POSITION.ERR = '' ; Y.NOM.CODE = ''
    CALL F.READ(FN.SECURITY.POSITION,Y.SP.ID,R.SECURITY.POSITION,F.SECURITY.POSITION,SECURITY.POSITION.ERR)

    Y.NOM.CODE     = R.SECURITY.POSITION<SC.SCP.NOMINEE.CODE>
    Y.UNIT.HLDG    += R.SECURITY.POSITION<SC.SCP.VALUE.DATED.POSN>
    IF Y.NOM.CODE EQ '1' THEN        
        Y.LIEN.UNITS   += R.SECURITY.POSITION<SC.SCP.VALUE.DATED.POSN>  
    END

RETURN
*----------------*
GET.SECURITY.DETS:
*----------------*

    R.SECURITY.MASTER = '' ; SM.ERR = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SP.SECCODE,R.SECURITY.MASTER,F.SECURITY.MASTER,SM.ERR)

    Y.SM.DESC     = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.UTS.DESC.POS>
    IF Y.SM.DESC EQ '' THEN
      Y.SM.DESC     = R.SECURITY.MASTER<SC.SCM.DESCRIPT>
    END
    Y.SM.CCY      = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
    Y.SM.PRC      = R.SECURITY.MASTER<SC.SCM.LAST.PRICE>
    Y.SM.PRC.DT   = R.SECURITY.MASTER<SC.SCM.DATE.LAST.PRICE>
    Y.LR.RET.DEPO = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.SM.RETDEPO.POS>
    Y.ISLAMIC.FLG = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.SM.ISLMSUK.POS>

    CHANGE @VM TO ' ' IN Y.SM.DESC
    CHANGE @SM TO ' ' IN Y.SM.DESC
    Y.SM.DESC  = EREPLACE(Y.SM.DESC, ",", " ")

 

    Y.VESTIMA      = 'N'                                  ;*CPSGMIG-22842-S/E
    IF Y.LR.RET.DEPO THEN                                     ;* Get Vestima
        CALL SCB.RB.VEST.FLAG(Y.LR.RET.DEPO,Y.VESTIMA)
    END

RETURN
*---------------*
GET.CUS.SAM.DETS:
*---------------*

* Customer Details
    Y.CUS.PRIMARY.HLDR = R.CUST<EB.CUS.LOCAL.REF,Y.CUS.LRPFOLIO.POS>
    Y.SECTOR           = R.CUST<EB.CUS.SECTOR>
    Y.STAFF.IND        = R.CUST<EB.CUS.LOCAL.REF,Y.CU.STAFFIND.POS>

    Y.CLIENT.IDENTIFIER = ""
    BEGIN CASE
        CASE Y.SECTOR EQ "21"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE Y.SECTOR EQ "51" AND Y.STAFF.IND EQ "Y"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE Y.SECTOR EQ "23"
            Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE

* SAM Details
    R.SEC.ACC.MASTER = '' ; SAM.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER,YSAMID,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,SAM.ERR)

    Y.POSMIG.DATE  = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.SAM.POSMIG.POS>    ;*CPSGMIG-22842 -S
    IF Y.POSMIG.DATE THEN
        Y.POSMIG.FLAG = 'Y'
    END ELSE
        Y.POSMIG.FLAG = 'N'
    END                                                                     ;*CPSGMIG-22842 -E

    Y.SAM.MAKER    = FIELD(R.SEC.ACC.MASTER<SC.SAM.INPUTTER,1>,'_',2,1)
    Y.SAM.CHECKER  = FIELD(R.SEC.ACC.MASTER<SC.SAM.AUTHORISER,1>,'_',2,1)
    Y.SAM.CURR.NO  = R.SEC.ACC.MASTER<SC.SAM.CURR.NO>
    Y.SAM.REMARKS  = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.SAM.LRREMAR.POS>
    CHANGE @SM TO '' IN Y.SAM.REMARKS
    Y.SAM.REMARKS  = EREPLACE(Y.SAM.REMARKS, ",", " ")

    Y.SAM.DATE.TM  = R.SEC.ACC.MASTER<SC.SAM.DATE.TIME,1>
    Y.SAM.DATE     = OCONV(ICONV(Y.SAM.DATE.TM[1,6],'D'),'D4/E')
    Y.SAM.DATE     = Y.SAM.DATE[7,4] :'/': Y.SAM.DATE[4,2]:'/':Y.SAM.DATE[1,2]

    Y.SAM.TIME     = Y.SAM.DATE.TM[7,2]:':':Y.SAM.DATE.TM[9,2]
    Y.SAM.DATE.TM  = '' ; Y.SAM.DATE.TM = Y.SAM.DATE:' ':Y.SAM.TIME

    CALL F.READ(FN.SCB.PORTFOLIO.REC.ACCT,YSAMID,R.SCB.PORTFOLIO.REC.ACCT,F.SCB.PORTFOLIO.REC.ACCT,SAM.PF.ERR)
    Y.SAM.SETT.ACCT = R.SCB.PORTFOLIO.REC.ACCT<REC.ACC.REC.WSA.ACC>
    Y.SAM.SETT.CCY  = R.SCB.PORTFOLIO.REC.ACCT<REC.ACC.REC.WSA.CCY>
    CONVERT @VM TO '|' IN Y.SAM.SETT.ACCT
    CONVERT @VM TO '|' IN Y.SAM.SETT.CCY

    IF Y.SAM.CURR.NO EQ "1" THEN
        Y.SAM.ACT.TYPE = "NEW"
    END ELSE
        Y.SAM.ACT.TYPE = "UPDATE"
    END

RETURN
*------------------*
GET.LIEN.CODE.DESC:
*------------------*
   IF Y.LR.LIEN.CODE EQ '' THEN
      Y.LR.LIEN.CODE = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.SAM.LIENCOD.POS>
      IF Y.LR.LIEN.CODE EQ '' THEN
         R.SC.SCB.RB.BLOCK = ''   ; Y.SC.SCB.RB.BLOCK.ERR = ''
         CALL F.READ(FN.SC.SCB.RB.BLOCK,Y.SP.ID,R.SC.SCB.RB.BLOCK,FN.SC.SCB.RB.BLOCK,Y.SC.SCB.RB.BLOCK.ERR)
         Y.LR.LIEN.CODE = R.SC.SCB.RB.BLOCK<RB.BLK.LR.LIEN.CODE>
      END
   END

RETURN
*------------*
WRITE.TO.FILE:
*------------*

    Y.SP.ARRAY  = Y.VESTIMA                  :','    ;* 1.  Vestima
    Y.SP.ARRAY := ''                         :','    ;* 2.  ID
    Y.SP.ARRAY := YSAMID                     :','    ;* 3.  Account
    Y.SP.ARRAY := ''                         :','    ;* 4.  Client
    Y.SP.ARRAY := Y.SP.SECCODE               :','    ;* 5.  Asset Code
    Y.SP.ARRAY := DQUOTE(Y.SM.DESC)          :','    ;* 6.  Asset Name
    Y.SP.ARRAY := Y.SM.CCY                   :','    ;* 7.  Currency
    Y.SP.ARRAY := Y.SM.PRC                   :','    ;* 8.  Last Price
    Y.SP.ARRAY := Y.SM.PRC.DT                :','    ;* 9.  Date Last Price
    Y.SP.ARRAY := Y.UNIT.HLDG                :','    ;* 10. Total Units/Holdings
    Y.SP.ARRAY := Y.LIEN.UNITS               :','    ;* 11. Lien Units
    Y.SP.ARRAY := Y.SAM.SETT.ACCT            :','    ;* 12. Settlement A/C No
    Y.SP.ARRAY := Y.SAM.SETT.CCY             :','    ;* 13. Settlement Currency
    Y.SP.ARRAY := Y.LR.LIEN.CODE             :','    ;* 14. Lien Reason Code
    Y.SP.ARRAY := DQUOTE(Y.LR.REMARKS)       :','    ;* 15. Lien Reason Description
    Y.SP.ARRAY := Y.LIEN.STATUS              :','    ;* 16. Lien Status
    Y.SP.ARRAY := Y.ISLAMIC.FLG              :','    ;* 17. Islamic Flag
    Y.SP.ARRAY := ''                         :','    ;* 18. Product Account Name
    Y.SP.ARRAY := Y.SAM.DATE.TM              :','    ;* 19. Update Date/Time
    Y.SP.ARRAY := Y.SAM.MAKER                :','    ;* 20. Maker ID
    Y.SP.ARRAY := Y.SAM.CHECKER              :','    ;* 21. Checker ID
    Y.SP.ARRAY := Y.SAM.ACT.TYPE             :','    ;* 22. Action Type
    Y.SP.ARRAY := Y.SAM.REMARKS              :','    ;* 23. Remark
    Y.SP.ARRAY := Y.CLIENT.IDENTIFIER        :','    ;* 24. ClientIdentifier
    Y.SP.ARRAY := Y.CUS.PRIMARY.HLDR         :','    ;* 25. Primary Account Holder
    Y.SP.ARRAY := Y.POSMIG.FLAG                      ;* 26. Position Migration Flag       ;*CPSGMIG-22842 -S/E

* Write to Temp File
    OPENSEQ AMEX.FILES,Y.RPT.AGENT.FILE TO FP.AMEX.FILES ELSE
    END
    WRITESEQ Y.SP.ARRAY APPEND TO FP.AMEX.FILES ELSE
        CALL OCOMO("Unable to Write temporary LIEN Report file")
    END
    CLOSESEQ FP.AMEX.FILES

RETURN
END