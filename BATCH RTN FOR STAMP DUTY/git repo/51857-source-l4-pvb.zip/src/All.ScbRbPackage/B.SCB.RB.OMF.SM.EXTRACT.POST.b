$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.OMF.SM.EXTRACT.POST
*--------------------------------------------------------------------------------------------
* Project Name  : CPSGMIG-309 - JEWEL_T24_PROJECT
* Developed By  : 1625136
* Developed On  : 03 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .POST Routine to merge SM temp files
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* 20241114 - ADO-6145440 - File transfer part handled in B.SCB.RB.OMF.SM.EXTRACT.CLOUD
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES

    GOSUB INITIALISE
	GOSUB PROCESS
*	GOSUB FILE.TRANSFER ;*ADO-6145440
	 
RETURN
*---------*
INITIALISE:
*---------*
	DL = '|'
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.SM.FILE.ID    = 'T24_SG_PCAT_File_'
	Y.TIMEDATE.STP = TIMEDATE()
*	Y.TIMESTAMP = TODAY:Y.TIMEDATE.STP[1,8]
	L.WORK.DATE=OCONV(DATE(),'D-') ;*MM-DD-YYYY
    Y.DATE = L.WORK.DATE[7,4]:L.WORK.DATE[1,2]:L.WORK.DATE[4,2]
    Y.TIMESTAMP = Y.DATE:Y.TIMEDATE.STP[1,8]
	CHANGE ":" TO "" IN  Y.TIMESTAMP
    Y.FINAL.FILE.ID = Y.SM.FILE.ID:Y.TIMESTAMP:".csv"
    
	Y.ARRAY = 'H':DL:Y.TIMESTAMP
	Y.ARRAY<-1> := "S":DL:"SCB_FundCode":DL:"SCB_FundName_EN":DL:"SCB_ISIN":DL:"SCB_FundClassCurrency":DL:"SCB_FundHouse_EN"
	Y.ARRAY := DL:"CutOffTime":DL:"FundDividendInstructionCode":DL:"TDS Global ID":DL:"Product Provider Code"
	Y.ARRAY := DL:"Subscription Allowed":DL:"Redemption Allowed":DL:"Transfer IN Allowed":DL:"Transfer OUT Allowed"
	Y.ARRAY := DL:"Switch IN allowed":DL:"Switch OUT allowed":DL:"Cancellation Allowed":DL:"Cash Allowed":DL:"OA"
	Y.ARRAY := DL:"SA":DL:"SRS":DL:"15"
	
RETURN
*---------------------------------------------------------------------------------------------------------------------------------
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.UTS.ARR = '' ; Y.FINAL.UTS.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
	Y.FILE.ID = 'RB_OMF_SG_PCAT_File_':Y.DATE
    SEL.CMD   = Y.FILE.ID:"*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.AMEX.FILE THEN
                R.ARRAY<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT
		Y.COUNT = DCOUNT(R.ARRAY,@FM)
		GOSUB GET.CHECKSUM
		Y.TRAILER = 'T':DL:Y.COUNT:DL:Y.HASH256SUM.VALUE:DL:Y.TIMESTAMP
		Y.ARRAY<-1> = R.ARRAY:@FM:Y.TRAILER
	    WRITE Y.ARRAY TO F.AMEX.FILES,Y.FINAL.FILE.ID
    END

RETURN
*-----------------------------------------------------------------------
GET.CHECKSUM:
*------------
*---Call Java API to get Hash256 Sum value ----*
    Y.INPUT.PARAM = R.ARRAY
    CHANGE @FM TO "" IN Y.INPUT.PARAM

    class_name = "com.hash.main.Sha256Utility"
    method_name = "sumValue"
    param = Y.INPUT.PARAM

    CALLJ class_name, method_name, param SETTING ret

    Y.HASH256SUM.VALUE = ret

*---Call Java API to get Hash256 Sum value ----*
RETURN
*-----------------------------------------------------------------------
FILE.TRANSFER:
*-------------
*
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''

    FLOW.IDENTIFER.ID = 'T24-RBSGOMF-SG'
 
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
    FILE.NAME = AMEXPATH
    RECORD.NAME = Y.FINAL.FILE.ID
    TARGET.FILE.NAME = Y.FINAL.FILE.ID

    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'')

RETURN
END