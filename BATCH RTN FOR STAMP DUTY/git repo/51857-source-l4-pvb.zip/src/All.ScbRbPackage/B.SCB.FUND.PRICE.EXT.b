$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FUND.PRICE.EXT(Y.SM.ID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13123 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       23 December 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Main Routine to extract price batch for iBanking from SECURITY.MASTER
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.PRICE.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 04-Apr-2023   1667095          CPSGMIG-23361 - Negative value fix in price
* 24-Apr-2023   1667095          CPSGMIG-24999 - Decimal value position increased for
*												 NAV price and offered price
* 06-Jun-2023   1648769          CPSGMIG-27441 - Adding retail SAT validation.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_B.SCB.FUND.PRICE.EXT.COMMON
    
    GOSUB INIT
    GOSUB PROCESS
RETURN
*-----------------------------------------------------------------------------
INIT:
*--------
    DETAIL.ID 	= "1" ; FUND.SHORT.NAME = ""
    FUND.CD 	= "" ;	CURRENCY = ""
    FUND.DT 	= "" ; 	NAV.PRICE = ""
    BID.PRICE 	= "" ; 	OFFERED.PRICE = ""
    Y.SM.REC	= "" ;  F.AMEX.FILES = ""
    
    
	
    
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*--------
    R.SECURITY.MASTER = '' ; SECURITY.MASTER.ERR = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,SECURITY.MASTER.ERR)

    Y.SUB.ASSET.TYPE = ''
    Y.SUB.ASSET.TYPE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
    
    GOSUB VAILD.SAT
    IF Y.ASSET.FLAG EQ '1' THEN
*CPSGMIG-24999(S)
    Y.ASSET.NAME = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.UTS.INS.DESC.POS>
	CONVERT @SM TO '' IN Y.ASSET.NAME
	IF NOT(Y.ASSET.NAME) THEN
        Y.ASSET.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME,1>
    END
    FUND.SHORT.NAME = Y.ASSET.NAME[1,50]

*CPSGMIG-24999(E)

	CURRENCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
	FUND.DT =     R.SECURITY.MASTER<SC.SCM.DATE.LAST.PRICE>
    BOND.OR.SHARE = R.SECURITY.MASTER<SC.SCM.BOND.OR.SHARE>
    LAST.PRICE = R.SECURITY.MASTER<SC.SCM.LAST.PRICE>
    IF BOND.OR.SHARE EQ 'B' THEN
        NAV.PRICE = LAST.PRICE/100
    END ELSE
        NAV.PRICE = LAST.PRICE
    END

*CPSGMIG-23361(S)
    IF NAV.PRICE[1,1] EQ '-' THEN
        NAV.PRICE = ABS(NAV.PRICE)
        NAV.PRICE = FMT(NAV.PRICE,"R6%13") ;*CPSGMIG-24999(S/E)
        NAV.PRICE = EREPLACE(NAV.PRICE,'.','')
        NAV.PRICE = '-':NAV.PRICE
    END ELSE
        NAV.PRICE = FMT(NAV.PRICE,"R6%14") ;*CPSGMIG-24999(S/E)
        NAV.PRICE = EREPLACE(NAV.PRICE,'.','')
    END
*CPSGMIG-23361(E)
    OFFERED.PRICE = NAV.PRICE
    BID.PRICE = '0'
*
       Y.SM.REC = FMT(DETAIL.ID,"1' 'L"):FMT(Y.SM.ID,"10' 'L"):FMT(FUND.SHORT.NAME,"50' 'L"):FMT(CURRENCY,"3' 'L"):
       Y.SM.REC := FMT(FUND.DT,"8' 'L"):NAV.PRICE:OFFERED.PRICE:FMT(BID.PRICE,"R%11")

    IF Y.SM.REC THEN
        OPENSEQ AMEX.FILES,FILE.NAME TO F.AMEX.FILES ELSE CREATE F.AMEX.FILES ELSE
            CALL OCOMO("Error opening ":FILE.NAME)
        END
        GOSUB WRITE.AMEX.FILE
*
        CLOSESEQ F.AMEX.FILES
*
    END
  END
RETURN

*-----------------------------------------------------------------------------
WRITE.AMEX.FILE:
*---------------
	WRITESEQ Y.SM.REC APPEND TO F.AMEX.FILES ELSE
        CALL FATAL.ERROR('Unable to write ':F.AMEX.FILES)
    END
RETURN
*----------------------------------------------------------------------------
VAILD.SAT:
*---------
     Y.ASSET.FLAG = ''
     BEGIN CASE
     CASE (Y.SUB.ASSET.TYPE MATCHES Y.MF.SAT.ARRAY)
            Y.ASSET.FLAG = '1'
     CASE (Y.SUB.ASSET.TYPE MATCHES Y.SN.SAT.ARRAY)
            Y.ASSET.FLAG = '1'
     CASE (Y.SUB.ASSET.TYPE MATCHES Y.FI.SAT.ARRAY)
            Y.ASSET.FLAG = '1'
     END CASE

RETURN
END
