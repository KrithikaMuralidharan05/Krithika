$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.PROCEEDS.POST
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-PROCEEDS-<start.date>-<end.date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.GTCP.PROCEEDS.COMMON
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
    Y.FINAL.FILE.NAME = '' ; R.GTCP.PROCEEDS.FINAL.ARR = ''
    Y.FINAL.FILE.NAME = 'MFU-T24-PROCEEDS-XX-':Y.START.DATE:'-':Y.END.DATE:'.csv'
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = ID.COMPANY[1,2]:'*-MFU-PROCEEDS-*':TODAY:'.txt*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.GTCP.PROCEEDS.FINAL.ARR EQ '' THEN
                R.GTCP.PROCEEDS.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.GTCP.PROCEEDS.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
		
		Y.PROCEEDS.HEADER  = 'SRC_TRAN_ID,client_id,client_name,ACCT_HOST_NUM,TRAN_CURY_CD,CUST_HOST_NUM,core_banking_rel_number_secondary_1,'
		Y.PROCEEDS.HEADER := 'core_banking_rel_number_secondary_2,core_banking_rel_number_secondary_3,isin_code,stock_fund_name,market,MKT_PRC,'
		Y.PROCEEDS.HEADER := 'fund_code,fund_name,exchangee,instrument_id,instrument_name,client_segment_code,customer_segment_description,'
		Y.PROCEEDS.HEADER := 'TRAN_DT,SETLM_DT,NUM_OF_UNIT,currency,TRAN_CURY_CD,GRS_AMT,NET_AMT,ACR_INT_AMT,settlement_account_number,DR_CR_CD,'
		Y.PROCEEDS.HEADER := 'security_type,CORP_ACTN_TYPE,TRAN_TYPE,security_issuer_country,ssa_account_number,DATA_SRC_CTRY_CD,DATA_SRC_SYS_NM,W_SNAPSHOT_DT'
		
		R.GTCP.PROCEEDS.FINAL = Y.PROCEEDS.HEADER:@FM:R.GTCP.PROCEEDS.FINAL.ARR
		WRITE R.GTCP.PROCEEDS.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
    END
*
RETURN
*-----------------------------------------------------------------------------
END
