* @ValidationCode : MjozMDgyNDAzMDU6SVNPLTg4NTktMToxNjgyMzMzNzE2OTUxOjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 24 Apr 2023 16:25:16
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.LIEN.REP.POST
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14081 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       7 Mar 2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is the multi-threaded routine which generates the Consolidated Lien Report
*-----------------------------------------------------------------------------
* Modification History :
* Date          Author           Description
* 11-Apr-2023   1663000          CPSGMIG-22842 - Include Position Migration flag column
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename Change
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
	GOSUB PROCESS

RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.DATA = BATCH.DETAILS<3,1>
    CONVERT @SM TO @FM IN Y.DATA
    
    MTH.DAILY.FLAG    = FIELD(Y.DATA,'*', 1)   ;* Contain the value as Daily or Monthly
    Y.LIEN.FINAL.FILE = FIELD(Y.DATA,'*', 2)

    Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)                         ;* CPSGMIG-21498
    Y.LIEN.FINAL.FILE = EREPLACE(Y.LIEN.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
    
RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; Y.LIEN.ARR = '' ; Y.FINAL.LIEN.ARR = '' ; Y.SEL.FILE = ''
*
    IF MTH.DAILY.FLAG EQ 'D' THEN
        SEL.CMD = 'LIENREPORTDAILY-':TODAY:"-*.csv*"
    END ELSE
        SEL.CMD = 'LIENREPORTMONTHLY-':TODAY:"-*.csv*"
    END
    
    Y.UDFILE  = 'AMEX.FILES'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(Y.LIEN.ARR) THEN
                Y.LIEN.ARR = R.AMEX.FILE
            END ELSE
                Y.LIEN.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

        IF Y.LIEN.ARR THEN
            Y.REC.CNT = DCOUNT(Y.LIEN.ARR,@FM)

            Y.LIEN.HDR  = "Vestima,ID,Account,Client,Asset Code,Asset Name,Currency,Price,Price Date,Total Units/Holdings,Lien Units,"
            Y.LIEN.HDR := "Settlement A/C No,Settlement Currency,Lien Reason Code,Lien Reason Description,Lien Status,Islamic Flag,"
            Y.LIEN.HDR := "Product Account Name,Update Date/Time,Maker ID,Checker ID,Action Type,Remark,ClientIdentifier,PrimaryAcctHolder,Position Migration Flag"      ;*CPSGMIG-22842 -S/E
            
            Y.FINAL.LIEN.ARR = Y.LIEN.HDR :@FM: Y.LIEN.ARR     ;* Final File
    
            WRITE Y.FINAL.LIEN.ARR TO F.AMEX.FILES,Y.LIEN.FINAL.FILE
        END ELSE
            CALL OCOMO("Data not available . Hence LIEN Report not generated")
        END
    END

RETURN
END