$PACKAGE All.ScbRbPackage
*
*Implementation of All.ScbRbPackage.bScbRsgIcmReconAttMatch
*Developed by:- Pawan kr(1668106)
*Description:- recon to be done on ICM for certain data fields like address type and using unmatched file
*              create 1 files each for PARTY table and CUSTOMER table.
*Jira ref:-CPSGMIG-17414

SUBROUTINE B.SCB.RSG.ICM.RECON.ATT.MATCH
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT


    GOSUB INIT ; *
    GOSUB PROCESS ; *
    GOSUB FILE.WRITE
RETURN

*-----------------------------------------------------------------------------

*** <region name= INIT>
INIT:
*** <desc> </desc>
    FN.DATA.IN = "DATA.IN"
    F.DATA.IN = ""
    CALL OPF(FN.DATA.IN,F.DATA.IN)
*
    Y.ATT.ID =BATCH.DETAILS<3,1,1>
*
    FN.REL.CONCAT = "F.ST.SCB.RSG.EBBS.REL.CONCAT"
    F.REL.CONCAT =""
    CALL OPF(FN.REL.CONCAT,F.REL.CONCAT)
    Y.DATE =OCONV(DATE(),'D4-')
    Y.TIME = TIMEDATE()
    DATE.TIME = Y.DATE[7,4]:Y.DATE[1,2]:Y.DATE[4,2]:Y.TIME[1,2]:Y.TIME[4,2]
    
RETURN
*** </region>

*-----------------------------------------------------------------------------

*** <region name= PROCESS>
PROCESS:
*** <desc> </desc>
    CALL F.READ(FN.DATA.IN,Y.ATT.ID,R.DATA.IN,F.DATA.IN,DATA.ERR)
    Y.DATA.CNT = DCOUNT(R.DATA.IN,@FM)

    Y.ICM.ATT = "ICM.ATT-":DATE.TIME
    REL.ARR =""
    FOR I =2 TO Y.DATA.CNT
       
    
        Y.REL.ID = FIELD(R.DATA.IN<I>,"|",1)
        Y.FLD.ID = FIELD(R.DATA.IN<I>,"|",2)
        Y.ICM.VAL = FIELD(R.DATA.IN<I>,"|",3)
        Y.T24.VAL = FIELD(R.DATA.IN<I>,"|",4)
        Y.TMP.ARR = ""
        Y.ADD.CODE = ""
        Y.W8 = ""
        Y.W9 = ""
        Y.NATIONALITY = ""
        Y.US.PERSON = ""
        Y.W8.EXP.DATE = ""
    	Y.W9.EXP.DATE = ""
	
        LOCATE Y.REL.ID IN REL.ARR SETTING REL.POS THEN
           
            Y.TMP.ARR = Y.SUCC.ARR<REL.POS>
            Y.W8 = FIELD(Y.TMP.ARR,"|",2)
            Y.W8.EXP.DATE = FIELD(Y.TMP.ARR,"|",3)
            Y.W9 = FIELD(Y.TMP.ARR,"|",4)
	        Y.W9.EXP.DATE = FIELD(Y.TMP.ARR,"|",5)
            Y.NATIONALITY = FIELD(Y.TMP.ARR,"|",6)
            Y.US.PERSON = FIELD(Y.TMP.ARR,"|",7)
            
          
            IF Y.FLD.ID EQ "W8 Flag" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.W8 = "N"
                END ELSE
                    Y.W8 = Y.ICM.VAL
                END
                Y.SUCC.ARR<REL.POS> = Y.REL.ID:"|":Y.W8:"|":Y.W8.EXP.DATE:"|":Y.W9:"|":Y.W9.EXP.DATE:"|":Y.NATIONALITY:"|":Y.US.PERSON:"|":Y.ICM.ATT

            END
	     
            IF Y.FLD.ID EQ "W8 Exp Date" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.W8.EXP.DATE = "NULL"
                END
                ELSE
                    Y.W8.EXP.DATE = Y.ICM.VAL
                END
                Y.SUCC.ARR<REL.POS> = Y.REL.ID:"|":Y.W8:"|":Y.W8.EXP.DATE:"|":Y.W9:"|":Y.W9.EXP.DATE:"|":Y.NATIONALITY:"|":Y.US.PERSON:"|":Y.ICM.ATT

            END

            IF Y.FLD.ID EQ "W9 Flag" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.W9 = "N"
                END ELSE
                    Y.W9 = Y.ICM.VAL
                END
                Y.SUCC.ARR<REL.POS> = Y.REL.ID:"|":Y.W8:"|":Y.W8.EXP.DATE:"|":Y.W9:"|":Y.W9.EXP.DATE:"|":Y.NATIONALITY:"|":Y.US.PERSON:"|":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "W9 Exp Date" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.W9.EXP.DATE = "NULL"
                END
                ELSE
                    Y.W9.EXP.DATE = Y.ICM.VAL
                END
                Y.SUCC.ARR<REL.POS> = Y.REL.ID:"|":Y.W8:"|":Y.W8.EXP.DATE:"|":Y.W9:"|":Y.W9.EXP.DATE:"|":Y.NATIONALITY:"|":Y.US.PERSON:"|":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "Nationality" THEN
                Y.NATIONALITY = Y.ICM.VAL
                Y.SUCC.ARR<REL.POS> = Y.REL.ID:"|":Y.W8:"|":Y.W8.EXP.DATE:"|":Y.W9:"|":Y.W9.EXP.DATE:"|":Y.NATIONALITY:"|":Y.US.PERSON:"|":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "US Person" THEN
                
                Y.US.PERSON  = Y.ICM.VAL
               
                Y.SUCC.ARR<REL.POS> =  Y.REL.ID:"|":Y.W8:"|":Y.W8.EXP.DATE:"|":Y.W9:"|":Y.W9.EXP.DATE:"|":Y.NATIONALITY:"|":Y.US.PERSON:"|":Y.ICM.ATT
            END
*
        END
        ELSE
            REL.ARR<-1> = Y.REL.ID
                
                   
            IF Y.FLD.ID EQ "W8 Flag" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.ICM.VAL = "N"
                END
                Y.SUCC.ARR<-1> =  Y.REL.ID :"|":Y.ICM.VAL:"||||||":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "W8 Exp Date" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.ICM.VAL = "NULL"
                END
                Y.SUCC.ARR<-1> =  Y.REL.ID :"||":Y.ICM.VAL:"|||||":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "W9 Flag" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.ICM.VAL = "N"
                END
                Y.SUCC.ARR<-1> =  Y.REL.ID :"|||":Y.ICM.VAL:"||||":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "W9 Exp Date" THEN
                IF Y.ICM.VAL EQ "" THEN
                    Y.ICM.VAL = "NULL"
                END
                Y.SUCC.ARR<-1> =  Y.REL.ID :"||||":Y.ICM.VAL:"|||":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "Nationality" THEN
                Y.SUCC.ARR<-1> =  Y.REL.ID :"|||||":Y.ICM.VAL:"||":Y.ICM.ATT
            END
            IF Y.FLD.ID EQ "US Person" THEN
                
                Y.SUCC.ARR<-1> =  Y.REL.ID :"||||||":Y.ICM.VAL:"|":Y.ICM.ATT
            END
          
        END
        CALL OCOMO(I:" number of records processed for dmd load file creation")
    NEXT I
   
RETURN
*** </region>
*-------------------------------------------
*------------------------------
FILE.WRITE:
*---------------------
    Y.PARTY.FILE.ID = "SCB.ICM.PARTY.RECON.ATT.txt"
   
    CALL F.WRITE(FN.DATA.IN,Y.PARTY.FILE.ID,Y.SUCC.ARR)
   
RETURN
**********
END