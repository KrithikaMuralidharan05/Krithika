$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EBBS.FILE.PROCESS.SELECT

* This is BATCH routine which is attached to the SNG/SCB.EBBS.FILE.PROCESS. This routine
* select the EBBS incoming file which is available in T24 environment.
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
* 10-Apr-2022		Jaheer Hussain		- CPSGMIG-1490     - Development
*
* 05-Sep-2022 - kalaikumaranp - CPSGMIG-1490  - EBBS file processing
*
* 12-Jun-2023 - Rajesh,V - PVBCOREBAU-8129 - BB clients statements are not generated, issue
*                                            has been fixed by introducing dependency
*                                            between incoming feed and statement generation.
*                                            This dependency is acheived by adding logic to
*                                            put Wait the file process execution until
*                                            the EBBS file arrived
*
*-------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.SECURITY.MASTER
	$INSERT I_F.SC.TRANS.NAME
	$INSERT I_F.SECURITY.TRANSFER
	$INSERT I_F.CUSTOMER
	$INSERT I_F.SCB.EBBS.FILE.PARAM
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_F.SCB.EBBS.FILE.PROCESS.COMMON
	
	GOSUB PROCESS.PARA
 
RETURN
*----------------------------------------------------------------------------*
PROCESS.PARA:
*************
*SEL.CMD = "SELECT ":INFILE.PATH:" LIKE ...EBBS...STMT..."
*
* PVBCOREBAU-8129 - Start
	SEL.CMD = "SELECT ":INFILE.PATH
	CALL EB.READLIST(SEL.CMD, SEL.LIST.EBBS,'',SEL.REC.EBBS,FILE.ERR.EBBS)
*
	IF SEL.LIST.EBBS NE '' THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST.EBBS)
    END ELSE
        CALL OCOMO("EBBS File Not Arrived")
        SLEEP 60
        GOTO PROCESS.PARA
    END
* PVBCOREBAU-8129 - End
*
RETURN
*----------------------------------------------------------------------------*
END