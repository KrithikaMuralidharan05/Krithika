$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------

SUBROUTINE B.SCB.RB.ODS.PORTFOL.EXT.LOAD
*******************************************************************************
*ORA-MT-CHG : For oracle performance the job AEB.CLS.DLRPT in the batch  "XXX/ZZX.SCB.SC.BATCH.REP "
*is modified as multi thread routine .
**--------------------------------------------------
*Modification History:
************************
* 16-Sep-2022 - CPSGMIG-5533 - Lavanya L - Copy of the existing routine AEB.CLS.DLRPT.SELECT
* 01/05/2025 - 1386007 - Haris - Made the routine online by modifing the date.
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SC.POS.ASSET
    $INSERT I_F.CUSTOMER
    $INSERT I_F.DATES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_B.SCB.RB.ODS.PORTFOL.EXT.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER          ;* RMWB_Client_Portfolio_S/E
***Recon_Report**** Start
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
***Recon_Report**** End

*Enable-1.2-CR-Start
    $INSERT I_F.CUSTOMER.STATUS
*Enable-1.2-CR-End

    GOSUB INITIALISE
    GOSUB OPEN.ALL.FILES

RETURN
*
*-----------------------------------------------------------------------------
*
***********
INITIALISE:
***********
*1386007-S	
	FN.DATES='F.DATES'
	F.DATES=''
	CALL OPF(FN.DATES,F.DATES)
	CALL F.READ(FN.DATES,ID.COMPANY,R.DATES.REC,F.DATES,DATE.ERR)
	Y.TODAY=R.DATES.REC<EB.DAT.LAST.WORKING.DAY>
*1386007-E
*   FILE.NAME = "ACCTPRTFL-":TODAY:".txt"			;*CPSGMIG-5533 - S/E
   FILE.NAME = "ACCTPRTFL-":Y.TODAY:".txt"			;*CPSGMIG-5533 - S/E
    BK.CENT = ID.COMPANY[1,2]
                                     ;* CM0000000578880 E

    FILE.NAME := ".":SESSION.NO

    SEC.POS.ASST.EXT = ''
    ASST.EXT.HDR = ''
    DL = '|'
    SP.CNT = 0

RETURN
*-----------------------------------------------------------------------------
*
OPEN.ALL.FILES:
***************

*
    FN.SC.POS.ASSET = 'F.SC.POS.ASSET' ; FP.SC.POS.ASSET = '' ; R.SC.POS.ASSET = ''
    CALL OPF(FN.SC.POS.ASSET,FP.SC.POS.ASSET)
*
    FN.CUSTOMER = 'F.CUSTOMER' ; FP.CUSTOMER = '' ; R.CUSTOMER = '' ;
    CALL OPF(FN.CUSTOMER,FP.CUSTOMER)
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER' ; FP.SECURITY.MASTER = '' ; R.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,FP.SECURITY.MASTER)
*
    FN.SAT = 'F.SUB.ASSET.TYPE' ; FP.SAT = '' ; R.SAT = ''
    CALL OPF(FN.SAT,FP.SAT)

    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
	
	FN.AEB.SEC.PAR = 'F.AEB.SEC.PAR'
	F.AEB.SEC.PAR = ''
	CALL OPF(FN.AEB.SEC.PAR,F.AEB.SEC.PAR)

    APP.NAME   = 'FOREX':@FM:'CUSTOMER':@FM:'SECURITY.MASTER':@FM:'DEPT.ACCT.OFFICER'			;**CPSGMIG-5533 - S/E
    FIELD.NAME = 'TYPE.OF.FOREX'
	FIELD.NAME := @FM:'L.O.B':@VM:'CLIENT.RISK'			;**CPSGMIG-5533 - S/E
	FIELD.NAME := @FM:'PR.ASSET.CLASS':@VM:'MIN.CONTRB.AMT'
	FIELD.NAME := @FM:'LOCATION'

    FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(APP.NAME, FIELD.NAME, FIELD.POS)
    TYPE.OF.FOREX.POS = FIELD.POS<1,1>
	
*CPSGMIG-5533 - S
	LOB.POS = FIELD.POS<2,1>
	LOCAL.REF.CLIENT.RISK = FIELD.POS<2,2>
	LOCAL.REF.AS.CLASS = FIELD.POS<3,1>
	MIN.CONTRB.AMT.POS = FIELD.POS<3,2>
	LOCAL.REF.LOCATION = FIELD.POS<4,1>
*OPICSDECOMM E

	Y.PARAM.ID    = 'SCB.CUST.SEG'	
    Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
    Y.ALLOWED.LOB = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
*CPSGMIG-5533 - E
RETURN
END
