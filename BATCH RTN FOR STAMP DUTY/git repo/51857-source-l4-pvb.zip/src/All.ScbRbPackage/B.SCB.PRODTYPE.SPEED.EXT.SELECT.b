$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.PRODTYPE.SPEED.EXT.SELECT
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 27/04/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> eSpeed
*						RBSG_ESPEED_PRODTYPE_YYYYMMDD.txt
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.PRODTYPE.SPEED.EXT.COMMON
*
    GOSUB SEL.PROCESS
*
RETURN
*-----------------------------------------------------------------------------
SEL.PROCESS:
*-----------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SUB.ASSET.TYPE
*
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
END
