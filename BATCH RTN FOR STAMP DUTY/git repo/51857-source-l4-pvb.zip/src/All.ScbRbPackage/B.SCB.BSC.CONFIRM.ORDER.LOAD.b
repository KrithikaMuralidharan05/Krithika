* @ValidationCode : MjotMTQ1ODk1NjE4MTpJU08tODg1OS0xOjE2NzY1NDE0MTkxMjA6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 16 Feb 2023 15:26:59
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.BSC.CONFIRM.ORDER.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17784
* Developed By                   :       1663000
* Developed On                   :       02-Feb-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* LOAD Routine to generate Extract file of BSC Confirmed Order Report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 16-Feb-2023   1663000          CPSGMIG-14085 - Column addition UTS data with DOB for all account holders
* 22-May-2023   1648769          CPSGMIG-27284 - Asset name changes - To captured from SM>LR.UTS.INS.DESC, if value is empty in SM>LR.UTS.INS.DESC then display SM->DESC in the report.
* 23-Jun-2023   1648769          CPSGMIG-29355 - Changes;
*                                                 1. If SP>NOMINEE.CODE is 1 then default ESPD esle check SAM>LR.LIEN.CODE is value exist update else Check the 
*                                                 table SC.SCB.RB.BLOCK>selected portfolio record with SM and Depo combination.If record exist then pick the 
*                                                 value from SC.SCB.RB.BLOCK>LR.LIEN.CODE else LR.LIEN.CODE and LIEN remarks values should be left Blank.
*                                                 2. Lien Remarks, replace ',' to '' to not exceed to next columns.
* 19-Jul-2023   1670271          CPSGMIG-31049 -  LR.CLOSING.ID & LR.REFERAL.ID is taken from SOO application instead of SEC.TRADE application for MF product.
* 29-Sep-2023   1670271          CPSGMIG-34479 - Reports - Mapping Change
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_BATCH.FILES
    $INSERT I_F.POSITION.TRANSFER
    $INSERT I_B.SCB.BSC.CONFIRM.ORDER.COMMON
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB OPENFILES
   
RETURN
*---------*
INITIALISE:
*---------*
  
* Get LOB Value by Segment
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)

* Get LRT Position
    Y.APP.NAME  = 'CUSTOMER' :@FM: 'SEC.OPEN.ORDER' :@FM: 'SEC.ACC.MASTER' :@FM: 'SEC.TRADE' :@FM: 'SECURITY.TRANSFER' :@FM: 'SECURITY.MASTER'
    Y.FLD.NAME<1> = 'L.O.B':@VM:'LR.EBBS.REL':@VM:'REL.CIF.NO':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM: 'LR.SIGN.MANDATE' ;*CPSGMIG-14085
    Y.FLD.NAME<2> = 'LR.RSP.REF':@VM:'LR.REFERRAL.ID':@VM:'LR.CLOSING.ID'
    Y.FLD.NAME<3> = 'LR.LIEN.CODE'
    Y.FLD.NAME<4> = 'LR.CLOSING.ID':@VM:'LWM.EDP.REF.NUM':@VM:"LR.OMF.REF.NO":@VM:"TAP.REF.NO":@VM:'LR.REFERRAL.ID' ;*CPSGMIG-14085
    Y.FLD.NAME<5> = 'RMPSID':@VM:'LWM.EDP.REF.NUM'
    Y.FLD.NAME<6> = 'LR.UTS.INS.DESC'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
    
*Customer LRT
    Y.LOB.POS           = Y.FLD.POS<1,1>
    Y.LR.EBBS.REL.POS   = Y.FLD.POS<1,2>
    Y.REL.CIF.NO.POS    = Y.FLD.POS<1,3>
    Y.LR.STAFF.IND.POS  = Y.FLD.POS<1,4>
    Y.LR.PFOLIO.KEY.POS = Y.FLD.POS<1,5>
    Y.LR.SIGN.MANDT.POS = Y.FLD.POS<1,6> ;* CPSGMIG-14085
    
*SOO LRT
    Y.LR.RSP.REF.POS   = Y.FLD.POS<2,1>
    Y.REFERRAL.ID.POS = Y.FLD.POS<2,2>	 
    Y.LR.CLOSING.ID.POS.SO = Y.FLD.POS<2,3>
    
*SAM LRT
    Y.LR.LIEN.CODE.POS = Y.FLD.POS<3,1>
    
*Sec Trade LRT
    Y.LR.ORD.CLOSE.ID.POS = Y.FLD.POS<4,1>
    Y.LWM.EDP.REF.NUM.POS = Y.FLD.POS<4,2>
    Y.LR.OMF.REF.NO.POS   = Y.FLD.POS<4,3>
    Y.TAP.REF.NO.POS      = Y.FLD.POS<4,4>
    Y.LR.REF.POS          = Y.FLD.POS<4,5>  ;* CPSGMIG-14085
    
*Security Transfer LRT
    Y.ST.RMPSID.POS          = Y.FLD.POS<5,1>
    Y.LWM.EDP.REF.NUM.ST.POS = Y.FLD.POS<5,2>

*Security Master LRT
    Y.LR.UTS.DESC.POS = Y.FLD.POS<6,1>
    
RETURN
*--------*
OPENFILES:
*--------*
           
    FN.SEC.TRADE             = 'F.SEC.TRADE'             ; F.SEC.TRADE              = '' ; CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    FN.SEC.TRADE.HIS         = 'F.SEC.TRADE$HIS'         ; F.SEC.TRADE.HIS          = '' ; CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)
    FN.SECURITY.TRANSFER     = 'F.SECURITY.TRANSFER'     ; F.SECURITY.TRANSFER      = '' ; CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
    FN.SECURITY.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS' ; F.SECURITY.TRANSFER.HIS  = '' ; CALL OPF(FN.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS)
    FN.SEC.OPEN.ORDER        = 'F.SEC.OPEN.ORDER'        ; F.SEC.OPEN.ORDER         = '' ; CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    FN.SEC.OPEN.ORDER.HIS    = 'F.SEC.OPEN.ORDER$HIS'    ; F.SEC.OPEN.ORDER.HIS     = '' ; CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
   
    FN.CUSTOMER              = 'F.CUSTOMER'              ; F.CUSTOMER              = '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SC.TRANS.NAME         = 'F.SC.TRANS.NAME'         ; F.SC.TRANS.NAME         = '' ; CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
    FN.SECURITY.MASTER       = 'F.SECURITY.MASTER'       ; F.SECURITY.MASTER       = '' ; CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SUB.ASSET.TYPE        = 'F.SUB.ASSET.TYPE'        ; F.SUB.ASSET.TYPE        = '' ; CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
    FN.DEPT.ACCT.OFFICER     = 'F.DEPT.ACCT.OFFICER'     ; F.DEPT.ACCT.OFFICER     = '' ; CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)
    FN.SEC.ACC.MASTER        = 'F.SEC.ACC.MASTER'        ; F.SEC.ACC.MASTER        = '' ; CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    FN.SC.SCB.LIEN.CODE      = 'F.SC.SCB.LIEN.CODE'      ; F.SC.SCB.LIEN.CODE      = '' ; CALL OPF(FN.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE)
    FN.SCB.SEC.TRADES.ALLDAY = 'F.SCB.SEC.TRADES.ALLDAY' ; F.SCB.SEC.TRADES.ALLDAY = '' ; CALL OPF(FN.SCB.SEC.TRADES.ALLDAY,F.SCB.SEC.TRADES.ALLDAY)
    FN.SC.SCB.RB.BLOCK        = 'F.SC.SCB.RB.BLOCK'        ; F.SC.SCB.RB.BLOCK        = '' ; CALL OPF(FN.SC.SCB.RB.BLOCK,F.SC.SCB.RB.BLOCK)
    FN.SECURITY.POSITION      = 'F.SECURITY.POSITION'      ; F.SECURITY.POSITION      = '' ; CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)
    FN.SCB.WM.H.LOCAL.PARAM   = 'F.SCB.WM.H.LOCAL.PARAM'  ; F.SCB.WM.H.LOCAL.PARAM 	= ''  ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
	
    CALL SCB.GET.ORACLE.VIEWNAME(FN.SECURITY.POSITION,Y.VIEW.NAME)   ;* Get Security Position View Name
   
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE = "SCBBSCCONFREPORT-":TODAY:"-":SESSION.NO:".csv"
	
    R.SCB.H.LOCAL.PARAM = '' ; ERR.SCB.WM.H.LOCAL.PARAM = '' ; Y.ALLOWED.SEGMENT = '' ; Y.ALLOWED.SAT.LIST = '' 
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,"SCB.CRES.SAT",R.SCB.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOCAL.PARAM)
    Y.ALLOWED.SEGMENT = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.ALLOWED.SAT.LIST  = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
	
	Y.SEG.POS = ''; Y.FI.SAT.CODES = ''
    LOCATE "FI" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.FI.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.FI.SAT.CODES
    END 
    
RETURN
END