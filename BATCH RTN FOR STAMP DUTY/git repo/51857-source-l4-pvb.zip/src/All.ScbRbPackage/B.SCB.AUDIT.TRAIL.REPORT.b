$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.AUDIT.TRAIL.REPORT(SAMID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-374 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       06 January 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Main Routine to extract Audit Trail report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.AUDIT.TRAIL.REPORT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 25-Apr-2023 - CPSGMIG-19027 & 22843  1667095 - Additional Columns Included
* 22-May-2023 - CPSGMIG-27275		   1667095 - Updated mapping for POS.MIG.FLG
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.AUDIT.TRAIL.REPORT.COMMON
    
*
    GOSUB INIT
    GOSUB PROCESS

*
RETURN
*---------------------
INIT:
*---------------------
    PORTFOLIO.NAME	= '' ; PORTFOLIO.STATUS = ''
    ADDRESS.LINE.1 	= '' ; ADDRESS.LINE.2 	= ''
    ADDRESS.LINE.3 	= '' ; ADDRESS.LINE.4 	= ''
    POSTAL.CODE 	= '' ; COUNTRY = '' ; CITY = ''
    STATE 			= '' ; Y.CLIENT.IDENTIFIER = ''
    PRIMARY.ACCT.HOLDER = '' ; Y.ADVICE.INDEX = ''
    Y.CLIENT.NRC = '' ; Y.LR.ISA.REMARKS = ''	;*CPSGMIG-19027 & 22843
    Y.MOBILE.NO = '' ; Y.POS.MIG.FLAG = ''		;*CPSGMIG-19027 & 22843
    
RETURN
*---------------------
PROCESS:
*---------------------
    R.SEC.ACC.MASTER = '' ; SEC.ACC.MASTER.ERR = ''
    Y.CUST.ID = FIELD(SAMID,'-',1)
    R.CUST = '' ; ERR.CUST = ''
    Y.LOB = ''
    CALL F.READ(FN.CUSTOMER,Y.CUST.ID,R.CUST,FV.CUSTOMER,ERR.CUST)
    PRIMARY.ACCT.HOLDER = R.CUST<EB.CUS.LOCAL.REF,Y.PORTFOLIO.KEY.POS>
    Y.STAFF.IND = R.CUST<EB.CUS.LOCAL.REF,Y.LR.STAFF.IND.POS>
    Y.SECTOR = R.CUST<EB.CUS.SECTOR>
    Y.LOB = R.CUST<EB.CUS.LOCAL.REF,Y.LOB.POS>
    IF Y.LOB MATCHES Y.ALLOWED.LOB ELSE
        RETURN
    END
    
    CALL F.READ(FN.SAM,SAMID,R.SEC.ACC.MASTER,FV.SAM,SEC.ACC.MASTER.ERR)
    Y.ADVICE.INDEX = R.SEC.ACC.MASTER<SC.SAM.ADVICE.INDEX>
    Y.LR.ISA.REMARKS = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.LR.ISA.REMARKS.POS>	;*CPSGMIG-19027 & 22843 -S
    CHANGE @SM TO '' IN Y.LR.ISA.REMARKS
    Y.LR.POS.MIG.FLAG = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.LR.POS.MIG.DT.POS>	;*CPSGMIG-19027 & 22843 -E
    IF Y.LR.POS.MIG.FLAG THEN
        Y.POSMIG.FLAG = 'Y'
    END ELSE
        Y.POSMIG.FLAG = 'N'
    END
    Y.BLOCKING.DATE = R.SEC.ACC.MASTER<SC.SAM.BLOCKING.DATE>
    IF Y.BLOCKING.DATE EQ '' THEN
        PORTFOLIO.STATUS = "NORMAL"
    END ELSE
        PORTFOLIO.STATUS = "BLOCKED"
    END

    BEGIN CASE
        CASE Y.SECTOR EQ "21"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE (Y.SECTOR EQ "51") AND (Y.STAFF.IND EQ "Y")
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE Y.SECTOR EQ "23"
            Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
    GOSUB WRITEFILE
    
RETURN
*---------------------
WRITEFILE:
*---------------------
    DELIM = ","
    Y.SAM.REC = SAMID:DELIM:PORTFOLIO.NAME:DELIM:PORTFOLIO.STATUS:DELIM:ADDRESS.LINE.1:DELIM:ADDRESS.LINE.2:DELIM:
    Y.SAM.REC := ADDRESS.LINE.3:DELIM:ADDRESS.LINE.4:DELIM:POSTAL.CODE:DELIM:COUNTRY:DELIM:CITY:DELIM:STATE:DELIM:
	Y.SAM.REC := Y.CLIENT.IDENTIFIER:DELIM:PRIMARY.ACCT.HOLDER:DELIM:Y.ADVICE.INDEX:DELIM:Y.CLIENT.NRC:DELIM: ;*CPSGMIG-19027 & 22843
    Y.SAM.REC := DQUOTE(Y.LR.ISA.REMARKS):DELIM:Y.MOBILE.NO:DELIM:Y.POSMIG.FLAG ;*CPSGMIG-19027 & 22843
    IF Y.SAM.REC THEN
        OPENSEQ AMEX.FILES,Y.TEMP.FILE.NAME TO F.AMEX.FILES ELSE  CREATE F.AMEX.FILES ELSE
            CALL OCOMO("Error opening ":Y.TEMP.FILE.NAME)
        END

        WRITESEQ Y.SAM.REC APPEND TO F.AMEX.FILES ELSE
            CALL OCOMO('Unable to write ':F.AMEX.FILES)
        END
        CLOSESEQ F.AMEX.FILES
    END
RETURN

END
