* @ValidationCode : MjotMTM2NTgzMDk5MDpJU08tODg1OS0xOjE2NjU3MzkxNjA3MTg6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 14 Oct 2022 14:49:20
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.UTS.MERGER.REPORT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5332 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       13 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract Trade details for Subscription, Redemption , SwitchIn & SwitchOut
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SCB.UTS.MERGER.REPORT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.UTS.MERGER.REPORT.COMMON
*--------------------------------------------------------------------------------------------

    GOSUB SELECT.RECORDS

RETURN
*-------------*
SELECT.RECORDS:
*-------------*
    
* Select Sec Trades for the Current Month
    SEL.CMD = "SELECT ":FN.SEC.TRADES.MDAY:" WITH @ID LIKE SG...*SCTRSC..."
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)

    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN
END
