$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgIcmMandRemovalSelect
* Descirpiotn: - .SELECT routine to select the SCB.RSG.ICM.T24.MAND.LIST to get the list and pass to batch.build.list for ,
* 				  processing and removing the ord id and corr id from SCB.RSG.ICM.T24.MAND.LIST
* 				  whose ORD ID record doesnot exist or got removed after 30 days.
* Developed by :- Pawan kr(1668106)
*Jira ref:- CPSGMIG-5191
SUBROUTINE B.SCB.RSG.ICM.MAND.REMOVAL.SELECT

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.ICM.MAND.REMOVAL.COMMON

    GOSUB INIT ; *
    GOSUB PROCESS ; *
RETURN

*-----------------------------------------------------------------------------

*** <region name= INIT>
INIT:
*** <desc> Form the select statment and process</desc>

*
    SEL.CMD = ""
    SEL.CMD = "SELECT ":FN.SRIT.MAND.LIST
    SEL.LIST =""
    CALL OCOMO("SELECT COMMAND ":SEL.CMD)
RETURN
*** </region>

*-----------------------------------------------------------------------------

*** <region name= PROCESS>
PROCESS:
*** <desc> </desc>
*
    SEL.LIST =""
    CALL EB.READLIST(SEL.CMD,SEL.LIST,"",NO.SEL.LIST,LIST.ERR)
*
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST("",SEL.LIST)
        CALL OCOMO("NO. OF RECORDS SELECTED TO BE PROCESS ":NO.SEL.LIST)
*
    END

RETURN
*** </region>
END
