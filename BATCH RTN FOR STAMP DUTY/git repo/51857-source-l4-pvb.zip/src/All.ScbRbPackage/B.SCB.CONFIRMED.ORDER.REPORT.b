* @ValidationCode : MjotNjQ4NjY5OTcxOklTTy04ODU5LTE6MTY4MjQ0MjIzNTY0ODoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 25 Apr 2023 22:33:55
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CONFIRMED.ORDER.REPORT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5701 - JEWEL_T24_PROJECT
* Developed By                   :       Sridhar. A
* Developed On                   :       12 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Batch report to generate the confirmed order from SEC.TRADE & SECURITY.TRANSFER
*--------------------------------------------------------------------------------------------
* Called From:  BATCH
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 27-Oct-2022   Krishnaveni      To update blank value for AccountHolderDOB column
* 07-Nov-22     Swaminathan.S.R  To update SOO live record values & Lien Reason Code change
* 11-Nov-22     Swaminathan.S.R  CPSGMIG-15223: Order Closing Id remapped to SEC.TRADE > LR.CLOSING.ID
* 13-Nov-22     Swaminathan.S.R  CPSGMIG-15223: SM>DESCRIPT & COMPANY.NAME field multivalue check removed
* 29-Nov-22     Swaminathan.S.R  CPSGMIG-17499: Order not created but captured in the report
* 23-Jan-2023   1667095          CPSGMIG-17723 - Update mapping for product provider name
* 09-Feb-2023   Senthil          CPSGMIG-17827 - Updated mapping for Order Closing ID
* 13-Feb-2023   1663000          CPSGMIG-18726 - To Include Reversed transactions in the Report
* 16-Feb-2023   1663000          CPSGMIG-14085 - Column addition UTS data with DOB for all account holders
* 23-Feb-2023   1663000          CPSGMIG-19791 - OrderID,OrderDate captured for SecurityTransfer
* 28-Feb-2023   1663000          CPSGMIG-19963 - OrderDate captured for SecurityTransfer
* 23-Mar-2023   1667095          CPSGMIG-21468 - Updated mapping for RSP Plan Id
* 17-Apr-2023   1663000          CPSGMIG-17827 - Remove Salesstaffname mapping
* 26-Apr-2023 - 1663000          CPSGMIG-21498 - Filename/Date Change
* 22-May-2023   1648769          CPSGMIG-27284 - Asset name changes - To captured from SM>LR.UTS.INS.DESC, if value is empty in SM>LR.UTS.INS.DESC then display SM->DESC in the report.
* 21-Jun-2023   1648769          CPSGMIG-29355 - Changes;
*                                                 1. If SP>NOMINEE.CODE is 1 then default ESPD esle check SAM>LR.LIEN.CODE is value exist update else Check the 
*                                                 table SC.SCB.RB.BLOCK>selected portfolio record with SM and Depo combination.If record exist then pick the 
*                                                 value from SC.SCB.RB.BLOCK>LR.LIEN.CODE else LR.LIEN.CODE and LIEN remarks values should be left Blank.
*                                                 2. Lien Remarks, replace ',' to '' to not exceed to next columns.
* 19-Jul-2023   1670271          CPSGMIG-31049 -  LR.CLOSING.ID & LR.REFERAL.ID is taken from SOO application instead of SEC.TRADE application for MF product.
* 10-Aug-2023   1648769          CPSGMIG-32375 - Rel ID Delimiters needs to be fixed from '-' to ':' for Joint Accounts.
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES           ;* CPSGMIG-21498
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION
   
  
    GOSUB INITIALISE
    GOSUB OPENFILES
    GOSUB PROCESS
    GOSUB WRITE.FINAL.ARRAY
    
RETURN


INITIALISE:
***********
    Y.DATA = BATCH.DETAILS<3,1>  ;* Contains the file name as Daily Transactions Confirmed Order
    CONVERT @SM TO @FM IN Y.DATA
    MTH.DAILY.FLAG  = FIELD(Y.DATA,'*', 1)   ;* Contain the value as Daily or Monthly
    Y.FILE.ID       = FIELD(Y.DATA,'*', 2)
    Y.LWD           = R.DATES(EB.DAT.LAST.WORKING.DAY)     ;* CPSGMIG-21498
    Y.FILE.ID       = EREPLACE(Y.FILE.ID,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
      
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)

    SEL.LIST         = ""
    Y.FINAL.ARRAY = "Transaction Reference,ISOC Operator,Order Closing Id,Country Code,Sales Staff Name,"
    Y.FINAL.ARRAY:= "Account Type,Account Number,Account Open Date,Lien Reason Code,Lien Reason Code Desc,"
    Y.FINAL.ARRAY:= "Order No.,Order Date,Account Holder DOB,Transaction Type,Detail On Order Type,Order Type,"
    Y.FINAL.ARRAY:= "Transaction Status,Product Provider Name,Asset Code,Asset Name,Asset Currency,"
    Y.FINAL.ARRAY:= "Transaction Amount,Remarks,Account Holder 1,ID Number 1,EBBS Rel ID 1,Account Holder 2,ID Number 2," ;*CPSGMIG-14085
    Y.FINAL.ARRAY:= "EBBS Rel ID 2,Account Holder 3,ID Number 3,EBBS Rel ID 3,Account Holder 4,ID Number 4,EBBS Rel ID 4,RSP Plan ID,ISIN,PRR [Risk]," ;*CPSGMIG-14085
    Y.FINAL.ARRAY:= "Channel info,ClientIdentifier,PrimaryAcctHolder,Account Holder DOB 2,Account Holder DOB 3,Account Holder DOB 4,"
    Y.FINAL.ARRAY:= "Transaction Date,Referral ID,Transaction CCY,Rel 1,Rel 2,Rel 3,Rel 4" ;*CPSGMIG-14085
    
    Y.ISOC.OPERATOR  = ""
    Y.BRANCH.CODE    = ""
    Y.BRANCH.CODE    = ""
    Y.PAYMENT.TYPE   = ""
    Y.DELIM          = ","
    Y.ACCOUNT.HOLDER = ""
    Y.LR.RSP.REF     = ""
    Y.LR.OMF.REF.NO  = ""
    Y.TAP.REF.NO     = ""
    Y.CHANNEL.REF    = ""
    Y.REL.CIF.NO     = ""

    Y.APP.NAME<1> = 'CUSTOMER'
    Y.APP.NAME<2> = 'SEC.OPEN.ORDER'
    Y.APP.NAME<3> = 'SEC.ACC.MASTER'
    Y.APP.NAME<4> = 'SEC.TRADE'
    Y.APP.NAME<5> = 'SECURITY.TRANSFER'
    Y.APP.NAME<6> = 'SECURITY.MASTER'
    Y.FLD.NAME<1> = 'L.O.B':@VM:'LR.EBBS.REL':@VM:'REL.CIF.NO':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM: 'LR.SIGN.MANDATE' ;*CPSGMIG-14085
    Y.FLD.NAME<2> = 'LR.RSP.REF':@VM:'LR.REFERRAL.ID':@VM:'LR.CLOSING.ID'
    Y.FLD.NAME<3> = 'LR.LIEN.CODE'
    Y.FLD.NAME<4> = 'LR.CLOSING.ID':@VM:'LWM.EDP.REF.NUM':@VM:"LR.OMF.REF.NO":@VM:"TAP.REF.NO":@VM:'LR.REFERRAL.ID' ;*CPSGMIG-14085
    Y.FLD.NAME<5> = 'RMPSID':@VM:'LWM.EDP.REF.NUM'
    Y.FLD.NAME<6> = 'LR.UTS.INS.DESC'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
*Customer LRT
    Y.LOB.POS           = Y.FLD.POS<1,1>
    Y.LR.EBBS.REL.POS   = Y.FLD.POS<1,2>
    Y.REL.CIF.NO.POS    = Y.FLD.POS<1,3>
    Y.LR.STAFF.IND.POS  = Y.FLD.POS<1,4>
    Y.LR.PFOLIO.KEY.POS = Y.FLD.POS<1,5>
    Y.LR.SIGN.MANDT.POS = Y.FLD.POS<1,6> ;* CPSGMIG-14085
*SOO LRT
    Y.LR.RSP.REF.POS   = Y.FLD.POS<2,1>
    Y.REFERRAL.ID.POS = Y.FLD.POS<2,2>	 
    Y.LR.CLOSING.ID.POS.SO = Y.FLD.POS<2,3>
*SAM LRT
    Y.LR.LIEN.CODE.POS = Y.FLD.POS<3,1>
    
*Sec Trade LRT
    Y.LR.ORD.CLOSE.ID.POS = Y.FLD.POS<4,1>
    Y.LWM.EDP.REF.NUM.POS = Y.FLD.POS<4,2>
    Y.LR.OMF.REF.NO.POS   = Y.FLD.POS<4,3>
    Y.TAP.REF.NO.POS      = Y.FLD.POS<4,4>
    Y.LR.REF.POS          = Y.FLD.POS<4,5>  ;* CPSGMIG-14085
*Security Transfer LRT
    Y.ST.RMPSID.POS = Y.FLD.POS<5,1>
    Y.LWM.EDP.REF.NUM.ST.POS = Y.FLD.POS<5,2>
*Security Master LRT
    Y.LR.UTS.DESC.POS = Y.FLD.POS<6,1>
    
    
RETURN

OPENFILES:
**********
             
    FN.CUSTOMER            = 'F.CUSTOMER'
    F.CUSTOMER             = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    
    FN.SEC.TRADE           = 'F.SEC.TRADE'
    F.SEC.TRADE            = ''
	CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    
    FN.SEC.TRADES.LDAY    = 'F.SCB.SEC.TRADES.LDAY'        ;* CPSGMIG-21498 -S
    F.SEC.TRADES.LDAY     = ''
	CALL OPF(FN.SEC.TRADES.LDAY,F.SEC.TRADES.LDAY)         ;* CPSGMIG-21498 -E
    
    FN.SC.TRANS.NAME       = 'F.SC.TRANS.NAME'
    F.SC.TRANS.NAME        = ''
	CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
    
    FN.SECURITY.MASTER     = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER      = ''
	CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    
    FN.SEC.OPEN.ORDER      = 'F.SEC.OPEN.ORDER'
    F.SEC.OPEN.ORDER       = ''
	CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    
    FN.SEC.OPEN.ORDER.HIS  = 'F.SEC.OPEN.ORDER$HIS'
    F.SEC.OPEN.ORDER.HIS   = ''
	CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
    
    FN.SUB.ASSET.TYPE      = 'F.SUB.ASSET.TYPE'
    F.SUB.ASSET.TYPE       = ''
	CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
    
    FN.SECURITY.TRANSFER   = 'F.SECURITY.TRANSFER'
    F.SECURITY.TRANSFER    = ''
	CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
    
    FN.DEPT.ACCT.OFFICER   = 'F.DEPT.ACCT.OFFICER'
    F.DEPT.ACCT.OFFICER    = ''
	CALL OPF(FN.DEPT.ACCT.OFFICER,F.DEPT.ACCT.OFFICER)
    
    FN.SCB.SEC.TRADES.MDAY = 'F.SCB.SEC.TRADES.MDAY'
    F.SCB.SEC.TRADES.MDAY  = ''
	CALL OPF(FN.SCB.SEC.TRADES.MDAY,F.SCB.SEC.TRADES.MDAY)
    
    FN.SEC.ACC.MASTER      = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER       = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
	
    FN.SC.SCB.LIEN.CODE    = 'F.SC.SCB.LIEN.CODE'
    F.SC.SCB.LIEN.CODE     = ''
	CALL OPF(FN.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE)

    FN.SEC.TRADE.HIS         = 'F.SEC.TRADE$HIS'         ; F.SEC.TRADE.HIS          = '' ; CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)                 ;* CPSGMIG-18726
    FN.SECURITY.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS' ; F.SECURITY.TRANSFER.HIS  = '' ; CALL OPF(FN.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS) ;* CPSGMIG-18726
    FN.SC.SCB.RB.BLOCK        = 'F.SC.SCB.RB.BLOCK'        ; F.SC.SCB.RB.BLOCK        = '' ; CALL OPF(FN.SC.SCB.RB.BLOCK,F.SC.SCB.RB.BLOCK)
    FN.SECURITY.POSITION      = 'F.SECURITY.POSITION'      ; F.SECURITY.POSITION      = '' ; CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)

    CALL SCB.GET.ORACLE.VIEWNAME(FN.SECURITY.POSITION,Y.VIEW.NAME)   ;* Get Security Position View Name
RETURN
   
PROCESS:
********
    
    IF MTH.DAILY.FLAG EQ "D" THEN
        SEL.CMD = 'SELECT ':FN.SEC.TRADES.LDAY:' WITH @ID LIKE SG...*SCTRSC... OR WITH @ID LIKE SG...*SECTSC...'      ;* CPSGMIG-21498 - Daily Report
    END ELSE
        SEL.CMD = 'SELECT ':FN.SCB.SEC.TRADES.MDAY:' WITH @ID LIKE SG...*SCTRSC... OR WITH @ID LIKE SG...*SECTSC...'  ;* Monthly Report
    END

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
    
    IF SEL.LIST NE '' THEN
        LOOP
            REMOVE Y.ID FROM SEL.LIST SETTING Y.POS
		WHILE Y.ID:Y.POS
            GOSUB RESET.VALUES ;* CPSGMIG-19791
            Y.TXN.ID = FIELD(Y.ID,'*',2,1)
            BEGIN CASE
                CASE Y.TXN.ID[1,6] EQ 'SCTRSC'
                    GOSUB SEC.TRADE.DET  ;* Process Sec Trade
                    
                CASE Y.TXN.ID[1,6] EQ 'SECTSC'
                    GOSUB SECURITY.TRANSFER.DET   ;* Process Security Transfer
                    
            END CASE
        REPEAT
    END
RETURN

RESET.VALUES:                              ;*CPSGMIG-19791
*-----------*
    
    Y.TXN.ID      = '' ; Y.ORDER.CLOSE.ID = '' ; Y.CO.CODE     = '' ; Y.SALES.STAFF.NAME  = '' ; Y.ACCT.TYPE      = '' ; Y.ACCT.NO    = '' ; Y.START.DATE = '' ; Y.LR.LIEN.CODE = '' ; Y.LR.REMARKS  = '' ; Y.SEC.OPEN.ORD.ID = '' ; Y.ORD.DATE         = '' ; Y.ORD.TYPE   = ''
    Y.TXN.STATUS  = '' ; Y.PRVDR.NAME     = '' ; Y.SM.ID       = '' ; Y.ASSET.NAME        = '' ; Y.ORDER.CURRENCY = '' ; Y.TRANS.AMT  = '' ; Y.REMARKS    = '' ; Y.LR.RSP.REF   = '' ; Y.LR.EBBS.REL = '' ; Y.LR.OMF.REF.NO   = '' ; Y.LWM.EDP.REF.NUM  = '' ; Y.TAP.REF.NO = ''
    Y.ISIN        = '' ; Y.RATING         = '' ; Y.CHANNEL.REF = '' ; Y.CLIENT.IDENTIFIER = '' ; Y.PRI.ACC.HOLDER = '' ; Y.TRADE.DATE = '' ; Y.LR.REF.ID  = '' ; Y.TRD.CCY      = '' ; Y.REL.ID.ARR  = '' ; R.SEC.OPEN.ORDER  = '' ; Y.DEPO = ''
    
RETURN

SEC.TRADE.DET:
**************
    
    CALL F.READ(FN.SEC.TRADE,Y.TXN.ID,R.SEC.TRADE,F.SEC.TRADE,Y.ST.ERR)
    IF R.SEC.TRADE EQ "" THEN                ;*CPSGMIG-18726 -s
        Y.HISTRADE.ID = '' ; Y.HISTRADE.ID = Y.TXN.ID
        CALL EB.READ.HISTORY.REC(F.SEC.TRADE.HIS,Y.HISTRADE.ID,R.SEC.TRADE,SECTRHIS.ERR)
    END                                      ;*CPSGMIG-18726 -e
    
    Y.CUS.ID = R.SEC.TRADE<SC.SBS.CUSTOMER.NO>
    GOSUB GET.CUS.LOB
   
    IF Y.L.O.B MATCHES Y.ALLOWED.LOB THEN
        GOSUB GET.CUSTOMER.DET                      ;* Get Customer DAO
        Y.SM.ID            = R.SEC.TRADE<SC.SBS.SECURITY.CODE>
        Y.CO.CODE          = R.SEC.TRADE<SC.SBS.CO.CODE>
        Y.TRADE.DATE       = R.SEC.TRADE<SC.SBS.TRADE.DATE>
        Y.SOO.ID           = R.SEC.TRADE<SC.SBS.CU.ORDER.NOS>
        Y.ACCT.NO          = R.SEC.TRADE<SC.SBS.CUST.SEC.ACC>
        Y.TRANS.AMT        = R.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>
        Y.TRANS.CODE       = R.SEC.TRADE<SC.SBS.CUST.TRANS.CODE>
        Y.REMARKS          = R.SEC.TRADE<SC.SBS.CU.NARRATIVE>
        Y.ORDER.CLOSE.ID   = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.ORD.CLOSE.ID.POS>
        Y.LR.OMF.REF.NO    = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.OMF.REF.NO.POS>
        Y.LWM.EDP.REF.NUM  = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LWM.EDP.REF.NUM.POS>
        Y.TAP.REF.NO       = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.TAP.REF.NO.POS>
        Y.LR.REF.ID        = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.REF.POS> ;*CPSGMIG-14085
        Y.TRD.CCY          = R.SEC.TRADE<SC.SBS.TRADE.CCY>   ;*CPSGMIG-14085
        Y.DEPO             = R.SEC.TRADE<SC.SBS.DEPOSITORY>
        Y.SEC.OPEN.ORD.ID  = Y.SOO.ID     ;* ID append with curr number when calling the EB.READ.HISTORY.REC
		Y.ORD.DATE = '' ; Y.LR.RSP.REF = ''
        CALL F.READ(FN.SEC.OPEN.ORDER,Y.SOO.ID,R.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER,Y.SOO.ERR)
        IF NOT(R.SEC.OPEN.ORDER) THEN
            CALL EB.READ.HISTORY.REC(F.SEC.OPEN.ORDER.HIS,Y.SOO.ID,R.SEC.OPEN.ORDER,Y.SOO.ERR)
        END
        IF R.SEC.OPEN.ORDER THEN
*            Y.ORD.DATE  = R.SEC.OPEN.ORDER<SC.SOO.ORDER.DATE>                                 ;*Commented *CPSGMIG-17827-(S/E)
            Y.LR.RSP.REF = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.LR.RSP.REF.POS>
        END
        GOSUB MAPPING.VAL.DETS
        GOSUB FORM.ARRAY
    END
        
RETURN

SECURITY.TRANSFER.DET:
**********************
    CALL F.READ(FN.SECURITY.TRANSFER,Y.TXN.ID,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,Y.SEC.TRANS.ERR)
    IF R.SECURITY.TRANSFER EQ "" THEN       ;*CPSGMIG-18726 -s
        Y.SECHIS.ID = '' ; SECHIS.ERR = '' ; Y.SECHIS.ID = Y.TXN.ID
        CALL EB.READ.HISTORY.REC(F.SECURITY.TRANSFER.HIS,Y.SECHIS.ID,R.SECURITY.TRANSFER,SECHIS.ERR)
    END                                     ;*CPSGMIG-18726 -e
    Y.CUS.ID = R.SECURITY.TRANSFER<SC.STR.CUSTOMER.NO>
    GOSUB GET.CUS.LOB

    IF ( Y.L.O.B MATCHES Y.ALLOWED.LOB ) THEN
        GOSUB GET.CUSTOMER.DET                      ;* Get Customer DAO
        Y.SM.ID           = R.SECURITY.TRANSFER<SC.STR.SECURITY.NO>
        Y.CO.CODE         = R.SECURITY.TRANSFER<SC.STR.CO.CODE>
        Y.ACCT.NO         = R.SECURITY.TRANSFER<SC.STR.SECURITY.ACC>
        Y.TRADE.DATE      = R.SECURITY.TRANSFER<SC.STR.TRADE.DATE>
        Y.ORDER.CLOSE.ID  = ''                                                               ; *CPSGMIG-15222-(S/E)
        Y.TRANS.AMT       = R.SECURITY.TRANSFER<SC.STR.NET.AMT.SEC.CCY>
        Y.LWM.EDP.REF.NUM = R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,Y.LWM.EDP.REF.NUM.ST.POS>
        Y.TRANS.CODE      = R.SECURITY.TRANSFER<SC.STR.TRANSACTION.TYPE>
        Y.REMARKS         = R.SECURITY.TRANSFER<SC.STR.CUST.REMARKS>
        Y.DEPO            = R.SECURITY.TRANSFER<SC.STR.DEPOSITORY>
        Y.SOO.ID          = ''
        Y.ORD.DATE        = ''
        
        GOSUB MAPPING.VAL.DETS
        Y.TRD.CCY         = Y.ORDER.CURRENCY  ;*CPSGMIG-14085
        GOSUB FORM.ARRAY
    END
    
RETURN

GET.CUS.LOB:
************
        
    R.CUSTOMER = ''  ;   Y.CUS.ERR = ''
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUSTOMER,F.CUSTOMER,Y.CUS.ERR)
    Y.L.O.B = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
RETURN

GET.CUSTOMER.DET:
*****************

    Y.DAO             = R.CUSTOMER<EB.CUS.ACCOUNT.OFFICER>
    Y.SECTOR          = R.CUSTOMER<EB.CUS.SECTOR>
    Y.LR.EBBS.REL     = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.EBBS.REL.POS>
    Y.STAFF.IND       = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.STAFF.IND.POS>
    Y.PRI.ACC.HOLDER  = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
    Y.LRSIGN.MDATE    = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.SIGN.MANDT.POS> ;* CPSGMIG-14085

    CHANGE @SM TO @FM IN Y.LRSIGN.MDATE   ;* CPSGMIG-14085
    CHANGE @VM TO @FM IN Y.LR.EBBS.REL
    CHANGE @SM TO @FM IN Y.LR.EBBS.REL
    
    Y.CLIENT.IDENTIFIER = ""
    BEGIN CASE
        CASE Y.SECTOR EQ "21"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE Y.SECTOR EQ "51" AND Y.STAFF.IND EQ "Y"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE Y.SECTOR EQ "23"
            Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
        
    Y.LR.PFOLIO.ARR = Y.PRI.ACC.HOLDER ; Y.REL.ID.ARR = '' ; PFOLIO.IDX = 0 ;*CPSGMIG-14085 -S
    CHANGE ':' TO @FM IN Y.LR.PFOLIO.ARR
    
    LOOP
        REMOVE Y.PFOLIO.ID FROM Y.LR.PFOLIO.ARR SETTING Y.LR.PFOLIO.POS1
    WHILE Y.PFOLIO.ID : Y.LR.PFOLIO.POS1
        IF PFOLIO.IDX LE 4 THEN
            LOCATE Y.PFOLIO.ID IN Y.LR.EBBS.REL SETTING Y.LR.PFOLIO.POS2 THEN
                PFOLIO.IDX += 1
                IF NOT(Y.REL.ID.ARR) THEN
                    Y.REL.ID.ARR = Y.LRSIGN.MDATE<Y.LR.PFOLIO.POS2>
                END ELSE
                    Y.REL.ID.ARR := Y.DELIM: Y.LRSIGN.MDATE<Y.LR.PFOLIO.POS2>
                END
            END
        END
    REPEAT                         ;*CPSGMIG-14085  -E
    
RETURN

MAPPING.VAL.DETS:
****************
    
    R.SECURITY.MASTER = '' ;   SM.ERR = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,SM.ERR)
    Y.ASSET.NAME     = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.UTS.DESC.POS>
    IF Y.ASSET.NAME EQ '' THEN
      Y.ASSET.NAME     = R.SECURITY.MASTER<SC.SCM.DESCRIPT>
    END
    CHANGE @VM TO '' IN Y.ASSET.NAME
    CHANGE @SM TO ' ' IN Y.ASSET.NAME
    Y.ORDER.CURRENCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
    Y.COMPANY.NAME   = R.SECURITY.MASTER<SC.SCM.COMPANY.NAME>
    CHANGE @VM TO ' ' IN Y.COMPANY.NAME
    Y.ISIN           = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
    Y.RATING         = R.SECURITY.MASTER<SC.SCM.RATING>
    CALL SCB.WM.GET.PRODUCT.TYPE(Y.SM.ID,Y.ACCT.TYPE)
    
*CPSGMIG-17723(S)
    Y.PRVDR.NAME = '' ; Y.TR.ISSUER = ''
    Y.TR.ISSUER = R.SECURITY.MASTER<SC.SCM.TR.ISSUER>
    IF Y.TR.ISSUER AND (Y.ACCT.TYPE EQ 'MF') THEN
        R.ISSUER.CUST = '' ; ISS.CUST.ERR = ''
        CALL F.READ(FN.CUSTOMER,Y.TR.ISSUER,R.ISSUER.CUST,F.CUSTOMER,ISS.CUST.ERR)
        Y.NAME.1 = '' ; Y.NAME.2 = '' ; NAME.DL = ''
        IF R.ISSUER.CUST THEN
            Y.NAME.1 = R.ISSUER.CUST<EB.CUS.NAME.1>
            Y.NAME.2 = R.ISSUER.CUST<EB.CUS.NAME.2>
            NAME.DL = ' '
            Y.PRVDR.NAME = Y.NAME.1:NAME.DL:Y.NAME.2
            CONVERT @VM TO '' IN Y.PRVDR.NAME
        END
    END
*CPSGMIG-17723(E)

*CPSGMIG-17827(S)
    IF Y.ACCT.TYPE EQ 'MF' THEN
        Y.ORD.DATE   = R.SEC.OPEN.ORDER<SC.SOO.ORDER.DATE>
        Y.ORDER.CLOSE.ID = '' ; Y.ORDER.CLOSE.ID = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.LR.CLOSING.ID.POS.SO>	 
        Y.LR.REF.ID = ''      ; Y.LR.REF.ID = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.REFERRAL.ID.POS>		
    END
*CPSGMIG-17827(E)

    Y.ORD.TYPE = ''
    IF Y.LR.RSP.REF THEN
        Y.ORD.TYPE = "Savings Plan"
    END ELSE
        CALL F.READ(FN.SC.TRANS.NAME,Y.TRANS.CODE,R.SC.TRANS.NAME,F.SC.TRANS.NAME,Y.SC.TRANS.NAME.ERR)
        IF R.SC.TRANS.NAME THEN
            Y.ORD.TYPE = R.SC.TRANS.NAME<SC.TNM.SHORT.NAME,1>
        END
    END

    Y.TXN.STATUS = ""
    CALL SCB.C.GET.TXN.STATUS(Y.TXN.ID,Y.TXN.STATUS)  ;* To get Transaction status
    
    R.SEC.ACC.MASTER = ''    ;  Y.SAM.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.ACCT.NO,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,Y.SAM.ERR)
    Y.START.DATE   = R.SEC.ACC.MASTER<SC.SAM.START.DATE>
    GOSUB GET.LIEN.CODE.VAL
    
    BEGIN CASE
        CASE Y.LWM.EDP.REF.NUM NE ""
            Y.CHANNEL.REF = Y.LWM.EDP.REF.NUM
            
        CASE Y.LR.OMF.REF.NO NE ""
            Y.CHANNEL.REF = Y.LR.OMF.REF.NO
            
        CASE Y.TAP.REF.NO NE ""
            Y.CHANNEL.REF = Y.TAP.REF.NO
    
    END CASE
    
RETURN

*------------------*
GET.LIEN.CODE.VAL:
*------------------*
* Get Security Position based on Portfolio
   SEL.CMD    = "SELECT RECID FROM ":Y.VIEW.NAME:" WHERE SECURITY_ACCOUNT = '":Y.ACCT.NO:"' AND SECURITY_NUMBER = '":Y.SM.ID:"'"
   SEL.CMD    := "AND DEPOSITORY = '":Y.DEPO:"' ORDER BY SECURITY_NUMBER"
   SEL.CMD    = TRIM(SEL.CMD)

   TRANSLATE.QUERY = '' ; RESULT.SET = "" ; ERR.CODE   = "" ; ERR.MSG    = "" ; UNIQUE.ID = OPERATOR:"-":TNO:"-LIENREP-":TIME()
   CALL SCB.CALL.ORACLE.SQL(TRANSLATE.QUERY, UNIQUE.ID, SEL.CMD, RESULT.SET, ERR.CODE, ERR.MSG)
   LOOP
        REMOVE Y.SP.ID FROM RESULT.SET SETTING SP.POS
   WHILE Y.SP.ID : SP.POS
     R.SECURITY.POSITION = '' ; SECURITY.POSITION.ERR = '' ; Y.NOM.CODE = ''
     CALL F.READ(FN.SECURITY.POSITION,Y.SP.ID,R.SECURITY.POSITION,F.SECURITY.POSITION,SECURITY.POSITION.ERR)
       Y.NOM.CODE     = R.SECURITY.POSITION<SC.SCP.NOMINEE.CODE>
       IF Y.NOM.CODE EQ '1' THEN        
        Y.LR.LIEN.CODE = 'ESPD'
       END
       GOSUB GET.LIEN.CODE.VAL1
   REPEAT
   IF Y.LR.LIEN.CODE EQ '' THEN
      GOSUB GET.LIEN.CODE.VAL1
   END

RETURN
*------------------*
GET.LIEN.CODE.VAL1:
*------------------*

     IF Y.LR.LIEN.CODE EQ '' THEN
       Y.LR.LIEN.CODE = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.LR.LIEN.CODE.POS>
      IF Y.LR.LIEN.CODE EQ '' THEN
         R.SC.SCB.RB.BLOCK = ''   ; Y.SC.SCB.RB.BLOCK.ERR = ''
         CALL F.READ(FN.SC.SCB.RB.BLOCK,Y.SP.ID,R.SC.SCB.RB.BLOCK,FN.SC.SCB.RB.BLOCK,Y.SC.SCB.RB.BLOCK.ERR)
         Y.LR.LIEN.CODE = R.SC.SCB.RB.BLOCK<RB.BLK.LR.LIEN.CODE>
      END
     END

     IF Y.LR.LIEN.CODE THEN
      R.SC.SCB.LIEN.CODE = ''  ;  Y.SC.SCB.LIEN.CODE.ERR = ''
      CALL F.READ(FN.SC.SCB.LIEN.CODE,Y.LR.LIEN.CODE,R.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE,Y.SC.SCB.LIEN.CODE.ERR)
      Y.LR.REMARKS = R.SC.SCB.LIEN.CODE<SC.SCBL.DESC>
      Y.LR.REMARKS  = EREPLACE(Y.LR.REMARKS, ",", " ")
     END

RETURN

FORM.ARRAY:
**********
    Y.ARRAY = Y.TXN.ID                               ;* 1.Transaction Reference
    Y.ARRAY := Y.DELIM:Y.ISOC.OPERATOR               ;* 2.ISOC Operator
    Y.ARRAY := Y.DELIM:Y.ORDER.CLOSE.ID              ;* 3.Order Closing Id
    Y.ARRAY := Y.DELIM:Y.CO.CODE[1,2]                ;* 4.Country Code
    Y.ARRAY := Y.DELIM:Y.SALES.STAFF.NAME            ;* 5.Sales Staff Name             ;*CPSGMIG-17827
    Y.ARRAY := Y.DELIM:Y.ACCT.TYPE                   ;* 6.Account Type
    Y.ARRAY := Y.DELIM:Y.ACCT.NO                     ;* 7.Account Number
    Y.ARRAY := Y.DELIM:Y.START.DATE                  ;* 8.Account Open Date
    Y.ARRAY := Y.DELIM:Y.LR.LIEN.CODE                ;* 9.Lien Reason Code
    Y.ARRAY := Y.DELIM:Y.LR.REMARKS                  ;* 10.Lien Reason Code Desc
    Y.ARRAY := Y.DELIM:Y.SEC.OPEN.ORD.ID             ;* 11.Order No.
    Y.ARRAY := Y.DELIM:Y.ORD.DATE                    ;* 12.Order Date
    Y.ARRAY := Y.DELIM:""                            ;* 13.Account Holder DOB
    Y.ARRAY := Y.DELIM:Y.ORD.TYPE                    ;* 14.Transaction Type
    Y.ARRAY := Y.DELIM:Y.ORD.TYPE                    ;* 15.Detail On Order Type
    Y.ARRAY := Y.DELIM:Y.ORD.TYPE                    ;* 16.Order Type
    Y.ARRAY := Y.DELIM:Y.TXN.STATUS                  ;* 17.Transaction Status
    Y.ARRAY := Y.DELIM:DQUOTE(Y.PRVDR.NAME)          ;* 18.Product Provider Name
    Y.ARRAY := Y.DELIM:Y.SM.ID                       ;* 19.Asset Code
    Y.ARRAY := Y.DELIM:DQUOTE(Y.ASSET.NAME)          ;* 20.Asset Name
    Y.ARRAY := Y.DELIM:Y.ORDER.CURRENCY              ;* 21.Asset Currency
    Y.ARRAY := Y.DELIM:Y.TRANS.AMT                   ;* 22.Transaction Amount
    Y.ARRAY := Y.DELIM:Y.REMARKS                     ;* 23.Remarks
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 1
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 25.ID Number 1
    Y.ARRAY := Y.DELIM:Y.LR.EBBS.REL<1>              ;* 26.EBBS Rel ID 1
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 2 ;*CPSGMIG-14085
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 27.ID Number 2
    Y.ARRAY := Y.DELIM:Y.LR.EBBS.REL<2>              ;* 28.EBBS Rel ID 2
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 3 ;*CPSGMIG-14085
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 29.ID Number 3
    Y.ARRAY := Y.DELIM:Y.LR.EBBS.REL<3>              ;* 30.EBBS Rel ID 3
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 24.Account Holder 4 ;*CPSGMIG-14085
    Y.ARRAY := Y.DELIM:Y.REL.CIF.NO                  ;* 31.ID Number 4
    Y.ARRAY := Y.DELIM:Y.LR.EBBS.REL<4>              ;* 32.EBBS Rel ID 4
    Y.ARRAY := Y.DELIM:Y.LR.RSP.REF                  ;* 33.RSP Plan ID
    Y.ARRAY := Y.DELIM:Y.ISIN                        ;* 34.ISIN
    Y.ARRAY := Y.DELIM:Y.RATING                      ;* 35.PRR [Risk]
    Y.ARRAY := Y.DELIM:Y.CHANNEL.REF                 ;* 36.Channel info
    Y.ARRAY := Y.DELIM:Y.CLIENT.IDENTIFIER           ;* 37.Client Identifier
    Y.ARRAY := Y.DELIM:Y.PRI.ACC.HOLDER              ;* 38.PrimaryAcctHolder
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 39.Account Holder DOB 2
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 40.Account Holder DOB 3
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.HOLDER              ;* 41.Account Holder DOB 4
    Y.ARRAY := Y.DELIM:Y.TRADE.DATE                  ;* 42.Transaction Date
    Y.ARRAY := Y.DELIM:Y.LR.REF.ID                   ;* 43.Referral ID                 ;*CPSGMIG-14085 -s
    Y.ARRAY := Y.DELIM:Y.TRD.CCY                     ;* 44.Transaction Ccy
    Y.ARRAY := Y.DELIM:Y.REL.ID.ARR                  ;* 45 - 48. Rel 1, Rel 2, Rel 3 & Rel 4  ;*CPSGMIG-14085 -e

    Y.FINAL.ARRAY<-1> = Y.ARRAY

         
RETURN

WRITE.FINAL.ARRAY:
*****************
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
    AMEXFILEPATH=""
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX.FILES,"",AMEXFILEPATH)
    
    WRITE Y.FINAL.ARRAY TO F.AMEX.FILES,Y.FILE.ID
	
RETURN
END
