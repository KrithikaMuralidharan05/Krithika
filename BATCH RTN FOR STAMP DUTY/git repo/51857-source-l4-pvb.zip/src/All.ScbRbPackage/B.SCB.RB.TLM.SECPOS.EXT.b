$PACKAGE All.ScbRbPackage
*---------------------------------------------------------------------------
* <Rating>158</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE B.SCB.RB.TLM.SECPOS.EXT(EXTRACT.ID)
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* New routine developed for TLM interface.
* Extract the required data.  
* 
*-----------------------------------------------------------------------------------
* Revision History:
*------------------
*   Date               who           	Reference            Description
* 03-Aug-2022        Shreekantha. G     CPSGMIG-5237         Initial Creation
* 25-Apr-2023		 1657186			CPSGMIG-22402	   External Sakekeeping Account Changes.
* 25-Nov-2025        1526956            10607079           SN-Swift - Exclusion of Aggregated Security Transfer transaction as part of the downstream reporting_PVB & RBSG
*-----------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.TLM.SECPOS.EXT.COMMON
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.CUSTOMER.SECURITY
*
    SEC.ACC.ID = FIELD(EXTRACT.ID,".",1)
    CALL F.READ(FN.SEC.ACC.MASTER,SEC.ACC.ID,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,ERR.SEC.ACC.MASTER)
    	DEALER.BOOK.VAL = ''
    	DEALER.BOOK.VAL = R.SEC.ACC.MASTER<SC.SAM.DEALER.BOOK>
*
	Y.CUST = R.SEC.ACC.MASTER<SC.SAM.CUSTOMER.NUMBER>
***10607079 -S
	Y.RET.POS = ''
	LOCATE Y.CUST IN RB.SG.CUST<1,1> SETTING Y.RET.POS THEN
		RETURN
	END
***10607079 -E
	R.CUSTOMER = ''
	ERR.CUST = ''
	CALL F.READ(FN.CUSTOMER,Y.CUST,R.CUSTOMER,F.CUSTOMER,ERR.CUST)
	Y.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
	LOCATE Y.LOB IN Y.ALLOWED.LOB<1,1> SETTING LOBPOS THEN
		IF DEALER.BOOK.VAL EQ '' THEN
			GOSUB INIT
			GOSUB PROCESS
		END
	END
*
    RETURN
*
*------------------------------------------------------------------------------------------------------------------------------
INIT:
*----
*
    Y.SEC.ACCOUNT = ''
    Y.SEC.NUMBER = ''
    Y.DEPOSITORY = ''
    Y.NOMINEE.CODE = ''
    Y.SUB.ACCT = ''
    Y.BUSINESS.UNIT = ''
    Y.ASSET.NAME = ''
    Y.ISSUER = ''
    Y.ISIN = ''
    Y.SUB.ASSET.TYPE = ''
    Y.SEC.CURRENCY = ''
    Y.VAL.DT.POS = ''
    Y.TRD.DT.POS = ''
    Y.UNSETTLED.POS = ''
    Y.SUB.ACCT = ''
    SEC.POS.DATA = ''
*

    OPENSEQ AMEX.PATH,REP.NAME TO F.OUT.FILE ELSE
	CALL OCOMO("UNABLE TO OPEN AMEX FILES")
    END
*	
    RETURN
*
*------------------------------------------------------------------------------------------------------------------------------
PROCESS:
*-------
*
        SEC.POS.ID = EXTRACT.ID
	Y.SEC.ACCOUNT = FIELD(SEC.POS.ID,'.',1,1)
        Y.SEC.NUMBER = FIELD(SEC.POS.ID,'.',2,1)
*
    	CALL F.READ(FN.SECURITY.POSITION,SEC.POS.ID,R.SECURITY.POSITION,F.SECURITY.POSITION,SEC.POS.ERR)
    	IF SEC.POS.ERR THEN RETURN
*	
	Y.DEPOSITORY = R.SECURITY.POSITION<SC.SCP.DEPOSITORY>
	Y.NOMINEE.CODE = R.SECURITY.POSITION<SC.SCP.NOMINEE.CODE>
	Y.SUB.ACCT = R.SECURITY.POSITION<SC.SCP.SUB.ACCOUNT>
* CPSGMIG-22402-S 
    Y.EXT.SAFE.ACT = Y.SUB.ACCT
    IF Y.EXT.SAFE.ACT EQ '' THEN
        ERR.CS = '' ; R.CS = ''
        CALL F.READ (FN.CUSTOMER.SECURITY,Y.DEPOSITORY,R.CS,F.CUSTOMER.SECURITY,ERR.CS)
        IF R.CS<SC.CSC.DEP.EXT.ACC.ID> THEN
            Y.EXT.SAFE.ACT = R.CS<SC.CSC.DEP.EXT.ACC.ID>
        END ELSE
        	Y.EXT.SAFE.ACT = R.CS<SC.CSC.SUB.ACC.EXT.ID>
        END
    END
* CPSGMIG-22402-E
	Y.BUSINESS.UNIT = 'SGSC'
*	
	CALL F.READ(FN.SECURITY.MASTER,Y.SEC.NUMBER,R.SECURITY.MASTER,F.SECURITY.MASTER,SECURITY.MASTER.ERR)
        Y.ASSET.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME,1>
*	
	Y.ISSUER = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.MF.ISSUER.NAME.POS>
    CONVERT @SM TO '' IN Y.ISSUER
    IF NOT(Y.ISSUER) THEN
    	Y.ISSUER = R.SECURITY.MASTER<SC.SCM.COMPANY.NAME,1>
    END 
*	
	Y.ISIN = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
	Y.SUB.ASSET.TYPE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
	Y.SEC.CURRENCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
*
	Y.VAL.DT.POS = R.SECURITY.POSITION<SC.SCP.VALUE.DATED.POSN>
	Y.TRD.DT.POS = R.SECURITY.POSITION<SC.SCP.CLOSING.BAL.NO.NOM>
*	
	Y.UNSETTLED.POS = Y.TRD.DT.POS - Y.VAL.DT.POS
*
	Y.SUB.ACCT = R.SECURITY.POSITION<SC.SCP.SUB.ACCOUNT>
*
    	SEC.POS.DATA = Y.SEC.ACCOUNT : Y.DELIM : Y.SEC.NUMBER : Y.DELIM : Y.DEPOSITORY : Y.DELIM
    	SEC.POS.DATA := Y.NOMINEE.CODE : Y.DELIM : Y.SUB.ACCT : Y.DELIM : Y.BUSINESS.UNIT : Y.DELIM
    	SEC.POS.DATA := Y.ASSET.NAME : Y.DELIM : Y.ISSUER: Y.DELIM : Y.ISIN : Y.DELIM : Y.SUB.ASSET.TYPE : Y.DELIM : Y.SEC.CURRENCY : Y.DELIM
    	SEC.POS.DATA := Y.VAL.DT.POS : Y.DELIM : Y.TRD.DT.POS : Y.DELIM : Y.UNSETTLED.POS : Y.DELIM : Y.EXT.SAFE.ACT : Y.DELIM
*
    WRITESEQ SEC.POS.DATA APPEND TO F.OUT.FILE ELSE
        CRT "Unable to write to Supplementary spring file "
    END
*
    CLOSESEQ F.OUT.FILE           	
*
    RETURN
*
*------------------------------------------------------------------------------------------------------------------------------	
END
*------------------------------------------------------------------------------------------------------------------------------
