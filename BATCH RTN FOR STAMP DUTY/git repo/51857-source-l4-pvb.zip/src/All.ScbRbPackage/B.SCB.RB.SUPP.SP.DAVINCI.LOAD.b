$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------------------------------------------------------
   SUBROUTINE B.SCB.RB.SUPP.SP.DAVINCI.LOAD
*-----------------------------------------------------------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This is a new multithreaded job introduced for improving the COB performance
*  as the replacement of the single threaded routine SCB.SUPPLEMENTARY.SP.DAVINCI.
* Copy of existing SCB.SUPPLEMENTARY.SP.DAVINCI.LOAD, include LOB logic for RB.
*-----------------------------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 29-Apr-2022       Lavanya L       CPSGMIG-2776        Initial Creation
*-----------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.SUPP.SP.DAVINCI.COMMON
*
    GOSUB INIT
    GOSUB OPEN.FILES
*
    RETURN
*-----------------------------------------------------------------------------------------------------------------------------
INIT:
*----
*
    Y.COMPANY.ID = ID.COMPANY[1,2]
    IF ID.COMPANY EQ 'CH2920660' THEN
        Y.COMPANY.ID = 'MC'
    END
    F.OUT.FILE = ''
    Y.DELIM = CHARX(9)
*CPSGMIG-2776 - S
    REP.NAME = 'SCB-':Y.COMPANY.ID:'-SP-RB-SECPOS-':TODAY:'-':SESSION.NO:'.txt'		
	Y.APP = 'CUSTOMER'
	Y.FLD = 'L.O.B'
	Y.POS = ''
	CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)
	Y.LOB.POS = Y.POS<1,1>
	
	Y.PARAM.ID    = 'SCB.CUST.SEG'	
    Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
    Y.ALLOWED.LOB = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
**CPSGMIG-2776 - E
    RETURN
*-----------------------------------------------------------------------------
OPEN.FILES:
*----------
*
    FN.SC.POS.ASSET = 'F.SC.POS.ASSET'
    F.SC.POS.ASSET = ''
    CALL OPF(FN.SC.POS.ASSET,F.SC.POS.ASSET)
*
    FN.SECURITY.POSITION = 'F.SECURITY.POSITION'
    F.SECURITY.POSITION = ''
    CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)
*
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
    FN.SUB.ASSET.TYPE = 'F.SUB.ASSET.TYPE'
    F.SUB.ASSET.TYPE = ''
    CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
**CPSGMIG-2776 - S
	FN.CUSTOMER = 'F.CUSTOMER'
	F.CUSTOMER = ''
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)
*CPSGMIG-2776 - E
*TAFJUPG-Start
*   OPENSEQ 'AMEX.FILES',REP.NAME TO F.OUT.FILE ELSE
    AMEX.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME('AMEX.FILES','',AMEX.PATH)
* MVM(S)	
*   OPENSEQ AMEX.PATH,REP.NAME TO F.OUT.FILE ELSE
*TAFJUPG-End
*        CREATE F.OUT.FILE ELSE
*            CRT "UNABLE TO OPEN AMEX.FILES"
*        END
*    END
* MVM(E)
*
  RETURN
*------------------------------------------------------------------------------------------------------------------------------  
END
