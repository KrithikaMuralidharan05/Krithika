$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CA.SUSP.POSTING(STMT.ENT.ID)
*-------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-662
* Routine Type                 Batch process routine
* Attached To                  BATCH>SNG/SCB.RB.STATIC.ENTRY
* Workflow                     This routine will read ACCT Entry table to identify Suspense Entry
*                              raised under PVB Category for RB Client on DIARY Transaction and
*                              raise contra posting for PVB and actual posting for RB Susp Category.
*-------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      Description
*-------------------------------------------------------------------------------------------------------
*  Tejomurthy M        02/Sep/2022     CPSGMIG-662    Initial Draft
*
*  Tejomurthy M        13/Oct/2022     CPSGMIG-13956  Checking the Customer class against DEPO id rather
*                                                     than customer field of STMT.ENTRY as it has been
*                                                     taken direction to use PSA Accounts.
*
*  Tejomurthy M        09/Nov/2022     CPSGMIG-15070  LOAD.COMPANY In parameter changes.
*
*  Tejomurthy M        05/Apr/2023     CPSGMIG-23142  R.NEW variable outcome seems to be inconsistent and
*                                                     hence replacing the variable usage to STMT.ENTRIES.WITH.IDS
*                                                     to capture the STMT.NOS post EB.ACCOUNTING. 
*  Loganathan G        08/Sep/2023     CPSGMIG-34058  Partial Entitlement Reversal Scenario
*-------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.CUSTOMER
    $INSERT I_F.DIARY
    $INSERT I_F.STMT.ENTRY
	$INSERT I_ACCT.COMMON
	$INSERT I_B.SCB.RB.CA.SUSP.POSTING.COMMON
   
    GOSUB INIT
    GOSUB PROCESS
	
    RETURN
*-------------------------------------------------------------------------------------------------------
INIT:
*****

    Y.REV.MARKER = ''
	Y.REC.STATUS = ''
	Y.CO.CODE = ''
	CUST.READ.ERR = ''
	Y.REV.DIA.ID = ''
	Y.TRN.ID = ''
	R.STAT.ENTRY = ''
	R.ENTRY.ARRAY = ''
	
    RETURN
*-------------------------------------------------------------------------------------------------------
PROCESS:
********
*Read STMT Entry and get the required information for processing -

    CALL F.READ(FN.STMT.ENTRY,STMT.ENT.ID,STMT.REC,FP.STMT.ENTRY,STMT.ERR)
	Y.TRN.ID  = STMT.REC<AC.STE.TRANS.REFERENCE>
    Y.ACCT.NO = STMT.REC<AC.STE.ACCOUNT.NUMBER>
    Y.PRD.CAT = STMT.REC<AC.STE.PRODUCT.CATEGORY>
    Y.REV.MARKER = STMT.REC<AC.STE.REVERSAL.MARKER>
	Y.CO.CODE = STMT.REC<AC.STE.COMPANY.CODE>
	CALL LOAD.COMPANY(Y.CO.CODE)
*	
    IF Y.TRN.ID[1,6] <> 'DIARSC' THEN         ;* If it is DIARY related transaction then only proceed for processing.  
	    RETURN
    END
*
    Y.ENT.ID.CHK = ''
	Y.ENT.ID.CHK = INDEX(Y.TRN.ID,'.',1)      ;* If the ID found as Entitlement ID then skip the processing.
	IF Y.ENT.ID.CHK THEN
		RETURN
	END
*
    CALL F.READ(FN.DIARY,Y.TRN.ID,R.DIARY,FP.DIARY,DIR.READ.ERR)
	IF NOT(R.DIARY) THEN
	    Y.REV.DIA.ID = Y.TRN.ID
        CALL EB.READ.HISTORY.REC(FP.DIARY.HIS,Y.REV.DIA.ID,R.DIARY,HIS.DIA.ERR)
	END

	Y.DIR.LOC.STMT.NOS = R.DIARY<SC.DIA.LOCAL.REF,Y.DIA.STMT.POS>
	Y.REC.STATUS = R.DIARY<SC.DIA.RECORD.STATUS>
	
* CPSGMIG-13956 - S
	Y.CUST.ID = R.DIARY<SC.DIA.DEPOSITORY>
    CALL F.READ(FN.CUSTOMER,Y.CUST.ID,R.CUS,FP.CUSTOMER,CUST.READ.ERR)
	
	IF CUST.READ.ERR THEN
	    RETURN								  ;* DEPO Record not found CUSTOMER table.
    END
	
	Y.CUST.CLASS = R.CUS<EB.CUS.LOCAL.REF,Y.CUST.CL.POS>
	IF Y.CUST.CLASS <> 'RB' THEN              ;* As per Business, this field must be referenced to identify RB.
		RETURN
	END	
* CPSGMIG-13956 - E

    BEGIN CASE
	CASE Y.REC.STATUS NE 'REVE'			;* Remove NOT(Y.REV.MARKER) for Partial Entitlement Reversal Scenario
	    CALL OCOMO("DIARY.ID Processing ":Y.TRN.ID)
	    CALL OCOMO("CORE STMT.ENTRY ID Processing ":STMT.ENT.ID)
        GOSUB DO.NEW.ENTRY.PROCESS
	CASE Y.REV.MARKER AND Y.DIR.LOC.STMT.NOS
	    CALL OCOMO("DIARY.ID for REV Processing ":Y.TRN.ID)
        GOSUB DO.REV.ENTRY.PROCESS				
	END CASE
*		
    RETURN
*-------------------------------------------------------------------------------------------------------
DO.NEW.ENTRY.PROCESS:
*********************

    ACC.TYPE = "SAO"
	
* Raise Contra Entry for Original Entry Posted -

    GOSUB BUILD.BASE.ARRAY
	GOSUB GET.OTH.TRANS.CODE
	R.STAT.ENTRY<AC.STE.TRANSACTION.CODE> = YY.TRANS.CODE
    R.STAT.ENTRY<AC.STE.ACCOUNT.NUMBER> = STMT.REC<AC.STE.ACCOUNT.NUMBER>
    Y.LCY.AMT.VAL = STMT.REC<AC.STE.AMOUNT.LCY>
	R.STAT.ENTRY<AC.STE.AMOUNT.LCY> = Y.LCY.AMT.VAL * (-1)
	IF STMT.REC<AC.STE.AMOUNT.FCY> THEN
	    Y.FCY.AMT.VAL = STMT.REC<AC.STE.AMOUNT.FCY>
		R.STAT.ENTRY<AC.STE.AMOUNT.FCY> = Y.FCY.AMT.VAL * (-1)
	END

    IF Y.REV.MARKER THEN
		R.STAT.ENTRY<AC.STE.REVERSAL.MARKER> = Y.REV.MARKER
    END

    R.STAT.ENTRY = LOWER(R.STAT.ENTRY)
    R.ENTRY.ARRAY<-1> = R.STAT.ENTRY 

* Raising New STMT entry for RB SUSP Category -

    R.STAT.ENTRY = ''
    GOSUB BUILD.BASE.ARRAY
	Y.AC.LEN = LEN(Y.ACCT.NO)
	Y.AC.NLEN = Y.AC.LEN - 8
	R.STAT.ENTRY<AC.STE.ACCOUNT.NUMBER> = Y.ACCT.NO[1,3]:Y.RB.SUSP.AC.CAT:Y.ACCT.NO[9,Y.AC.NLEN]
	R.STAT.ENTRY<AC.STE.AMOUNT.LCY> = STMT.REC<AC.STE.AMOUNT.LCY>
	IF STMT.REC<AC.STE.AMOUNT.FCY> THEN
	    R.STAT.ENTRY<AC.STE.AMOUNT.FCY> = STMT.REC<AC.STE.AMOUNT.FCY>
    END
    R.STAT.ENTRY<AC.STE.PRODUCT.CATEGORY> = Y.RB.SUSP.AC.CAT

    IF Y.REV.MARKER THEN
		R.STAT.ENTRY<AC.STE.REVERSAL.MARKER> = Y.REV.MARKER
    END

	R.STAT.ENTRY = LOWER(R.STAT.ENTRY)
    R.ENTRY.ARRAY<-1> = R.STAT.ENTRY

* Call Accounting -
    GOSUB CALL.ACCOUNTING
	
* Update Local Entries to respective Deal -
    IF NOT(Y.REV.MARKER) THEN
		R.DIARY<SC.DIA.LOCAL.REF,Y.DIA.STMT.POS> = Y.NEW.ENT.IDS
        
    	CALL F.WRITE(FN.DIARY,Y.TRN.ID,R.DIARY)
    END 
    CALL OCOMO("New Local STMT.ENTRIES updated to Diary ":Y.TRN.ID)
    
	
    RETURN
*-------------------------------------------------------------------------------------------------------
BUILD.BASE.ARRAY:
*****************
    
    R.STAT.ENTRY<AC.STE.COMPANY.CODE>=    STMT.REC<AC.STE.COMPANY.CODE>
	R.STAT.ENTRY<AC.STE.TRANSACTION.CODE> = STMT.REC<AC.STE.TRANSACTION.CODE>
    R.STAT.ENTRY<AC.STE.CURRENCY> =    STMT.REC<AC.STE.CURRENCY> 
    R.STAT.ENTRY<AC.STE.CUSTOMER.ID> =    STMT.REC<AC.STE.CUSTOMER.ID> 
**    R.STAT.ENTRY<AC.STE.NARRATIVE>=    STMT.REC<AC.STE.NARRATIVE>
    R.STAT.ENTRY<AC.STE.NARRATIVE> = "RB-CA-SUSP-LOCAL-ENT"
    R.STAT.ENTRY<AC.STE.PL.CATEGORY> =    STMT.REC<AC.STE.PL.CATEGORY> 
    R.STAT.ENTRY<AC.STE.PRODUCT.CATEGORY> =    STMT.REC<AC.STE.PRODUCT.CATEGORY> 
    R.STAT.ENTRY<AC.STE.ACCOUNT.OFFICER> =    STMT.REC<AC.STE.ACCOUNT.OFFICER>
	R.STAT.ENTRY<AC.STE.POSITION.TYPE> = STMT.REC<AC.STE.POSITION.TYPE>
    R.STAT.ENTRY<AC.STE.VALUE.DATE> =    STMT.REC<AC.STE.VALUE.DATE> 
    R.STAT.ENTRY<AC.STE.OUR.REFERENCE> =    STMT.REC<AC.STE.OUR.REFERENCE>
    R.STAT.ENTRY<AC.STE.CURRENCY.MARKET> =    STMT.REC<AC.STE.CURRENCY.MARKET> 
    R.STAT.ENTRY<AC.STE.DEPARTMENT.CODE> =    STMT.REC<AC.STE.DEPARTMENT.CODE> 
    R.STAT.ENTRY<AC.STE.TRANS.REFERENCE> =    STMT.REC<AC.STE.TRANS.REFERENCE>
    R.STAT.ENTRY<AC.STE.SYSTEM.ID> =    STMT.REC<AC.STE.SYSTEM.ID> 
    R.STAT.ENTRY<AC.STE.BOOKING.DATE> =    STMT.REC<AC.STE.BOOKING.DATE> 

    RETURN
*----------------------------------------------------------------------------------------------------------
CALL.ACCOUNTING:
****************
*
*    R.NEW(1)=''     ;*  R.NEW(V-9)=''
*    ACC.TYPE<3> = "UPDATE.ACTIVITY"
    CALL EB.ACCOUNTING("DIARY",ACC.TYPE,R.ENTRY.ARRAY, "")
*
    R.STAT.ENTRY = ''

* CPSGMIG-23142 - S

*	Y.NEW.ENT.IDS = R.NEW(1)

	Y.ENT.COUNT = 0
	Y.ENT.CNTR = 0
	Y.NEW.ENT.IDS = ''
	
    Y.ENT.COUNT = DCOUNT(STMT.ENTRIES.WITH.IDS,@FM)
	FOR Y.ENT.CNTR = 1 TO Y.ENT.COUNT
		YSTMTNO = ''
		YR.ENTRY = RAISE(STMT.ENTRIES.WITH.IDS<Y.ENT.CNTR>)
		YSTMTNO = YR.ENTRY<AC.STE.STMT.NO>
		Y.NEW.ENT.IDS<1,-1> = YSTMTNO
	NEXT Y.ENT.CNTR
	
* CPSGMIG-23142 - E

	CONVERT VM TO '*' IN Y.NEW.ENT.IDS
	CALL OCOMO("New STMT.ENTRY Nos ":Y.NEW.ENT.IDS)
*
    RETURN
*-----------------------------------------------------------------------------------------------------------
GET.OTH.TRANS.CODE:
*******************
    
	Y.CORE.STMT.NOS = R.DIARY<SC.DIA.STATEMENT.NO>
	CSQN.VAL = FIELD(Y.CORE.STMT.NOS,@SM,1,1)
	CSEQ.VAL = FIELD(Y.CORE.STMT.NOS,@SM,2,1)
	CFVAL = FIELD(CSEQ.VAL,'-',1,1)
	CSVAL = FIELD(CSEQ.VAL,'-',2,1)
	FOR CX = CFVAL TO CSVAL
	    YN = CSQN.VAL:"000":CX
		IF YN <> STMT.ENT.ID THEN
		    CALL F.READ(FN.STMT.ENTRY,YN,R.STMT1,FP.STMT.ENTRY,STMT.ERR1)
			YY.TRANS.CODE = R.STMT1<AC.STE.TRANSACTION.CODE>
			CX = CSVAL
		END
	NEXT CX
	
    RETURN
*-----------------------------------------------------------------------------------------------------------	
DO.REV.ENTRY.PROCESS:
*********************

    ACC.TYPE = "SAO"
	CONVERT '*' TO VM IN Y.DIR.LOC.STMT.NOS
	GOSUB READ.LOC.STMT.ENTRIES
    GOSUB CALL.ACCOUNTING

* Update Local Entries to respective Deal -
	R.DIARY<SC.DIA.LOCAL.REF,Y.DIA.REV.STMT.POS> = Y.NEW.ENT.IDS
    CALL F.WRITE(FN.DIARY.HIS,Y.REV.DIA.ID,R.DIARY)
	CALL OCOMO("REV STMT.ENTRIES updated to Diary ":Y.TRN.ID)
	
    RETURN
*-------------------------------------------------------------------------------
READ.LOC.STMT.ENTRIES:
**********************

    R.STAT.ENTRY = '' ; R.ENTRY.ARRAY = ''

* CPSGMIG-23142 - S

	Y.OLD.ID.CHK = ''
	Y.OLD.ID.CHK = INDEX(Y.DIR.LOC.STMT.NOS,'-',1)
	IF Y.OLD.ID.CHK THEN
		GOSUB OLD.ENT.ID.PROCESS
	END ELSE
		GOSUB NEW.ENT.ID.PROCESS
	END
	
* CPSGMIG-23142 - E
	
	RETURN
*-------------------------------------------------------------------------------
NEW.ENT.ID.PROCESS:
*******************

	YLOC.ENT.CNT = 0	; Y.LOC.ENT.CNTR = 0
	YLOC.ENT.CNT = DCOUNT(Y.DIR.LOC.STMT.NOS,@VM)
	
	FOR Y.LOC.ENT.CNTR = 1 TO YLOC.ENT.CNT
		YNO = ''
		YNO = FIELD(Y.DIR.LOC.STMT.NOS,@VM,Y.LOC.ENT.CNTR,1)
		CALL F.READ(FN.STMT.ENTRY,YNO,R.STAT.ENTRY,FP.STMT.ENTRY,STMT.ERR)
	    Y.LCY.AMT.VAL = R.STAT.ENTRY<AC.STE.AMOUNT.LCY>
	    R.STAT.ENTRY<AC.STE.AMOUNT.LCY> = Y.LCY.AMT.VAL * (-1)
	    IF R.STAT.ENTRY<AC.STE.AMOUNT.FCY> THEN
	        Y.FCY.AMT.VAL = R.STAT.ENTRY<AC.STE.AMOUNT.FCY>
		    R.STAT.ENTRY<AC.STE.AMOUNT.FCY> = Y.FCY.AMT.VAL * (-1)
	    END
		R.STAT.ENTRY<AC.STE.REVERSAL.MARKER> = 'R'        ;* Indicates Reversal.
		R.STAT.ENTRY = LOWER(R.STAT.ENTRY)
        R.ENTRY.ARRAY<-1> = R.STAT.ENTRY
	NEXT Y.LOC.ENT.CNTR

    RETURN
*-------------------------------------------------------------------------------
OLD.ENT.ID.PROCESS:
*******************

	SQN.VAL = FIELD(Y.DIR.LOC.STMT.NOS,@VM,1,1)
	SEQ.VAL = FIELD(Y.DIR.LOC.STMT.NOS,@VM,2,1)
	FVAL = FIELD(SEQ.VAL,'-',1,1)
	SVAL = FIELD(SEQ.VAL,'-',2,1)
	FOR XV = FVAL TO SVAL
	    R.STAT.ENTRY = ''
		YNO = SQN.VAL:"000":XV
		CALL F.READ(FN.STMT.ENTRY,YNO,R.STAT.ENTRY,FP.STMT.ENTRY,STMT.ERR)
	    Y.LCY.AMT.VAL = R.STAT.ENTRY<AC.STE.AMOUNT.LCY>
	    R.STAT.ENTRY<AC.STE.AMOUNT.LCY> = Y.LCY.AMT.VAL * (-1)
	    IF R.STAT.ENTRY<AC.STE.AMOUNT.FCY> THEN
	        Y.FCY.AMT.VAL = R.STAT.ENTRY<AC.STE.AMOUNT.FCY>
		    R.STAT.ENTRY<AC.STE.AMOUNT.FCY> = Y.FCY.AMT.VAL * (-1)
	    END
		R.STAT.ENTRY<AC.STE.REVERSAL.MARKER> = 'R'        ;* Indicates Reversal.
		R.STAT.ENTRY = LOWER(R.STAT.ENTRY)
        R.ENTRY.ARRAY<-1> = R.STAT.ENTRY
	NEXT XV
	
	RETURN
*-------------------------------------------------------------------------------
END