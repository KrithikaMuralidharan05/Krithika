$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.MAST.CODE.EXTRACT.SELECT
*---------------------------------------------------------------------------
* Modification History :- 
* 10-Jan-2023 - Lavanya L  - NEW - CPSGMIG-17799
* Description 	:	The routine is used to send the daily dump of Fees & Charges 
*					configured for MF Instrument to Springwatch.
*--------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_B.SCB.RB.MAST.CODE.EXTRACT.COMMON
	$INSERT I_BATCH.FILES
	
	
	IF NOT(CONTROL.LIST) THEN
        CONTROL.LIST = "FH":@FM:"FC":@FM:"CHARGE.TYPE":@FM:"ARMCODE":@FM:"PROCODE"
    END
	BEGIN CASE
        CASE CONTROL.LIST<1,1> = "FH"
			SEL.CMD = "SELECT ":FN.CUSTOMER:" WITH L.O.B EQ '8' AND LR.PP.CODE NE ''"
		CASE CONTROL.LIST<1,1> = "FC"
			SEL.CMD = "SELECT ":FN.SECURITY.MASTER:" WITH SUB.ASSET.TYPE EQ ":Y.CHG.TYPE.VALUE
		CASE CONTROL.LIST<1,1> = "CHARGE.TYPE"
			SEL.CMD = "SELECT ":FN.CHARGE.TAX:" WITH CHG.COMM.CODE NE ''"
		CASE CONTROL.LIST<1,1> = "ARMCODE"
			SEL.CMD = "SELECT ":FN.DAO:" WITH L.O.B EQ '8' AND LR.ARM.CODE NE ''"
		CASE CONTROL.LIST<1,1> = "PROCODE"
			SEL.CMD = "SELECT ":FN.SUB.ASSET.TYPE:" WITH @ID EQ ":Y.CHG.TYPE.VALUE
	END CASE
	
	CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
    CALL BATCH.BUILD.LIST('',SEC.ID)
	
	RETURN
*--------------------------------------------------------------------------------
