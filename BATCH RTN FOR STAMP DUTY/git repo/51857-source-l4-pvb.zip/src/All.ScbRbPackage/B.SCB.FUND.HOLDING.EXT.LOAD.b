* @ValidationCode : Mjo5NDc1MTAwNTA6SVNPLTg4NTktMToxNjgxNzQ2Njg2MTUxOjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 17 Apr 2023 21:21:26
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*----------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FUND.HOLDING.EXT.LOAD
*----------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17751 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       10 Jan 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .LOAD Routine to extract iBanking Fund Holding details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.HOLDING.EXT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 10-Apr-2023   1663000          CPSGMIG-23263 - To remove duplicates in Holding file
* 17-Apr-2023   1663000          CPSGMIG-24759 - Exclude CPF/SRS Position
* 30-Jun-2023   1648769          CPSGMIG-29571 - i)To include zero holding. 
*                                                ii) To inculde no holdings to zero holdings, when ISA account is active for the asset type.
* 02-Feb-2024   1645888          ADO-2561964   - Ibanking response file to be enhanced to consolidate the Security Holding Position at the Rel Ids & Instrument level.
* 10607079 - 1526956 - SN-Swift - Exclusion of Aggregated Security Transfer transaction as part of the downstream reporting_PVB & RBSG
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.FUND.HOLDING.EXT.COMMON
    $INSERT I_F.AEB.SEC.PAR ;* ADO-2561964 - S/E
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB OPEN.FILES
    GOSUB GET.VALUES
    GOSUB GET.DEPO ;* ADO-2561964 - S/E
RETURN
*---------*
INITIALISE:
*---------*
    
    AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
	Y.FUND.TEMP.FILE = "T24SGIBANKHOLDINGTEMP-":TODAY:"-":SESSION.NO:".txt"
    
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    
    Y.APP       = 'CUSTOMER':@FM:'SEC.ACC.MASTER'
    Y.FIELD     = 'L.O.B':@FM:'LR.TP.ACCT.NO':@VM:'LR.TP.SYSTEM':@VM:'LR.TP.AC.STATUS'
    Y.FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    Y.LOB.POS = Y.FIELD.POS<1,1>
    Y.LR.TP.ACCT.NO.POS = Y.FIELD.POS<2,1>
    Y.LR.TP.SYSTEM.POS = Y.FIELD.POS<2,2>
    Y.LR.TP.AC.STATUS.POS = Y.FIELD.POS<2,3>
    
    Y.CPF.SRS.VAL = FIELD(BATCH.DETAILS<3,1>,'*',2) ;* CPSGMIG-24759
    CONVERT '|' TO @VM IN Y.CPF.SRS.VAL  ;* CPSGMIG-24759
    
RETURN
*---------*
OPEN.FILES:
*---------*

    FN.CURRENCY                   = 'F.CURRENCY'                    ; FV.CURRENCY                  = '' ; CALL OPF(FN.CURRENCY,FV.CURRENCY)
    FN.CUSTOMER                   = 'F.CUSTOMER'                    ; F.CUSTOMER                   = '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SEC.ACC.CUST               = 'F.SEC.ACC.CUST'                ; F.SEC.ACC.CUST               = '' ; CALL OPF(FN.SEC.ACC.CUST,F.SEC.ACC.CUST)
    FN.SEC.ACC.MASTER             = 'F.SEC.ACC.MASTER'              ; F.SEC.ACC.MASTER             = '' ; CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    FN.SECURITY.MASTER            = 'F.SECURITY.MASTER'             ; F.SECURITY.MASTER            = '' ; CALL OPF(FN.SECURITY.MASTER, F.SECURITY.MASTER)
    FN.SECURITY.POSITION          = 'F.SECURITY.POSITION'           ; F.SECURITY.POSITION          = '' ; CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)
    FN.SCB.WM.H.LOCAL.PARAM       = 'F.SCB.WM.H.LOCAL.PARAM'        ; F.SCB.WM.H.LOCAL.PARAM       = '' ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
    FN.SCB.RB.PENDING.TRANSACTION = 'F.SCB.RB.PENDING.TRANSACTION'  ; F.SCB.RB.PENDING.TRANSACTION = '' ; CALL OPF(FN.SCB.RB.PENDING.TRANSACTION,F.SCB.RB.PENDING.TRANSACTION)
    FN.AEB.SEC.PAR                = 'F.AEB.SEC.PAR'                 ; F.AEB.SEC.PAR                = '' ; CALL OPF(FN.AEB.SEC.PAR,F.AEB.SEC.PAR)        ;*CPSGMIG-24759

    FN.SCB.AT.SETT.DETAILS = 'F.SCB.AT.SETT.DETAILS' ; F.SCB.AT.SETT.DETAILS  = '' ; CALL OPF(FN.SCB.AT.SETT.DETAILS,F.SCB.AT.SETT.DETAILS) 
    FN.SEC.TRANSFER = 'F.SECURITY.TRANSFER' ; F.SEC.TRANSFER = '' ;    CALL OPF(FN.SEC.TRANSFER,F.SEC.TRANSFER)
    FN.SEC.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS' ; F.SEC.TRANSFER.HIS = '' ;     CALL OPF(FN.SEC.TRANSFER.HIS,F.SEC.TRANSFER.HIS)

RETURN
*---------*
GET.VALUES:
*---------*
    
    Y.LOCAL.PARAM.ID = 'SCB.CRES.SAT' ;  R.SCB.WM.H.LOCAL.PARAM = ''  ; LOCAL.PARAM.ERR = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.LOCAL.PARAM.ID,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,LOCAL.PARAM.ERR)
    
    Y.FIELD.NAME  = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.FIELD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>

    LOCATE "FI" IN Y.FIELD.NAME<1,1> SETTING FI.POS THEN
        Y.FI.SAT.ARRAY = Y.FIELD.VALUE<1,FI.POS>
        CONVERT @SM TO @VM IN Y.FI.SAT.ARRAY
    END
    
    LOCATE "SN" IN Y.FIELD.NAME<1,1> SETTING SN.POS THEN
        Y.SN.SAT.ARRAY = Y.FIELD.VALUE<1,SN.POS>
        CONVERT @SM TO @VM IN Y.SN.SAT.ARRAY
    END
    
    LOCATE "MF" IN Y.FIELD.NAME<1,1> SETTING MF.POS THEN
        Y.MF.SAT.ARRAY = Y.FIELD.VALUE<1,MF.POS>
        CONVERT @SM TO @VM IN Y.MF.SAT.ARRAY
    END
***10607079 -S
    R.LOC.PARAM = '' ; LOC.PARAM.ERR = '' ; Y.FIELD.NAME = '' ; Y.FIELD.VALUE = ''
	RB.SG.CUS.POS = '' ; RB.SG.CUST = '' ; PARAM.ID = 'SNSWIFT.DETS'
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,PARAM.ID,R.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,LOC.PARAM.ERR)
	IF R.LOC.PARAM THEN
		Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
		Y.FIELD.VALUE = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE>
		LOCATE 'RB.SG.CUS' IN Y.FIELD.NAME<1,1> SETTING RB.SG.CUS.POS THEN
			RB.SG.CUST = Y.FIELD.VALUE<1,RB.SG.CUS.POS>
			CHANGE @SM TO @VM IN RB.SG.CUST
		END
	END
***10607079 -E
* ADO-2561964 - S
*-----------------------------------------------------------------------------
GET.DEPO:
*--------
	Y.DEPOSITORY = ''
	SEL.CMD = 'SELECT ':FN.AEB.SEC.PAR:' WITH @ID LIKE ...CPF... OR WITH @ID LIKE ...SRS...'
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
*
	LOOP
		REMOVE Y.AEB.SEC.PAR.ID FROM SEL.LIST SETTING SEC.PAR.POS
    WHILE Y.AEB.SEC.PAR.ID:SEC.PAR.POS
		R.AEB.SEC.PAR = '' ; AEB.SEC.PAR.ERR = '' ; Y.DEPO = ''
		CALL F.READ(FN.AEB.SEC.PAR,Y.AEB.SEC.PAR.ID,R.AEB.SEC.PAR,F.AEB.SEC.PAR,AEB.SEC.PAR.ERR)
		Y.DEPO = R.AEB.SEC.PAR<SC.OPP.DEPOSITORY>
		IF NOT(Y.DEPOSITORY) THEN
			Y.DEPOSITORY = Y.DEPO
		END ELSE
			Y.DEPOSITORY<-1> = Y.DEPO
		END
	REPEAT
*
	CHANGE @FM TO @VM IN Y.DEPOSITORY
*
* ADO-2561964 - E   
RETURN
END