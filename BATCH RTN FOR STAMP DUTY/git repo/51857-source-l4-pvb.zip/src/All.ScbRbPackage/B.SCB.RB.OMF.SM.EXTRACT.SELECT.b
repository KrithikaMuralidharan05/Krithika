$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.OMF.SM.EXTRACT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name  : CPSGMIG-309 - JEWEL_T24_PROJECT
* Developed By  : 1625136
* Developed On  : 03 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract SM details
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.OMF.SM.EXTRACT.COMMON

	
	SEL.CMD = "SELECT ":FN.SECURITY.MASTER:" WITH SUB.ASSET.TYPE EQ ":Y.ALL.SAT.CODE:" AND NEW.SECURITY.NO EQ '' AND LR.RET.FND.FLAG EQ 'Y'"
    

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN
END
