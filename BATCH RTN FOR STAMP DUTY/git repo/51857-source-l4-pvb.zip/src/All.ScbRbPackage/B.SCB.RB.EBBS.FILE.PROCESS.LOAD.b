$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EBBS.FILE.PROCESS.LOAD

* This is BATCH routine which is attached to the SNG/SCB.EBBS.FILE.PROCESS. This routine
* loads the requested files and to process the EBBS incoming file.
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
* 10-Apr-2022 - Jaheer Hussain	- CPSGMIG-1490  - Development
*
* 05-Sep-2022 - kalaikumaranp 	- CPSGMIG-1490  - EBBS file processing
*
* 08-Dec-2023 - Loganathan G  	- ADO-2339312	- Exception handling in case of incorrect /incomplete EBBS request file for RB SG Statement via Locking
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SCB.EBBS.FILE.PARAM
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.SCB.EBBS.FILE.PROCESS.COMMON
	
    GOSUB OPEN.PARA
    GOSUB PROCESS.PARA
	
RETURN
*----------------------------------------------------------------------------*
OPEN.PARA:
**********

   FN.SCB.EBBS.FILE.PARAM = 'F.SCB.EBBS.FILE.PARAM'
   F.SCB.EBBS.FILE.PARAM  = ''
   CALL OPF(FN.SCB.EBBS.FILE.PARAM,F.SCB.EBBS.FILE.PARAM)

   FN.SAM = 'F.SEC.ACC.MASTER'
   F.SAM  = ''
   CALL OPF(FN.SAM,F.SAM)

   YF.LOCKING = 'F.LOCKING'
   FP.LOCKING = ''
   CALL OPF(YF.LOCKING,FP.LOCKING)

RETURN
*----------------------------------------------------------------------------*
PROCESS.PARA:
*************
    INFILE.PATH  = ''
    OUTFILE.PATH = ''
    BKPFILE.PATH = ''
    ERRFILE.PATH = ''
	
    GOSUB GET.FILE.PATH
	
RETURN
*----------------------------------------------------------------------------*
GET.FILE.PATH:
**************
    
    EBBS.INFIL.PATH = 'EBBS.MMINFILE'
    CALL SCB.GET.ORACLE.FILENAME(EBBS.INFIL.PATH, '', INFILE.PATH) 
	
    EBBS.OUTFIL.PATH = 'EBBS.MMOUTFILE'
    CALL SCB.GET.ORACLE.FILENAME(EBBS.OUTFIL.PATH, '', OUTFILE.PATH)

    EBBS.BKPFIL.PATH = 'EBBS.MMBKPFILE'
    CALL SCB.GET.ORACLE.FILENAME(EBBS.BKPFIL.PATH, '', BKPFILE.PATH)

    EBBS.ERRFIL.PATH = 'EBBS.MMERRFILE'
    CALL SCB.GET.ORACLE.FILENAME(EBBS.ERRFIL.PATH, '', ERRFILE.PATH)
	  
    INW.ERR.NAME = ID.COMPANY[1,2]:"-EBBS-FAILED-REC-":TODAY:".csv"
    INW.ERR.NAME:= ".":SESSION.NO
    	 
    FN.INW.FILE = INFILE.PATH
    F.INW.FILE  = ''
    CALL OPF(FN.INW.FILE, F.INW.FILE)	 
		 
    FN.OUT.FILE = OUTFILE.PATH
    F.OUT.FILE  = ''
    CALL OPF(FN.OUT.FILE, F.OUT.FILE)

    FN.BKP.FILE = BKPFILE.PATH
    F.BKP.FILE  = ''
    CALL OPF(FN.BKP.FILE, F.BKP.FILE)

    FN.ERR.FILE = ERRFILE.PATH
    F.ERR.FILE  = ''
    CALL OPF(FN.ERR.FILE, F.ERR.FILE) 	
	
RETURN
*----------------------------------------------------------------------------*
END	