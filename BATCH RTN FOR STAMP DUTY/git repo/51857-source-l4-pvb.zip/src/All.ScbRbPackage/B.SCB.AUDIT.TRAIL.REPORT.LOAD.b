$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.AUDIT.TRAIL.REPORT.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-374 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       06 January 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Load Routine to extract Audit Trail report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.AUDIT.TRAIL.REPORT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 25-Apr-2023 - CPSGMIG-19027 & 22843  1667095 - Additional Columns Included
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
    $INSERT I_F.CUSTOMER
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.AUDIT.TRAIL.REPORT.COMMON
*
	FN.CUSTOMER = 'F.CUSTOMER'
	FV.CUSTOMER = ''
	CALL OPF(FN.CUSTOMER,FV.CUSTOMER)
*
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	FN.SAM = 'F.SEC.ACC.MASTER'
	FV.SAM = ''
	CALL OPF(FN.SAM,FV.SAM)
*
	FN.SCB.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	FV.SCB.LOC.PARAM = ''
	CALL OPF(FN.SCB.LOC.PARAM,FV.SCB.LOC.PARAM)
*
	APPLN = 'CUSTOMER':@FM:'SEC.ACC.MASTER'
	LOC.FLDS = 'LR.PFOLIO.KEY':@VM:'LR.STAFF.IND':@VM:'L.O.B':@FM:'LR.TP.AC.STATUS':@VM:'LR.ISA.REMARKS':@VM:'LR.POS.MIG.DT' ;*CPSGMIG-19027 & 22843
	CALL MULTI.GET.LOC.REF(APPLN,LOC.FLDS,LOC.FLD.POS)
	Y.PORTFOLIO.KEY.POS = LOC.FLD.POS<1,1>
    Y.LR.STAFF.IND.POS = LOC.FLD.POS<1,2>
    Y.LOB.POS = LOC.FLD.POS<1,3>
	Y.AC.STATUS.POS = LOC.FLD.POS<2,1>
    Y.LR.ISA.REMARKS.POS = LOC.FLD.POS<2,2> ;*CPSGMIG-19027 & 22843
    Y.LR.POS.MIG.DT.POS = LOC.FLD.POS<2,3> ;*CPSGMIG-19027 & 22843
    
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    
	AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
	AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE.NAME = "AddressAuditTrailReport-":TODAY:"-":AGENT.NUMBER:".csv"
    
*
END
