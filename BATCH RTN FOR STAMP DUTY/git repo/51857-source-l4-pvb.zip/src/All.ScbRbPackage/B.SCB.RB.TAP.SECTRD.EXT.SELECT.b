$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.SECTRD.EXT.SELECT
**--------------------------------------------------------------------------------------------------------------------
    ! DESCRIPTION : THIS IS A SELECT FILE WHICH WILL SELECT ALL THE TRADE TRASACTION HAPPENED ON A DAY TO DAY BASIS
    !               FOR EXTRACTION.
**--------------------------------------------------------------------------------------------------------------------
*
* 16/08/2022 - Shreekantha. G - CPSGMIG-5346 - Copy of Existing Routine B.SCB.RB.EDM.SECTRD.EXT.SELECT.b
*
*---------------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.TAP.SECTRD.EXTRACT.COMMON
	$INSERT I_BATCH.FILES
*

	IF NOT(CONTROL.LIST) THEN
        CONTROL.LIST<-1> = "SEC.TRADE.EXT"
		CONTROL.LIST<-1> = "SEC.TRADE.REVE.TODAY"
    END

    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "SEC.TRADE.EXT"
		
            IF ID.COMPANY EQ "SG1090400" THEN   
				SEL.CMD = "SSELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":COUNTRY.NAME:"...*SCTRSC..."
			END ELSE        
				SEL.CMD = "SSELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":ID.COMPANY:"...*SCTRSC..."          
			END

			CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
			CALL BATCH.BUILD.LIST('',SEC.ID)
		CASE CONTROL.LIST<1,1> = "SEC.TRADE.REVE.TODAY"
			
			SEL.CMD = 'SSELECT ':FN.SCB.ENT.DAILY
			CALL EB.READLIST(SEL.CMD,ID.LIST,'',NO.OF.REC,ER)
			CALL F.READ(FN.SCB.ENT.DAILY,ID.LIST,R.SCB.ENT.DAILY,F.SCB.ENT.DAILY,ERR.DAILY)
			CALL BATCH.BUILD.LIST('',R.SCB.ENT.DAILY)
	END CASE		
			
    RETURN
*
*---------------------------------------------------------------------------------------------------------------------
END
*---------------------------------------------------------------------------------------------------------------------
