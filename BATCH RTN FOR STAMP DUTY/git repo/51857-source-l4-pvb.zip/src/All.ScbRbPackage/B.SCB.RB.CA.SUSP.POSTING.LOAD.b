$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CA.SUSP.POSTING.LOAD
*-------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-662
* Routine Type                 Batch process routine
* Attached To                  BATCH>SNG/B.SCB.RB.CA.SUSP.PROCESS
* Workflow                     This routine will read ACCT Entry table to identify Suspense Entry
*                              raised under PVB Category for RB Client on DIARY Transaction and
*                              arrange contra posting for PVB and actual posting for RB Susp Category.
*-------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      Description
*-------------------------------------------------------------------------------------------------------
*  Tejomurthy M        02/Sep/2022     CPSGMIG-662    Initial Draft
*-------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_F.CUSTOMER
    $INSERT I_F.DIARY
    $INSERT I_F.STMT.ENTRY
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_B.SCB.RB.CA.SUSP.POSTING.COMMON
   
    GOSUB INIT
	
    RETURN
*-------------------------------------------------------------------------------------------------------
INIT:
*****

    FN.CATEG.INT.ACCT = 'F.CATEG.INT.ACCT'
    FP.CATEG.INT.ACCT = ''
    CALL OPF(FN.CATEG.INT.ACCT,FP.CATEG.INT.ACCT)

    FN.ACCT.ENT.LWD = 'F.ACCT.ENT.LWORK.DAY'
	FP.ACCT.ENT.LWD = ''
	CALL OPF(FN.ACCT.ENT.LWD,FP.ACCT.ENT.LWD)
	
	FN.STMT.ENTRY = 'F.STMT.ENTRY'
	FP.STMT.ENTRY = ''
	CALL OPF(FN.STMT.ENTRY,FP.STMT.ENTRY)
	
	FN.CUSTOMER = 'F.CUSTOMER'
	FP.CUSTOMER = ''
	CALL OPF(FN.CUSTOMER,FP.CUSTOMER)
	
	FN.DIARY = 'F.DIARY'
	FP.DIARY = ''
	CALL OPF(FN.DIARY,FP.DIARY)
	
	FN.DIARY.HIS = 'F.DIARY$HIS'
	FP.DIARY.HIS = ''
	CALL OPF(FN.DIARY.HIS,FP.DIARY.HIS)
	
	FN.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    FV.PARAM = ''
    CALL OPF(FN.PARAM,FV.PARAM)
	
* To get the Susp Ac Category to be considered for processing -
    CALL F.READ(FN.PARAM,"SCB.PVB.CA.SUSP.CAT",R.PARAM.REC1,FV.PARAM,PARAM.READ.ERR1)
    Y.PARAM.FLDNAME1 = R.PARAM.REC1<SCBWM.PRM.FIELD.NAME>
    Y.PARAM.FLDVAL1 = R.PARAM.REC1<SCBWM.PRM.FIELD.VALUE>
    LOCATE 'SCB.PVB.CA.SUSP.CAT' IN Y.PARAM.FLDNAME1<1,1> SETTING CAT.POS1 THEN
        PVB.CAT = Y.PARAM.FLDVAL1<1,CAT.POS>
        CONVERT @SM TO @FM IN PVB.CAT
		Y.PVB.SUSP.AC.CAT = PVB.CAT
    END
	
* New Susp Ac Category to be considered for processing -
    CALL F.READ(FN.PARAM,"SCB.RBSG.CA.SUSP.CAT",R.PARAM.REC,FV.PARAM,PARAM.READ.ERR)
    Y.PARAM.FLDNAME = R.PARAM.REC<SCBWM.PRM.FIELD.NAME>
    Y.PARAM.FLDVAL = R.PARAM.REC<SCBWM.PRM.FIELD.VALUE>
    LOCATE 'SCB.RBSG.CA.SUSP.CAT' IN Y.PARAM.FLDNAME<1,1> SETTING CAT.POS THEN
        RB.CAT = Y.PARAM.FLDVAL<1,CAT.POS>
        CONVERT @SM TO @FM IN RB.CAT
		Y.RB.SUSP.AC.CAT = RB.CAT<1>
    END

* Fetching Local Field Positions -	
	Y.APPL      = 'CUSTOMER':@FM:'DIARY'
	Y.LOC.FLDS  = 'LWM.CUST.CLASS':@FM:'LR.RB.STMT.NOS':@VM:'LR.RB.REV.STNO'
    Y.LOC.REF.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APPL,Y.LOC.FLDS,Y.LOC.REF.POS)
	Y.CUST.CL.POS = Y.LOC.REF.POS<1,1>
	Y.DIA.STMT.POS = Y.LOC.REF.POS<2,1>
	Y.DIA.REV.STMT.POS = Y.LOC.REF.POS<2,2>

* Variable Initializations -
	Y.TEMP.ARRAY = ''
	Y.REV.MARKER = ''
	R.ENTRY.ARRAY = ''
	R.STAT.ENTRY = ''	
	
    RETURN
*-------------------------------------------------------------------------------------------------------
END