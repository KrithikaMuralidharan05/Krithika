$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.ENT.EXTRACT.DAY0.LOAD
**-----------------------------------------------------------------------------------------------------------
    ! CREATED DT  : 
    ! AUTHOR      : 
    ! CC NO       :
    ! DESCRIPTION : THIS LOAD FILE WILL LOAD ALL THE ENTITLEMENT TRASACTION HAPPENED ON A DAY TO DAY BASIS
    !               FOR EXTRACTION AND SENT TO TAP.
*
**-----------------------------------------------------------------------------------------------------------
*
* 16/08/2022 - Shreekantha. G - CPSGMIG-5346
* 27-Sep-2022 - Lavanya L - CPSGMIG-12635 Position of New field 
* 09-Feb-2023 - kalaikumaranp - CPSGMIG-14326 - T24 to TAP Sectrade Additional Fields.
*------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_TSA.COMMON
    $INSERT I_B.SCB.RB.TAP.ENT.EXTRACT.COMMON
    $INSERT I_BATCH.FILES     
*
    GOSUB INIT.PARA
*
    RETURN
*
*------------------------------------------------------------------------------------------------------------
INIT.PARA:
*--------*
*
    FN.SEC.MASTER = 'F.SECURITY.MASTER'
    F.SEC.MASTER = ''
    CALL OPF(FN.SEC.MASTER,F.SEC.MASTER)
*
    FN.SEC.TRD.TODAY = 'F.SEC.TRADES.TODAY'
    F.SEC.TRD.TODAY = ''
    CALL OPF(FN.SEC.TRD.TODAY,F.SEC.TRD.TODAY)
*
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
*
    FN.ENTITLEMENT = 'F.ENTITLEMENT'
    F.ENTITLEMENT = ''
    CALL OPF(FN.ENTITLEMENT,F.ENTITLEMENT)
*
    FN.DIARY = 'F.DIARY'
    F.DIARY = ''
    CALL OPF(FN.DIARY,F.DIARY)
*
    FN.SEC.TRADE = 'F.SEC.TRADE'
    F.SEC.TRADE = ''
    CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
*
    FN.SEC.TRD.REV = 'F.SEC.REVERSAL.TODAY'
    F.SEC.TRD.REV = ''
    CALL OPF(FN.SEC.TRD.REV,F.SEC.TRD.REV)
*
    FN.ENTITLEMENT.HIS = 'F.ENTITLEMENT$HIS'
    F.ENTITLEMENT.HIS = ''
    CALL OPF(FN.ENTITLEMENT.HIS,F.ENTITLEMENT.HIS)
*
    FN.DIARY.HIS = 'F.DIARY$HIS'
    F.DIARY.HIS = ''
    CALL OPF(FN.DIARY.HIS,F.DIARY.HIS)
*
	FN.CUST = 'F.CUSTOMER'
	F.CUST = ''
	CALL OPF(FN.CUST,F.CUST)
	  
    FN.AEB.SEC.PAR = 'F.AEB.SEC.PAR'
	F.AEB.SEC.PAR = ''
	CALL OPF(FN.AEB.SEC.PAR,F.AEB.SEC.PAR)
    
    LREF.APPL = 'ENTITLEMENT':@FM:'SECURITY.MASTER':@FM:'CUSTOMER':@FM:'DIARY'
    LREF.FLDS = 'SAME.INS.REF':@VM:'LR.NO.OF.SHS'
    LREF.FLDS := @FM:'TDS.GLOBAL.ID'
	LREF.FLDS := @FM:'L.O.B'
    LREF.FLDS := @FM:'LR.EVENT.DESC':@VM:'LR.RB.EX.DATE':@VM:'LR.SHS.STRK.PRC':@VM:'LR.SHS.ISIN.CDE':@VM:'LR.SHS.CCY':@VM:'LR.FIXING.DATE'			;*CPSGMIG-12635 - S/E
    LREF.POS = ''
    CALL MULTI.GET.LOC.REF(LREF.APPL,LREF.FLDS,LREF.POS)
    Y.SAME.INS.REF.POS = LREF.POS<1,1>
* CPSGMIG-14326    
    Y.LR.NO.OF.SHS = LREF.POS<1,2>
* CPSGMIG-14326
    Y.TDS.GLOBAL.ID.POS = LREF.POS<2,1>
	Y.CUST.LOB.POS = LREF.POS<3,1>
    Y.LR.EVENT.DESC.POS = LREF.POS<4,1>			;*CPSGMIG-12635 - S/E
	Y.LR.RB.EX.DATE.POS = LREF.POS<4,2>
* CPSGMIG-14326
    Y.LR.SHS.STRK.PRC.POS = LREF.POS<4,3>
    Y.LR.SHS.ISIN.CODE.POS = LREF.POS<4,4>
    Y.LR.SHS.CCY.POS = LREF.POS<4,5>
    Y.LR.FIXING.DATE.POS = LREF.POS<4,6>
* CPSGMIG-14326    
    TRADE.EXTRACT = ''
    TRADE.FLD = ''
*
    COUNTRY.CODE = ID.COMPANY[7,3]
    COUNTRY.NAME = ID.COMPANY[1,2]
    COUNTRY.NAME1 = COUNTRY.NAME
*
    Y.WRITE.FILE = 'T24-':COUNTRY.NAME1:'-RB-TAP-MANTAS-ENT-':TODAY:'.TXT-':AGENT.NUMBER			;* CPSGMIG-5346-S/E
*
    ARG1 = 'AMEX.FILES'
    CALL SCB.GET.ORACLE.FILENAME(ARG1,'',FOLDER.PATH)
    FILE.NAME = FOLDER.PATH
    
    RETURN
*
*------------------------------------------------------------------------------------------------------------
END
*------------------------------------------------------------------------------------------------------------
