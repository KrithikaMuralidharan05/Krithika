* @ValidationCode : MjoxODc5NDMxMzMwOklTTy04ODU5LTE6MTY4MjMzMzc0Nzg3NzoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 24 Apr 2023 16:25:47
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SP.EXTRACT.POST

*---------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-12700 - JEWEL_T24_PROJECT
* Developed By                   :       Sathish
* Developed On                   :       14 October 2022
*----------------------------------------------------------------------------------------------
* Description:
*-------------
* POST Routine to merge the spoke Monthly download files and generate final report
*----------------------------------------------------------------------------------------------
* Called From:  BATCH>SCB.WM.SP.EXTRACT
*--------------------------------------------------------------------------------------------
* Modification History :
*
* 1404392     16-Nov-2022 - CPSGMIG-14651 - ADVICE.INDEX field addition
* 1663000     27-Feb-2023 - CPSGMIG-19026 - Daily Spoke Monthly Report
* 1663000     11-Apr-2023 - CPSGMIG-22845 & 22846  - Include Position Migration flag column
* 1663000     26-Apr-2023 - CPSGMIG-21498 - Filename Change
* 1648769     28-Apr-2023   CPSGMIG-14070   To includ customer type, Portfolio valuation and the RM details.
* 1671073     05-Jun-2023   CPSGMIG-24900   Adding 2 new fields viz Average Unit Cost & Unrealized P/L
*----------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB PROCESS

RETURN
*---------*
INITIALISE:
*---------*
    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
    
    Y.DATA = BATCH.DETAILS<3,1>                      ;* CPSGMIG-19026 -S
    CONVERT @SM TO @FM IN Y.DATA
    MTH.DAILY.FLAG    = FIELD(Y.DATA,'*', 1)
    Y.UTS.FINAL.FILE  = FIELD(Y.DATA,'*', 2)         ;* CPSGMIG-19026 -E

    Y.LWD            = R.DATES(EB.DAT.LAST.WORKING.DAY) ;* CPSGMIG-21498
    Y.UTS.FINAL.FILE = EREPLACE(Y.UTS.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
    
    YDL = ','

RETURN
*------*
PROCESS:
*------*

    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.UTS.ARR = '' ; Y.FINAL.UTS.ARR = ''
*
    Y.UDFILE    = 'AMEX.FILES'
    IF MTH.DAILY.FLAG EQ 'D' THEN     ;*CPSGMIG-19026 -S
        SEL.CMD = "SpokeDailyDownload-":TODAY:"-*.csv*"
    END ELSE                          ;*CPSGMIG-19026 -E
        SEL.CMD = "SpokeMonthlyDownload-":TODAY:"-*.csv*"
    END                               ;*CPSGMIG-19026 -S/E

    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN

        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS

            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)

            IF NOT(R.UTS.ARR) THEN
                R.UTS.ARR = R.AMEX.FILE
            END ELSE
                R.UTS.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)

        REPEAT
* Include the Header part
        IF MTH.DAILY.FLAG EQ 'M' THEN                ;*CPSGMIG-19026 -S/E
            Y.UTS.HDR  = 'Vestima':YDL:'Ctry':YDL:'Account':YDL:'Account Holder 1':YDL:'ID Number 1':YDL:'Account Holder 2':YDL:
            Y.UTS.HDR  := 'ID Number 2':YDL:'Account Holder 3':YDL:'ID Number 3':YDL:'Account Holder 4':YDL:'ID Number 4':YDL:
            Y.UTS.HDR  := 'Home Telephone':YDL:'Work Telephone':YDL:'Date of Birth':YDL:'Account Open Date':YDL:'Product Provider Name':YDL:
            Y.UTS.HDR  := 'Asset':YDL:'Name':YDL:'CCY':YDL:'Price':YDL:'Price Date':YDL:'Units Balance':YDL:'AUM Amount':YDL:
            Y.UTS.HDR  := 'Address 1':YDL:'Address 2':YDL:'Address 3':YDL:'Address 4':YDL:'District':YDL:'State':YDL:'Country':YDL:
            Y.UTS.HDR  := 'Postal Code':YDL:'Country Full Name':YDL:'Branch':YDL:'Branch Description':YDL:'Product Type':YDL:
            Y.UTS.HDR  := 'Dividend Instruction':YDL:'ISIN Code':YDL:'Islamic Flag':YDL:'City':YDL:'EBBS.REL':YDL:'ClientIdentifier':YDL:'PrimaryAcctHolder':YDL:'Advice Index'
            Y.UTS.HDR  := YDL:'Position Migration Flag':YDL:'Customer Type':YDL:'RM Name'   ;*CPSGMIG-22845 & 22846 -S/E **CPSGMIG-14070-S/E
			Y.UTS.HDR  := YDL:'Average Unit Cost':YDL:'Unrealized P/L' 
        END ELSE                         ;*CPSGMIG-19026 -S
            Y.UTS.HDR  = 'Vestima':YDL:'Ctry':YDL:'Account':YDL:'Account Holder 1':YDL:'ID Number 1':YDL:'Account Holder 2':YDL:
            Y.UTS.HDR  := 'ID Number 2':YDL:'Account Holder 3':YDL:'ID Number 3':YDL:'Account Holder 4':YDL:'ID Number 4':YDL:
            Y.UTS.HDR  := 'Home Telephone':YDL:'Work Telephone':YDL:'Date of Birth':YDL:'Account Open Date':YDL:'Product Provider Name':YDL:
            Y.UTS.HDR  := 'Asset':YDL:'Name':YDL:'CCY':YDL:'Price':YDL:'Price Date':YDL:'Units Balance':YDL:'AUM Amount':YDL:
            Y.UTS.HDR  := 'Address 1':YDL:'Address 2':YDL:'Address 3':YDL:'Address 4':YDL:'District':YDL:'State':YDL:'Country':YDL:
            Y.UTS.HDR  := 'Postal Code':YDL:'Country Full Name':YDL:'Branch':YDL:'Branch Description':YDL:'Product Type':YDL:
            Y.UTS.HDR  := 'Dividend Instruction':YDL:'ISIN Code':YDL:'Islamic Flag':YDL:'City':YDL:'EBBS.REL':YDL:'ClientIdentifier':YDL:'PrimaryAcctHolder':YDL:'Advice Index'
            Y.UTS.HDR  := YDL:'Settlement Group':YDL:'Position Migration Flag':YDL:'Customer Type':YDL:'RM Name'   ;*CPSGMIG-22845 & 22846 -S/E **CPSGMIG-14070-S/E
        END
    
        Y.FINAL.UTS.ARR     = Y.UTS.HDR
        Y.FINAL.UTS.ARR<-1> = R.UTS.ARR

        WRITE Y.FINAL.UTS.ARR TO F.AMEX.FILES,Y.UTS.FINAL.FILE
    END

RETURN
END