$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.PORTFOL.EXTRACT.M.LOAD
*----------------------------------------------------------------------------------------------------------------
*
*
*-----------------------------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-----------------------------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864
*
* 17-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
*
* 27/10/2022 - Swaminathan.S.R - CPSGMIG-13848 - Report modification to send ISA details
*                                Copy of existing B.SCB.RB.EBBS.PORTFOL.EXTRACT routine + ISA Details added as per CPSGMIG-13848
*
* 30/10/2022 - Swaminathan.S.R - CPSGMIG-13848 - Day0 file doesnt require date check, so date check is removed
*
* 04/12/2022 - Sasi V - PF.SKIP - To suppress configured portfolio in SCB.WM.H.LOCAL.PARAM>SCB.RB.DPL.PF
* 24-Mar-2023 - Lavanya L - CPSGMIG-21169 - Tranche requirement
*-----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_TSA.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.LOCAL.TABLE
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM             ;*CPSGMIG-13848 S/E
    $INSERT I_B.SCB.RB.EBBS.PORTFOL.EXT.M.COMMON
*
    GOSUB INITIALISE
    GOSUB GET.LOC.REF.POS
*
    COUNTRY.NAME = ID.COMPANY[1,2]
*
    Y.FILE.NAME = COUNTRY.NAME:'-eBBS-T24AM-':TODAY:'.txt-':AGENT.NUMBER
*
RETURN
*
*-----------------------------------------------------------------------------------------------------------------
INITIALISE:
*---------*
* Initialise and open all the required application
*
	FN.SEC.ACC.MAST = 'F.SEC.ACC.MASTER'
	F.SEC.ACC.MAST = ''
	CALL OPF(FN.SEC.ACC.MAST,F.SEC.ACC.MAST)
*
	FN.CUST = 'F.CUSTOMER'
	F.CUST = ''
	CALL OPF(FN.CUST,F.CUST)
*
	AMEX.FILES.PATH = 'AMEX.FILES'
	CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, Y.APPEND.FILE)
*
*CPSGMIG-13848 Start
	FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.SCB.WM.H.LOCAL.PARAM  = ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
*CPSGMIG-13848 End
*
RETURN
*
*-----------------------------------------------------------------------------------------------------------------
GET.LOC.REF.POS:
*--------------*
* Get Local Ref Fields
*
	Y.APPLICATION = 'CUSTOMER':@FM:'SEC.ACC.MASTER'  ;*CPSGMIG-13848 S/E
*
    Y.FIELD = 'LR.EBBS.REL':@VM:'LR.PRIM.SEC.ID':@VM:'L.O.B':@FM:'LR.TP.ACCT.NO':@VM:'LR.PFOLIO.KEY':@VM:'LR.POS.MIG.DT'    ;*CPSGMIG-13848 S/E
*
	CALL MULTI.GET.LOC.REF(Y.APPLICATION,Y.FIELD,Y.LOC.REF.POS)
*
    Y.EBBS.CUST.REL.ID.POS = Y.LOC.REF.POS<1,1>
    Y.PRI.SEC.ID.POS = Y.LOC.REF.POS<1,2>
    Y.CUST.LOB.POS = Y.LOC.REF.POS<1,3>
*CPSGMIG-13848 Start
    Y.LR.TP.ACCT.NO.POS = Y.LOC.REF.POS<2,1>
    Y.LR.PFOLIO.KEY.POS = Y.LOC.REF.POS<2,2>
*CPSGMIG-13848 End
	Y.LR.POS.MIG.DT.POS = Y.LOC.REF.POS<2,3>			;**CPSGMIG-21169 - S/E
    Y.PARAM.ID    = 'SCB.CUST.SEG'
    Y.ALLOW.SEG   = 'RET'			;* Only Retail customer
    Y.ALLOWED.LOB = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
*CPSGMIG-13848 Start
    Y.WM.ID ="RSG.PILOT.IND" ; ERR.SCB.WM.H.LOC.P = '' ; R.SCB.WM.H.LOC.PARAM = '' ; Y.FIND.FIELD.NAME = 'UTS.ISA.NUMBERS' ; PATH.POS = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.WM.ID,R.SCB.WM.H.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOC.P)
	Y.FIELD.NAME = R.SCB.WM.H.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
    LOCATE Y.FIND.FIELD.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
	    ISA.LISTS = R.SCB.WM.H.LOC.PARAM<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>		;*Get the list of Individual ISA lists from table SCB.WM.H.LOCAL.PARAM
	    CONVERT @SM TO @VM IN ISA.LISTS
	END
*CPSGMIG-13848 End
*CPSGMIG-13878 Start
	ID.LOC.PARAM = 'RSG.PILOT.IND.CUST' ; ERR.SCB.WM.H.LOC.P = '' ; R.SCB.WM.H.LOC.PARAM = '' ; Y.FIND.FIELD.NAME = 'UTS.IND.CUST' ; PATH.POS = ''
	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,ID.LOC.PARAM,R.SCB.WM.H.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOC.P)
    Y.FIELD.NAME = R.SCB.WM.H.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
    LOCATE Y.FIND.FIELD.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
        Y.LOC.CUST.LIST = R.SCB.WM.H.LOC.PARAM<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>
        CONVERT @SM TO @VM IN Y.LOC.CUST.LIST
    END
*CPSGMIG-13878 End
*
* PF.SKIP - S
	LOC.PARAM.ID = 'SCB.RB.DPL.PF'
	R.LOC.PARAM.REC = '' ; E.LOC.PARAM.ERR = '' ; Y.PF.LIST = ''
	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,LOC.PARAM.ID,R.LOC.PARAM.REC,F.SCB.WM.H.LOCAL.PARAM,E.LOC.PARAM.ERR)
*
	IF R.LOC.PARAM.REC THEN
		Y.FLD.NAME = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.NAME>
		LOCATE 'PORT.SKIP' IN Y.FLD.NAME<1,1> SETTING Y.NAME.POS THEN
            Y.PF.LIST = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.VALUE,Y.NAME.POS>
			CHANGE @SM TO @FM IN Y.PF.LIST
        END
	END
* PF.SKIP - E
*CPSGMIG-21169 - S
	Y.FILE.FLAG =  ''
    R.LOC.PARAM.REC = ''
    LOC.PARAM.ERR = ''
   Y.ID.LOC.PARAM = 'SCB.RB.CUST.FULL.TRANCHE'
   Y.FIND.FILE.NAME = 'SG_eBBS_T24MA'
   CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.ID.LOC.PARAM,R.LOC.PARAM.REC,F.SCB.WM.H.LOCAL.PARAM,LOC.PARAM.ERR)
   IF R.LOC.PARAM.REC THEN
      Y.FIELD.NAME = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.NAME>
          LOCATE Y.FIND.FILE.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
           Y.FILE.FLAG = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>
        	CONVERT @SM TO @VM IN Y.FILE.FLAG
           	Y.FILE.FLAG = Y.FILE.FLAG<1,2>
          END
   END
*CPSGMIG-21169 - E
RETURN
*
*-----------------------------------------------------------------------------------------------------------------
END
*-----------------------------------------------------------------------------------------------------------------