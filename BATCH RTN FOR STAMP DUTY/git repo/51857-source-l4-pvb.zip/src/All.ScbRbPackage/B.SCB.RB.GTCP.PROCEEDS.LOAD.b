$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.PROCEEDS.LOAD
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-PROCEEDS-<start.date>-<end.date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.GTCP.PROCEEDS.COMMON

    GOSUB INITIALISE
    GOSUB OPEN.ALL.FILES

RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*----------
	FILE.NAME = ID.COMPANY[1,2]:"-MFU-PROCEEDS-":TODAY:".txt-":SESSION.NO
    DL = ','

RETURN
*-----------------------------------------------------------------------------
OPEN.ALL.FILES:
*--------------
    FN.SEC.TRADE = 'F.SEC.TRADE' ; F.SEC.TRADE = ''
    CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
*
	FN.SECURITY.TRANSFER = 'F.SECURITY.TRANSFER' ; F.SECURITY.TRANSFER = ''
	CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
*
	FN.POSITION.TRANSFER = 'F.POSITION.TRANSFER' ; F.POSITION.TRANSFER = ''
	CALL OPF(FN.POSITION.TRANSFER,F.POSITION.TRANSFER)
*
	FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER' ; F.SEC.ACC.MASTER = ''
	CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
    FN.SC.TRA.CODE = 'F.SC.TRA.CODE' ; F.SC.TRA.CODE = ''
    CALL OPF(FN.SC.TRA.CODE,F.SC.TRA.CODE)
*
    FN.SC.TRANS.TYPE = 'F.SC.TRANS.TYPE' ; F.SC.TRANS.TYPE = ''
    CALL OPF(FN.SC.TRANS.TYPE,F.SC.TRANS.TYPE)
*
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
	CONVERT @VM TO ' ' IN Y.ALLOWED.LOB
* PVB/RB Customer Demarkation
*
    Y.APP.NAME<1> = 'SEC.ACC.MASTER'
    Y.FLD.NAME<1> = 'LR.TP.ACCT.NO':@VM:'LR.PFOLIO.KEY'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
	LR.TP.ACCT.NO.POS = Y.FLD.POS<1,1>
	LR.PFOLIO.KEY.POS = Y.FLD.POS<1,2>
*
	Y.STEND.DATE = BATCH.DETAILS<3,1,2>
	Y.START.DATE = FIELD(Y.STEND.DATE,'-',1)
	Y.END.DATE   = FIELD(Y.STEND.DATE,'-',2,1)
*
RETURN
*-----------------------------------------------------------------------------
END
