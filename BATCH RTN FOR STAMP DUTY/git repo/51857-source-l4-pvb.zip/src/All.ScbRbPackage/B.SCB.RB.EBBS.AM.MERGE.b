$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.AM.MERGE
*-----------------------------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-----------------------------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864	New development
*
* 08-Dec-2022	 Lavanya L 	 CPSGMIG-17686 		File name change
*-------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY    
    $INSERT I_F.DATES   
*    
    GOSUB INIT.PARA
*	GOSUB HEADER.DETS
    GOSUB PROCESS.PARA
    GOSUB MOVE.FILE
*
	RETURN
*
*---------------------------------------------------------------------------------------------------------------------
INIT.PARA:
*---------------------------------------------------------------------------------------------------------------------
*
    Y.DELIM = '|'
    Y.FINAL.ID = ''
    Y.FILE.ARRAY = ''
	TOTAL.LINE.COUNT = 0
*
    COUNTRY.NAME = ID.COMPANY[1,2]  
*
    LINE.COUNT = ''
*    TOTAL.LINE.COUNT = ''
*
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
*  
	Y.NEXT.WORKING.DAY = R.DATES(EB.DAT.NEXT.WORKING.DAY)
	Y.FINAL.ID = COUNTRY.NAME:'_eBBS_T24AM_':TODAY:'.txt'			;*CPSGMIG-17686 - S/E
*
    RETURN
*
*---------------------------------------------------------------------------------------------------------------------
HEADER.DETS:
*----------*
*
    Y.HEAD = 'H'; Y.T24 = 'T24'; Y.COMP = 'SG'; Y.TODAY = TODAY
*    
    Y.HEADER = Y.HEAD:Y.DELIM:Y.T24:Y.DELIM:Y.COMP:Y.DELIM:TODAY				;*CPSGMIG-17686 - S/E

    Y.DET 		    = "D":Y.DELIM
    Y.ACT.TYPE 		= "ACTION_TYPE":Y.DELIM
    Y.SAM.ID 		= "ACT_NUMBER":Y.DELIM
    Y.CUST.ID1 		= "CUST_ID_01":Y.DELIM
    Y.CUST.ACC.REL1	= "CUST_A/C_REL_01":Y.DELIM
    Y.CUST.ID2 		= "CUST_ID_02":Y.DELIM
    Y.CUST.ACC.REL2 = "CUST_A/C_REL_02":Y.DELIM
    Y.CUST.ID3 		= "CUST_ID_03":Y.DELIM
    Y.CUST.ACC.REL3 = "CUST_A/C_REL_03":Y.DELIM
    Y.CUST.ID4 		= "CUST_ID_04":Y.DELIM
    Y.CUST.ACC.REL4 = "CUST_A/C_REL_04":Y.DELIM
    Y.ISCI.AC.PRD	= "ISCI_AC_PRD":Y.DELIM
    Y.ACC.BRANCH	= "ACCOUNT_BRANCH":Y.DELIM
    Y.DATE.OPEN     = "DATE_OPENED":Y.DELIM
    Y.ACC.STATUS    = "ACT_STATUS":Y.DELIM
    Y.DATE.CLOSE	= "DATE_CLOSED":Y.DELIM
    Y.SETT.CUR.COD	= "SETTLE_CURRCODE":Y.DELIM
    Y.SETT.ACT.NUM  = "SETTLE_ACT_NUMBER"
*
*   Y.HEADER<-1> = Y.DET:Y.ACT.TYPE:Y.SAM.ID:Y.CUST.ID1:Y.CUST.ACC.REL1:Y.CUST.ID2:Y.CUST.ACC.REL2:Y.CUST.ID3:Y.CUST.ACC.REL3:Y.CUST.ID4:Y.CUST.ACC.REL4:Y.ISCI.AC.PRD:Y.ACC.BRANCH:Y.DATE.OPEN:Y.ACC.STATUS:Y.DATE.CLOSE:Y.SETT.CUR.COD:Y.SETT.ACT.NUM
    Y.FINAL.FILE.ARRAY = Y.HEADER
*	
	RETURN
*	
*---------------------------------------------------------------------------------------------------------------------
PROCESS.PARA:
*---------------------------------------------------------------------------------------------------------------------
*
* Select all the files with file name like SG-eBBS-T24AM...
* and consolidate into a single file.
* Footer of the file contains 'T', total record count, YYYYDDMM
*
    Y.UDFILE    = 'AMEX.FILES'
    Y.CRITERIA  = COUNTRY.NAME:'-eBBS-T24AM-':TODAY:'.txt-*'
    SEL.FILE.ID = ''
    NO.OF.IDS   = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, SEL.FILE.ID, NO.OF.IDS)
*        
      
        LOOP
            REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
        WHILE Y.FILE.ID:POS
            CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.AMEX.FILES,F.APPEND.FILES,APP.ERR)
            ! Checking whether the file contains any record
            IF R.AMEX.FILES NE '' THEN
                Y.FILE.ARRAY<-1> = R.AMEX.FILES
* Count the number of records in the file to get the total count of CUSTOMER
                LINE.COUNT = DCOUNT(R.AMEX.FILES, @FM)
                TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
            END
* Delete the file after forming the array
            CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
            LINE.COUNT = ''
        REPEAT   
*
*---Call Java API to get Hash256 Sum value ----*

    Y.INPUT.PARAM = Y.FILE.ARRAY
    CHANGE @FM TO "" IN Y.INPUT.PARAM

    class_name = "com.hash.main.Sha256Utility"
    method_name = "sumValue"
    param = Y.INPUT.PARAM

    CALLJ class_name, method_name, param SETTING ret
 
    Y.HASH256SUM.VALUE = ret

*---Call Java API to get Hash256 Sum value ----*
    
    *TOTAL.LINE.COUNT1 = DCOUNT(Y.FILE.ARRAY,@FM)
    Y.TRAIL = 'T'; Y.TOTAL.LINE.COUNT = TOTAL.LINE.COUNT; Y.TODAY = TODAY ; Y.FILLER = ''
	
	IF Y.FILE.ARRAY THEN
		Y.FINAL.FILE.ARRAY<-1> = Y.FILE.ARRAY
	END
 *   Y.FINAL.FILE.ARRAY<-1> := Y.TRAIL:Y.DELIM:Y.TOTAL.LINE.COUNT:Y.DELIM:Y.TODAY:Y.DELIM:Y.HASH256SUM.VALUE
*
* Finally write the single file to the AMEX.FILES path
*    
	WRITE Y.FINAL.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID
*
	RETURN
*------------------------------------------------------------------------------------------------------------
MOVE.FILE:
*---------
	Y.EBBS.SOURCE.PATH = '../bnk.interface/outbound/SG/RB/eBBS/AM'
    Y.AMEX.PATH = '../bnk.interface/AMEX.FILES'
    
    EXE.MOVE.CMD = "SH -c 'mv ":Y.AMEX.PATH:"/":Y.FINAL.ID:" ":Y.EBBS.SOURCE.PATH:"/":Y.FINAL.ID:"'"
    CRT EXE.MOVE.CMD
    EXECUTE EXE.MOVE.CMD CAPTURING MVE.CMD.STATUS
	CALL OCOMO(MVE.CMD.STATUS)
	
	RETURN
*---------------------------------------------------------------------------------------------------------------------
END
*---------------------------------------------------------------------------------------------------------------------