$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PII.DETS.UPD(Y.REL.ID)
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* ADO Ref				       CPSGMIG-12313
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.PII.DETS.UPD
* Workflow                     This Multi Thread Service will select the SCB.RSG.PARTY.DETAILS table with PII.DETAILS LIKE …FAILED…
*                              and look into the concat table SCB.RSG.EBBS.REL.CONCAT and update the correct value.
**
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        06/Nov/2023     TBD        Initial Draft
*
*  Lew Bo Ren		   17/Jan/2024	   2506025	  Check for all Primary CIF, if record exists, all records check closure date. 
*                                                 If all portfolio closed, update PARTY concat table.
*
*  Tejomurthy M		   13/Mar/2024     3575091    Excluding NO.PRIMARY.RELATION case.
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.SCB.RSG.PARTY.DETAILS
	$INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT
	$INSERT I_B.SCB.RB.PII.DETS.UPD.COMMON

	GOSUB INIT
	GOSUB PROCESS
	GOSUB WRITE.DATA
	
	RETURN
*--------------------------------------------------------------------------------------------------------
INIT:
*****
	
	R.REL.CONCAT.DETS = ''	; REL.CONC.READ.ERR = '' ; R.SEC.ACC.MASTER = ''	; SAM.READ.ERR = ''
	Y.CUST.LIST = ''		; Y.PRIM.SEC.LIST = ''   ; PARTY.DETS.READ.ERR = ''	; R.PARTY.DETS = ''
	Y.CUS.CNT = ''			; Y.CHG.FLAG = ''
	
	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********
* Read the PARTY details Table -

	CALL F.READ(FN.PARTY.DETS,Y.REL.ID,R.PARTY.DETS,F.PARTY.DETS,PARTY.DETS.READ.ERR)
	
* Read the REL Concat table -

	CALL F.READ(FN.REL.CONCAT,Y.REL.ID,R.REL.CONCAT.DETS,F.REL.CONCAT,REL.CONC.READ.ERR)
	
* If there is NO entry in REL Concat table then no further action can be performed. Hence, return from the para -

	IF NOT(R.REL.CONCAT.DETS) THEN
		RETURN
	END
	
	Y.CUST.LIST = R.REL.CONCAT.DETS<ST.RSG.EBBS.MANDATE.KEY>
	Y.PRIM.SEC.LIST = R.REL.CONCAT.DETS<ST.RSG.EBBS.PRIM.SEC.INDICATOR>
		
* Loop through the entire mandate list to check for at least active Portfolio -

	Y.CUS.CNT = DCOUNT(Y.CUST.LIST,@VM)
	Y.CHKALL.CLOSE.COUNT = 0
	
	FOR I = 1 TO Y.CUS.CNT
		Y.CUST.ID = ''	; Y.CHG.FLAG = '' ; Y.ACTIVE = ''
		Y.CUST.ID = Y.CUST.LIST<1,I>
		GOSUB CHECK.SAM.CD
		IF Y.ACTIVE THEN
			I = Y.CUS.CNT	;* If at least one active portfolio then no further checks needed.
		END
	NEXT I
	
* If All are closed portfolio(s) then update as NO.ACTIVE.PORTFOLIO -

	IF Y.CHKALL.CLOSE.COUNT EQ Y.CUS.CNT THEN
		R.PARTY.DETS<PR.DETS.PII.DETAILS> = 'NO.ACTIVE.PORTFOLIO'	;* There is NO active Portfolio.
		Y.CHG.FLAG = 1
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
WRITE.DATA:
***********

	IF Y.CHG.FLAG THEN
		Y.APPLN = "SCB.RSG.PARTY.DETAILS"
        Y.LAST.FLD = "AUDIT.DATE.TIME"
        Y.SS.REC = ""
        Y.ERR = ""
        CALL EB.GET.APPL.FIELD(Y.APPLN,Y.LAST.FLD,Y.SS.REC,Y.ERR)

        TIME.STAMP = TIMEDATE()
        DIM R.DIM.REC(Y.LAST.FLD)
        MAT R.DIM.REC = ""
        CALL COMMON.SAVE
        MAT F = ''
        CALL AZ.AUTH.AND.HIST.WRITE(Y.APPLN,Y.REL.ID,R.PARTY.DETS)
        CALL COMMON.RESTORE
        CALL JOURNAL.UPDATE("Y.REL.ID")
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
CHECK.SAM.CD:
*************

	Y.SAM.ID = '' ; R.SEC.ACC.MASTER = '' ; SAM.READ.ERR = ''
	Y.SAM.ID = Y.CUST.ID:"-1"
	CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,SAM.READ.ERR)
	Y.CL.DATE = R.SEC.ACC.MASTER<SC.SAM.CLOSURE.DATE>
	IF Y.CL.DATE NE "" AND Y.CL.DATE LT TODAY THEN
		Y.CHKALL.CLOSE.COUNT = Y.CHKALL.CLOSE.COUNT + 1
	END ELSE
		Y.ACTIVE = 1	;* If there is at least one portfolio that is still opened, set flag to 1.
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------	
END