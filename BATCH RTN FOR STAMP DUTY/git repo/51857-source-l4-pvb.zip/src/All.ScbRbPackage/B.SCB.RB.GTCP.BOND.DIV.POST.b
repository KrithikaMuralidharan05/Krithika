$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.BOND.DIV.POST
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-BOND.DIVIDENDS-<start.date>-<end.date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.GTCP.BOND.DIV.COMMON
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
    Y.FINAL.FILE.NAME = '' ; R.GTCP.BOND.DIVIDENDS.FINAL.ARR = ''
    Y.FINAL.FILE.NAME = 'MFU-T24-BOND-DIVIDENDS-XX-':Y.START.DATE:'-':Y.END.DATE:'.csv'
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = ID.COMPANY[1,2]:'*-MFU-BOND-DIVIDENDS-*':TODAY:'.txt*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.GTCP.BOND.DIVIDENDS.FINAL.ARR EQ '' THEN
                R.GTCP.BOND.DIVIDENDS.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.GTCP.BOND.DIVIDENDS.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
		
		Y.BOND.DIVIDENDS.HEADER  = 'SRC_TRAN_ID,client_id,client_name,ACCT_HOST_NUM,currency_of_security_account_number,core_banking_relationship_number,'
		Y.BOND.DIVIDENDS.HEADER := 'core_banking_rel_number_secondary_1,core_banking_rel_number_secondary_2,core_banking_rel_number_secondary_3,ISIN_CD,'
		Y.BOND.DIVIDENDS.HEADER := 'stock_fund_name,market,MKT_PRC,local_stock_code,FUND_CD,FUND_NM,instrument_id,instrument_name,client_segment_code,'
		Y.BOND.DIVIDENDS.HEADER := 'customer_segment_description,TRAN_DT,value_date,INSTM_TRAN_CURY_CD,GRS_AMT,NET_AMT,WTHL_TAX_AMT,CORP_ACTN_TYPE,'
		Y.BOND.DIVIDENDS.HEADER := 'INSTM_TYPE,Reinvestment_PRC,NUM_OF_UNIT,ISU_CTRY,TRAN_TYPE,nar1,nar2,nar3,TRAN_RMK,nar1_1,glcode,glname,DR_CR_CD,'
		Y.BOND.DIVIDENDS.HEADER := 'corebanking_account_number,settlement_amount,settlement_currency,ssa_account_number,DATA_SRC_CTRY_CD,DATA_SRC_SYS_NM,W_SNAPSHOT_DT'
		
		R.GTCP.BOND.DIVIDENDS.FINAL = Y.BOND.DIVIDENDS.HEADER:@FM:R.GTCP.BOND.DIVIDENDS.FINAL.ARR
		WRITE R.GTCP.BOND.DIVIDENDS.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
    END
*
RETURN
*-----------------------------------------------------------------------------
END
