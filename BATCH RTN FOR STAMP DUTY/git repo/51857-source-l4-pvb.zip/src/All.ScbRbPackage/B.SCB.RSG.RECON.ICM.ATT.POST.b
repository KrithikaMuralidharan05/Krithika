$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.RECON.ICM.ATT.POST
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*Jira Reference:CPSGMIG-17414
*Developer : Raja Prabhu S
*Date : 14-APR-2023
*Description : Used to extract the details from ICM  for recon against the data from t24
*O/p : NA
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.RECON.ICM.ATT.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT
    

    GOSUB INIT
    GOSUB PROCESS
    
RETURN
*--------
INIT:
*----------
    
    FN.DEST.PATH = "./DATA.IN"
    F.DEST.PATH  = ''
    CALL OPF(FN.DEST.PATH,F.DEST.PATH)
    
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.SCB.WM.H.LOCAL.PARAM  = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)

    Y.ID = "MIG.MT.POST.PARAM"
    Y.BATCH.DATA = BATCH.DETAILS<3,1,1>

    
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.ID,R.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.PARAM.ERR)
    Y.BATCH.ID = R.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.FILE.NAMES = R.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>

    LOCATE Y.BATCH.DATA IN Y.BATCH.ID<1,1> SETTING Y.BATCH.POS THEN
        
        Y.PATH.FILE.SET = Y.FILE.NAMES<1,Y.BATCH.POS>

        Y.PATH.FILE = RAISE(Y.PATH.FILE.SET)
        Y.PATH.FILE.CNT = DCOUNT(Y.PATH.FILE,@VM)

        FOR I = 1 TO Y.PATH.FILE.CNT

            Y.FILE.CHECK = ''; Y.FILE.CHECK = Y.PATH.FILE<1,I>;*SRC need to be defined as first SV  in MIG.MT.POST.PARAM

            IF I = '1' THEN
                Y.SRC.FLD.PATH = FIELD(Y.FILE.CHECK,'>',1)
                Y.SRC.FILE.NAME = FIELD(Y.FILE.CHECK,'*',2)
                CALL OPF(Y.SRC.FLD.PATH,Y.SRC.FILEPATH)
            END ELSE
                BEGIN CASE
                    CASE I = 2
                        Y.DEST.FLD.PATH = FIELD(Y.FILE.CHECK,'>',1)
                        Y.DEST.FILE.NAME.POST = FIELD(Y.FILE.CHECK,'>',2)
                END CASE
            END
        
        NEXT I
    END
        
RETURN
                
*---------------------
PROCESS:
*----------------------

    CALL F.READ(FN.DEST.PATH,Y.DEST.FILE.NAME.POST,R.DEST.PATH,F.DEST.PATH,ERR.DEST)
    IF R.DEST.PATH THEN
        Y.REL.REC.CNT   =DCOUNT(R.DEST.PATH,@FM)
        FOR J = 1 TO Y.REL.REC.CNT
            Y.CUR.REC = R.DEST.PATH<J>
            Y.CUR.RELID = FIELD(Y.CUR.REC,'|',1)
            Y.CUR.W8.FLAG = FIELD(Y.CUR.REC,'|',3)
            Y.CUR.W8.EXP.DTE = FIELD(Y.CUR.REC,'|',4)
            Y.CUR.W9.FLAG = FIELD(Y.CUR.REC,'|',5)
            Y.CUR.W9.EXP.DTE = FIELD(Y.CUR.REC,'|',6)
            Y.NAT=FIELD(Y.CUR.REC,'|',7)
            Y.ADD.CODE =FIELD(Y.CUR.REC,'|',2)
            Y.US.PERSON = FIELD(Y.CUR.REC,'|',8)
            Y.AU.PERSON = FIELD(Y.CUR.REC,'|',9)
            Y.NZ.PERSON = FIELD(Y.CUR.REC,'|',10)
            Y.EU.PERSON = FIELD(Y.CUR.REC,'|',11)
            Y.MAN.KEY   = FIELD(Y.CUR.REC,'|',12)
            FIND Y.CUR.RELID IN Y.RECID.ARR SETTING Y.CURREC.POS THEN
                Y.EXIST.REC = Y.CURREC.ARR<Y.CURREC.POS>
                Y.EXIST.W8.FLAG = FIELD(Y.EXIST.REC,'|',3)
                Y.EXIST.W8.EXP.DTE = FIELD(Y.EXIST.REC,'|',4)
                Y.EXIST.W9.FLAG = FIELD(Y.EXIST.REC,'|',5)
                Y.EXIST.W9.EXP.DTE = FIELD(Y.EXIST.REC,'|',6)
                IF Y.EXIST.W8.FLAG EQ '' THEN
                    Y.EXIST.W8.FLAG = Y.CUR.W8.FLAG
                    Y.EXIST.W8.EXP.DTE = Y.CUR.W8.EXP.DTE
                END
                IF Y.EXIST.W9.FLAG EQ '' THEN
                    Y.EXIST.W9.FLAG = Y.CUR.W9.FLAG
                    Y.EXIST.W9.EXP.DTE = Y.CUR.W9.EXP.DTE
                END
                Y.EXIST.MAN.KEY =  FIELD(Y.EXIST.REC,'|',12)
                Y.CURREC.ARR<Y.CURREC.POS> = Y.CUR.RELID:'|': Y.ADD.CODE:'|':Y.EXIST.W8.FLAG:'|':Y.EXIST.W8.EXP.DTE:'|':Y.EXIST.W9.FLAG:'|':Y.EXIST.W9.EXP.DTE:'|':Y.NAT:'|':Y.US.PERSON:'|':Y.AU.PERSON:'|':Y.NZ.PERSON:'|':Y.EU.PERSON:'|':Y.MAN.KEY
                Y.DUP.ARR<-1> = Y.CUR.RELID:" - Already exists in Array"
            END ELSE
                Y.RECID.ARR<-1> = Y.CUR.RELID
                Y.CURREC.ARR<-1> = Y.CUR.REC
            END
        NEXT J
    END
    CALL F.WRITE(FN.DEST.PATH,"SCB.ICM.RECON.ATT.txt",Y.CURREC.ARR)
    CALL F.WRITE(FN.DEST.PATH,"SCB.ICM.RECON.DUP.EXEP.txt",Y.DUP.ARR)
RETURN
*----------------------------------------------------------------------
END
