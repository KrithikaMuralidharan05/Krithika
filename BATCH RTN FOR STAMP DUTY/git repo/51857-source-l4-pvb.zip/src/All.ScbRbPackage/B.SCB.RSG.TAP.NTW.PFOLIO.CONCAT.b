$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.TAP.NTW.PFOLIO.CONCAT
*-----------------------------------------------------------------------------
*Created by :-Pawan kr Sahu(1668106)
*Description:-Handling of exceptional cases for NTW Portfolio creation workflow
*Jira ref:-CPSGMIG-5871
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*
* 13-FEB-2024	Kavitha R -  ADO-2865634- SG - RTOB & TAP channel classification
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SC.SCB.RSG.TAP.NTW.PFOLIO.CONCAT
    $INSERT I_F.OFS.REQUEST.DETAIL
    
*
    GOSUB STRING.FORM
*
RETURN
*--------------------------*--------------------------*--------------------------
STRING.FORM:
*************
*
    CALL LOAD.COMPANY("SG1090400")
	COMP.ID =ID.COMPANY
    FN.SL ="&SAVEDLISTS&"
    F.SL =""
    CALL OPF(FN.SL,F.SL)
*
    FN.CUS = 'F.CUSTOMER'
    FV.CUS = ''
    CALL OPF(FN.CUS, FV.CUS)
    FN.CS = 'F.CUSTOMER.SECURITY'
    FV.CS = ''
    CALL OPF(FN.CS, FV.CS)
    
    FN.CS.HIS = 'F.CUSTOMER.SECURITY$HIS'
    FV.CS.HIS = ''
    CALL OPF(FN.CS.HIS, FV.CS.HIS)
    
    FN.SAM = 'F.SEC.ACC.MASTER'
    FV.SAM = ''
    CALL OPF(FN.SAM, FV.SAM)
    
    FN.SAM.NAU = 'F.SEC.ACC.MASTER$NAU'
    FV.SAM.NAU = ''
    CALL OPF(FN.SAM.NAU, FV.SAM.NAU)
*
    FN.ORD = "F.OFS.REQUEST.DETAIL"
    F.ORD =""
    CALL OPF(FN.ORD,F.ORD)
*
	FN.NTW.CONCAT = "F.SC.SCB.RSG.TAP.NTW.PFOLIO.CONCAT"
	F.NTW.CONCAT = ""
    CALL OPF(FN.NTW.CONCAT,F.NTW.CONCAT)
*
   
	SEL.CMD= "SELECT ":FN.SL:" WITH @ID LIKE ":"...NTW.PFOLIO... AND @ID UNLIKE ...NTW.PFOLIO...PROCESSED" ;*ADO-2865634-S/E
    SEL.LIST =""
    CALL EB.READLIST(SEL.CMD,SEL.LIST,"",NO.REC,ERR.LIST)
    LOOP
        REMOVE Y.OUT.OFS FROM SEL.LIST SETTING S.POS
    WHILE Y.OUT.OFS:S.POS
*
        R.SL = ""
        CALL F.READ(FN.SL,Y.OUT.OFS,R.SL,F.SL,SL.ERR)
        Y.SL.CNT =DCOUNT(R.SL,@FM)
        Y.STRING = R.SL
        R.NTW.CONCAT = ""
*
        GOSUB PROCESS
        R.NTW.CONCAT<SC.TAP.NTW.CO.CODE> =COMP.ID
        CALL F.WRITE(FN.NTW.CONCAT,Y.TABLE.ID,R.NTW.CONCAT)
*
		Y.PROCESSED.FILE.ID = Y.OUT.OFS:'-PROCESSED'
		CALL F.WRITE(FN.SL,Y.PROCESSED.FILE.ID,R.SL)
        GOSUB RM.FILES
    REPEAT
*
RETURN
*--------------------------*--------------------------*--------------------------
PROCESS:
************
*
    TOT.LEN =LEN(Y.STRING)
    Y.STR = ""
    Y.STR = DCOUNT(Y.STRING,'</request>')
    Y.RESPONSE.STRING = ""
    Y.OFS.STR.STAT =""
    Y.TXN.ID=""
    STRING.DATE =TODAY
    Y.DATE = ""
    ERROR.MSG =""
    Y.STATUS =""
    Y.APP =""
    Y.OFS.STR = ""
	Y.REQ.CNT = ""
	Y.ORD.ID = ""
    FINDSTR '</request>' IN Y.STRING SETTING S.POS THEN
        Y.STR.LEN = FIELD(Y.STRING,'</request>',S.POS):'</request>'
        Y.RESPONSE.STRING = FIELD(FIELD(Y.STR.LEN,'</request>',1),'<request>',2)
*
        Y.NTW.TAP.REQ.STATUS = FIELD(FIELD(Y.RESPONSE.STRING,',',5),"=",2)
*
        Y.OFS.STR.STAT = FIELD(FIELD(FIELD(Y.STR.LEN,",",1),'<request>','2'),"/",3)
        Y.OFS.STR.STATUS<-1> = FIELD(FIELD(Y.STR.LEN,"/",1),'<request>',2):"|":Y.OFS.STR.STAT
        Y.TXN.ID = FIELD(FIELD(Y.STR.LEN,"/",1),'<request>',2)
*
        Y.TIME = CHANGE(OCONV(TIME(),'MT'),":","")

        Y.INP.TXN.TIME = TODAY:Y.TIME
        Y.TABLE.ID = 'TAP.NTW.PFOLIO-':Y.TXN.ID:'-':Y.NTW.TAP.REQ.STATUS:'-':Y.INP.TXN.TIME
        Y.ORD.ID =FIELD(Y.STR.LEN,"/",2)
        Y.DATE =STRING.DATE
*
        GOSUB OFS.ORD.DETAILS
        Y.FIELD.STATUS =Y.OFS.STR.STAT
        IF Y.FIELD.STATUS EQ "-1" THEN
            Y.STATUS = "FAILURE"
            ERROR.MSG = "Failure in Flow"
        END
        ELSE
            ERROR.MSG =""
            Y.STATUS = "SUCCESS"
        END
        J = 1
        GOSUB UPDATE.TABLE
    END

    J = 2
	
	LOOP
	WHILE J LE Y.STR
        Y.REQ.CNT+ =LEN(Y.STR.LEN)
        Y.TOT.LEN = TOT.LEN-(Y.REQ.CNT)
        Y.OFS.STR = Y.STRING[Y.TOT.LEN]
        FINDSTR '</request>' IN Y.OFS.STR SETTING S.POS THEN
           
            Y.STR.LEN = FIELD(Y.OFS.STR,'</request>',S.POS):'</request>'
            Y.RESPONSE.STRING = FIELD(FIELD(Y.STR.LEN,'</request>',1),'<request>',2)
			Y.OFS.STR.STAT = FIELD(FIELD(FIELD(Y.STR.LEN,",",1),'<request>','2'),"/",3)
			Y.OFS.STR.STATUS<-1> = FIELD(FIELD(Y.STR.LEN,"/",1),'>',2):"|":Y.OFS.STR.STAT
            Y.TXN.ID = FIELD(FIELD(Y.STR.LEN,"/",1),'<request>',2)
            
            Y.ORD.ID =FIELD(Y.STR.LEN,"/",2)
            Y.DATE =STRING.DATE
            GOSUB OFS.ORD.DETAILS
            Y.FIELD.STATUS =Y.OFS.STR.STAT
            GOSUB APPEND.STATUS
*
            GOSUB UPDATE.TABLE
            
        END
        J+=1
    REPEAT

RETURN
*--------------------------*--------------------------*--------------------------
OFS.ORD.DETAILS:
    
    CALL F.READ(FN.ORD,Y.ORD.ID,R.ORD,F.ORD,RD.ERR)
    OFS.ORD.ID = Y.ORD.ID
    Y.APP =R.ORD<1>
    
RETURN
*--------------------------*--------------------------*--------------------------
APPEND.STATUS:

    IF Y.FIELD.STATUS EQ "1" THEN
        Y.STATUS = "SUCCESS"
        ERROR.MSG =""
    END
    ELSE
        Y.STATUS = "FAILURE"
        Y.ERR.MSG =FIELD(FIELD(Y.STR.LEN, ',' , 2),"<",1)
        ERROR.MSG =Y.ERR.MSG
    END
*
RETURN
*--------------------------*--------------------------*--------------------------
UPDATE.TABLE:
*-----------*
*
    Y.NO = J
*
    R.NTW.CONCAT<SC.TAP.NTW.OFS.RESPONSE,Y.NO> = Y.RESPONSE.STRING
*
    R.NTW.CONCAT<SC.TAP.NTW.STATUS,Y.NO> = Y.STATUS
*
    R.NTW.CONCAT<SC.TAP.NTW.APPLICATION,Y.NO> = Y.APP
    R.NTW.CONCAT<SC.TAP.NTW.ORD.ID,Y.NO> = OFS.ORD.ID
    R.NTW.CONCAT<SC.TAP.NTW.ERR.MSG,Y.NO> = ERROR.MSG
    R.NTW.CONCAT<SC.TAP.NTW.TXN.ID,Y.NO> = Y.TXN.ID
    R.NTW.CONCAT<SC.TAP.NTW.DATE,Y.NO> = Y.DATE

    IF (Y.APP EQ 'SCB.RSG.TAP.API.NTW.DETS') AND (Y.STATUS EQ 'FAILURE') THEN
        Y.NTW.APP.STATUS = 'FAILURE'
        Y.TAP.REQ.ID = Y.TXN.ID
    END
*
    IF Y.NTW.APP.STATUS NE '' AND Y.APP EQ 'CUSTOMER.SECURITY' THEN
        GOSUB VERIFY.CORE.APP.RECORDS
    END
    
*
RETURN
*--------------------------*--------------------------*--------------------------
RM.FILES:
*****************
***	EXE.FILE.DEL.CMD = "SH -c ":"rm ":FN.SL:"/":Y.OUT.OFS
***	EXECUTE EXE.FILE.DEL.CMD
    CALL F.DELETE(FN.SL,Y.OUT.OFS)
RETURN
*--------------------------*--------------------------*--------------------------
VERIFY.CORE.APP.RECORDS:
*
    Y.CS.ID = Y.TXN.ID
    R.CUS.REC = ''
    E.CUS.ERR = ''
    CALL F.READ(FN.CUS,Y.CS.ID,R.CUS.REC,FV.CUS,E.CUS.ERR)

    R.SAM.REC = ''
    E.SAM.ERR = ''
    Y.SAM.ID = Y.CS.ID:'-1'
    CALL F.READ(FN.SAM.NAU,Y.SAM.ID,R.SAM.REC.NAU,FV.SAM.NAU,E.SAM.ERR)
    IF R.SAM.REC.NAU EQ '' THEN
        CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM.REC,FV.SAM,E.SAM.ERR)
    
        IF R.CUS.REC EQ '' AND R.SAM.REC EQ '' THEN
            CALL OCOMO('Selected Customer Security record is :- ':Y.CS.ID)
            Y.CUS.SEC.LIST<-1> = Y.CS.ID
            CALL F.DELETE(FN.CS,Y.CS.ID)
            Y.CS.ID.HIS = Y.CS.ID:";1"
            CALL F.READ(FN.CS.HIS,Y.CS.ID.HIS,R.CS.HIS,FV.CS.HIS,CS.HIS.ERR)
            IF R.CS.HIS THEN
                CALL F.DELETE(FN.CS.HIS,Y.CS.ID.HIS)
            END
        END
    END

    
    Y.TIMEDATE.STP = ''
    Y.TIME = ''
    Y.TIMEDATE.STP = TIMEDATE()
    Y.TIME = TODAY:'-':Y.TIMEDATE.STP[1,2]:Y.TIMEDATE.STP[4,2]
*
    SL.FILE.ID = 'NTW.CUS.SEC-DEL.LIST-':Y.TAP.REQ.ID:'-':Y.TIME 
    WRITE Y.CUS.SEC.LIST TO F.SL,SL.FILE.ID
RETURN
*--------------------------*--------------------------*--------------------------
END