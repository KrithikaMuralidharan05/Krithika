* @ValidationCode : MjoxOTg2MzQ2MTA3OklTTy04ODU5LTE6MTY4MzAyNDM0MTk5MToxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 02 May 2023 16:15:41
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SM.EXTRACT(Y.SM.ID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5311 - JEWEL_T24_PROJECT
* Developed By                   :       1494730
* Developed On                   :       21 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract SM details
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*10-Nov-2022    1404392       	CPSGMIG-16220 Asset Name multivalue changed to null and DQUOTES added
*28-Nov-2022	1667095		CPSGMIG-17481 To filter out PVB SAT codes
* 7-Dec-2022    1404392         CPSGMIG-17645 Asset master listing is showing WRAP funds (belongs to PVB) and negative holdings.
* 23-Jan-2023   1667095         CPSGMIG-17723 - Update mapping for product provider name
* 13-Feb-2023   Senthil         CPSGMIG-18727 - Updating mapping for Div Instruction (Unit/Cash) CASH OR REINVEST.
* 07-Mar-2023   1663000         CPSGMIG-18727 - Update DivInstruction as Cash/Reinvest
* 20-Mar-2023   1663000         CPSGMIG-18727 - Holdings not fetched for FI/SN
* 17-Apr-2023   1648769         CPSGMIG-14065 - Update mapping Asset Fee & Charge Detail
* 25-Apr-2023   1663000         CPSGMIG-18727 - Update mapping for Cash/Reinvest Acct no
* 28-Apr-2023   1663000         CPSGMIG-18727 - Update mapping for Cash/Reinvest acct when CashOrReinvest field is blank in SM
* 19-Jun-2023   1667095         CPSGMIG-29409 - Changes done to display units holding
* 20-Jan-2025	Padmapriya		6893710 - Added one column Depository to the Report which has the Depo details.
* 22-May-2025	8208772			ADO-8461567   - Closed SM details are not displayed due to the missing end in the IF condition.
*--------------------------------------------------------------------------------------------
 
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.CUSTOMER.SECURITY
*CPSGMIG-14065-S
    $INSERT I_F.SC.TRAIL.FEES.ARRANGEMENT
    $INSERT I_F.FT.COMMISSION.TYPE
*CPSGMIG-14065-E
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.RB.SM.EXTRACT.COMMON
    $INSERT I_F.AEB.SEC.PAR

    GOSUB PROCESS
    
RETURN

 
PROCESS:
*********
    I+=1
    GOSUB EXTRACT.SM.DETS
    GOSUB EXTRACT.MAPPING
*CPSGMIG-17645 Start
    
    IF Y.SAT.TYPE EQ 'MF' THEN                      ;* CPSGMIG-18727 -s
        GOSUB GET.UNIT.HOLDINGS.DEPO	;* To Get the holdings for Active Instrument Depository wise
        Y.REINVEST.BK.NO = Y.REINVEST.ACC.NO
        FOR J = 1 TO 2

*6893710-S Added new logic to handle multiple depo for CASH and REINVEST.
            IF J = 1 AND (Y.UNIT.HOLDINGS.C NE '') THEN
		
				Y.DEPO.CNT = DCOUNT(Y.DEPO.CASH,@FM)
				IF NOT(Y.DEPO.CNT) THEN
					Y.DEPO.CNT = 1
				END
				FOR DEPO.J = 1 TO Y.DEPO.CNT
					Y.REINVEST.ACC.NO = ''
					Y.CASH.OR.REINV = 'CASH'
					Y.DEPO = FIELD(Y.DEPO.CASH,@FM,DEPO.J,1)
					Y.UNIT.HOLDINGS = FIELD(Y.UNIT.HOLDINGS.C,@FM,DEPO.J,1)
					IF NOT(Y.UNIT.HOLDINGS) THEN
						Y.UNIT.HOLDINGS = 0
					END
					GOSUB FORM.ARRAY 
				NEXT DEPO.J
			                   
			END
            IF J = 2 AND (Y.UNIT.HOLDINGS.R NE '') THEN
				Y.DEPO.CNT = DCOUNT(Y.DEPO.REINV,@FM)
				IF NOT(Y.DEPO.CNT) THEN
					Y.DEPO.CNT = 1
				END
				FOR DEPO.J = 1 TO Y.DEPO.CNT
					Y.REINVEST.ACC.NO = Y.REINVEST.BK.NO
					Y.CASH.ACC.NO   = ''
					Y.CASH.OR.REINV = 'REINVEST'
					Y.DEPO = FIELD(Y.DEPO.REINV,@FM,DEPO.J,1)
					Y.UNIT.HOLDINGS = FIELD(Y.UNIT.HOLDINGS.R,@FM,DEPO.J,1)
					IF NOT(Y.UNIT.HOLDINGS) THEN
						Y.UNIT.HOLDINGS = 0
					END
					GOSUB FORM.ARRAY 
				NEXT DEPO.J
 
            END
*6893710-E
        NEXT J
    END ELSE
        GOSUB GET.UNIT.HOLDINGS ;*To Get the holdings for Active Instrument
     *   GOSUB FORM.ARRAY ;**6893710-S/E
    END                                             ;* CPSGMIG-18727 -e

RETURN

EXTRACT.SM.DETS:
*****************
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,ERR)
    IF R.SECURITY.MASTER THEN
        Y.SUB.ASSET.TYPE     = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
        PRODUCT.PROVIDER     = DQUOTE(R.SECURITY.MASTER<SC.SCM.LOCAL.REF,MF.ISSUER.NAME.POS>)
        Y.COMPANY.NAME	     = DQUOTE(R.SECURITY.MASTER<SC.SCM.COMPANY.NAME,1>)
        Y.DESCRIPT           = DQUOTE(R.SECURITY.MASTER<SC.SCM.DESCRIPT>)
        Y.NEW.SECURITY.NO    = R.SECURITY.MASTER<SC.SCM.NEW.SECURITY.NO>
        Y.SECURITY.CURRENCY  = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
        Y.TR.ISSUER          = R.SECURITY.MASTER<SC.SCM.TR.ISSUER>
        Y.CAPITAL.PROTECTION = R.SECURITY.MASTER<SC.SCM.CAPITAL.PROTECTION>
        Y.MUTUAL.FUND.IND    = R.SECURITY.MASTER<SC.SCM.MUTUAL.FUND>
        Y.TRADING.UNITS      = R.SECURITY.MASTER<SC.SCM.TRADING.UNITS>
        Y.ISSUE.DATE	     = R.SECURITY.MASTER<SC.SCM.ISSUE.DATE>
        Y.SECURITY.DOMICILE  = R.SECURITY.MASTER<SC.SCM.SECURITY.DOMICILE>
        Y.MIN.INIT.INVT	     = R.SECURITY.MASTER<SC.SCM.MIN.INIT.INVT>
        Y.MIN.SUBS.INVT	     = R.SECURITY.MASTER<SC.SCM.MIN.SUBS.INVT>
        Y.MIN.REDEM.AMT	     = R.SECURITY.MASTER<SC.SCM.MIN.REDEM.AMT>
        Y.MATURITY.DATE	     = R.SECURITY.MASTER<SC.SCM.MATURITY.DATE>
        Y.TRADING.UNITS	     = R.SECURITY.MASTER<SC.SCM.TRADING.UNITS>
        Y.PAR.VALUE	     = R.SECURITY.MASTER<SC.SCM.PAR.VALUE>
        Y.I.S.I.N.           = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
        Y.COOL.CANCEL.PERIOD = R.SECURITY.MASTER<SC.SCM.COOL.CANCEL.PERIOD>
        Y.CUT.OFF.TIME	     = R.SECURITY.MASTER<SC.SCM.CUT.OFF.TIME>
        Y.DATE.LAST.PRICE    = R.SECURITY.MASTER<SC.SCM.DATE.LAST.PRICE>
        Y.SEDOL.NO	     = R.SECURITY.MASTER<SC.SCM.SEDOL.NO>
        Y.LAST.PRICE	     = R.SECURITY.MASTER<SC.SCM.LAST.PRICE>
        Y.INPUTTER	     = FIELD(R.SECURITY.MASTER<SC.SCM.INPUTTER,1>,'_',2,1)
        Y.AUTHORISER         = FIELD(R.SECURITY.MASTER<SC.SCM.AUTHORISER>,'_',2,1)
        Y.DATE.TIME	     = R.SECURITY.MASTER<SC.SCM.DATE.TIME,1>
        Y.LR.UT.CODE.ID      = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LR.UT.CODE.ID.POS>
        Y.PR.ASSET.CLASS     = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,PR.ASSET.CLASS.POS>
        Y.ASSET.NAME         = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LR.UTS.INS.DESC.POS>
        Y.LR.MF.SWITCH.GR    = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LR.MF.SWITCH.GR.POS>
        Y.RIC.CODE           = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,RIC.CODE.POS>
        Y.LR.CHRG.FORM       = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LR.CHRG.FORM.POS>
        Y.LR.RETAIL.DEPO     = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LR.RETAIL.DEPO.POS>
        Y.CASH.OR.REINV      = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,CASH.OR.REINV.POS>
        Y.LM.RET.DEPO.INV    = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LM.RET.DEPO.INV.POS>
        
        BEGIN CASE                          ;* CPSGMIG-18727 -S
            CASE Y.CASH.OR.REINV EQ 'C'
                Y.CASH.OR.REINV = "CASH"
            CASE Y.CASH.OR.REINV EQ 'R'
                Y.CASH.OR.REINV = "REINVEST"
        END CASE                            ;* CPSGMIG-18727 -E

        GOSUB UPD.ASSET.CHARGES             ;*CPSGMIG-14065-S/E
        
    END
RETURN

EXTRACT.MAPPING:
*****************
    GOSUB GET.SAT.TYPE

    
    IF NOT(Y.ASSET.NAME) THEN
        Y.ASSET.NAME = Y.DESCRIPT
    END ELSE
        Y.ASSET.NAME = DQUOTE(Y.ASSET.NAME)
    END
    CONVERT @SM TO " " IN Y.ASSET.NAME
    CONVERT @VM TO " " IN Y.ASSET.NAME
    Y.ASSET.NAME = EREPLACE(Y.ASSET.NAME,',',' ')
    
    Y.UNIT.HOLDINGS = 0
    IF Y.NEW.SECURITY.NO THEN
        Y.STATUS = "Closed" ; *CPSGMIG-17481(S/E)
    END ELSE
        Y.STATUS = "Active"
	END  				   ;*ADO-8461567 S/E
        CALL F.READ(FN.CUSTOMER,Y.TR.ISSUER,R.CUSTOMER,F.CUSTOMER,ERR1)
*CPSGMIG-17723(S)
        Y.PRODUCT.PROVIDER = ''
        IF R.CUSTOMER AND (Y.SAT.TYPE EQ 'MF') THEN
            Y.NAME.1 = '' ; Y.NAME.2 = ''
            Y.NAME.1 = R.CUSTOMER<EB.CUS.NAME.1>
            Y.NAME.2 = R.CUSTOMER<EB.CUS.NAME.2>
            NAME.DL = ' '
            Y.PRODUCT.PROVIDER = Y.NAME.1:NAME.DL:Y.NAME.2
            CONVERT @VM TO '' IN Y.PRODUCT.PROVIDER
            Y.PRODUCT.PROVIDER	= EREPLACE(Y.PRODUCT.PROVIDER,',',' ')
        END
*CPSGMIG-17723(E)

        Y.GST.REQUIRED = R.CUSTOMER<EB.CUS.LOCAL.REF,LR.BELONG.STATS.POS>  ; *CPSGMIG-14065-S/E
        IF Y.GST.REQUIRED NE "Y" THEN
            Y.GST.REQUIRED = "N"
        END

        IF Y.COOL.CANCEL.PERIOD	THEN
            Y.CANCELLATION = "Y"
        END ELSE
            Y.CANCELLATION = "N"
        END
       
        IF Y.SAT.TYPE EQ 'MF' THEN

            IF Y.LR.RETAIL.DEPO EQ '6708' THEN                    ;*CPSGMIG-18727
                Y.CUST.NO = Y.LR.RETAIL.DEPO
                GOSUB GET.CUS.ACC.NO
                Y.CASH.ACC.NO = R.CUSTOMER<EB.CUS.EXTERN.CUS.ID>
                Y.VESTIMA = "YES"
            END                                                   ;*CPSGMIG-18727

            IF Y.LM.RET.DEPO.INV EQ '6709' THEN                   ;*CPSGMIG-18727
                Y.CUST.NO = Y.LM.RET.DEPO.INV
                GOSUB GET.CUS.ACC.NO
                Y.REINVEST.ACC.NO = R.CUSTOMER<EB.CUS.EXTERN.CUS.ID>
                Y.VESTIMA = "YES"
            END                                                   ;*CPSGMIG-18727

            IF Y.LR.RETAIL.DEPO NE '' AND Y.LR.RETAIL.DEPO NE '6708' THEN      ;*CPSGMIG-18727
                Y.CUST.NO = Y.LR.RETAIL.DEPO
                GOSUB GET.CUS.ACC.NO
                Y.CASH.ACC.NO = R.CUSTOMER.SECURITY<SC.CSC.DEP.EXT.ACC.ID>
                Y.VESTIMA = "NO"
            END                                                                ;*CPSGMIG-18727

            IF Y.LM.RET.DEPO.INV NE '' AND Y.LM.RET.DEPO.INV NE '6709' THEN    ;*CPSGMIG-18727
                Y.CUST.NO = Y.LM.RET.DEPO.INV
                GOSUB GET.CUS.ACC.NO
                Y.REINVEST.ACC.NO = R.CUSTOMER.SECURITY<SC.CSC.DEP.EXT.ACC.ID>
                Y.VESTIMA = "NO"
            END                                                                ;*CPSGMIG-18727
        END
*CPSGMIG-18727-(E)
        IF Y.CASH.OR.REINV = "CASH" THEN Y.REINVEST.ACC.NO = ''          ;*CPSGMIG-18727 -s/e
        IF Y.CASH.OR.REINV = "REINVEST" THEN Y.CASH.ACC.NO = ''          ;*CPSGMIG-18727 -s/e
        
        RETURN
                
GET.UNIT.HOLDINGS:
******************
*CPSGMIG-17645 Start
*SEL.CMD = "SELECT SUM(CLOSING_BAL_NO_NOM),SUM(UNSETTLED_NOM_DR),SUM(UNSETTLED_NOM_CR),SUM(NOM_AMT_BLOCKED) FROM ":Y.SCHEMA.NAME:".V_":Y.TABLE.NAME:" WHERE SECURITY_NUMBER = '":Y.SM.ID:"'"
*6893710-S
*SEL.CMD = "SELECT SUM(A.CLOSING_BAL_NO_NOM),SUM(A.UNSETTLED_NOM_DR),SUM(A.UNSETTLED_NOM_CR),SUM(A.NOM_AMT_BLOCKED) FROM ":Y.SCHEMA.NAME:".V_":Y.TABLE.NAME:" A JOIN ":Y.SCHEMA.NAME1:".V_":Y.TABLE.NAME1:" B ON A.CUSTOMER_NUMBER=B.CUSTOMER_NO WHERE SECURITY_NUMBER = '":Y.SM.ID:"' AND B.L_O_B IN ('":Y.ALLOWED.LOB:"')"
		SEL.CMD = "SELECT SUM(A.CLOSING_BAL_NO_NOM),SUM(A.UNSETTLED_NOM_DR),SUM(A.UNSETTLED_NOM_CR),SUM(A.NOM_AMT_BLOCKED),A.DEPOSITORY FROM ":Y.SCHEMA.NAME:".V_":Y.TABLE.NAME:" A JOIN ":Y.SCHEMA.NAME1:".V_":Y.TABLE.NAME1:" B ON A.CUSTOMER_NUMBER=B.CUSTOMER_NO WHERE SECURITY_NUMBER = '":Y.SM.ID:"' AND B.L_O_B IN ('":Y.ALLOWED.LOB:"') GROUP BY A.DEPOSITORY"		
*6893710-E
*CPSGMIG-17645 End
        RESULT.SET = "" ; RES.SET.FLG = '' ; Y.CLOSING.BAL.NO.NOM = '' ;**6893710-S/E
        CALL EB.EXEC.SQLQUERY(SEL.CMD,RESULT.SET)
 **6893710-S -Below is the logic for removing unified/ special character in RESULT.SET and change them to VM marker
* Y.CLOSING.BAL.NO.NOM = FIELD(RESULT.SET,@FM,1)
		

        Y.FM.CNT = DCOUNT(RESULT.SET,@FM)
        IF RESULT.SET THEN
            RES.SET.FLG = 1
        END
        FOR Y.LOOP = 5 TO (Y.FM.CNT-1)
            Y.5TH.DELIM.VALUE = FIELD(RESULT.SET,@FM,Y.LOOP,1) ; Y.5TH.DELIM.VALUE.NEW = '' ; LOOP.LEN = LEN(Y.5TH.DELIM.VALUE)
            FOR Y.LOOP.I = 1 TO LOOP.LEN
                IF NUM(Y.5TH.DELIM.VALUE[Y.LOOP.I,1]) THEN
                    Y.5TH.DELIM.VALUE.NEW = Y.5TH.DELIM.VALUE.NEW:Y.5TH.DELIM.VALUE[Y.LOOP.I,1]
                END ELSE
                    Y.5TH.DELIM.VALUE.NEW = Y.5TH.DELIM.VALUE.NEW:@VM:Y.5TH.DELIM.VALUE[(Y.LOOP.I+1),LOOP.LEN]
                    Y.LOOP.I = LOOP.LEN + 1
                END
            NEXT Y.LOOP.I
            IF Y.LOOP EQ 5 THEN
                Y.NEW.RESULT.SET = FIELD(RESULT.SET,@FM,1,4):@FM:Y.5TH.DELIM.VALUE.NEW:@FM:FIELD(RESULT.SET,@FM,(Y.LOOP+1),Y.FM.CNT)
            END ELSE
                Y.NEW.RESULT.SET = FIELD(Y.NEW.RESULT.SET,@FM,1,(Y.LOOP-1)):@FM:Y.5TH.DELIM.VALUE.NEW:@FM:FIELD(RESULT.SET,@FM,(Y.LOOP+1),Y.FM.CNT)
            END
            Y.LOOP = Y.LOOP + 3
        NEXT Y.LOOP
*
        IF Y.NEW.RESULT.SET NE '' THEN
            RESULT.SET = Y.NEW.RESULT.SET
        END
        Y.VM.CNT = DCOUNT(RESULT.SET,@VM)
        IF NOT(Y.VM.CNT) THEN
            Y.VM.CNT = 1
        END
        Y.SP.DEPOSITORY = '' ; Y.SP.DEPOSITORY.LOOP = '' ;Y.SP.DEPOSITORY.REC = '' ; Y.CLOSING.BAL.NO.NOM = '' ;Y.DEPO = ''
*Extract Depository from oracle query RESULT.SET
        IF RES.SET.FLG THEN
            FOR DEPO.I = 1 TO Y.VM.CNT
                Y.SP.DEPOSITORY.REC = FIELD(RESULT.SET,@VM,DEPO.I,1)
                Y.SP.DEPOSITORY.LOOP = FIELD(Y.SP.DEPOSITORY.REC,@FM,5,1)
				Y.CLOSING.BAL.NO.NOM =  FIELD(Y.SP.DEPOSITORY.REC,@FM,1,1)
                Y.SP.DEPOSITORY<1,-1> = Y.SP.DEPOSITORY.LOOP
				Y.UNIT.HOLDINGS = Y.CLOSING.BAL.NO.NOM
				Y.DEPO = Y.SP.DEPOSITORY.LOOP
				IF NOT(Y.UNIT.HOLDINGS) THEN
					Y.UNIT.HOLDINGS = 0
				END
                GOSUB FORM.ARRAY 
            NEXT DEPO.I
        END

**6893710-E

*CPSGMIG-17645 Start
*Y.UNSETTLED.NOM.DR = FIELD(RESULT.SET,@FM,2)
*Y.UNSETTLED.NOM.CR = FIELD(RESULT.SET,@FM,3)
*Y.NOM.AMT.BLOCKED = FIELD(RESULT.SET,@FM,4)
*Y.UNIT.HOLDINGS = (Y.CLOSING.BAL.NO.NOM-Y.UNSETTLED.NOM.CR-Y.NOM.AMT.BLOCKED) + (Y.UNSETTLED.NOM.DR)
        *Y.UNIT.HOLDINGS = Y.CLOSING.BAL.NO.NOM ;**6893710-S/E
*CPSGMIG-17645 End
**6893710-S
       * IF NOT(Y.UNIT.HOLDINGS) THEN
       *    Y.UNIT.HOLDINGS = 0
       * END
**6893710-E      
        RETURN

GET.UNIT.HOLDINGS.DEPO:
************************
        SEL.CMD = "SELECT SUM(A.CLOSING_BAL_NO_NOM),SUM(A.UNSETTLED_NOM_DR),SUM(A.UNSETTLED_NOM_CR),SUM(A.NOM_AMT_BLOCKED),A.DEPOSITORY FROM ":Y.SCHEMA.NAME:".V_":Y.TABLE.NAME:" A JOIN ":Y.SCHEMA.NAME1:".V_":Y.TABLE.NAME1:" B ON A.CUSTOMER_NUMBER=B.CUSTOMER_NO WHERE SECURITY_NUMBER = '":Y.SM.ID:"' AND B.L_O_B IN ('":Y.ALLOWED.LOB:"') GROUP BY A.DEPOSITORY"
        RESULT.SET = ""
        CALL EB.EXEC.SQLQUERY(SEL.CMD,RESULT.SET)
*Below is the logic for removing unified/ special character in RESULT.SET and change them to VM marker
        Y.FM.CNT = DCOUNT(RESULT.SET,@FM)
        IF RESULT.SET THEN
            RES.SET.FLG = 1
        END
        FOR Y.LOOP = 5 TO (Y.FM.CNT-1)
            Y.5TH.DELIM.VALUE = FIELD(RESULT.SET,@FM,Y.LOOP,1) ; Y.5TH.DELIM.VALUE.NEW = '' ; LOOP.LEN = LEN(Y.5TH.DELIM.VALUE)
            FOR Y.LOOP.I = 1 TO LOOP.LEN
                IF NUM(Y.5TH.DELIM.VALUE[Y.LOOP.I,1]) THEN
                    Y.5TH.DELIM.VALUE.NEW = Y.5TH.DELIM.VALUE.NEW:Y.5TH.DELIM.VALUE[Y.LOOP.I,1]
                END ELSE
                    Y.5TH.DELIM.VALUE.NEW = Y.5TH.DELIM.VALUE.NEW:@VM:Y.5TH.DELIM.VALUE[(Y.LOOP.I+1),LOOP.LEN]
                    Y.LOOP.I = LOOP.LEN + 1
                END
            NEXT Y.LOOP.I
            IF Y.LOOP EQ 5 THEN
                Y.NEW.RESULT.SET = FIELD(RESULT.SET,@FM,1,4):@FM:Y.5TH.DELIM.VALUE.NEW:@FM:FIELD(RESULT.SET,@FM,(Y.LOOP+1),Y.FM.CNT)
            END ELSE
                Y.NEW.RESULT.SET = FIELD(Y.NEW.RESULT.SET,@FM,1,(Y.LOOP-1)):@FM:Y.5TH.DELIM.VALUE.NEW:@FM:FIELD(RESULT.SET,@FM,(Y.LOOP+1),Y.FM.CNT)
            END
            Y.LOOP = Y.LOOP + 3
        NEXT Y.LOOP
*
        IF Y.NEW.RESULT.SET NE '' THEN
            RESULT.SET = Y.NEW.RESULT.SET
        END
        Y.VM.CNT = DCOUNT(RESULT.SET,@VM)
        IF NOT(Y.VM.CNT) THEN
            Y.VM.CNT = 1
        END
        Y.SP.DEPOSITORY = '' ; Y.SP.DEPOSITORY.LOOP = ''
*Extract Depository from oracle query RESULT.SET
        Y.UNIT.HOLDINGS.R = '' ; Y.UNIT.HOLDINGS.C = '' 
		Y.DEPO = '' ;*6893710-S/E
        IF RES.SET.FLG THEN
            FOR DEPO.I = 1 TO Y.VM.CNT
                Y.SP.DEPOSITORY.REC = FIELD(RESULT.SET,@VM,DEPO.I,1)
                Y.SP.DEPOSITORY.LOOP = FIELD(Y.SP.DEPOSITORY.REC,@FM,5,1)
                Y.SP.DEPOSITORY<1,-1> = Y.SP.DEPOSITORY.LOOP
                GOSUB CALC.UNITS ;* For each position get unit holding based on depo from SM>LR.RET.DEPO OR LM.RET.DEP.INV OR AEB.SEC.PAR
            NEXT DEPO.I
        END
        IF NOT(Y.UNIT.HOLDINGS.C) AND (Y.CASH.OR.REINV NE 'REINVEST') THEN ;*When CASH.OR.REINV is CASH or NULL and no holdings in SP, default to zero
          
		  Y.UNIT.HOLDINGS.C = 0
			
        END
        IF NOT(Y.UNIT.HOLDINGS.R) AND (Y.CASH.OR.REINV NE 'CASH') THEN ;*When CASH.OR.REINV is REINVEST or NULL and no holdings in SP, default to zero
            Y.UNIT.HOLDINGS.R = 0
			
        END
		
        RETURN
        
CALC.UNITS:
***************
        Y.CLOSING.BAL.NO.NOM.C = ''
        Y.CLOSING.BAL.NO.NOM.R = ''
*6893710-S
		Y.DEPO.C = ''
		Y.DEPO.R = ''
*6893710-E
        IF Y.SP.DEPOSITORY.LOOP THEN
            BEGIN CASE
                CASE Y.SP.DEPOSITORY.LOOP EQ Y.LR.RETAIL.DEPO
                    Y.CLOSING.BAL.NO.NOM.C = FIELD(Y.SP.DEPOSITORY.REC,@FM,1)
					Y.DEPO.C = Y.SP.DEPOSITORY.LOOP ;*6893710-S/E
        
                CASE Y.SP.DEPOSITORY.LOOP EQ Y.LM.RET.DEPO.INV
                    Y.CLOSING.BAL.NO.NOM.R = FIELD(Y.SP.DEPOSITORY.REC,@FM,1)
					Y.DEPO.R = Y.SP.DEPOSITORY.LOOP ;*6893710-S/E
                CASE 1
                    Y.ASP.CASH.REINV = ''
                    SEL.CMD = 'SELECT ':FN.AEB.SEC.PAR:' WITH @ID LIKE "SG...2.MF..." AND DEPOSITORY EQ "':Y.SP.DEPOSITORY.LOOP:'"'
                    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.SEL)
                    LOOP
                        REMOVE Y.AEB.PAR.ID FROM SEL.LIST SETTING Y.AEB.POS
                    WHILE Y.AEB.PAR.ID : Y.AEB.POS ;*check if record id is ALL TO DEFAULT TO CASH
                        IF Y.ASP.CASH.REINV NE '' THEN
                            BREAK
                        END
                        CALL F.READ(FN.AEB.SEC.PAR,Y.AEB.PAR.ID,R.AEB.SEC.PAR,F.AEB.SEC.PAR,PAR.ERR)
                        IF R.AEB.SEC.PAR THEN
                            GOSUB AEB.LOOP.PROCESS
                        END
                    REPEAT
            END CASE
        END
       IF Y.CLOSING.BAL.NO.NOM.C NE '' THEN
*6893710-S
            *Y.UNIT.HOLDINGS.C += Y.CLOSING.BAL.NO.NOM.C
			*Y.DEPO = Y.DEPO.C 
			Y.UNIT.HOLDINGS.C<-1> = Y.CLOSING.BAL.NO.NOM.C
			Y.DEPO.CASH<-1> = Y.DEPO.C
*6893710-E
        END
        IF Y.CLOSING.BAL.NO.NOM.R NE '' THEN
*6893710-S
        *    Y.UNIT.HOLDINGS.R += Y.CLOSING.BAL.NO.NOM.R
		*	Y.DEPO = Y.DEPO.R 
			Y.UNIT.HOLDINGS.R<-1> = Y.CLOSING.BAL.NO.NOM.R
			Y.DEPO.REINV<-1> = Y.DEPO.R
*6893710-E
        END

        RETURN

AEB.LOOP.PROCESS:
******************
*Fetch unit holding based on depo from AEB.SEC.PAR
        Y.DEPO.IDS       = R.AEB.SEC.PAR<SC.OPP.DEPOSITORY>
        Y.ASP.CASH.REINV = R.AEB.SEC.PAR<SC.OPP.CASH.OR.REINV>
        DEPO.COUNT = DCOUNT(Y.DEPO.IDS,@VM)
        LOCATE Y.SP.DEPOSITORY.LOOP IN Y.DEPO.IDS<1,1> SETTING DP.INT.POS THEN ;*Locate DEPOSITORY at first occurence to get CASH.OR.REINV value
            Y.ASP.CASH.REINV = Y.ASP.CASH.REINV<1,DP.INT.POS>
        END
        IF Y.ASP.CASH.REINV EQ 'C' THEN
            Y.CLOSING.BAL.NO.NOM.C = FIELD(Y.SP.DEPOSITORY.REC,@FM,1)
			Y.DEPO.C = Y.SP.DEPOSITORY.LOOP ;*6893710-S/E
        END
        ELSE IF Y.ASP.CASH.REINV EQ 'R' THEN
            Y.CLOSING.BAL.NO.NOM.R = FIELD(Y.SP.DEPOSITORY.REC,@FM,1)
			Y.DEPO.R = Y.SP.DEPOSITORY.LOOP ;*6893710-S/E
        END
        RETURN
        
GET.CUS.ACC.NO:
***************
        CALL F.READ(FN.CUSTOMER,Y.CUST.NO,R.CUSTOMER,F.CUSTOMER,ERR.DEPO)
        CALL F.READ(FN.CUSTOMER.SECURITY,Y.CUST.NO,R.CUSTOMER.SECURITY,F.CUSTOMER.SECURITY,Y.CS.ERR)

        RETURN

GET.SAT.TYPE:
*************
   
        R.SUB.ASSET.TYPE = '' ; SUB.ASSET.TYPE.ERR = '' ; Y.DESCRIPTION = '' ;
        CALL F.READ(FN.SUB.ASSET.TYPE,Y.SUB.ASSET.TYPE,R.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE,SUB.ASSET.TYPE.ERR)
        Y.DESCRIPTION = R.SUB.ASSET.TYPE<SC.CSG.DESCRIPTION>


        BEGIN CASE
            CASE (Y.SUB.ASSET.TYPE MATCHES Y.MF.PARAM.FLD.VALUE)
                Y.SAT.TYPE = "MF"
            CASE Y.SUB.ASSET.TYPE MATCHES Y.SN.PARAM.FLD.VALUE
                Y.SAT.TYPE = "SN"
                IF Y.CAPITAL.PROTECTION EQ "99" THEN
                    Y.SAT.TYPE = "Non Capital SN"
                END
                IF Y.CAPITAL.PROTECTION EQ "100" THEN
                    Y.SAT.TYPE = "Capital SN"
                END
            CASE Y.SUB.ASSET.TYPE MATCHES Y.FI.PARAM.FLD.VALUE
                Y.SAT.TYPE = Y.DESCRIPTION
            CASE 1
                Y.SAT.TYPE = ''
        END CASE
    

        RETURN

FORM.ARRAY:
************
        Y.ARRAY = Y.SAT.TYPE
        Y.ARRAY:= ",":Y.PRODUCT.PROVIDER     ;* 2.Product Provider name
        Y.ARRAY:= ",":Y.SM.ID                ;* 3.Asset Code
        Y.ARRAY:= ",":Y.LR.UT.CODE.ID        ;* 4.UT Asset Code
        Y.ARRAY:= ",":Y.PR.ASSET.CLASS       ;* 5.Asset Class
        Y.ARRAY:= ",":Y.ASSET.NAME           ;* 6.Asset Name
        Y.ARRAY:= ",":Y.LR.MF.SWITCH.GR	 ;* 7.Switch Group
        Y.ARRAY:= ",":Y.STATUS               ;* 8.Status
        Y.ARRAY:= ",":Y.SECURITY.CURRENCY    ;* 9.Currency Code
        Y.ARRAY:= ",":Y.PRICE.INDICATOR	 ;* 10.Price Indicator
        Y.ARRAY:= ",":Y.GST.REQUIRED         ;* 11.GST required
        Y.ARRAY:= ",":Y.LR.CHRG.FORM	 ;* 12.Commission Formula
        Y.ARRAY:= ",":Y.TRADING.UNITS	 ;* 13.Decimal Places (Unit)
        Y.ARRAY:= ",":Y.CASH.OR.REINV	 ;* 14.Div Instruction (Unit/Cash)
        Y.ARRAY:= ",":Y.ISSUE.DATE	         ;* 15.Launch Date
        Y.ARRAY:= ",":Y.SECURITY.DOMICILE	 ;* 16.Domicile Country
        Y.ARRAY:= ",":Y.MIN.INIT.INVT	 ;* 17.First Time Min. Subs Amount
        Y.ARRAY:= ",":Y.MIN.SUBS.INVT	 ;* 18.Min. Subs Amount
        Y.ARRAY:= ",":Y.MIN.REDEM.AMT	 ;* 19.Min. Redemption Amount
        Y.ARRAY:= ",":Y.MATURITY.DATE	 ;* 20.Maturity Date
        Y.ARRAY:= ",":Y.CASH.ACC.NO          ;* 21.Cash Account No
        Y.ARRAY:= ",":Y.REINVEST.ACC.NO      ;* 22.Reinvest Account No
        Y.ARRAY:= ",":Y.TRADING.UNITS	 ;* 23.Lot Size
        Y.ARRAY:= ",":"1"                    ;* 24.Par Value
        Y.ARRAY:= ",":Y.I.S.I.N.	         ;* 25.ISIN Code
        Y.ARRAY:= ",":Y.CUT.OFF.TIME	 ;* 26.Aggregation Cutoff Time
        Y.ARRAY:= ",":"2"                    ;* 27.Amount Round To Decimal
        Y.ARRAY:= ",":Y.CANCELLATION         ;* 28.Cancellation
        Y.ARRAY:= ",":Y.VESTIMA     	 ;* 29.Vestima
        Y.ARRAY:= ",":Y.RIC.CODE	         ;* 30.RIC IDENTIFIER
        Y.ARRAY:= ",":Y.DATE.LAST.PRICE	 ;* 31.EFFECTIVE DATE
        Y.ARRAY:= ",":Y.SEDOL.NO	         ;* 32.SEDOL Code
        Y.ARRAY:= ",":Y.UNIT.HOLDINGS	 ;* 33.Unit holdings
        Y.ARRAY:= ",":Y.LAST.PRICE	         ;* 34.NAV Price
*CPSGMIG-14065-S
        Y.ARRAY:= ",":Y.FT.ID	                 ;* 35.TR Fee code
        Y.ARRAY:= ",":Y.FT.DESC	                 ;* 36.TR Fee Description
        Y.ARRAY:= ",":Y.FT.UPTO	                 ;* 37.Upto Amount
        Y.ARRAY:= ",":Y.FT.PERCENT	         ;* 38.TR Fee Percentage
*CPSGMIG-14065-S
        Y.ARRAY:= ",":Y.INPUTTER             ;* 39.MAKER ID
        Y.ARRAY:= ",":Y.AUTHORISER           ;* 40.CHECKER ID
        Y.ARRAY:= ",":Y.DATE.TIME	         ;* 41.MAKER /AUTHORIZATION DATE
		Y.ARRAY:= ",":Y.DEPO                 ;* 42.DEPOSITORY ;*6893710-S/E

        GOSUB WRITE.SM.FILE
        RETURN
WRITE.SM.FILE:
***************
        IF Y.ARRAY THEN
            OPENSEQ AMEX.FILES,Y.FILE.ID TO FP.AMEX.FILES ELSE
            END
            WRITESEQ Y.ARRAY APPEND TO FP.AMEX.FILES ELSE
                CALL OCOMO("Unable to Write UTS Merger Report")
            END
            CLOSESEQ FP.AMEX.FILES
        
            IF MOD(I,1000) = 0 THEN
                CALL OCOMO("Completed Processing ":I:" Records")
            END
        END
        RETURN

UPD.ASSET.CHARGES:
******************
*CPSGMIG-14065-S
        TR.FEE.ERR  = ''
        Y.TR.FEE.ID = ''
        R.TR.FEE    = ''
        Y.FT.ID     = ''
        R.FT.REC    = ''
        FT.ERR      = ''
        Y.FT.DESC   = ''
        Y.FT.UPTO   = ''
        Y.FT.PERCENT = ''
        Y.TR.FEE.ID = Y.TR.ISSUER:".":Y.SM.ID
  
        CALL F.READ(FN.SC.TRAIL.FEES.ARR,Y.TR.FEE.ID,R.TR.FEE,F.SC.TRAIL.FEES.ARR,TR.FEE.ERR)
 
        Y.FT.ID = R.TR.FEE<SC.TFA.FEE.CODE>

        CALL F.READ(FN.FT.COM,Y.FT.ID,R.FT.REC,F.FT.COM,FT.ERR)
  
        Y.FT.DESC     = R.FT.REC<FT4.DESCRIPTION>
        Y.FT.UPTO     = R.FT.REC<FT4.UPTO.AMT>
        Y.FT.PERCENT  = R.FT.REC<FT4.PERCENTAGE>

        CHANGE @SM TO '|' IN Y.FT.UPTO
        CHANGE @SM TO '|' IN Y.FT.PERCENT

        RETURN
*CPSGMIG-14065-E
    END
