* @ValidationCode : Mjo0NjYxNzkzMzk6SVNPLTg4NTktMToxNjc3NDgwMjM4ODAyOjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 27 Feb 2023 12:13:58
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FUND.HOLDING.EXT.POST
*-----------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17751 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       10 Jan 2023
*-----------------------------------------------------------------------------------------------
* Description:
*-------------
* .POST Routine to extract iBanking Fund Holding details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.HOLDING.EXT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 27-Feb-2023   1663000          CPSGMIG-19423 - Generate the file with "-" inorder to push it to NAS path
* 02-Jun-23     1648769          CPSGMIG-27441 - File name should set the date as -1C calendar date.
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_BATCH.FILES
    
*--------------------------------------------------------------------------------------------   
    GOSUB INITIALISE
	GOSUB PROCESS

RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.SYSDATE     = OCONV(DATE(),"D4/")
    Y.SYSDATE     = FIELD(Y.SYSDATE,'/',3):FIELD(Y.SYSDATE,'/',1):FIELD(Y.SYSDATE,'/',2)
    Y.LAST.SYSDATE = Y.SYSDATE
    CALL CDT('',Y.LAST.SYSDATE,'-1C')

    Y.IBANK.FINAL.FILE = BATCH.DETAILS<3,1>
    Y.IBANK.FINAL.FILE = EREPLACE(Y.IBANK.FINAL.FILE,"<LSYSDATE>",Y.LAST.SYSDATE,-1)

RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; Y.IBANK.ARR = '' ; Y.FINAL.IBANK.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = "T24SGIBANKHOLDINGTEMP-" :TODAY:"-*.txt*"
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(Y.IBANK.ARR) THEN
                Y.IBANK.ARR = R.AMEX.FILE
            END ELSE
                Y.IBANK.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

        IF Y.IBANK.ARR THEN
            Y.REC.CNT = DCOUNT(Y.IBANK.ARR,@FM)

            Y.IBANK.HDR = "0": "2000" : FMT(Y.LAST.SYSDATE,"R%8") : FMT(" ",'L#227')                        ;* Header
            Y.IBANK.FTR = "9" : "2000" : FMT(Y.LAST.SYSDATE,"R%8") : FMT(Y.REC.CNT,"R%9") :FMT(" ",'L#218')  ;* Footer
        
            Y.FINAL.IBANK.ARR = Y.IBANK.HDR :@FM: Y.IBANK.ARR :@FM: Y.IBANK.FTR    ;* Final File
    
            WRITE Y.FINAL.IBANK.ARR TO F.AMEX.FILES,Y.IBANK.FINAL.FILE
        END
    END

RETURN
END