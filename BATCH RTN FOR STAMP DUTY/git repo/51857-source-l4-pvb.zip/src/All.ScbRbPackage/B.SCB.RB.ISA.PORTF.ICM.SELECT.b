$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ISA.PORTF.ICM.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13848 - JEWEL_T24_PROJECT
* Developed By                   :       Chandru Sampath
* Developed On                   :       19 October 2022
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract Day0 File for ICM
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/B.SCB.RB.ISA.PORTF.ICM
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
    $INSERT I_B.SCB.RB.ISA.PORTF.ICM.COMMON
 
    SEL.LIST = ''
    SEL.SAM.CMD = "SELECT ": FN.SEC.ACC.MASTER : " WITH LR.PFOLIO.KEY NE ''"
    CALL EB.READLIST(SEL.SAM.CMD,SEL.LIST,'',NO.REC,RET.CODE)
          
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN
END
