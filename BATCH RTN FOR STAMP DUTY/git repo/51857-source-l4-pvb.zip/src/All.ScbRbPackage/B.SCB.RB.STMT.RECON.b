$PACKAGE All.ScbRbPackage
*-------------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.STMT.RECON
*-------------------------------------------------------------------------------
* This is a Single threaded BATCH routine which is attached to both 'SNG/SCB.RB.STMT.FILE.PROCESS' and
* 'SNG/SCB.RB.WKND.STMT.PROC'. This routine will reconcile the RBSG statment generation and
* generate 3 Recon Files namely,
*
* 1. T24_RBSG_STMT_RECON.txt
* 2. T24_RBSG_STMT_RECON_DIFF.txt
* 3. T24_RBSG_STMT_RECON_MISSING_DDMMYYYY.txt'
*
* Above files will be generated under ../bnk.interface/ITRS.MONITOR
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
***
* 12-Jul-2023 - V,Rajesh Kumar - PVBCOREBAU-8122 - Initial Version
*
* 23-Aug-2023 - V,Rajesh Kumar - PVBCOREBAU-10531 -  1. Selecting all portfolios from EBBS.FILE.PARAM
*                                                    with NEXT.STMT.DATE GE Last Working Day
*                                                    to fix incorrect values in missing count
*                                                    2. Splitting Eligible and Non-Elible SAM among the
*                                                    list of missing Portfolios. Respective Recon files
*                                                    modified
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SCB.EBBS.FILE.PARAM
    $INSERT I_F.DATES
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER				;* PVBCOREBAU-10531 S/E
*-------------------------------------------------------------------------------
    GOSUB INIT
    GOSUB OPEN.FILES
    GOSUB PROCESS
*
RETURN
*---------*
INIT:
*---------*
    GOSUB GET.RUN.DATE
*
    FN.SCB.EBBS.FILE.PARAM = 'F.SCB.EBBS.FILE.PARAM'
    F.SCB.EBBS.FILE.PARAM = ''
* PVBCOREBAU-10531 - Start
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
* PVBCOREBAU-10531 - End
    Y.STMT.NAME = 'T24-CSE-STATEMENT-SG-':Y.LWORK.DAY:'.txt'
*
    Y.FILE1 = 'T24_RBSG_STMT_RECON.txt'
    Y.FILE2 = 'T24_RBSG_STMT_RECON_DIFF.txt'
    Y.FILE3 = 'T24_RBSG_STMT_RECON_MISSING_':Y.LWORK.DAY:'.txt'
*
    Y.DELIM = ','
* PVBCOREBAU-10531 - Start
    Y.APP = 'SEC.ACC.MASTER'
    Y.FIELD = 'LR.TP.ACCT.NO':@VM:'LR.TP.SYSTEM':@VM:'LR.TP.AC.STATUS'
    Y.FIELD.POS = '';Y.TP.ACCT.NO.POS = '';Y.TP.SYSTEM.POS = '';Y.TP.AC.STATUS.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    Y.TP.ACCT.NO.POS = Y.FIELD.POS<1,1>
    Y.TP.SYSTEM.POS = Y.FIELD.POS<1,2>
    Y.TP.AC.STATUS.POS = Y.FIELD.POS<1,3>
* PVBCOREBAU-10531 - End
RETURN
*------------*
OPEN.FILES:
*------------*
    CALL OPF(FN.SCB.EBBS.FILE.PARAM,F.SCB.EBBS.FILE.PARAM)
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)				;* PVBCOREBAU-10531 S/E
*
    FN.ITRS.MONITOR = 'ITRS.MONITOR' ; F.ITRS.MONITOR = ''
    OPEN '',FN.ITRS.MONITOR TO F.ITRS.MONITOR ELSE
        CALL OCOMO( 'Error: RBSG Statement Recon - CANNOT OPEN FILE ':FN.ITRS.MONITOR)
    END
*
    Y.EBBS.OUTFILE = 'EBBS.MMOUTFILE'
    CALL SCB.GET.ORACLE.FILENAME(Y.EBBS.OUTFILE, '', Y.STMT.PATH)
* PVBCOREBAU-10531 - Start
    FN.EBBS.OUTFILE = Y.STMT.PATH
    F.EBBS.OUTFILE = ''
* PVBCOREBAU-10531 - End
    Y.FILE.PATH = ''
    Y.FILE.PATH = QUOTE(Y.STMT.PATH:"/":Y.STMT.NAME)
*
    Y.TEMP.FILE1 = "temp1.txt"
    Y.TEMP.PATH1 = QUOTE(Y.STMT.PATH:"/":Y.TEMP.FILE1)
*
    Y.TEMP.FILE2 = "temp2.txt"
    
    OPEN '',Y.STMT.PATH TO F.EBBS.OUTFILE ELSE
        CALL OCOMO('Error: RBSG Statement Recon - CANNOT OPEN FILE ':Y.STMT.PATH)
    END
*
    Y.TEMP.PATH2 = QUOTE(Y.STMT.PATH:"/":Y.TEMP.FILE2)
* PVBCOREBAU-10531 - Start
    Y.TEMP.FILE3 = "temp3.txt"
    Y.TEMP.PATH3 = QUOTE(Y.STMT.PATH:"/":Y.TEMP.FILE3)
* PVBCOREBAU-10531 - End
RETURN
*-------------*
PROCESS:
*-------------*
    GOSUB EXPECTED.STMT.COUNT
    GOSUB ACTUAL.STMT.COUNT
    Y.MISSING.CNT = Y.EXPECTED.CNT - Y.ACTUAL.CNT
    CALL OCOMO('RBSG Statement Recon - Missing Statment Count : ':Y.MISSING.CNT)
*
    GOSUB WRITE.RECON.MISSING					;* PVBCOREBAU-10531 S/E
    GOSUB WRITE.RECON
    GOSUB WRITE.RECON.DIFF
    GOSUB CLEAR.TEMP.FILES
*
RETURN
*-----------------*
GET.RUN.DATE:
*-----------------*
    Y.BATCH.ID = ''
    Y.BATCH.ID = PROCESS.NAME
    Y.LWORK.DAY = ''
*
    BEGIN CASE
        CASE Y.BATCH.ID EQ 'SNG/SCB.RB.STMT.FILE.PROCESS'
            Y.LWORK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
        CASE Y.BATCH.ID EQ 'SNG/SCB.RB.WKND.STMT.PROC'
            Y.LWORK.DAY = OCONV(DATE(),'D-') ;*MM-DD-YYYY
            Y.LWORK.DAY = Y.LWORK.DAY[7,4]:Y.LWORK.DAY[1,2]:Y.LWORK.DAY[4,2]
            CALL CDT("",Y.LWORK.DAY,"-1C")
    END CASE
    CALL OCOMO('RBSG Statement Recon - Date : ':Y.LWORK.DAY)
*
RETURN
*-----------------*
EXPECTED.STMT.COUNT:
*-----------------*
    Y.SEL.CMD = '' ; Y.SEL.LIST = '' ; Y.NO.OF.REC = '' ; Y.RET.CODE = '' ; Y.EXPECTED.CNT = ''
	Y.SEL.CMD = "SELECT ":FN.SCB.EBBS.FILE.PARAM:" WITH NEXT.STMT.DATE GE ":Y.LWORK.DAY:" BY @ID"           ;* PVBCOREBAU-10531 S/E
    CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST,'',Y.NO.OF.REC,Y.RET.CODE)
    WRITE Y.SEL.LIST ON F.EBBS.OUTFILE, Y.TEMP.FILE2
*
    Y.EXPECTED.CNT = Y.NO.OF.REC
    CALL OCOMO('RBSG Statement Recon - Expected Statement Count : ':Y.EXPECTED.CNT)
*
RETURN
*-----------------*
ACTUAL.STMT.COUNT:
*-----------------*
    Y.UNIQUE.CMD = ''; Y.UNIQUE.CNT = ''; Y.ACTUAL.CNT = ''; Y.UNIQUE.VALUES = ''; Y.COUNT.CMD = ''
    Y.UNIQUE.CMD = "SH -c tail -n +3 ":Y.FILE.PATH:" | head -n -1 | cut -d'~' -f4 | awk '!temp[$0]++' | sort > ":Y.TEMP.PATH1
    EXECUTE Y.UNIQUE.CMD CAPTURING Y.UNIQUE.VALUES
*
    Y.COUNT.CMD = "SH -c cat ":Y.TEMP.PATH1:" | wc -l"
    EXECUTE Y.COUNT.CMD CAPTURING Y.UNIQUE.CNT
*
    Y.ACTUAL.CNT = Y.UNIQUE.CNT
    CALL OCOMO('RBSG Statement Recon - Actual Statement Count : ':Y.ACTUAL.CNT)
*
RETURN
*-----------------*
WRITE.RECON:
*-----------------*
    Y.BODY.RECON = ''
    Y.BODY.RECON = '***************Reconciliation Utility file T24 RB Statement******************'
    Y.BODY.RECON<-1> = 'Total No. of Expected statement generation [A] : ':Y.EXPECTED.CNT
    Y.BODY.RECON<-1> = 'No. of actual statements are generated [B] : ': Y.ACTUAL.CNT
    Y.BODY.RECON<-1> = 'Total No. of Missing statement [C=A-B] : ':Y.MISSING.CNT
* PVBCOREBAU-10531 - Start
    Y.BODY.RECON<-1> = '>No of eligible statement in missing [D] : ':Y.ELIGIBLE.CNT
    Y.BODY.RECON<-1> = '>No of non-eligible statement in missing [E] : ':Y.NON.ELIGIBLE.CNT
* PVBCOREBAU-10531 - End
    WRITE Y.BODY.RECON ON F.ITRS.MONITOR, Y.FILE1
    CALL OCOMO('RBSG Statement Recon - ':Y.FILE1:' Written')
*
RETURN
*-----------------*
WRITE.RECON.DIFF:
*-----------------*
    Y.BODY.RECON.DIFF = Y.LWORK.DAY:Y.DELIM:Y.NON.ELIGIBLE.CNT				;* PVBCOREBAU-10531 S/E
*
    WRITE Y.BODY.RECON.DIFF ON F.ITRS.MONITOR, Y.FILE2
    CALL OCOMO('RBSG Statement Recon - ':Y.FILE2:' Written')
*
RETURN
* PVBCOREBAU-10531 - Start
*-----------------*
FIND.POS.TAG.CHECK:
*-----------------*
    CALL OCOMO('RBSG Statement Recon - Finding Position Tag started')
    R.MISSING = ''
    MISS.ERR = ''
    Y.ELIGIBLE.ARR = 'Eligible SAM'
    Y.NOT.ELIGIBLE.ARR = 'Non-Eligible SAM'
    Y.NON.ELI.SNO = 1
    Y.ELI.SNO = 1
    Y.MISSING.ARR = '';Y.NON.ELIGIBLE.CNT = ''; Y.ELIGIBLE.CNT = ''
*
    CALL F.READ(FN.EBBS.OUTFILE,Y.TEMP.FILE3,R.MISSING,F.EBBS.OUTFILE, MISS.ERR)
    Y.TOT.MISSING.CNT = DCOUNT(R.MISSING,@FM)
    CALL OCOMO('RBSG Statement Recon - Total Missing SAM count : ':Y.TOT.MISSING.CNT)
*
    LOOP
        REMOVE Y.MISS.PFOLIO.ID FROM R.MISSING SETTING Y.MISS.PFOLIO.ID.POS
    WHILE Y.MISS.PFOLIO.ID:Y.MISS.PFOLIO.ID.POS
        CALL F.READ(FN.SEC.ACC.MASTER,Y.MISS.PFOLIO.ID,R.SAM,F.SEC.ACC.MASTER, SAM.ERR)
*
        Y.TP.ACCT.NO = ''; Y.TP.SYSTEM = ''; Y.TP.AC.STATUS = ''
        Y.TP.ACCT.NO = R.SAM<SC.SAM.LOCAL.REF,Y.TP.ACCT.NO.POS>
        Y.TP.SYSTEM = R.SAM<SC.SAM.LOCAL.REF,Y.TP.SYSTEM.POS>
        Y.TP.AC.STATUS = R.SAM<SC.SAM.LOCAL.REF,Y.TP.AC.STATUS.POS>
        CALL OCOMO('RBSG Statement Recon - TP.ACCT.NO : ':Y.TP.ACCT.NO:' TP.SYSTEM : ':Y.TP.SYSTEM:' TP.AC.STATUS : ':Y.TP.AC.STATUS)
*
        IF Y.TP.ACCT.NO NE '' AND Y.TP.SYSTEM EQ 'UTS' AND Y.TP.AC.STATUS NE 'CLOSED' THEN
            Y.NOT.ELIGIBLE.ARR<-1> = Y.NON.ELI.SNO:'. ':Y.MISS.PFOLIO.ID
            Y.NON.ELI.SNO++
        END ELSE
            Y.ELIGIBLE.ARR<-1> = Y.ELI.SNO:'. ':Y.MISS.PFOLIO.ID
            Y.ELI.SNO++
        END
    REPEAT
*
    Y.ELIGIBLE.CNT = DCOUNT(Y.ELIGIBLE.ARR,@FM) - 1
    CALL OCOMO('RBSG Statement Recon - Missing Eligible SAM count : ':Y.ELIGIBLE.CNT)
    Y.NON.ELIGIBLE.CNT = DCOUNT(Y.NOT.ELIGIBLE.ARR,@FM) - 1
    CALL OCOMO('RBSG Statement Recon - Missing Non-Eligible SAM count : ':Y.NON.ELIGIBLE.CNT)
*
    Y.MISSING.ARR = Y.ELIGIBLE.ARR
    Y.MISSING.ARR<-1> = ''
    Y.MISSING.ARR<-1> = Y.NOT.ELIGIBLE.ARR
    CALL OCOMO('RBSG Statement Recon - Finding Position Tag Ended')
*
RETURN
* PVBCOREBAU-10531 - End
*-----------------*
WRITE.RECON.MISSING:
*-----------------*
    Y.MISSING.CMD = "SH -c grep -vf ":Y.TEMP.PATH1:" ":Y.TEMP.PATH2:' > ':Y.TEMP.PATH3				;* PVBCOREBAU-10531 S/E
    EXECUTE Y.MISSING.CMD CAPTURING Y.MISSING.VALUES
* PVBCOREBAU-10531 - Start
    GOSUB FIND.POS.TAG.CHECK
*
    WRITE Y.MISSING.ARR ON F.ITRS.MONITOR, Y.FILE3
* PVBCOREBAU-10531 - End
    CALL OCOMO('RBSG Statement Recon - ':Y.FILE3:' Written')
*
RETURN
*-----------------*
CLEAR.TEMP.FILES:
*-----------------*
    Y.REMOVE.CMD = "SH -c  rm ":Y.TEMP.PATH1:" ":Y.TEMP.PATH2:" ":Y.TEMP.PATH3					;* PVBCOREBAU-10531 - S/E
    EXECUTE Y.REMOVE.CMD CAPTURING Y.REMOVE.CMD.OUT
    CALL OCOMO('RBSG Statement Recon - Temp Files Cleared')
*
RETURN
*
END