$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-211</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.CONSOL.XML.ADV.RB.POST
*--------------------------------------------------------------------------------*
* Created by    : Sasikumar Kannan
* Creation Date : 28/06/2012
*---- Parallel UAT run Changes(Modified by Sasikumar Kannan- 20131026)---*
*---- Zero kb file check-(Modified by Sasikumar Kannan- 20131118)---*
*-----------*
*DESCRIPTION:
*-----------*
* This is a BATCH routine is used for consolidating all the XML advices generated.
* This is a requirement for DE-PERSONALISATION Project.
* Routine attached to the BATCH Application
* XXX/B.SCB.CONSOL.XML.ADV(Online Generation with Interval of 30 mins in Business days.
* This .POST Routine sends the file to middleware path defined in F.AEB.PATHNAMES.
*------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Date            Who               Reference         Description
*
* 21-Sep-2016     1540133           QC747             Sprinwatch-Advices XML process challenge
* 20-Aug-2019     1573317           QC1743            Final or Last XML for the day should have total advice count
* 09-Oct-2020     Kapil K           PVB-60661           SMS Post Trade Notification
*	TAFJUPG - Code conversion for TAFJ upgrade.  TAFJ DIR/VOC, SELECT changes.
* 05-04-2021 - SasikumarKannan - Modified to send the FILEIT notification to the external system.
* Commented the existing copy commands to copy files to the SCAN (middleware) folders.
* 23-Sep-2021 - PVBCOREBAU-109 - Vijayarani.G - Suppression of 2nd SMS Notification to Clients (for SAT 195)
* 21-Oct-2021 - PVBCOREBAU-255 - 1589999 - Changes made to write the Checksum file along with the actual Contract Note XML File.
*                                        - Checksum values are being retrieved from a Java package using SHA1 encryption method.
* 25-04-2022  -	CPSGMIG-1081   - Avinash	     This Routine copied from B.SCB.CONSOL.XML.ADV.POST to
*                                                B.SCB.CONSOL.XML.ADV.RB.POST and XML file renamed since file contains only
*                                                advices related to retail & code related to sms count has been removed
*                                                as it is not required for retail.
* 29-Oct-2022-CPSGMIG-1081R- 1389710 - FILEIT Changes.
* 07-Dec-2022- CPSGMIG-17650 - 1389710 - Changes done for zero kb file transfer.
* 17-Feb-2022	CPSGMIG-17700	1667095	File will be generated in batches
* 20-Apr-2023 - CPSGMIG-21500 - 1657186 - Hypen changed to underscore in the Filename.
* 24-May-2025 - ADO-7884637 - Prithi Koppolu - TODAY date update in F.LOCKING>SCB.RB.XML.ADV.RECON.RPT.DATE Record
* 29-Sep-2025 - ADO-10382007 - Prithi Koppolu - Additional intra-day contract note batches from T24 to Batch Layer
*-------------------------------------------------------------------------------------------------------------------------------*
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.DP.XML.FILE.STATUS
*QC747 - Start
    $INSERT I_F.SCB.JOB.SCHED
    $INSERT I_F.COMPANY
*QC747 - End
*
    GOSUB INITIALIZE
    GOSUB SELECT.RECORDS
    GOSUB RUN.FILE.TRANSFER
*
    WRITE TODAY TO F.LOCKING,'SCB.RB.XML.ADV.RECON.RPT.DATE' ;* ADO-7884637-S/E
*

RETURN
*-------------------------------------------------------------------------------------------*
*----------
INITIALIZE:
*---------
    FN.SCB.RB.DP.XML.FILES = 'F.SCB.RB.DP.XML.FILES'
    F.SCB.RB.DP.XML.FILES = ''
    CALL OPF(FN.SCB.RB.DP.XML.FILES,F.SCB.RB.DP.XML.FILES)
*	TAFJUPG -/S
	XMLFILEPATH=""
    CALL SCB.GET.ORACLE.FILENAME(FN.SCB.RB.DP.XML.FILES,"",XMLFILEPATH)
*	TAFJUPG -/E
*
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*	TAFJUPG -/S
    AMEXFILEPATH=""
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX.FILES,"",AMEXFILEPATH)
*	TAFJUPG -/E
    FN.SCB.DP.XML.FILE.STATUS = 'F.SCB.DP.XML.FILE.STATUS'
    F.SCB.DP.XML.FILE.STATUS  = ''
    CALL OPF(FN.SCB.DP.XML.FILE.STATUS,F.SCB.DP.XML.FILE.STATUS)
*
    Y.COMP = '' ; Y.FLAG='N'
    Y.COMP = ID.COMPANY[1,2]
* QC1743 - S
    IF Y.COMP EQ 'GB' THEN
        Y.COMP.ID = 'UK'
    END
    ELSE
        Y.COMP.ID = Y.COMP
    END
*QC1743 - E
    Y.FILE.UPD.ID = ID.COMPANY:'-':TODAY
*
*QC747 - Start
    FN.SCB.JOB.SCHED = 'F.SCB.JOB.SCHED'
    F.SCB.JOB.SCHED = ''
    CALL OPF(FN.SCB.JOB.SCHED,F.SCB.JOB.SCHED)
*QC1743 - S
    FN.LOCKING = 'F.LOCKING'
    F.LOCKING = ''
    CALL OPF(FN.LOCKING,F.LOCKING)

    Y.ADV.TOT.CNT.ID = Y.COMP.ID:'.PVB.ADV.TOT.CNT'
*QC1743 - E
    Y.SMS.SUM.ID = Y.COMP.ID:'.PVB.ADV.SMS.CNT'   ;* PVB-60661
    R.SCB.JOB.SCHED = ''
    SCB.JOB.ERR = ''

    Y.REGION = R.COMPANY(EB.COM.OFFICIAL.HOLIDAY)
    Y.SCH.ID = "RBSG" ;* CPSGMIG-17700(S/E)
    Y.DAY.TYPE = ''
    DATE.NOW = OCONV(ICONV(FIELD(TIMEDATE(),' ',2,3),'D'),'D4/E')
    Y.DATE.NOW = DATE.NOW[7,4]:DATE.NOW[4,2]:DATE.NOW[1,2]
	
	
	
*QC747 - End
*
RETURN
*-------------------------------------------------------------------------------------------*
*-------------
SELECT.RECORDS:
*-------------
*
    SEL.CMD = ''; SEL.LIST = ''; SEL.CNT = '' ; Y.CNT = '' ; Y.TOT.DATA.CNT = 0
*   SEL.CMD = 'SELECT ':FN.SCB.RB.DP.XML.FILES:' LIKE ...':PROCESS.NAME[1,3]		;* TAFJUPG -S/E
	SEL.CMD = 'SELECT ':XMLFILEPATH
    Y.TIMEDATE.STP        = TIMEDATE()
    Y.TIMESTAMP           = TODAY:'_':Y.TIMEDATE.STP[1,8]
    CHANGE ":" TO "" IN  Y.TIMESTAMP
*CPSGMIG-17700(S)
    Y.FILE.CNT = '' ; Y.DPFILE.ID = '' ; Y.CURR.RUN.TIME = ''
	
    CALL F.READ(FN.SCB.JOB.SCHED,Y.SCH.ID,R.SCB.JOB.SCHED,F.SCB.JOB.SCHED,SCB.JOB.ERR)
    Y.LAST.RUN = R.SCB.JOB.SCHED<RUN.TIME>
 
    Y.RUN.DCNT = DCOUNT(Y.LAST.RUN,@VM)
    Y.LAST.RUN.TIME = Y.LAST.RUN<1,Y.RUN.DCNT>
*ADO-10382007-(S)
    Y.CURR.RUN.TIME = Y.TIMEDATE.STP[1,8]
    CHANGE ':' TO '' IN Y.CURR.RUN.TIME
    R.ADV.COUNT = '' ; Y.ADV.ERR = ''
    CALL F.READ(FN.LOCKING,Y.FILE.UPD.ID,R.ADV.COUNT,F.LOCKING,Y.ADV.ERR) ;*Locking ID will be ID.COMPANY-TODAY
    IF R.ADV.COUNT THEN
        Y.DPFILE.ID = 'T24-RB-':Y.COMP:'-ADVPDF-':TODAY:Y.CURR.RUN.TIME:'.XML' ;*CPSGMIG-1081R(S/E)
        CALL F.DELETE(FN.LOCKING,Y.FILE.UPD.ID)
    END ELSE
        Y.FILE.CNT = '01'
        Y.DPFILE.ID = 'T24-RB-':Y.COMP:'-ADVPDF-':TODAY:Y.CURR.RUN.TIME:'-':Y.FILE.CNT:'.XML' ;*CPSGMIG-1081R(S/E)
        Y.FILE.CNT = '-':Y.FILE.CNT
        R.ADV.COUNT = '1'
        CALL F.WRITE(FN.LOCKING,Y.FILE.UPD.ID,R.ADV.COUNT)
    END
*ADO-10382007-(E)
*CPSGMIG-17700(E)
    Y.FILE.ARRAY = ''
    GOSUB PROCESS
*
    IF Y.FILE.ARRAY THEN
        Y.FILE.ARRAY<-1>='</ADV_CONF>'
        WRITE Y.FILE.ARRAY TO F.AMEX.FILES,Y.DPFILE.ID
* CPSGMIG-17650(S)
    END ELSE
        Y.FILE.ARRAY = '<ADV_CONF>'
        Y.FILE.ARRAY<-1>='<T24_ADV_CONF>'
        Y.FILE.ARRAY<-1>='<ADV_CONF_DATA>'
        Y.FILE.ARRAY<-1>='</ADV_CONF_DATA>'
        Y.FILE.ARRAY<-1>='</T24_ADV_CONF>'
        Y.FILE.ARRAY<-1>='</ADV_CONF>'
        WRITE Y.FILE.ARRAY TO F.AMEX.FILES,Y.DPFILE.ID
    END
* CPSGMIG-17650(E)

RETURN
*-------------------------------------------------------------------------------------------*
*------
PROCESS:
*------
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,'')
    LOOP
        REMOVE Y.FILE.ID FROM SEL.LIST SETTING Y.FILE.POS
    WHILE Y.FILE.ID:Y.FILE.POS
        IF RIGHT(Y.FILE.ID,3)=PROCESS.NAME[1,3] THEN		;* TAFJUPG -S/E
            CALL F.READ(FN.SCB.RB.DP.XML.FILES,Y.FILE.ID,R.SCB.RB.DP.XML.FILES,F.SCB.RB.DP.XML.FILES,Y.FILE.ERR)
            IF R.SCB.RB.DP.XML.FILES THEN
                IF Y.FLAG EQ 'N' THEN
                    Y.FILE.ARRAY = '<ADV_CONF>'
                    Y.FLAG='Y'
                END
                Y.FILE.ARRAY<-1> = R.SCB.RB.DP.XML.FILES
                CALL F.DELETE(FN.SCB.RB.DP.XML.FILES,Y.FILE.ID)
            END ELSE
                CALL F.DELETE(FN.SCB.RB.DP.XML.FILES,Y.FILE.ID)
            END
        END
    REPEAT
*
RETURN
*CPSGMIG-17700(S)
*-----------------
RUN.FILE.TRANSFER:
*-----------------
*File generation will be notified to batch layer by updating oracle table

    BATCH.DTL = BATCH.DETAILS<3,1>
    BATCH.DTL = EREPLACE(BATCH.DTL, "<HHMMSS>", Y.CURR.RUN.TIME)	;* ADO-10382007-(S/E)
    BATCH.DTL = EREPLACE(BATCH.DTL, "-<CNT>", Y.FILE.CNT)
    BATCH.DETAILS<3,1> = BATCH.DTL
    CALL SCB.RB.POST.BATCH.LAYER.FILES
RETURN
*-----------------

*CPSGMIG-17700(E)
END