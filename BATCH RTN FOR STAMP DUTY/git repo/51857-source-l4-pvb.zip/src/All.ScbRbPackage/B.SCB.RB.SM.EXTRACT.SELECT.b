$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SM.EXTRACT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5311 - JEWEL_T24_PROJECT
* Developed By                   :       1494730
* Developed On                   :       21 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract SM details
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
* 7-Dec-2022    1404392         CPSGMIG-17645 Asset master listing is showing WRAP funds (belongs to PVB) and negative holdings.
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.SM.EXTRACT.COMMON
*CPSGMIG-17645 Start
*CHANGE @FM TO @VM IN Y.ALL.SAT.CODE
*SEL.CMD = "SELECT ":FN.SECURITY.MASTER:" WITH SUB.ASSET.TYPE MATCHES ":Y.ALL.SAT.CODE
    SEL.CMD = "SELECT ":FN.SECURITY.MASTER:" WITH LR.RET.FND.FLAG EQ 'Y'"
*CPSGMIG-17645 End
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN
END
