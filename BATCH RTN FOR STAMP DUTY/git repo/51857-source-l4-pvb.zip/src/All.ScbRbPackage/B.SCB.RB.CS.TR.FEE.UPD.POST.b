$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CS.TR.FEE.UPD.POST
*-------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-12313
* Routine Type                 Batch Job
* Attached To                  BATCH>SNG/B.SCB.RB.CS.TR.FEE.UPD
* Workflow                     This post routine will consolidate the all individual session reports updated 
*                              by multi thread job and prepare one single unique report by deleting all
*                              individual session reports.
*-------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference       Description
*-------------------------------------------------------------------------------------------------------
*  Tejomurthy M        22/Dec/2022     CPSGMIG-12313    Initial Draft
*-------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_B.SCB.RB.CS.TR.FEE.UPD.COMMON

	GOSUB INIT
	GOSUB PROCESS
	GOSUB DO.FINAL.WRITE
	
	RETURN
*-------------------------------------------------------------------------------------------------------
INIT:
*****

	Y.ARR = ''
	YFL1 = 'SCB.CS.EX.TR.FEE.DET.':TODAY
	Y.FINAL.FL.NAME = "SCB.RB.CS.EX.TR.FEE.UPD.REPORT.":TODAY:".csv"
	
	RETURN
*-------------------------------------------------------------------------------------------------------
PROCESS:
********

	SEL.CMD1 = "SELECT ":FN.SL:" WITH @ID LIKE ":YFL1:"..."
	CALL EB.READLIST(SEL.CMD1,SEL.LIST1,'',NO.OF.RECS1,SEL.ERR1)
	
    IF SEL.LIST1 THEN
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST1 SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
			READLIST Y.RECS FROM Y.SEL.ID THEN
				Y.ARR<-1> = Y.RECS
				CALL F.DELETE(FN.SL,Y.SEL.ID)
			END
		REPEAT
    END    

    RETURN
*-------------------------------------------------------------------------------------------------------
DO.FINAL.WRITE:
***************

	IF Y.ARR THEN
		Y.HDR = "CUS.SEC.ID,CUS.LOB,CUST.TYPE,STATUS,ADDL.INFORMATION"
		Y.FINAL.ARRAY = Y.HDR:@FM:Y.ARR
		WRITELIST Y.FINAL.ARRAY TO Y.FINAL.FL.NAME
	END
	
	RETURN
*-------------------------------------------------------------------------------------------------------
END