$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgEbbsW8W9VDsc
*
*
SUBROUTINE B.SCB.RSG.EBBS.W8.W9.V.DSC
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES

    $INSERT I_F.DM.SERVICE.CONTROL
    $INSERT I_B.SCB.RSG.EBBS.W8.W9.PROCESS.COMMON
   
 

    GOSUB INIT
    GOSUB OPEN.FILES
    GOSUB PROCESS

RETURN
*------------------------------------------------------------------------------------------------*
INIT:
*****

    CALL OCOMO("Control is getting into INIT part")
    BAT.DATA1 = BATCH.DETAILS<3,1,1>
    Y.DSC.ID = FIELD(BAT.DATA1,'-',2)
* Y.DSC.ID = "RSG.V.CUS.W8.W9.UPDATE"

RETURN
*------------------------------------------------------------------------------------------------*
OPEN.FILES:
***********

    CALL OCOMO("Control is getting into OPF part for DSC ID ":Y.DSC.ID)

    FN.DM.SERVICE.CONTROL = 'F.DM.SERVICE.CONTROL'
    F.DM.SERVICE.CONTROL = ''
    CALL OPF(FN.DM.SERVICE.CONTROL,F.DM.SERVICE.CONTROL)

RETURN
*-------------------------------------------------------------------------------------------------*
PROCESS:
********

    CALL F.READ(FN.DM.SERVICE.CONTROL,Y.DSC.ID,R.DSC,F.DM.SERVICE.CONTROL,ERR.DSC)
    Y.FILE.NAME = R.DSC<DMS.CONTROL.FLAT.FILE.NAME>
    Y.RUN.STATUS = R.DSC<DMS.CONTROL.RUN.STATUS>
        

    CALL OCOMO("File Check is completed for ":Y.DSC.ID:" File available in DSC is ":Y.FILE.NAME)
    CALL OCOMO("Current Run Status of DSC ":Y.DSC.ID:" is":Y.RUN.STATUS)

    IF (Y.RUN.STATUS) EQ 'STOP' THEN
        IF Y.FILE.NAME EQ "RSG.SG.EBBS.RDD.":Y.DATE:".txt" THEN
            
        END
        ELSE
            R.DSC<DMS.CONTROL.FLAT.FILE.NAME,1> ="RSG.SG.EBBS.RDD.":Y.DATE:".txt"
           
        END
	CALL F.WRITE(FN.DM.SERVICE.CONTROL,Y.DSC.ID,R.DSC)
        GOSUB FORM.OFS.STRING
    END
    ELSE
	
        CALL OCOMO("DSC ":Y.DSC.ID:" is currently running ")
    END
   
        
        
RETURN
******************
FORM.OFS.STRING:
    
    APP.NAME = "DM.SERVICE.CONTROL"
    FUNCT = "V"
    PROC = "PROCESS"
    VERSION = 'DM.SERVICE.CONTROL,'
    Y.GTS.MODE = ''
    Y.AUTH = "0"
    TRANS.ID = Y.DSC.ID
    
   
    Y.TAP.PFOLIO.REC.UPD.ERR = ''

    CALL OFS.BUILD.RECORD(APP.NAME,FUNCT,PROC,VERSION,Y.GTS.MODE,Y.AUTH,TRANS.ID,R.DSC,DSC.STRING)

    Y.OFS.SOURCE = 'DM.OFS.SRC.VAL'
    Y.BULK.RES = '' ; Y.FLAG = '' ; Y.MSG.ID = ''
    CALL OFS.CALL.BULK.MANAGER(Y.OFS.SOURCE,DSC.STRING,Y.BULK.RES,Y.FLAG)
RETURN
*-------------------------------------------------------------------------------------------------*
END
