$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>331</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE B.SCB.RB.CCMS.REQUEST.PROCESS
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Month end job to process the incoming request file to CCMS.
*
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- CCMS - Month end job to process the incoming request file to CCMS.
* 13-Apr-2023 - CPSGMIG-312 - kalaikumaranp - CCMS - Prefixed Cust type to Cust id.
* 09-Jun-2023 - CPSGMIG-29137 - kalaikumaranp - CCMS - Clear Previous month request file.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SCB.RB.CCMS.REQUEST.DATA
    $INSERT I_F.DATES
*
    GOSUB INIT
    GOSUB OPEN.FILES
*
    RETURN
*
*-----------------------------------------------------------------------------
INIT:
*---
    FN.SCB.RB.CCMS.REQUEST.DATA = 'F.SCB.RB.CCMS.REQUEST.DATA'
    F.SCB.RB.CCMS.REQUEST.DATA = ''
    CALL OPF(FN.SCB.RB.CCMS.REQUEST.DATA,F.SCB.RB.CCMS.REQUEST.DATA)
*
* CPSGMIG-29137 - Clear previous Month request File
	EXECUTE "CLEAR-FILE ":FN.SCB.RB.CCMS.REQUEST.DATA
* CPSGMIG-29137    
	CCMS.PATH = 'CCMS'
	CALL SCB.GET.ORACLE.FILENAME(CCMS.PATH, '', Y.IN.DIR) 
    SECONDS = 60
    Y.FILE.ARRIVED = ''
	Y.FILE.NAME.DEST = 'SGREWARD.':TODAY:'.processed.txt'
    RETURN
*
*-----------------------------------------------------------------------------
OPEN.FILES:
*---------
*

    Y.FILE.NAME = 'SGREWARD.txt'
*
* Open the file where SM upload file will be available
*
    OPEN Y.IN.DIR TO F.CCMS.FEED ELSE
        TEXT = 'ERROR OPENING CCMS UPLOAD PATH'
    END
*
    GOSUB PROCESS.MSG
*
    RETURN
*
*-----------------------------------------------------------------------------
PROCESS.MSG:
*--------------
* Check if the file has arrived. Else wait till the file arrives in the IN.DIRECTORY

    LOOP
        GOSUB CHECK.FILE.ARRIVED
    UNTIL Y.FILE.ARRIVED
        SLEEP SECONDS
    REPEAT
    LOOP
        REMOVE Y.CCMS.REC FROM R.CCMS.REC SETTING Y.CCMS.POS
    WHILE  Y.CCMS.REC:Y.CCMS.POS
	IF Y.CCMS.REC[1,1] EQ 'H' OR Y.CCMS.REC[1,1] EQ 'T' THEN CONTINUE
			Y.CUST.ID    = TRIM(Y.CCMS.REC[2,30])
			Y.CUST.TYPE = TRIM(Y.CCMS.REC[32,2])
			Y.CUST.ORG     = TRIM(Y.CCMS.REC[34,3]) 
			Y.CUSTNUM = TRIM(Y.CCMS.REC[37,16])
			Y.ACCT.ORG     = TRIM(Y.CCMS.REC[65,3])
			Y.ACCT.TYPE = TRIM(Y.CCMS.REC[68,3])
			Y.ACCT.NUM = TRIM(Y.CCMS.REC[71,18])
			Y.OFFER.KEY     = TRIM(Y.CCMS.REC[89,12])	
			
	R.CCMS.FILE.DATA<CCMS.REQ.CUSTID> = Y.CUST.ID
	R.CCMS.FILE.DATA<CCMS.REQ.CUSTYPE> = Y.CUST.TYPE
	R.CCMS.FILE.DATA<CCMS.REQ.CUSTORG> = Y.CUST.ORG
	R.CCMS.FILE.DATA<CCMS.REQ.CUSTNUM> = Y.CUSTNUM
	R.CCMS.FILE.DATA<CCMS.REQ.ACCTORG> = Y.ACCT.ORG
	R.CCMS.FILE.DATA<CCMS.REQ.ACCTYPE> = Y.ACCT.TYPE
	R.CCMS.FILE.DATA<CCMS.REQ.ACCTNUM> = Y.ACCT.NUM
	R.CCMS.FILE.DATA<CCMS.REQ.OFFERKEY> = Y.OFFER.KEY
	
	Y.REL.ID = Y.CUST.TYPE:Y.CUST.ID
	WRITE R.CCMS.FILE.DATA TO F.SCB.RB.CCMS.REQUEST.DATA, Y.REL.ID


    REPEAT

*    UNIX.CMD = "mv -f ":Y.IN.DIR:"/":Y.FILE.NAME:" ":Y.IN.DIR:"/X.":Y.FILE.NAME
*    EXECUTE "SH -c '":UNIX.CMD:"'" RETURNING Y.ERROR CAPTURING RETURN.TEXT

	SH.CMD = "SH -c mv -f ":Y.IN.DIR:"/":Y.FILE.NAME:" ":Y.IN.DIR:"/":Y.FILE.NAME.DEST
   	EXECUTE SH.CMD
*
    RETURN
*
*-----------------------------------------------------------------------------
CHECK.FILE.ARRIVED:
*----------------
*
    READ R.CCMS.REC FROM F.CCMS.FEED,Y.FILE.NAME THEN
        Y.FILE.ARRIVED = 1
    END ELSE		
        PRINT "CCMS file ":Y.FILE.NAME:" not arrived under ":Y.IN.DIR
    END
*
    RETURN
*
*-----------------------------------------------------------------------------
END
