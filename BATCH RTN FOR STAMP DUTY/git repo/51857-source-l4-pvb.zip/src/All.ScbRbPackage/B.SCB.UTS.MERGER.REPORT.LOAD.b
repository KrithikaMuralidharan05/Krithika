* @ValidationCode : MjoxNjk1ODkzMjAwOklTTy04ODU5LTE6MTY2NTczNzUyODMzOToxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 14 Oct 2022 14:22:08
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.UTS.MERGER.REPORT.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5332 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       13 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .LOAD Routine to extract Trade details for Subscription, Redemption , SwitchIn & SwitchOut
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SCB.UTS.MERGER.REPORT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.UTS.MERGER.REPORT.COMMON
*--------------------------------------------------------------------------------------------
    
    GOSUB OPEN.FILES

RETURN
*---------*
OPEN.FILES:
*---------*

    FN.SEC.TRADES.MDAY      = 'F.SCB.SEC.TRADES.MDAY'    ; F.SEC.TRADES.MDAY      = ''  ; CALL OPF(FN.SEC.TRADES.MDAY,F.SEC.TRADES.MDAY)
    
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.UTS.TEMP.FILE = "SGINQSUBSREDEMPSWISWO-":TODAY:"-":SESSION.NO:".csv"
    
    Y.MAP.REC.ID = BATCH.DETAILS<3,1>
    
RETURN
END