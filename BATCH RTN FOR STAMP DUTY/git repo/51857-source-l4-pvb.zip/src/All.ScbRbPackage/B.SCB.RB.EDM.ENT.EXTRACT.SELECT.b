$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EDM.ENT.EXTRACT.SELECT
**-------------------------------------------------------------------------------------------------------------------------
    ! CREATED DT  : 
    ! AUTHOR      : 
    ! CC NO       :
    ! DESCRIPTION : THIS IS A SELECT FILE WHICH WILL SELECT ALL THE ENTITLEMENT TRASACTION HAPPENED ON A DAY TO DAY BASIS
    !                FOR EXTRACTION
*
**-------------------------------------------------------------------------------------------------------------------------
*
* 25/07/2022 - Shreekantha. G - CPSGMIG-4971             
*
*--------------------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.EDM.ENT.EXTRACT.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.L.CAPE.CA.REF ;*ADO_11084241_S/E
   *
* 

    IF NOT(CONTROL.LIST) THEN
 *       CONTROL.LIST = "ENT.LIVE":@FM:"ENT.REVE":@FM:"ENT.RIGHTS"
  		CONTROL.LIST = "ENT.LIVE":@FM:"ENT.REVE"
         CONTROL.LIST:= @FM:"CA.FTST"  ;*ADO_11084241_S/E
    END
*
    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "ENT.LIVE"
            IF ID.COMPANY EQ "SG1090400" THEN         ;* QC-574 S/E For SNG, ACU transactions should be included.
                SEL.CMD = "SELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":COUNTRY.NAME:"...*DIAR..."
            END ELSE    ;* For HKB, since COUNTRY.NAME based selection includes HKW transactions also
                SEL.CMD = "SELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":ID.COMPANY:"...*DIAR..."         
            END
            CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
            CALL BATCH.BUILD.LIST('',SEC.ID)
*
        CASE CONTROL.LIST<1,1> = "ENT.REVE"
            SEL.CMD = ''
            IF ID.COMPANY EQ "SG1090400" THEN
                SEL.CMD = "SELECT ":FN.SEC.TRD.REV:" WITH @ID LIKE ":COUNTRY.NAME:"...*DIAR..."
            END ELSE
                SEL.CMD = "SELECT ":FN.SEC.TRD.REV:" WITH @ID LIKE ":ID.COMPANY:"...*DIAR..."
            END
            CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
            CALL BATCH.BUILD.LIST('',SEC.ID)

*ADO_11084241_S
        CASE CONTROL.LIST<1,1> = "CA.FTST"
        
        SEL.CMD = "SELECT ":FN.SCB.L.CAPE:" WITH PROCESSING.DATE EQ ":TODAY:" AND WITH DEL.REF NE 'NostroPayment'"
        CALL EB.READLIST(SEL.CMD,SEC.ID,"",NO.OF.IDS,SEC.ERR)
       CALL BATCH.BUILD.LIST('',SEC.ID)
*ADO_11084241_E
*
*        CASE CONTROL.LIST<1,1> = "ENT.RIGHTS"
*            SEL.CMD = "SELECT ":FN.ENTITLEMENT:" WITH OPT.STATUS EQ 'PENDING'"
*			SEL.CMD = "SELECT ":FN.ENTITLEMENT:" 
*            CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
*            CALL BATCH.BUILD.LIST('',SEC.ID)
*
    END CASE
*
    RETURN
*
*--------------------------------------------------------------------------------------------------------------------------
END
*--------------------------------------------------------------------------------------------------------------------------
