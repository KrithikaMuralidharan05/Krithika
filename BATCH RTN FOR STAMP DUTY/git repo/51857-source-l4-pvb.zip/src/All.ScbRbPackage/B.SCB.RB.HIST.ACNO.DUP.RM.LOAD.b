$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.HIST.ACNO.DUP.RM.LOAD
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Remove Duplicate Txn Ids from SCB.UTS.HIST.PROD.ACNO Table.
*
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 21-Nov-2023 - ADO-2100833 - kalaikumaranp- Remove Duplicate Txn Ids from SCB.UTS.HIST.PROD.ACNO Table.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.RB.HIST.ACNO.DUP.RM.COMMON
    
    GOSUB INIT
    
 RETURN
 *-----------------------------------------------------------------------------
 INIT:
*---
	FN.SCB.UTS.HIST.PROD.ACNO = 'F.SCB.UTS.HIST.PROD.ACNO'
   	F.SCB.UTS.HIST.PROD.ACNO  = ''
    CALL OPF(FN.SCB.UTS.HIST.PROD.ACNO,F.SCB.UTS.HIST.PROD.ACNO)
   
   	AMEX.FILES.PATH = 'CCMS' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)

RETURN
 *-----------------------------------------------------------------------------
END   