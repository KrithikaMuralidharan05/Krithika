$PACKAGE All.ScbRbPackage
	SUBROUTINE B.SCB.RB.TRD.DAILY.UPD
*---------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This routine is used to clear records from the concat table SCB.TRADE.DAILY.
*---------------------------------------------------------------
* Attached To : BATCH>SNG/SCB.RB.PEND.TRANS.UPD
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 18-Aug-2022       Lavanya L       CPSGMIG-5346       Initial Creation
** 07-Jul-2023 - Lavanya L - TOOLKIT-33634 - For clearing file on daily basis after intraday and cob extracion.
*----------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
		
	GOSUB INIT
	GOSUB PROCESS
	
	RETURN
*--------------------------------------------------------
INIT:
*---
	FN.TRD.DAILY = 'F.SCB.TRADE.DAILY'
	F.TRD.DAILY = ''
	CALL OPF(FN.TRD.DAILY,F.TRD.DAILY)
	
     FN.SCB.DIARY.DAILY = 'F.SCB.DIARY.DAILY'
    F.SCB.DIARY.DAILY = ''
    CALL OPF(FN.SCB.DIARY.DAILY,F.SCB.DIARY.DAILY)
    
    FN.SCB.ENT.DAILY = 'F.SCB.TRDREVENT.DAILY'
    F.SCB.ENT.DAILY = ''
    CALL OPF(FN.SCB.ENT.DAILY,F.SCB.ENT.DAILY)
     

	RETURN
*--------------------------------------------------------
PROCESS:
*---------------
	EXECUTE "CLEAR-FILE ":FN.TRD.DAILY
	
    EXECUTE "CLEAR-FILE ":FN.SCB.DIARY.DAILY
    
    EXECUTE "CLEAR-FILE ":FN.SCB.ENT.DAILY
    
	RETURN

END