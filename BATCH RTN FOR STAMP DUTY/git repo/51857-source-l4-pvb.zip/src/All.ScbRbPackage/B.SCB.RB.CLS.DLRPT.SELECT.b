$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.CLS.DLRPT.SELECT
******************************************************************************
*ORA-MT-CHG : For oracle performance the job AEB.CLS.DLRPT in the batch  "XXX/ZZX.SCB.SC.BATCH.RE"
*is modified as multi thread routine. The selection of SC.POS.ASSET is done by this routine.
*--------------------------------------------------
*Modification History:
************************
* 24-May-2022 - CPSGMIG-3320 - Lavanya L - Copy of the existing routine AEB.CLS.DLRPT.SELECT
*-------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SC.POS.ASSET
    $INSERT I_F.CUSTOMER
    $INSERT I_F.DATES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.MD.DEAL
    $INSERT I_F.ACCOUNT
    $INSERT I_F.MM.MONEY.MARKET
    $INSERT I_F.CATEGORY
    $INSERT I_F.FD.FID.ORDER
    $INSERT I_F.FOREX
    $INSERT I_F.CL.SUIT.PARAM
    $INSERT I_F.AEB.LOCATION
    $INSERT I_B.SCB.RB.CLS.DLRPT.COMMON

    SEL.CMD = "SELECT ":FN.SC.POS.ASSET
*
    CALL EB.READLIST(SEL.CMD,SPA.ALL.IDS,'',NO.OF.REC,RET.COD)
    CALL BATCH.BUILD.LIST('', SPA.ALL.IDS)
*
RETURN
END
