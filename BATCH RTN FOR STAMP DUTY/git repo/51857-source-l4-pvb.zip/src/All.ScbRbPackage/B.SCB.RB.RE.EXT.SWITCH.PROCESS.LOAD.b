$PACKAGE All.ScbRbPackage
* @ValidationCode : MjotMzc3NDQxNTc1OkNwMTI1MjoxNTgzOTA3NjUwNDU2OjE2MDEyNzQ6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxODA5LjE6LTE6LTE=
* @ValidationInfo : Timestamp         : 11 Mar 2020 11:50:50
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1601274
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201809.1

SUBROUTINE B.SCB.RB.RE.EXT.SWITCH.PROCESS.LOAD
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Author		      Date 	         Reference	    Description
*-------------------------------------------------------------------------------------------------------------------------------------------
* Bharathiraja Ponmudi        24-May-2022        CPSGMIG-565        Settle MF Trade: Cash Debit / Credit in Client's Account
*-----------------------------------------------------------------------------
	$INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_B.SCB.RB.RE.EXT.SWITCH.PROCESS.COMMON
	$INSERT I_F.SCB.CASH.BLK.SETT
*-----------------------------------------------------------------------------

    FN.CASH.BLK.SETT = "F.SCB.CASH.BLK.SETT"
    F.CASH.BLK.SETT = ""
    CALL OPF(FN.CASH.BLK.SETT, F.CASH.BLK.SETT)
 
    FnScParentLink = "F.SC.PARENT.TRADE.LINK"
    FScParentLink = ""
    CALL OPF(FnScParentLink,FScParentLink)
    
    FnSecTrade = 'F.SEC.TRADE'
    FSecTrade = ''
    CALL OPF(FnSecTrade, FSecTrade)
     
    YDate = TODAY

RETURN
*-----------------------------------------------------------------------------
END
