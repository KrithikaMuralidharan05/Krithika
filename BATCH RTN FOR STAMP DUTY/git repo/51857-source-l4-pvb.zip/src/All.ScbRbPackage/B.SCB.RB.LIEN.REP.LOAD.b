* @ValidationCode : MjotMTYzNjg4OTYwNDpJU08tODg1OS0xOjE2ODExMDI0MDczMzQ6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 10 Apr 2023 10:23:27
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.LIEN.REP.LOAD
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14081 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       7 Mar 2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is the multi-threaded routine which generates the Lien Report
*-----------------------------------------------------------------------------
* Modification History :
* Date          Author           Description
* 11-Apr-2023   1663000          CPSGMIG-22842 - Include Position Migration flag column
* 22-May-2023   1648769          CPSGMIG-27284 - Asset name changes - To captured from SM>LR.UTS.INS.DESC, if value is empty in SM>LR.UTS.INS.DESC then display SM->DESC in the report.
* 22-May-2023   1648769          CPSGMIG-27390 - Remarks and Lien code changes
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SCB.PORTFOLIO.REC.ACCT
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_B.SCB.RB.LIEN.REP.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.LOCKING
    $INSERT I_F.SC.SCB.RB.BLOCK
*-----------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB GET.VALUES
 
RETURN
*---------*
INITIALISE:
*---------*
    
    FN.CUSTOMER               = 'F.CUSTOMER'               ; F.CUSTOMER               = '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SEC.ACC.MASTER         = 'F.SEC.ACC.MASTER'         ; F.SEC.ACC.MASTER         = '' ; CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    FN.SECURITY.POSITION      = 'F.SECURITY.POSITION'      ; F.SECURITY.POSITION      = '' ; CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)
    FN.SECURITY.MASTER        = 'F.SECURITY.MASTER'        ; F.SECURITY.MASTER        = '' ; CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SCB.PORTFOLIO.REC.ACCT = 'F.SCB.PORTFOLIO.REC.ACCT' ; F.SCB.PORTFOLIO.REC.ACCT = '' ; CALL OPF(FN.SCB.PORTFOLIO.REC.ACCT,F.SCB.PORTFOLIO.REC.ACCT)
    FN.SC.SCB.LIEN.CODE       = 'F.SC.SCB.LIEN.CODE'       ; F.SC.SCB.LIEN.CODE       = '' ; CALL OPF(FN.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE)
    FN.SC.SCB.RB.BLOCK        = 'F.SC.SCB.RB.BLOCK'        ; F.SC.SCB.RB.BLOCK        = '' ; CALL OPF(FN.SC.SCB.RB.BLOCK,F.SC.SCB.RB.BLOCK)
    
    CALL SCB.GET.ORACLE.VIEWNAME(FN.SECURITY.POSITION,Y.VIEW.NAME)   ;* Get Security Position View Name
 
RETURN
*---------*
GET.VALUES:
*---------*
    
    AMEX.FILES.PATH = 'AMEX.FILES'  ;  ARG2 = ''   ;    AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2,AMEX.FILES)
 
    Y.DATA = BATCH.DETAILS<3,1>
    CONVERT @SM TO @FM IN Y.DATA
   
    MTH.DAILY.FLAG  = FIELD(Y.DATA,'*', 1)   ;* Contain the value as Daily or Monthly
   
    IF MTH.DAILY.FLAG EQ 'D' THEN
        Y.RPT.AGENT.FILE = 'LIENREPORTDAILY-':TODAY:'-':SESSION.NO:'.csv'
    END ELSE
        Y.RPT.AGENT.FILE = 'LIENREPORTMONTHLY-':TODAY:'-':SESSION.NO:'.csv'
    END
    
* Get LRF values
    LOC.REF.APP    = 'SEC.ACC.MASTER':@FM:'SECURITY.MASTER':@FM:'CUSTOMER'
    LOC.REF.FLD<1> = 'LR.LIEN.CODE':@VM:'LR.ISA.REMARKS':@VM:'LR.POS.MIG.DT'                ;*CPSGMIG-22842 -S/E
    LOC.REF.FLD<2> = 'LR.RETAIL.DEPO':@VM:'ISLAMIC.SUKUK':@VM:'LR.UTS.INS.DESC'	
    LOC.REF.FLD<3> = 'L.O.B' :@VM: 'LR.PFOLIO.KEY' :@VM: 'LR.STAFF.IND'
    
    LOC.REF.POS = ''
    CALL MULTI.GET.LOC.REF(LOC.REF.APP,LOC.REF.FLD,LOC.REF.POS)
   
    Y.SAM.LIENCOD.POS = LOC.REF.POS<1,1>   ;  Y.SAM.LRREMAR.POS = LOC.REF.POS<1,2>  ; Y.SAM.POSMIG.POS = LOC.REF.POS<1,3>  ;*CPSGMIG-22842 -S/E
    Y.SM.RETDEPO.POS  = LOC.REF.POS<2,1>   ;  Y.SM.ISLMSUK.POS  = LOC.REF.POS<2,2>  ; Y.LR.UTS.DESC.POS = LOC.REF.POS<2,3>
    Y.CUS.LOB.POS     = LOC.REF.POS<3,1>   ;  Y.CUS.LRPFOLIO.POS= LOC.REF.POS<3,2>
    Y.CU.STAFFIND.POS = LOC.REF.POS<3,3>
    
* Get LOB Condition
    Y.PARAM.ID = 'SCB.CUST.SEG'; Y.ALLOW.SEG = 'RET'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    
RETURN
END
