$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.AUM.LOAD
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-AUM-XX-<start.date>-<end date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SC.POS.ASSET
    $INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.RB.GTCP.AUM.COMMON

    GOSUB INITIALISE
    GOSUB OPEN.ALL.FILES

RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*----------
	FILE.NAME = ID.COMPANY[1,2]:"-MFU-AUM-":TODAY:".txt-":SESSION.NO
    DL = ','

RETURN
*-----------------------------------------------------------------------------
OPEN.ALL.FILES:
*--------------
    FN.SC.POS.ASSET = 'F.SC.POS.ASSET' ; FP.SC.POS.ASSET = ''
    CALL OPF(FN.SC.POS.ASSET,FP.SC.POS.ASSET)
*
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER' ; FP.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,FP.SEC.ACC.MASTER)
*
    FN.CUSTOMER = 'F.CUSTOMER' ; FP.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,FP.CUSTOMER)
*
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
    Y.PARAM.ID    = 'SCB.CUST.SEG'
    Y.ALLOW.SEG   = 'RET'
    Y.ALLOWED.LOB = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
	CONVERT @VM TO ' ' IN Y.ALLOWED.LOB
*
	FN.ISAC.CONCAT = 'F.SC.SCB.RSG.SAM.ISAC.CON'
	FV.ISAC.CONCAT = ''
	CALL OPF(FN.ISAC.CONCAT, FV.ISAC.CONCAT)
*
	FN.SCB.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	FV.SCB.LOC.PARAM = ''
	CALL OPF(FN.SCB.LOC.PARAM,FV.SCB.LOC.PARAM)
*
	LOC.PARAM.ID = 'RSG.PILOT.IND'
	R.LOC.PARAM.REC = '' ; E.LOC.PARAM.ERR = '' ; Y.MANDATE.LIST = '' ; Y.FLD.NAME = ''
	CALL F.READ(FN.SCB.LOC.PARAM,LOC.PARAM.ID,R.LOC.PARAM.REC,FV.SCB.LOC.PARAM,E.LOC.PARAM.ERR)
*
	IF R.LOC.PARAM.REC THEN
		Y.FLD.NAME = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.NAME>
		LOCATE 'UTS.ISA.NUMBERS' IN Y.FLD.NAME<1,1> SETTING Y.NAME.POS THEN
            Y.ISA.NOS = R.LOC.PARAM.REC<SCBWM.PRM.FIELD.VALUE,Y.NAME.POS>
			CHANGE @SM TO @FM IN Y.ISA.NOS
			TOT.ISA.CNT = DCOUNT(Y.ISA.NOS,@FM)
			FOR ISA.INT = 1 TO TOT.ISA.CNT
				Y.ISA.ACCT.ID = Y.ISA.NOS<ISA.INT>
				R.ISA.ACCT.REC = '' ; E.ISA.ACCT.ERR = ''
				CALL F.READ(FN.ISAC.CONCAT,Y.ISA.ACCT.ID,R.ISA.ACCT.REC,FV.ISAC.CONCAT,E.ISA.ACCT.ERR)
				IF R.ISA.ACCT.REC THEN
					LOCATE R.ISA.ACCT.REC<1> IN Y.MANDATE.LIST<1> SETTING MANDATE.POS THEN
					END ELSE
						Y.MANDATE.LIST<-1> = R.ISA.ACCT.REC<1>
					END
                END
            NEXT ISA.INT
        END
	END
*
    Y.APP.NAME<1> = 'SEC.ACC.MASTER'
    Y.FLD.NAME<1> = 'LR.TP.ACCT.NO':@VM:'LR.PFOLIO.KEY'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
	LR.TP.ACCT.NO.POS = Y.FLD.POS<1,1>
	LR.PFOLIO.KEY.POS = Y.FLD.POS<1,2>
*
	Y.STEND.DATE = BATCH.DETAILS<3,1,2>
	Y.START.DATE = FIELD(Y.STEND.DATE,'-',1)
	Y.END.DATE   = FIELD(Y.STEND.DATE,'-',2,1)

RETURN
*-----------------------------------------------------------------------------
END
