$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.R2W.GROUP.AUM.LOAD
*-----------------------------------------------------------------------------
* Modification History:
*----------------------
* 10-Oct-2022 - CPSGMIG-5314  - Sasi V - R2W report: AUM for Group for RBSG
* 02-Jan-2026 - ADO-11478676 - Prithi Koppolu - Enhanced to include additional column and capture
*                                               the details in 2 separate rows based on PLEDGED and UNPLEDGED positions.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SC.POS.ASSET
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
	$INSERT I_F.ASSET.TYPE
	$INSERT I_F.AEB.SEC.PAR
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.RB.R2W.GROUP.AUM.COMMON
	$INSERT I_F.SECURITY.POSITION ;*ADO-11478676-(s/e)

    GOSUB INITIALISE
    GOSUB OPEN.ALL.FILES

RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*----------
*
	DL = ','
	FILE.NAME = ID.COMPANY[1,2]:"-RB-GROUP-AUM-DATA":TODAY:"-":SESSION.NO:".CSV"
*
RETURN
*-----------------------------------------------------------------------------
OPEN.ALL.FILES:
*--------------
*
    FN.SC.POS.ASSET = 'F.SC.POS.ASSET' ; FP.SC.POS.ASSET = ''
    CALL OPF(FN.SC.POS.ASSET,FP.SC.POS.ASSET)
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER' ; FP.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,FP.SECURITY.MASTER)
*
	FN.AEB.SEC.PAR = 'F.AEB.SEC.PAR' ; F.AEB.SEC.PAR = ''
	CALL OPF(FN.AEB.SEC.PAR,F.AEB.SEC.PAR)
*
    FN.SUB.ASSET.TYPE = 'F.SUB.ASSET.TYPE' ; F.SUB.ASSET.TYPE = ''
    CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
*
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM' ; F.SCB.WM.H.LOCAL.PARAM = '' ; R.SCB.WM.H.LOCAL.PARAM = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM, F.SCB.WM.H.LOCAL.PARAM)
*
    R.SCB.H.LOCAL.PARAM = '' ; ERR.SCB.WM.H.LOCAL.PARAM = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,"SCB.CRES.SAT",R.SCB.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOCAL.PARAM)

    Y.ALLOWED.SEGMENT = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.ALLOWED.SAT.LIST  = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>

    Y.SEG.POS = '' ; Y.SN.SAT.CODES = ''
    LOCATE "SN" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.SN.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.SN.SAT.CODES
    END

    Y.SEG.POS = ''; Y.FI.SAT.CODES = ''
    LOCATE "FI" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.FI.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.FI.SAT.CODES
    END

    Y.SEG.POS = '';Y.MF.SAT.CODES = ''
    LOCATE "MF" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.MF.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.MF.SAT.CODES
    END
*
    APP.NAME   = 'SECURITY.MASTER'
	FIELD.NAME = 'MF.ISSUER.NAME':@VM:'ISLAMIC.MANDTE':@VM:'LR.RETAIL.DEPO'
    FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(APP.NAME, FIELD.NAME, FIELD.POS)
	MF.ISSUER.NAME.POS = FIELD.POS<1,1>
	ISLAMIC.MANDTE.POS = FIELD.POS<1,2>
	LR.RETAIL.DEPO.POS = FIELD.POS<1,3>
*
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
	CONVERT @VM TO ' ' IN Y.ALLOWED.LOB
* PVB/RB Customer Demarkation
*ADO-11478676-(s)
	FN.SEC.POS = 'F.SECURITY.POSITION'
	FV.SEC.POS = ''
	CALL OPF(FN.SEC.POS,FV.SEC.POS)
*ADO-11478676-(e)
RETURN
*-----------------------------------------------------------------------------
END