$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.EBBS.W8.W9.RMV.DUP
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*Descrption : Single thread routine to remove the duplicates DMD laod file in W8W9 FLAG process
*Attached to Batch:- SNG/B.SCB.RSG.EBBS.W8.W9.PROCESS
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.EBBS.W8.W9.PROCESS.COMMON

    CALL LOAD.COMPANY("SG1090400")
    
    
*
    GOSUB DATA.ARCH
     
    FN.DATA.IN = 'DATA.IN'
    F.DATA.IN  = ''
    CALL OPF(FN.DATA.IN,F.DATA.IN)
    Y.FILE.ID = "EBBS.W8.W9.PROCESS.UPD.txt"
    Y.EXCP.ID = "RSG.SG.EBBS.RDD.EXCP.txt"

    Y.EXCEPTION.ID = "RSG.SG.EBBS.RDD.EXCP.":Y.DATE:".txt"

    CALL OCOMO("Ebbs source file is ":Y.FILE.ID)

    EXE.CMD = "SH -c ":"cp ":FN.DATA.IN:"/":Y.EXCP.ID:" ":FN.DATA.IN:"/":Y.EXCEPTION.ID
	CALL OCOMO('Copying to temporary file - Started: ':EXE.CMD)
	EXECUTE EXE.CMD

    CALL F.READ( FN.DATA.IN,Y.FILE.ID,R.DATA,F.DATA.IN,DIP.ERR)
    FOR I =1 TO DCOUNT(R.DATA,@FM)
       
        Y.ID = FIELD(R.DATA<I>,'|',1)
        Y.FLAG = FIELD(R.DATA<I>,"|",2)

        LOCATE Y.ID IN R.DATA.ARRAY SETTING S.POS THEN
            LOCATE Y.FLAG IN FLAG.ARR<S.POS> SETTING FLAG.POS ELSE
                FLAG.ARR<S.POS> = Y.FLAG

                Y.STRING.UPLOAD<-1> = R.DATA<I>
                R.DATA.ARRAY<-1> = Y.ID

            END
        END
        ELSE
            FLAG.ARR<S.POS> = Y.FLAG
            Y.STRING.UPLOAD<-1> = R.DATA<I>
            R.DATA.ARRAY<-1> = Y.ID
        END
    NEXT I
    Y.FORM.FILE ="RSG.SG.EBBS.RDD.":Y.DATE:".txt"
  
    CALL F.WRITE(FN.DATA.IN,Y.FORM.FILE,Y.STRING.UPLOAD)

    CALL F.DELETE(FN.DATA.IN,Y.FILE.ID)
    CALL F.DELETE(FN.DATA.IN,Y.EXCP.ID)

RETURN
***************
DATA.ARCH:
*******************
    SEL.FILE.CMD = "SELECT ":FN.DATA.IN:" WITH @ID LIKE ...SG_EBBS_RDD..."
    CALL EB.READLIST(SEL.FILE.CMD,FILE.LISTS,"",NO.LIST,ERR.LIST)
    CALL OCOMO("PROCESSED FILES List ":FILE.LISTS)
    FILE.CNT = DCOUNT(FILE.LISTS,@FM)
    IF FILE.CNT GE '1' THEN
        K=1
        LOOP

        WHILE K LE FILE.CNT

            CALL OCOMO("Archiving the uploaded file ":FILE.LISTS<K>:" after Processing w8w9 flag")
            EXE.CMD = "SH -c 'mv ":Y.T24.UPLOAD.PATH:"/":FILE.LISTS<K>:" ":Y.T24.UPLOAD.ARC.PATH:"/'"
            CRT "File movement command:- ":EXE.CMD
            EXECUTE EXE.CMD
            K= K+1
        REPEAT
    END
RETURN
**************
END