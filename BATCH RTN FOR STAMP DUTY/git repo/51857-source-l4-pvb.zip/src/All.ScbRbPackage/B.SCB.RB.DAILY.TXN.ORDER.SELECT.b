* @ValidationCode : MjotMjIzMjQ0MzE6SVNPLTg4NTktMToxNjkzMjk3OTE3MTU3OjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 29 Aug 2023 14:01:57
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.DAILY.TXN.ORDER.SELECT
*-----------------------------------------------------------------------------
* Jira ref                       :      ADO-11887708
* Developed By                   :      8219622
* Developed On                   :      20-Feb-2026
*-----------------------------------------------------------------------------
* Description:
*-------------
* Batch report attached to SNG/SCB.RB.DAILY.TXN.ORDER inorder to generate report for daily transactions of SEC.TRADE,SEC.OPEN.ORDER AND SECURITY.TRANSFER 
* regardless of whether it is in authorized, unauthorized or hold status
*-------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_TSA.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.DAILY.TXN.ORDER.COMMON
	$INSERT I_F.DATES
	$INSERT I_F.SEC.TRADE
*-----------------------------------------------------------------------------
	
	CALL F.READ(FN.DATES,'SG1090400',R.DATES,F.DATES,S.DATE.ERRR)
	Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)
 	Y.FINAL.LIST = ''
	
    MTH.DAILY.FLAG = BATCH.DETAILS<3,1,1>             ;* Contain the value as Daily or Monthly
	
    IF MTH.DAILY.FLAG EQ "D" THEN
        SEL.CMD = 'SELECT ':FN.SCB.RB.DAILY.TXN.DETAILS:' WITH @ID LIKE ...':Y.LWD  
	END

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)	
    CALL BATCH.BUILD.LIST('',SEL.LIST)
	
RETURN
END
