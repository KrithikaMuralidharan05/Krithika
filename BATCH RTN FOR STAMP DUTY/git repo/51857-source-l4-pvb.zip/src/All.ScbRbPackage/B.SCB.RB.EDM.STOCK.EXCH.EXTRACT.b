$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-54</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.STOCK.EXCH.EXTRACT
**************************************************************************
* 25 Feb 2016 - FCC EDMP - Subramanian M
*             - This routine will generate the Stock Exchange Dump in AMEX.FILES.
**************************************************************************
*******************************************************************************
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
* 16-Jun-2022 - CPSGMIG-3789 - Shreekantha. G - Copy of the existing routine B.SCB.EDM.STOCK.EXCH.EXTRACT
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.STOCK.EXCHANGE
    $INSERT I_F.DATES
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*******************************************************************************
INIT:
****
    FN.STOCK.EXCHANGE = 'F.STOCK.EXCHANGE'
    F.STOCK.EXCHANGE = ''
    CALL OPF(FN.STOCK.EXCHANGE,F.STOCK.EXCHANGE)
*
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
    Y.HEADER = ''
    Y.FINAL.FILE.NAME = '' ; Y.COMP.NAME = ''
    R.STOCK.EXCH.RPT.ARR = ''
    DL = CHAR(01)
**Headers** CPSGMIG-3789 - S								;*CPSGMIG-3789-HEADER
	Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
    Y.HEADER<-1> = 'D':DL:'ID':DL:'DESCRIPTION':DL:'SHORT_DESCR':DL:'CALC_COUNTRY':DL:'SETTLEMENT_DAYS':DL:'DOMICILE'
**Headers** CPSGMIG-3789 - E
*
    Y.COMP.NAME = ID.COMPANY[1,2]
    IF Y.COMP.NAME EQ 'GB' THEN
        Y.COMP.NAME = 'UK'
    END
    Y.FINAL.FILE.NAME = Y.COMP.NAME:"-RB-STOCK.EXCH-":TODAY:".CSV"			;*CPSGMIG-3789 - S/E
RETURN	
*******************************************************************************
PROCESS:
********
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.STOCK.EXCHANGE
	TOTAL.LINE.COUNT = 0								;*CPSGMIG-3789-TRAILER
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        LOOP
            REMOVE STK.ID FROM SEL.LIST SETTING SEL.POS
        WHILE STK.ID:SEL.POS
            R.STOCK.EXCH = '' ; STOCK.EXCH.ERR = ''
            CALL F.READ(FN.STOCK.EXCHANGE,STK.ID,R.STOCK.EXCH,F.STOCK.EXCHANGE,STOCK.EXCH.ERR)
            IF R.STOCK.EXCH THEN
                GOSUB ADD.ARRAY
            END
			TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + 1				;*CPSGMIG-3789-TRAILER
        REPEAT
    END
    Y.FINAL.ARR = ''
    Y.FINAL.ARR = Y.HEADER:FM:R.STOCK.EXCH.RPT.ARR
	Y.FINAL.ARR :=@FM:'T':DL:TOTAL.LINE.COUNT					;*CPSGMIG-3789-TRAILER-S/E
*   Y.FINAL.ARR = R.STOCK.EXCH.RPT.ARR
    GOSUB WRITE.AMEX.FILE
*
RETURN
*******************************************************************************
ADD.ARRAY:
*********
	Y.DESC = R.STOCK.EXCH<SC.STE.DESCRIPTION,1>
    CONVERT ',' TO '|' IN Y.DESC
    Y.SHORT.DESC = R.STOCK.EXCH<SC.STE.SHORT.DESCR>
    CONVERT ',' TO '|' IN Y.SHORT.DESC
    IF R.STOCK.EXCH.RPT.ARR EQ '' THEN
        R.STOCK.EXCH.RPT.ARR = 'D':DL:STK.ID:DL:Y.DESC:DL:Y.SHORT.DESC
        R.STOCK.EXCH.RPT.ARR := DL:R.STOCK.EXCH<SC.STE.CALC.COUNTRY>:DL:R.STOCK.EXCH<SC.STE.SETTLEMENT.DAYS>:DL:R.STOCK.EXCH<SC.STE.DOMICILE>
    END ELSE
        TEMP.ARR = ''
        TEMP.ARR = 'D':DL:STK.ID:DL:Y.DESC:DL:Y.SHORT.DESC
        TEMP.ARR := DL:R.STOCK.EXCH<SC.STE.CALC.COUNTRY>:DL:R.STOCK.EXCH<SC.STE.SETTLEMENT.DAYS>:DL:R.STOCK.EXCH<SC.STE.DOMICILE>
        R.STOCK.EXCH.RPT.ARR<-1> = TEMP.ARR
    END
RETURN
*******************************************************************************
WRITE.AMEX.FILE:
****************
	Y.FINAL.ARR = UTF8(Y.FINAL.ARR)
    CALL F.WRITE(FN.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FINAL.ARR)
RETURN
*******************************************************************************
END
