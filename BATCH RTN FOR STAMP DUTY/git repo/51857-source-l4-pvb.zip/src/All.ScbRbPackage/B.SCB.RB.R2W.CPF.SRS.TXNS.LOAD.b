*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.R2W.CPF.SRS.TXNS.LOAD
*-----------------------------------------------------------------------------
* Description   :  CPSGMIG-5330 -> R2W report -> CPF/ SRS Transaction Details Report Load Routine
* 				   This routine will generate the CPF/ SRS Transaction Details Report in AMEX.FILES.
* Author        :  Swaminathan
* Date          :  17 Oct 2022
*----------------------
* Modification History:
*----------------------
* 8/11/2022 - Swaminathan.S.R - CPSGMIG-5330 Select table logic changed to SEC.OPEN.ORDER instead of SCB.SEC.OPEN.ORD.TRD.STATUS
* 25/04/2023 - Bharathi       - CPSGMIG-25001 - T24 mapping update- Remarks column - CUSTOMER>LR.US.PERSON is "Y" - ‘US PERSON’; "N" - ‘NON-US PERSON, NO US INDICIA’
*                                                                   Product Provider No column : Order id (SOO>@ID).
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.R2W.CPF.SRS.TXNS.COMMON
*
    FN.SEC.OPEN.ORDER = 'F.SEC.OPEN.ORDER'
    F.SEC.OPEN.ORDER  = ''
    CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
*
    FN.CUSTOMER = 'F.CUSTOMER'
	F.CUSTOMER  = ''
	CALL OPF(FN.CUSTOMER,F.CUSTOMER)
*
	FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER  = ''
	CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
	FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
	F.SEC.ACC.MASTER  = ''
	CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
	LOC.FIELD  = 'LR.INVST.ACC.NO':@VM:'LR.PAYMENT.TYPE':@VM:'LR.NET.SAL.PERC':@VM:'CPFSRS.AGNT.BNK':@VM:'CPFSRS.ACCT.NO':@FM
	LOC.FIELD := 'LR.ISA.REMARKS':@FM:'L.O.B':@VM:'LR.EBBS.REL':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.US.PERSON':@FM  ; *CPSGMIG-25001-S/E
	LOC.FIELD := 'MF.ISSUER.NAME':@VM:'LR.UTS.INS.DESC'
    LOC.APP = 'SEC.OPEN.ORDER':@FM:'SEC.ACC.MASTER':@FM:'CUSTOMER':@FM:'SECURITY.MASTER'
    CALL MULTI.GET.LOC.REF(LOC.APP,LOC.FIELD,LOC.POS)
	LR.INVST.ACC.NO.POS = LOC.POS<1,1>
	LR.PAYMENT.TYPE.POS = LOC.POS<1,2>
	LR.NET.SAL.PERC.POS = LOC.POS<1,3>
	CPFSRS.AGNT.BNK.POS = LOC.POS<1,4>
	CPFSRS.ACCT.NO.POS  = LOC.POS<1,5>
	LR.ISA.REMARKS.POS  = LOC.POS<2,1>
	CUST.LOB.POS        = LOC.POS<3,1>
	LR.EBBS.REL.POS     = LOC.POS<3,2>
	LR.STAFF.IND.POS    = LOC.POS<3,3>
	LR.PFOLIO.KEY.POS   = LOC.POS<3,4>
        LR.US.PERSON.POS    = LOC.POS<3,5>     ; *CPSGMIG-25001-S/E
	MF.ISSUER.NAME.POS  = LOC.POS<4,1>
	LR.UTS.INS.DESC.POS = LOC.POS<4,2>
*
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
* PVB/RB Customer Demarkation
    Y.PARAM.ID          = 'SCB.CUST.SEG'
    Y.ALLOW.SEG         = 'RET'
    Y.ALLOWED.LOB       = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
* PVB/RB Customer Demarkation
	DL = ','
	FILE.NAME = ID.COMPANY[1,2]:'-RB-R2W-CPF-SRS-TXNS-':TODAY:'-':SESSION.NO:'.csv'
*
RETURN
END