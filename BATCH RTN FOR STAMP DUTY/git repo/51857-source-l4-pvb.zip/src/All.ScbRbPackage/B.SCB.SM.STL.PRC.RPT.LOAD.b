$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SM.STL.PRC.RPT.LOAD
*-----------------------------------------------------------------------------
* CPSGMIG-1552 Stale Price Report
*              To view price and date last price for active Structured Note instruments
*              To  identify the Structured Note instrument with stale or missing price
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SC.PRICE.CHANGE
    $INSERT I_B.SCB.SM.STL.PRC.RPT.COMMON
    
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)

    FN.SC.PRICE.CHANGE = 'F.SC.PRICE.CHANGE'
    F.SC.PRICE.CHANGE = ''
    CALL OPF(FN.SC.PRICE.CHANGE,F.SC.PRICE.CHANGE)

    FN.SECURITY.POSITION = 'F.SECURITY.POSITION'
    F.SECURITY.POSITION = ''
    CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)

    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
        
    Y.DATE = TODAY
    CALL CDT("",Y.DATE,"-21C")
    LAST.DATE.TB = Y.DATE
    
    Y.FILE.NAME = 'SN.STALE.PRICE.REPORT.':AGENT.NUMBER:'.':TODAY:'.csv'

RETURN
END
