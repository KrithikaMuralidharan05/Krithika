$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.R2W.GROUP.AUM.SELECT
*-----------------------------------------------------------------------------
* Modification History:
*----------------------
* 10-Oct-2022 - CPSGMIG-5314  - Sasi V - R2W report: AUM for Group for RBSG
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.DATES
    $INSERT I_B.SCB.RB.R2W.GROUP.AUM.COMMON

	GOSUB CHECK.EOM
	GOSUB PROCESS
	
RETURN
*-----------------------------------------------------------------------------
CHECK.EOM:
*---------
	EOM.FLAG = ''
	Y.LAST.WORKING.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
	
*IF TODAY[5,2] NE Y.LAST.WORKING.DAY[5,2] THEN ; *Commented for UAT testing
    EOM.FLAG = '1'
*END
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
	IF EOM.FLAG THEN
		SEL.CMD = "SELECT ":FN.SC.POS.ASSET:" WITH L.O.B EQ ":Y.ALLOWED.LOB
*
		CALL EB.READLIST(SEL.CMD,SPA.ALL.IDS,'',NO.OF.REC,RET.COD)
		CALL BATCH.BUILD.LIST('', SPA.ALL.IDS)
	END
*
RETURN
*-----------------------------------------------------------------------------
END
