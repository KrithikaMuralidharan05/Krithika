$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.HIST.ACNO.DUP.RM.POST
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 21-Nov-2023 - ADO-2100833 - kalaikumaranp- Remove Duplicate Txn Ids from SCB.UTS.HIST.PROD.ACNO Table.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.CCMS.FILES = 'CCMS'
    F.CCMS.FILES = ''
    CALL OPF(FN.CCMS.FILES,F.CCMS.FILES)

    Y.FINAL.FILE.NAME = 'ISADUPLIST.TXT'
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*   
	R.FINAL.ARR = ''
    Y.UDFILE = 'CCMS'
    SEL.CMD  = 'ISALIST.TXT-*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.CCMS.FILE = '' ; CCMS.ERR = ''
            CALL F.READ(FN.CCMS.FILES,SEL.FILE,R.CCMS.FILE,F.CCMS.FILES,CCMS.ERR)
			IF R.CCMS.FILE THEN
                IF R.FINAL.ARR EQ '' THEN
                    R.FINAL.ARR = R.CCMS.FILE
                END ELSE
                    R.FINAL.ARR :=@FM:R.CCMS.FILE
                END
			END
            CALL F.DELETE(FN.CCMS.FILES,SEL.FILE)
        REPEAT
    END
*
    WRITE R.FINAL.ARR TO F.CCMS.FILES,Y.FINAL.FILE.NAME
*
RETURN
*-----------------------------------------------------------------------------
END