$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.LIEN.MARK.LOAD
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 14/04/2023 - Sasi V - To create POSITION.TRANSFER records for Lien/Unlien request
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.POSITION.TRANSFER
	$INSERT I_F.SCB.RB.LIEN.MARKING
    $INSERT I_B.SCB.RB.LIEN.MARK.COMMON
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.SCB.RB.LIEN.MARKING = 'F.SCB.RB.LIEN.MARKING'
    F.SCB.RB.LIEN.MARKING = ''
    CALL OPF(FN.SCB.RB.LIEN.MARKING, F.SCB.RB.LIEN.MARKING)
*
    FN.POSITION.TRANSFER = 'F.POSITION.TRANSFER'
    F.POSITION.TRANSFER = ''
    CALL OPF(FN.POSITION.TRANSFER, F.POSITION.TRANSFER)
*
	FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
	F.SEC.ACC.MASTER = ''
	CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
	FN.SCB.PORTFOLIO.REC.ACCT = 'F.SCB.PORTFOLIO.REC.ACCT'
	F.SCB.PORTFOLIO.REC.ACCT = ''
	CALL OPF(FN.SCB.PORTFOLIO.REC.ACCT,F.SCB.PORTFOLIO.REC.ACCT)
*
	FN.SCB.PORTFOLIO.REC.ACCT.HIS = 'F.SCB.PORTFOLIO.REC.ACCT$HIS'
	F.SCB.PORTFOLIO.REC.ACCT.HIS = ''
	CALL OPF(FN.SCB.PORTFOLIO.REC.ACCT.HIS,F.SCB.PORTFOLIO.REC.ACCT.HIS)
*
	Y.APP   = 'SEC.ACC.MASTER':@FM:'POSITION.TRANSFER'
	Y.FIELD = 'LR.WLTH.LND.IND':@VM:'LR.WL.EFF.DATE':@VM:'LR.FACILITY.ID'
    Y.FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
	LR.WLTH.LND.IND.POS = Y.FIELD.POS<1,1>
	LR.WL.EFF.DATE.POS = Y.FIELD.POS<1,2>
	LR.FACILITY.ID.SAM.POS = Y.FIELD.POS<1,3>
*
RETURN
*-----------------------------------------------------------------------------
END
