* @ValidationCode : MjotMTgwNDg1MDU1ODpJU08tODg1OS0xOjE2OTUxMDMyODQyNjA6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 19 Sep 2023 11:31:24
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.BSC.CONFIRM.ORDER.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17784
* Developed By                   :       1663000
* Developed On                   :       02 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* POST Routine to generate Extract file of BSC Confirmed Order Report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 09-02-2023    Senthil          CPSGMIG-17827 - Account Holder DOB 2, Account Holder DOB 3 , Account Holder DOB 4 should be added next to PrimaryAccHolder column.
*                                              - Transaction (Trade) Date column to be captured next to Account Holder DOB 4
*                                              - Mapping - SEC.TRADE > TRADE.DATE ; SECURITY.TRANSFER >TRADE.DATE
* 16-Feb-2023   1663000          CPSGMIG-14085 - Column addition UTS data with DOB for all account holders
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename/Date Change
* 19-Sep-2023   1663000          CPSGMIG-34480 - Filename Changes
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB PROCESS
	 
RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.TXN.FINAL.FILE    = BATCH.DETAILS<3,1>
    Y.LWD               = R.DATES(EB.DAT.LAST.WORKING.DAY)            ;* CPSGMIG-21498
    Y.TXN.FINAL.FILE    = EREPLACE(Y.TXN.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
    Y.TXN.FINAL.FILE    = EREPLACE(Y.TXN.FINAL.FILE,"<TODAY>",TODAY,-1)
      
RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.TXN.ARR = '' ; Y.FINAL.TXN.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = "SCBBSCCONFREPORT-" :TODAY:"-*.csv*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(R.TXN.ARR) THEN
                R.TXN.ARR = R.AMEX.FILE
            END ELSE
                R.TXN.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

        IF R.TXN.ARR THEN
           
* Include the Header part
            Y.TXN.HDR = "Transaction Reference,ISOC Operator,Order Closing Id,Country Code,Sales Staff Name,"
            Y.TXN.HDR:= "Account Type,Account Number,Account Open Date,Lien Reason Code,Lien Reason Code Desc,"
            Y.TXN.HDR:= "Order No.,Order Date,Account Holder DOB,Transaction Type,Detail On Order Type,Order Type,"
            Y.TXN.HDR:= "Transaction Status,Product Provider Name,Asset Code,Asset Name,Asset Currency,"
            Y.TXN.HDR:= "Transaction Amount,Remarks,Account Holder 1,ID Number 1,EBBS Rel ID 1,Account Holder 2,ID Number 2," ;*CPSGMIG-14085
            Y.TXN.HDR:= "EBBS Rel ID 2,Account Holder 3,ID Number 3,EBBS Rel ID 3,Account Holder 4,ID Number 4,EBBS Rel ID 4,RSP Plan ID,"
            Y.TXN.HDR:= "ISIN,PRR [Risk],Channel info,ClientIdentifier,PrimaryAcctHolder,Account Holder DOB 2,Account Holder DOB 3,Account Holder DOB 4," ;*CPSGMIG-14085
            Y.TXN.HDR:= "Transaction Date,Referral ID,Transaction CCY,Rel 1,Rel 2,Rel 3,Rel 4" ;*CPSGMIG-14085
 
* Include the Data content
            Y.FINAL.TXN.ARR     = Y.TXN.HDR
            Y.FINAL.TXN.ARR<-1> = R.TXN.ARR
    
            WRITE Y.FINAL.TXN.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
            
        END
    END

RETURN
END