$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.PRODTYPE.SPEED.EXT(Y.SAT.ID)
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 27/04/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> eSpeed
*						RBSG_ESPEED_PRODTYPE_YYYYMMDD.txt
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
	$INSERT I_F.ASSET.TYPE
	$INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_B.SCB.PRODTYPE.SPEED.EXT.COMMON
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
	FILE.NAME = ID.COMPANY[1,2]:"-PRODUCT-TYPE-":TODAY:".csv-":SESSION.NO
*
	OPENSEQ AMEX.FILES,FILE.NAME TO F.AMEX.FILES ELSE CREATE F.AMEX.FILES ELSE
        CALL OCOMO("Error opening ":FILE.NAME)
        CALL FATAL.ERROR("B.SCB.PRODTYPE.SPEED.EXT")
    END
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
	Y.RECORD.TYPE = 'D'
	R.SUB.ASSET.TYPE = '' ; SUB.ASSET.TYPE.ERR = '' ; Y.DESCRIPTION = '' ; Y.ASSET.TYPE.CODE = ''
    CALL F.READ(FN.SUB.ASSET.TYPE,Y.SAT.ID,R.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE,SUB.ASSET.TYPE.ERR)
	Y.DESCRIPTION = R.SUB.ASSET.TYPE<SC.CSG.DESCRIPTION>
	Y.ASSET.TYPE.CODE = R.SUB.ASSET.TYPE<SC.CSG.ASSET.TYPE.CODE>
*
	R.ASSET.TYPE = '' ; ASSET.TYPE.ERR = '' ; Y.ASSET.DESC = ''
    CALL F.READ(FN.ASSET.TYPE,R.SUB.ASSET.TYPE<SC.CSG.ASSET.TYPE.CODE>,R.ASSET.TYPE,F.ASSET.TYPE,ASSET.TYPE.ERR)
	Y.ASSET.DESC = R.ASSET.TYPE<SC.ASS.ASSET.DESC,1>
*
	Y.SAT.REC = FMT(Y.RECORD.TYPE,"1' 'L"):FMT(Y.SAT.ID,"6' 'L"):FMT(Y.DESCRIPTION,"40' 'L"):FMT(Y.ASSET.TYPE.CODE,"6' 'L"):FMT(Y.ASSET.DESC,"40' 'L")
*
    GOSUB WRITE.AMEX.FILE
*
	CLOSESEQ F.AMEX.FILES
*
RETURN
*-----------------------------------------------------------------------------
WRITE.AMEX.FILE:
*---------------
	WRITESEQ Y.SAT.REC APPEND TO F.AMEX.FILES ELSE
        CALL FATAL.ERROR('Unable to write ':F.AMEX.FILES)
    END
*
RETURN
*-----------------------------------------------------------------------------
END
