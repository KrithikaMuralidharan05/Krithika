$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.FUND.HOLD.PDW.EXT.FILTER(Y.SECPOS.ID)
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 28/Apr/2022 - Lavanya L - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_FundHolding_YYYYMMDD.csv
* Routine to filter sec pos ids.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.FUND.HOLD.PDW.EXT.COMMON
*

	Y.SEL.ID.REM = ''
    GOSUB SEC.POS
* 
RETURN
*-----------------------------------------------------------------------------
SEC.POS:
*-------
    Y.DEPO = FIELD(Y.SECPOS.ID,'.',3)						;*500000005-1.000001-103.6087....
	Y.SEL.ID = Y.SECPOS.ID
	
	Y.SEL.ID.REM = FIELD(Y.SECPOS.ID,'.',4,6)					;*500000005-1.000001-103.6087.1...

	IF Y.DEPO AND Y.SEL.ID.REM EQ '...' THEN
	
		Y.SECPOS.ID = Y.SEL.ID
	END
	ELSE 
		Y.SECPOS.ID = ''
	END
*
RETURN
*-----------------------------------------------------------------------------
END
