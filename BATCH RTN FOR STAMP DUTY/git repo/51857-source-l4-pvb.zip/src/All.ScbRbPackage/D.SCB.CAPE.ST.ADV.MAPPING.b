$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.CAPE.ST.ADV.MAPPING(CAPE.CA.REF.ID,TRANS.REF.ID, MAT HANDOFF.REC)

*****
* Description: - Advice generation for CA from FT and Security Transfer
*ADO - 9634277
*                              Attached to DE.MAPPING >998.FM.1

**************
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
$INSERT I_F.CUSTOMER
$INSERT I_F.SEC.ACC.MASTER
$INSERT I_F.SCB.L.CAPE.CA.REF
$INSERT I_F.SECURITY.TRANSFER
$INSERT I_F.SECURITY.MASTER
$INSERT I_F.SCB.WM.H.LOCAL.PARAM
$INSERT I_F.SCB.CAPE.EVENT.PARAM
$INSERT I_F.SUB.ASSET.TYPE
$INSERT I_F.ASSET.TYPE
$INSERT I_F.FUNDS.TRANSFER


GOSUB INIT
GOSUB PROCESS
GOSUB UPDATE.USR.DEF.VALUE
RETURN
*****************
INIT:
  FnClientOutputParam= 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    FClientOutputParam = ''
    CALL OPF(FnClientOutputParam,FClientOutputParam)
*
    FnSecAccMaster = 'F.SEC.ACC.MASTER'
    FvSecAccMaster = ''
    CALL OPF(FnSecAccMaster,FvSecAccMaster)

   FnSecMaster = "F.SECURITY.MASTER"
   FvSecMaster = ""
  CALL OPF(FnSecMaster,FvSecMaster )

    fnSecurityTransfer = "F.SECURITY.TRANSFER"
    fvSecurityTransfer = ""
    CALL OPF(fnSecurityTransfer,fvSecurityTransfer)
    
    fnScbLCapeCaref = "F.SCB.L.CAPE.CA.REF"
   fvScbLCapeCaref = ""
    CALL OPF(fnScbLCapeCaref ,fvScbLCapeCaref )

   fnScbCapeEventParam = "F.SCB.CAPE.EVENT.PARAM"
  fvScbCapeEventParam = ""
   CALL OPF(fnScbCapeEventParam,fvScbCapeEventParam)


   fnScbWmHLocalParam = "F.SCB.WM.H.LOCAL.PARAM"
   fvScbWmHLocalParam = ""
   CALL OPF(fnScbWmHLocalParam ,fvScbWmHLocalParam)

   fnFundsTransfer = "F.FUNDS.TRANSFER"
    fvFundsTransfer = ""
    CALL OPF(fnFundsTransfer,fvFundsTransfer)

   fnFundsTransferHis = "F.FUNDS.TRANSFER$HIS"
    fvFundsTransferHis = ""
    CALL OPF(fnFundsTransferHis,fvFundsTransferHis)


  fnSat = "F.SUB.ASSET.TYPE"
   fvSat = ""
   CALL OPF(fnSat,fvSat)
    
   fnAssetCode= "F.ASSET.TYPE"
   fvAssetCode= ""
   CALL OPF(fnAssetCode,fvAssetCode)
    
    fnCustomer = "F.CUSTOMER"
    fvCustomer = ""
    CALL OPF(fnCustomer,fvCustomer)

    yParamId = 'SCB.CRES.SAT'
    CALL F.READ(fnScbWmHLocalParam ,yParamId,rLocalRec,fvScbWmHLocalParam,rLocalRecErr)
    IF NOT(rLocalRecErr) THEN      
        yProdCodes = rLocalRec<SCBWM.PRM.FIELD.VALUE>
        yProdNames= RAISE(rLocalRec<SCBWM.PRM.FIELD.NAME>)
      

 YAppName = 'CUSTOMER':@FM:'SECURITY.MASTER':@FM:'SECURITY.TRANSFER'
    YFldName = 'L.O.B':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.EBBS.REL':@FM:'LR.UTS.INS.DESC':@FM:"CAPE.EVENT.ID"
    YFldName:= @VM:"CAPE.EVENT.TYPE":@VM:"L.QUAL.HOLDING":@VM:"L.RATIO":@VM:"L.OPTION.NOM":@VM:"LWM.EX.DATE"
    YFldName:= @VM:"L.NEW.NOMINAL":@VM:"L.NEW.MKT.PRICE":@VM:"LR.SN.STRK.PERC":@VM:"LR.SN.KI.PERC"
    YFldName:= @VM:"LR.SN.KO.PERC":@VM:"L.SECU.PAY.DATE":@VM:"CA.EVENT.CLASS":@VM:"LR.FIXING.DATE":@VM:"LED.UNDER.NOM":@VM:'CA.EVENT.DESC':@VM:"LED.UNDER.ISIN"
    YFldName:= @VM:"LR.NO.OF.SHS"
    YFldPos  = ""
    CALL MULTI.GET.LOC.REF(YAppName,YFldName,YFldPos)
    YLobPos          = YFldPos<1,1>
    YStfPos          = YFldPos<1,2>
    YPfolPos         = YFldPos<1,3>
    YEbbsRelIdpos    = YFldPos<1,4>
    YUtsPos          = YFldPos<2,1>
      yCapeEventPos = YFldPos<3,1>
    yCapeEventTypePos = YFldPos<3,2> 
  
    yQualHoldPos = YFldPos<3,3>
    
    yRatioPos = YFldPos<3,4>
    yLOptionNomPos = YFldPos<3,5> 
    yLExDatePos = YFldPos<3,6> 
    yNewNominalPos = YFldPos<3,7>
    yNewMktPricePos = YFldPos<3,8>
    ySnStrikePerPos =YFldPos<3,9>
    ySnKnockInPos =YFldPos<3,10>
    ySnKnockOutPos =  YFldPos<3,11>
    ySecPayDatePos = YFldPos<3,12>
    yCaEventClsPos = YFldPos<3,13>
    yLrFixingDatePos = YFldPos<3,14>
    yLedUnderNomPos = YFldPos<3,15>
    yStockCaDescPos = YFldPos<3,16>
    yLedUnderIsinPos = YFldPos<3,17>
    yNoSharesPos = YFldPos<3,18>
yTxnId = TRANS.REF.ID
IF CAPE.CA.REF.ID THEN 
yFtId = FIELD(CAPE.CA.REF.ID,'*',1)
yStId = FIELD(CAPE.CA.REF.ID,'*',2)
END 
CHANGE @SM TO @FM IN yTxnId
RETURN
***********************

PROCESS:

   CALL F.READ(fnSecurityTransfer,yTxnId<1>,rStRecord,fvSecurityTransfer,StError)
   CALL F.READ(fnFundsTransfer,yFtId,rFundsTransfer,fvFundsTransfer,ftErr)
ySettleCurrency = ""
ySettleAmt = '0.00'
IF NOT(rFundsTransfer) THEN

CALL EB.READ.HISTORY.REC(fvFundsTransferHis,yFtId,rFundsTransfer,ftErr)

END
ySettleCurrency = rFundsTransfer<FT.DEBIT.CURRENCY>
     ySettleAmt = rFundsTransfer<FT.DEBIT.AMOUNT>


********
    yPortfolioId = rStRecord<SC.STR.SECURITY.ACC>
     yCaEventId = rStRecord<SC.STR.LOCAL.REF,yCapeEventPos>
     yCaDesc = rStRecord<SC.STR.LOCAL.REF,yStockCaDescPos>
     yCapeEventType = rStRecord<SC.STR.LOCAL.REF,yCapeEventTypePos>
      yTransactionType = rStRecord<SC.STR.TRANSACTION.TYPE>
     ySecurityNo = rStRecord<SC.STR.SECURITY.NO>
     yValueDate = rStRecord<SC.STR.VALUE.DATE>
     yTradeDate = rStRecord<SC.STR.TRADE.DATE>
     ySecPrice = rStRecord<SC.STR.PRICE>
     yTotHoldings = rStRecord<SC.STR.LOCAL.REF,yQualHoldPos>
     yTradeCurrency = rStRecord<SC.STR.SECURITY.CCY>
     yGrossAmtSecCcy = rStRecord<SC.STR.GROSS.AMT.SEC.CCY>
    yLNomineeCode = rStRecord<SC.STR.NOMINEE.CODE>
    yNoNominalValue = rStRecord<SC.STR.NO.NOMINAL>
    yAccruedInterest = rStRecord<SC.STR.INTEREST.AMT>
      yRatio = rStRecord<SC.STR.LOCAL.REF,yRatioPos>
        yLOptionNominal = rStRecord<SC.STR.LOCAL.REF,yLOptionNomPos>
       yLExDate = rStRecord<SC.STR.LOCAL.REF,yLExDatePos>
      yPaymentDate = rStRecord<SC.STR.LOCAL.REF,ySecPayDatePos>
      yNewNominal = rStRecord<SC.STR.LOCAL.REF,yNewNominalPos>
     yNewMktPrice = rStRecord<SC.STR.LOCAL.REF,yNewMktPricePos>
     ySnStrikePerc = rStRecord<SC.STR.LOCAL.REF,ySnStrikePerPos>
     yKnockInPerc = rStRecord<SC.STR.LOCAL.REF,ySnKnockInPos>
     yKnockOutPerc = rStRecord<SC.STR.LOCAL.REF,ySnKnockOutPos>
     yCaEventClass = rStRecord<SC.STR.LOCAL.REF,yCaEventClsPos>
       yValuationDate = rStRecord<SC.STR.LOCAL.REF,yLrFixingDatePos>
       yLedUnderNom = rStRecord<SC.STR.LOCAL.REF,yLedUnderNomPos>
       yLedUnderISIN = rStRecord<SC.STR.LOCAL.REF,yLedUnderIsinPos>
       yNoShares = rStRecord<SC.STR.LOCAL.REF,yNoSharesPos>
        yRatioFirst = FIELD(yRatio,':',1)
    yNetAmt = yTotHoldings*yRatioFirst

     yTelNo = 'TNO'
     yLending = 'No'
    IF yLNomineeCode EQ 1 THEN
     yLending = 'Yes'
    END 
  **********************************  
GOSUB READ.SM.DETS 

       IF yCapeEventType EQ 'SECURITY.SWITCH' OR yCapeEventType EQ 'MERGER' THEN
  
  IF yTransactionType EQ 'TRI' THEN
    yNewAssetName = YAssetName
    yNewSecIsin = Y.ISIN
    ySatCode = Y.SAT
    yNewLending = yLending
    yNewTradeDate = yTradeDate
    yNewFundCurrency = Y.SM.CURRENCY
    yNominal = yNoNominalValue
    yRatio = yRatio
    yNominalAmt = yNetAmt
    yNewAssetType = yProdType
    yPrincipalAmt = yNoNominalValue
    yNewMktPrice = yNewMktPrice
    yAcrInt = yAccruedInterest
    
IF yNewMktPrice EQ "" THEN
yNewMktPrice = yLastPrice
END
    yNewAssetValue = yTotHoldings * yNewMktPrice 
  CALL F.READ(fnSecurityTransfer,yTxnId<2>,rStRecord,fvSecurityTransfer,StError)
     ySecurityNo = rStRecord<SC.STR.SECURITY.NO>
     GOSUB READ.SM.DETS
     yDealingDate = rStRecord<SC.STR.VALUE.DATE>
     yTradeDate = rStRecord<SC.STR.TRADE.DATE>
     yAssetName = YAssetName
     ySecIsin = Y.ISIN
     yProductTypeVal = yProdType
     IF rStRecord<SC.STR.NOMINEE.CODE> EQ '1' THEN
    yLending = 'Yes'
    END ELSE
     yLending = 'No'
     END
      yFundCurrency = Y.SM.CURRENCY
     yUnits = rStRecord<SC.STR.LOCAL.REF,yLOptionNomPos>
     IF yCapeEventType EQ 'MERGER' THEN
       
       yUnits = rStRecord<SC.STR.LOCAL.REF,yQualHoldPos>
       yAssetValue = yUnits * yLastPrice
     END
   END 
IF yTransactionType EQ 'TRO' THEN
    yAssetName = YAssetName
    ySecIsin = Y.ISIN
    yProductTypeVal = yProdType
    yLending = yLending
    yDealingDate = yValueDate
    yTradeDate = yTradeDate
    yFundCurrency = Y.SM.CURRENCY
    yUnits =  yLOptionNominal
   IF yCapeEventType EQ 'MERGER' THEN
       yUnits = yTotHoldings
       yAssetValue = yUnits * yLastPrice 
     END

 CALL F.READ(fnSecurityTransfer,yTxnId<2>,rStRecord,fvSecurityTransfer,StError)
  yTransactionType = rStRecord<SC.STR.TRANSACTION.TYPE>
  yNewMktPrice = ""
yNoNominalValue = ""
yNewAssetName = ""
yNewSecIsin = ""
ySatCode = ""
yNewLending = ""
yNewTradeDate = ""
yNewFundCurrency = ""
yNominal = ""
yRatio = ""
yNominalAmt = ""
yPrincipalAmt = ""
yNewAssetValue = ""
yNewAssetType = ""
yAcrInt = ""

  IF yTransactionType EQ 'TRI' THEN
  ySecurityNo = rStRecord<SC.STR.SECURITY.NO>
yNewMktPrice = rStRecord<SC.STR.LOCAL.REF,yNewMktPricePos>
IF yNewMktPrice EQ "" THEN
yNewMktPrice = yLastPrice
END
yNoNominalValue = rStRecord<SC.STR.NO.NOMINAL>
     GOSUB READ.SM.DETS
   yNewAssetName = YAssetName
    yNewSecIsin = Y.ISIN
    ySatCode = Y.SAT
    IF rStRecord<SC.STR.NOMINEE.CODE> EQ '1' THEN
    yNewLending = 'Yes'
    END ELSE
     yNewLending = 'No'
  END
    yNewTradeDate = rStRecord<SC.STR.TRADE.DATE>
    yNewFundCurrency = Y.SM.CURRENCY
    yNominal = rStRecord<SC.STR.NO.NOMINAL>
     yAcrInt = rStRecord<SC.STR.INTEREST.AMT>
    yRatio = rStRecord<SC.STR.LOCAL.REF,yRatioPos>
    yRatioFirst = FIELD(yRatio,':',1)
    yNominalAmt = yTotHoldings*yRatioFirst
    yPrincipalAmt = yNoNominalValue
    yNewAssetValue = yNoNominalValue * yNewMktPrice
END
END
     END
**********************
RETURN
*********************************
*******************

READ.SM.DETS:
***********************************
 CALL F.READ(FnSecMaster,ySecurityNo,RSecurityMaster,FvSecMaster,YSecErr)
    Y.SM.DESCRIPTION  = RSecurityMaster<SC.SCM.DESCRIPT>
    YSmNewDescription = RSecurityMaster<SC.SCM.LOCAL.REF,YUtsPos>
    
    yLastPrice = RSecurityMaster<SC.SCM.LAST.PRICE>
    ySmDate = RSecurityMaster<SC.SCM.ACCRUAL.START.DATE>
       IF ySmDate THEN
    GOSUB DATE.FORMAT 
     yAccrualStartDt = returnDate
     END
     ySmDate = ""
     
      ySmDate = RSecurityMaster<SC.SCM.INT.PAYMENT.DATE>
      IF ySmDate THEN
      GOSUB DATE.FORMAT
       yIntPymtDt  = returnDate
     END
    Y.SAT = RSecurityMaster<SC.SCM.SUB.ASSET.TYPE>
  yProdType = ""
     FINDSTR Y.SAT IN yProdCodes SETTING fmPos,vmPos,smPos THEN
     yProdType = yProdNames<vmPos>
     BEGIN CASE
    CASE yProdType EQ 'MF'
         yProdType = 'Funds'
    CASE yProdType EQ 'SN'
         yProdType = "Structured Products"
    CASE yProdType EQ 'FI'
      yProdType = 'Fixed Income'
    END CASE
     END
      Y.ISIN      = RSecurityMaster<SC.SCM.I.S.I.N.>
    YInvestType = RSecurityMaster<SC.SCM.INVEST.OPTION.TYPE>
 
*

 yIssuerName = RSecurityMaster<SC.SCM.ISSUER.NAME>
    yIssuePrice = RSecurityMaster<SC.SCM.ISSUE.PRICE>
    yIssueDate = RSecurityMaster<SC.SCM.ISSUE.DATE>
    yMatDate = RSecurityMaster<SC.SCM.MATURITY.DATE>
    Y.SM.CURRENCY = RSecurityMaster<SC.SCM.SECURITY.CURRENCY>
    yUnderlyingDesc = CHANGE(RSecurityMaster<SC.SCM.UNDERLYING.DESCRIPTION>,@VM,"|")
               ySmMarketIdentifier = CHANGE(RSecurityMaster<SC.SCM.MARKET.IDENTIFIER>,@VM,@FM)
yMarketShares = ""
LOCATE yLedUnderISIN IN ySmMarketIdentifier SETTING marketPos THEN
    yMarketShares = RSecurityMaster<SC.SCM.UNDERLYING.DESCRIPTION,marketPos>
END
    ySpotPrice = CHANGE(RSecurityMaster<SC.SCM.SPOT.PRICE>,@VM,"|")
    yStrikePrice = CHANGE(RSecurityMaster<SC.SCM.STRIKE.PRICE>,@VM,"|")
    yPriceBarrierType = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE>
     yNotePriceBarrier= RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER>
     yIssuer = CHANGE(RSecurityMaster<SC.SCM.ISSUER>,@VM,"|")
    yKnockInOutDataCnt = DCOUNT(yPriceBarrierType,@SM)
yKnockInPrice = ""
yKnockOutPrice = ""
 yUnderlyingCnt = DCOUNT(yUnderlyingDesc,"|")
FOR I = 1 TO yUnderlyingCnt
yPriceBarrierType = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,I>
yNotePriceBarrier= RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER,I>

     FINDSTR "KNOCK.IN" IN yPriceBarrierType SETTING fmPos,vmPos,smPos THEN
     yKnockInPrice<-1> = yNotePriceBarrier<1,vmPos,smPos>
     END
     FINDSTR "KNOCK.OUT" IN yPriceBarrierType SETTING fmPos,vmPos,smPos THEN
     yKnockOutPrice<-1> = yNotePriceBarrier<1,vmPos,smPos>
     END
NEXT I 
    CHANGE @FM TO "|" IN yKnockInPrice
    CHANGE @FM TO "|" IN yKnockOutPrice
**************************************To be concluded
    


*****************************

** Logic to get the Product Group
  *  CALL SCB.GET.PRODUCT.API(Y.SECURITY.NO, ProductGrp) ;* Get the Product Type FI SN or Funds
    
    GOSUB GET.SM.DESC
    yLCapeCaRefId = yCaEventId:'*':yPortfolioId   ;*to read the Live template SCB.L.CAPE.CA.REF

       yCustomerId = FIELD(yPortfolioId,'-',1)

 CALL F.READ(fnCustomer ,yCustomerId,rCustomer,fvCustomer,CUST.ERR)
    L.O.B = rCustomer<EB.CUS.LOCAL.REF,YLobPos>
    LR.PFOLIO.KEY.VAL = rCustomer<EB.CUS.LOCAL.REF,YPfolPos>
    PriAcctHolder = FIELD(LR.PFOLIO.KEY.VAL,':',1)
    JntHolder = LR.PFOLIO.KEY.VAL
    CHANGE ':' TO '|' IN JntHolder
* As per the new logic for cleint Identifier provided as on 20220208
    STAFF.IND = rCustomer<EB.CUS.LOCAL.REF,YStfPos>
*
    BEGIN CASE
        CASE rCustomer<EB.CUS.SECTOR> EQ "21"
            yClientIdentifier = "SG.RETAIL"
        CASE rCustomer<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
            yClientIdentifier = "SG.RETAIL"
        CASE rCustomer<EB.CUS.SECTOR> EQ "23"
            yClientIdentifier = "SG.RET.CB.BB"
    END CASE
  CALL F.READ(FnSecAccMaster,yPortfolioId,rSecAccMaster,FvSecAccMaster,errorSecAcc)
   yAdviceIndex = rSecAccMaster<SC.SAM.ADVICE.INDEX>

    GOSUB READ.LIVE.REF.TABLE

    yDescName = Y.DESC.NAME
      IF rCapeEventParam NE '' THEN
        
        BEGIN CASE
            CASE ProductGrpValue EQ 'FIXEDINCOME'
                YAssetName = yDescName
            CASE  ProductGrpValue EQ 'FUNDS'
                GOSUB GET.FUND.VALUE
            CASE  ProductGrpValue EQ 'STRUCTUREDPRODUCTS'
                YAssetName = yDescName
        END CASE
    END 
RETURN
***************************************
DATE.FORMAT:
returnDate = ""
CALL DIETER.DATE(ySmDate,returnDate,'D')

RETURN
*********************
GET.SM.DESC:
*----------
** Logic to form the Asset Name
    IF YSmNewDescription THEN
        Y.DESC.NAME = YSmNewDescription
    END ELSE
    Y.DESC.NAME = Y.SM.DESCRIPTION
    END
    CHANGE @SM TO '' IN Y.DESC.NAME

*
RETURN
**************************
GET.FUND.VALUE:
*--------------*
    IF YInvestType NE '' THEN
        YInvestOption = 'INVEST.OPTION'
        CALL F.READ(FnClientOutputParam,YInvestOption,RInvestLocalParam,FClientOutputParam,YInvestErr)
        InvestFieldName = RInvestLocalParam<SC.CO.FIELD.NAME>
        LOCATE YInvestType IN InvestFieldName<1,1> SETTING YInvestPos THEN
            YDepoAsset = RInvestLocalParam<SC.CO.FIELD.SUB.VALUE,YInvestPos>
        END
    END
*
    IF YDepoAsset NE '' THEN
        YAssetName = yDescName:' ':YDepoAsset
    END ELSE
        YAssetName = yDescName
    END

RETURN
*************************
READ.LIVE.REF.TABLE:

CALL F.READ(fnScbLCapeCaref,yLCapeCaRefId,rLCapeCaRec,fvScbLCapeCaref,errorLCape)

IF rLCapeCaRec THEN
yCapeEventDets = rLCapeCaRec<SCBCA.CAPE.EVENT.DETS>
yRecStatus = rLCapeCaRec<SCBCA.EVENT.STATUS>
IF yRecStatus EQ 'AUTH' ELSE RETURN
CALL F.READ(fnScbCapeEventParam,yCapeEventDets,rCapeEventParam,fvScbCapeEventParam,errorCapeEventParam)
IF rCapeEventParam THEN
yClientOutputParamId = rCapeEventParam<SCBCE.CLIENT.PARAM.ID>

GOSUB GET.ADVICE.FIELD.VALUE
END
END
RETURN

**********************************
*********************************************

GET.ADVICE.FIELD.VALUE:

   ProductGrpValue = FIELD(yClientOutputParamId,'-',2)

 CALL F.READ(FnClientOutputParam,yClientOutputParamId,RClientOutputParam,FClientOutputParam,YAdviceErr)
    EventTypeArr = RClientOutputParam<SC.CO.EVENT.TYPE>
    CHANGE @VM TO @FM IN EventTypeArr
    LOCATE yRecStatus IN EventTypeArr SETTING AdvPos THEN
        AdviceId      = RClientOutputParam<SC.CO.ADVICE.ID,AdvPos>
        ConsolId      = RClientOutputParam<SC.CO.CONSOL.ID,AdvPos>
        DisclaimerId  = RClientOutputParam<SC.CO.DISCLAMIER.ID,AdvPos>
        ConfNotice    = RClientOutputParam<SC.CO.CONFIRMATION.NOTICE,AdvPos>
        DelMode       = RClientOutputParam<SC.CO.DELIVERY.MODE,AdvPos>
    END
    CALL SCB.CLIENTIDEN.R2WFOLD.RTN(yClientIdentifier,R2wFolder)
RETURN



****************************************
UPDATE.USR.DEF.VALUE:


HANDOFF.REC(9)<1> = "" 
HANDOFF.REC(9)<2> = yAdviceIndex 
HANDOFF.REC(9)<3> = TODAY
     HANDOFF.REC(9)<4> = AdviceId
 HANDOFF.REC(9)<6> = YAssetName
   HANDOFF.REC(9)<8> = yClientIdentifier
    
    HANDOFF.REC(9)<9> = ConfNotice
    HANDOFF.REC(9)<10> = ConsolId

 HANDOFF.REC(9)<16> =  DisclaimerId 
HANDOFF.REC(9)<21> = Y.ISIN
 HANDOFF.REC(9)<32> = yLending
 HANDOFF.REC(9)<34> = yNetAmt
 HANDOFF.REC(9)<43> =yLOptionNominal  ; *Nominal

HANDOFF.REC(9)<49> = JntHolder
HANDOFF.REC(9)<50> = yPortfolioId 
HANDOFF.REC(9)<52> = PriAcctHolder
HANDOFF.REC(9)<53> = yTotHoldings
HANDOFF.REC(9)<54> = yProdType
HANDOFF.REC(9)<56> = R2wFolder
HANDOFF.REC(9)<57> = yRatio   ;*rate
*HANDOFF.REC(9)<58> = yRatio 
HANDOFF.REC(9)<68> = 'TNO'

HANDOFF.REC(9)<70> = Y.SM.CURRENCY
 HANDOFF.REC(9)<72> = yCaEventId   ;*yTxnId
HANDOFF.REC(9)<73> = yCapeEventType
IF yCapeEventType EQ 'STOCK.DIV' THEN
 HANDOFF.REC(9)<43> = yNoNominalValue
 HANDOFF.REC(9)<51> = FIELD(yRatio,":",2)

HANDOFF.REC(9)<57> = yRatioFirst
HANDOFF.REC(9)<73> = 'DIV REINV'
END
HANDOFF.REC(9)<77> = yValueDate

********************************************
 BEGIN CASE

         CASE yCapeEventType EQ 'STOCK.SPLIT'
    
            HANDOFF.REC(9)<18> = yLExDate
            
            
            HANDOFF.REC(9)<34> = ""  ;*net amt
             HANDOFF.REC(9)<43> = ""  ;*nominal
             HANDOFF.REC(9)<47> = yPaymentDate
            HANDOFF.REC(9)<51> = ""   ;*price
            HANDOFF.REC(9)<57> = ""  ;*rate
            HANDOFF.REC(9)<58> = yRatio
            HANDOFF.REC(9)<70> = ""
            HANDOFF.REC(9)<73> = 'STOCK SPLIT'

            HANDOFF.REC(9)<75> = yTotHoldings
            HANDOFF.REC(9)<77> = "" ;*Vlaue date 

        CASE yCapeEventType EQ 'MERGER'
        HANDOFF.REC(9)<6> = yAssetName
            HANDOFF.REC(9)<7> = yAssetValue ;*asset value
                HANDOFF.REC(9)<17> = yPaymentDate ;*effective date
             HANDOFF.REC(9)<18> = yLExDate 
HANDOFF.REC(9)<21> = ySecIsin
               HANDOFF.REC(9)<23> = yTotHoldings
                HANDOFF.REC(9)<34> = ""  ;*net amt
               HANDOFF.REC(9)<35> = yNewAssetName   ;*new asset name
                 HANDOFF.REC(9)<36> = yNewAssetType
             HANDOFF.REC(9)<37> = yNewAssetValue 
                HANDOFF.REC(9)<38> = yNewFundCurrency
                HANDOFF.REC(9)<39> = yNewLending
                 
         HANDOFF.REC(9)<40> = yNewMktPrice 
                        HANDOFF.REC(9)<41> = yNewSecIsin
                 HANDOFF.REC(9)<47> = yPaymentDate
               HANDOFF.REC(9)<51> = yLastPrice 
HANDOFF.REC(9)<53> = yPrincipalAmt
               HANDOFF.REC(9)<57> = ""  ;*rate
               HANDOFF.REC(9)<43> = ""  ;*nominal
HANDOFF.REC(9)<70> = yFundCurrency
             HANDOFF.REC(9)<75> = yUnits
              HANDOFF.REC(9)<77> = "" ;*Vlaue date

 
************************
        CASE yCapeEventType EQ 'SECURITY.SWITCH'

 CALL F.READ(fnSat,ySatCode,recSat,fvSat,satError)

      yAssetTypeCode = recSat<SC.CSG.ASSET.TYPE.CODE>
CALL F.READ(fnAssetCode,yAssetTypeCode,rAssetType,fvAssetCode,assetErr)
yAssetDescription = rAssetType<SC.ASS.ASSET.DESC,1>

       HANDOFF.REC(9)<1> = yAcrInt
     HANDOFF.REC(9)<5> = yAssetDescription    ;*asset desc
HANDOFF.REC(9)<6> = yAssetName
  HANDOFF.REC(9)<14> = yFundCurrency   ;*security currency
   HANDOFF.REC(9)<15> = yDealingDate  ;* DEALING DATE

       HANDOFF.REC(9)<21> = ySecIsin
HANDOFF.REC(9)<32> = yLending
 HANDOFF.REC(9)<34> = "" ;*net amt
 HANDOFF.REC(9)<35> = yNewAssetName
HANDOFF.REC(9)<36> =yNewAssetType
  HANDOFF.REC(9)<38> = yNewFundCurrency
		  	HANDOFF.REC(9)<39> = yNewLending 	
         HANDOFF.REC(9)<41> = yNewSecIsin
           HANDOFF.REC(9)<42> = yNewTradeDate
            
		HANDOFF.REC(9)<43> = yNominal ;*nominal
                   HANDOFF.REC(9)<44> = ySettleAmt   ;*nominal amt
              HANDOFF.REC(9)<45> =yLOptionNominal   ;*NO.UNITS 
	HANDOFF.REC(9)<46> = ""  ;*other charges
          HANDOFF.REC(9)<53> = "0.00"  ;* Pricnipal amt
          HANDOFF.REC(9)<51> = '' ;*price 
         HANDOFF.REC(9)<57> = ""  ;*rate
          HANDOFF.REC(9)<58> = yRatio 
HANDOFF.REC(9)<62> = ySettleCurrency ;*settle acct currencu
HANDOFF.REC(9)<63> = '0.00'  ;*settle amt
HANDOFF.REC(9)<71> = yTradeDate
HANDOFF.REC(9)<73> = 'SECURITY SWITCH'
HANDOFF.REC(9)<75> = yUnits
IF yCaDesc EQ 'CONVERSION' OR yCaDesc EQ 'SECURITIES.WRITE.DOWN' THEN
      HANDOFF.REC(9)<14> = yTradeCurrency 
HANDOFF.REC(9)<20> = yGrossAmtSecCcy
        HANDOFF.REC(9)<51> = ySecPrice  ;*price
      HANDOFF.REC(9)<62> = ""
       HANDOFF.REC(9)<63> = '0.00' ;*settle amt 

HANDOFF.REC(9)<73> = 'EXT TRANSF OUT'
END
       HANDOFF.REC(9)<65> = ""  ;*STAMP DUTY
 HANDOFF.REC(9)<70> = Y.SM.CURRENCY
 HANDOFF.REC(9)<71> = yValueDate  ;*Trade date
  HANDOFF.REC(9)<75> =yLOptionNominal   ;*Units
 HANDOFF.REC(9)<77> = ""  ;*value date

 CASE yCapeEventType EQ 'REDEMPTION' AND yCaDesc EQ 'MATURITY.IN.SHARES'

selCmdIsin = "SELECT ":FnSecMaster:" WITH I.S.I.N. EQ ":yLedUnderISIN:" BY.DSND DATE.TIME"
selListIsin = ""
CALL EB.READLIST(selCmdIsin,selListIsin,"",NoRecords,stErr)

  CALL F.READ(FnSecMaster,selListIsin<1>,RSecurityMaster,FvSecMaster,YSecErr)
    yDescriptionName  = RSecurityMaster<SC.SCM.SHORT.NAME,1>


     HANDOFF.REC(9)<14> =  yTradeCurrency
            HANDOFF.REC(9)<22> = yIssueDate
            HANDOFF.REC(9)<23> = yIssuePrice
        HANDOFF.REC(9)<24> = yIssuerName
       HANDOFF.REC(9)<25> = yIssueDate
         HANDOFF.REC(9)<26> =yIssuerName 
         HANDOFF.REC(9)<27> = yIssuePrice

         HANDOFF.REC(9)<28> =yKnockInPerc 
         HANDOFF.REC(9)<29> = yKnockInPrice

         HANDOFF.REC(9)<30> =yKnockOutPerc 
         HANDOFF.REC(9)<31> = yKnockOutPrice
         HANDOFF.REC(9)<33> = yMatDate 
    HANDOFF.REC(9)<34> = ""   ;*NET AMT
    HANDOFF.REC(9)<44> = yLOptionNominal  ;*NOMINAL AMT 
     HANDOFF.REC(9)<45> = yNoShares  ;*noUnits
HANDOFF.REC(9)<51> = ""  ;*price 
HANDOFF.REC(9)<43> = "" ;*nominal
HANDOFF.REC(9)<57> = ""  ;*rate
HANDOFF.REC(9)<60> = ySpotPrice
HANDOFF.REC(9)<62> = ySettleCurrency ;*settle acct currencu
HANDOFF.REC(9)<63> = ySettleAmt  ;*settle amt
HANDOFF.REC(9)<64> =  yDescriptionName  ;*shares
HANDOFF.REC(9)<66> = ySnStrikePerc
HANDOFF.REC(9)<67> = yStrikePrice 
 HANDOFF.REC(9)<70> = ""  ;*Trade ccy
HANDOFF.REC(9)<76> = yValuationDate
 HANDOFF.REC(9)<74> = yUnderlyingDesc 

 HANDOFF.REC(9)<77> = ""  ;*value date
           	END CASE		
***********************************************
*
*****************************************************

*
   
    RETURN
***********************************************************
END


