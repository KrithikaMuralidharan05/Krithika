$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ICM.SAM.MIGDET.POST
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-22772 - JEWEL_T24_PROJECT
* Developed By                   :       Revathi G
* Developed On                   :       5thMay2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is a post routine to merge and generate final file which
* extract details of SAM with LR.POS.MIG.DT EQ TODAY for ICM
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES

    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    L.WORK.DATE=R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.FINAL.ID = 'SAM.UPDATE':'.csv'

    Y.UDFILE       = 'AMEX.FILES'
    Y.ST.CRITERIA  = 'SG.SAM.UPDATE.':TODAY:'-*'
    Y.FILE.ARRAY = ''
    Y.FILE.ARRAY = "T24 Portfolio Id":",":"T24 Customer ID":",":"Rel ID(primary)":",":"Rel ID Secondary1":",":"Rel ID Secondary2":",":"Rel ID Secondary3":",":"Rel ID Secondary4":",":"Mailing Type":",":"ISA Consol Flag":",":"Open Date":",":"Product Code":",":"System Name":",":"Product Name"

    SEL.FILE.ID    = ''
    Y.ST.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.CRITERIA, SEL.FILE.ID, Y.ST.CNT)

    Y.DEL.FILE.ID = SEL.FILE.ID
    LOOP
        REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
    WHILE Y.FILE.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.SAM.REC,F.APPEND.FILES,APP.ERR)
        IF R.SAM.REC NE  '' THEN
            Y.FILE.ARRAY<-1> = R.SAM.REC
         END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
    REPEAT

    WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID 

RETURN
*****************
END