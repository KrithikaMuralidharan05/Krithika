$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EDM.FEE.CHRG.EXT.LOAD
*--------------------------------------------------------------------------------------------------------
* Modification History :- 
* 22/07/2022 - Shreekantha. G  - NEW - CPSGMIG-4971
* Description 	:	The routine is used to send the daily dump of Fees & Charges 
*					configured for MF Instrument to eDMP.
*
* 22/07/2022 - Shreekantha. G - CPSGMIG-4971 - Copy of the existing routine B.SCB.FEE.CHARGE.EXTRACT.LOAD
*
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SC.CHARGE.TAX.CALC.CREATE
	$INSERT I_F.FT.COMMISSION.TYPE
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_B.SCB.RB.EDM.FEE.CHRG.EXT.COMMON
	$INSERT I_TSA.COMMON
*	
	FN.SC.CHARGE.TAX = 'F.SC.CHARGE.TAX.CALC.CREATE'
	F.SC.CHARGE.TAX = ''
	CALL OPF(FN.SC.CHARGE.TAX,F.SC.CHARGE.TAX)
*	
	FN.FT.COMMISSION.TYPE = 'F.FT.COMMISSION.TYPE'
	F.FT.COMMISSION.TYPE = ''
	CALL OPF(FN.FT.COMMISSION.TYPE,F.FT.COMMISSION.TYPE)
*	
	FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.SCB.WM.H.LOCAL.PARAM = ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
*	
	FP.CHARGE.LIST = ''
	Y.FILE.NAME = 'T24.RB.EDM.TAX.CALC.':AGENT.NUMBER:'.csv'				;*CPSGMIG-4971-S/E
*	
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*	
	Y.PARAM.ID = 'RBFEES.TXN.TYPE'
*
	RETURN
*--------------------------------------------------------------------------------------------------------
END
*--------------------------------------------------------------------------------------------------------
