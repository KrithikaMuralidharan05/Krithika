* @ValidationCode : MjoxNjM0NTQyNjM5OklTTy04ODU5LTE6MTY3NTc4ODExNTIxNzoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 07 Feb 2023 22:11:55
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PROD.PRVIDR.LIST.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14082
* Developed By                   :       Senthil
* Developed On                   :       02-Feb-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* SELECT Routine to generate Extract file of Product Provide detail listing
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.PROD.PRVIDR.LIST.COMMON
*--------------------------------------------------------------------------------------------
    GOSUB INIT
    GOSUB SEL.PROCESS

RETURN
*--------------------------------------------------------------------------------------------
INIT:
*----
*    Y.SELECT.VAL = ''
    Y.SELECT.VAL = BATCH.DETAILS<3,1>
    CHANGE '*' TO ' ' IN Y.SELECT.VAL

* Get LOB Value by Segment
    Y.PARAM.ID	     = 'SCB.CUST.SEG'
    Y.ALLOW.SEG      = 'RET'
    Y.ALLOWED.LOB    = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    CHANGE @VM TO ' ' IN Y.ALLOWED.LOB

RETURN
*---------------------------------------------------------------------------------------------
SEL.PROCESS:
*----------*

    SEL.LIST = '' ; SEL.CNT = '' ; SEL.ERR = ''
    SEL.CMD  = "SELECT ":FN.CUSTOMER:" WITH L.O.B EQ ":Y.ALLOWED.LOB:" AND SECTOR EQ ":Y.SELECT.VAL
        
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN
*----------------------------------------------------------------------------------------------
END