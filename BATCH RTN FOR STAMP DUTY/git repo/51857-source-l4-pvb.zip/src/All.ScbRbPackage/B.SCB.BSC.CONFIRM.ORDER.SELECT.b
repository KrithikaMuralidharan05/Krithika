* @ValidationCode : MjoxNzU1NTkyNTkxOklTTy04ODU5LTE6MTY4MjQyNDA4NTQ3MjoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 25 Apr 2023 17:31:25
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.BSC.CONFIRM.ORDER.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17784
* Developed By                   :       1663000
* Developed On                   :       02-Feb-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* SELECT Routine to generate Extract file of BSR Confirmed Order Report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*--------------------------------------------------------------------------------------------
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename/Date Change
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.BSC.CONFIRM.ORDER.COMMON
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------

    GOSUB SEL.PROCESS

RETURN
*----------*
SEL.PROCESS:
*----------*
    
    Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)    ;*CPSGMIG-21498
    
* Get Subsequent YYYYMM
    Y.DIFF.VAL = BATCH.DETAILS<3,1>[2,5]
    Y.CUR.YR   = '' ; Y.CUR.YR  = Y.LWD[1,4]    ;*CPSGMIG-21498
    Y.CUR.MTH  = '' ; Y.CUR.MTH = Y.LWD[5,2]    ;*CPSGMIG-21498
    Y.CUR.MTH  = Y.CUR.MTH - Y.DIFF.VAL
    IF Y.CUR.MTH LE 0 THEN
        Y.CUR.MTH = 12 + Y.CUR.MTH
        Y.CUR.YR -= 1
    END
    IF LEN(Y.CUR.MTH) EQ 1 THEN Y.CUR.MTH = '0':Y.CUR.MTH
    
    Y.CALC.YYMM = '' ; Y.CALC.YYMM =  Y.CUR.YR : Y.CUR.MTH
   
* Select ALL Day records for the requested Previous month
    SEL.LIST = '' ; SEL.CNT = '' ; SEL.ERR = ''
    SEL.CMD  = 'SELECT ':FN.SCB.SEC.TRADES.ALLDAY:' WITH @ID LIKE ':Y.CALC.YYMM:'...'
        
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    
RETURN
END