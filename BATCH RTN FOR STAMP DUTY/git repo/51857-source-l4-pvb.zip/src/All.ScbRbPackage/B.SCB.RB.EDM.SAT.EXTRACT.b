$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-56</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.SAT.EXTRACT
*******************************************************************************
* 12 Nov 2015 - FCC EDMP - Subramanian M
*             - This routine will generate the Sub Asset Type Dump in AMEX.FILES.
*******************************************************************************
*******************************************************************************
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
* 16-Jun-2022 - CPSGMIG-3789 - Shreekantha. G - Copy of the existing routine B.SCB.EDM.SAT.EXTRACT
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.DATES
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*******************************************************************************
INIT:
****
    FN.SUB.ASSET.TYPE = 'F.SUB.ASSET.TYPE'
    F.SUB.ASSET.TYPE = ''
    CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
*
*R20 UPG -S
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
    
    ARG1 = 'AMEX.FILES'
    ARG2= ''
    ARG3 =''
    CALL SCB.GET.ORACLE.FILENAME(ARG1, ARG2, ARG3)
    FW.AMEX.FILES = ARG3
*R20 UPG -E
*
   Y.HEADER = ''									;*CPSGMIG-3789 - Header									
    Y.FINAL.FILE.NAME = '' ; Y.COMP.NAME = ''
    R.SAT.RPT.ARR = '' ; Y.DESC = ''
**Headers** CPSGMIG-3789 - S
	DL = CHAR(01)
	Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)  
  	Y.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
   	Y.HEADER<-1> = 'D':DL:'ID':DL:'DESCRIPTION':DL:'SHORT_DESCRIPTION':DL:'ASSET_TYPE_CODE'
**Headers** CPSGMIG-3789 - E
*
    Y.COMP.NAME = ID.COMPANY[1,2]
    
    Y.FINAL.FILE.NAME = Y.COMP.NAME:"-RB-SAT-":TODAY:".CSV"				;*CPSGMIG-3789 - S/E
RETURN
*******************************************************************************
PROCESS:
********
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SUB.ASSET.TYPE
	TOTAL.LINE.COUNT = 0								;*CPSGMIG-3789 - TRAILER
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        LOOP
            REMOVE SAT.ID FROM SEL.LIST SETTING SEL.POS
        WHILE SAT.ID:SEL.POS
            R.SAT = '' ; SAT.ERR = ''
            CALL F.READ(FN.SUB.ASSET.TYPE,SAT.ID,R.SAT,F.SUB.ASSET.TYPE,SAT.ERR)
            IF R.SAT THEN
                GOSUB ADD.ARRAY
            END
	    TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + 1					;*CPSGMIG-3789 - TRAILER
        REPEAT
    END
    Y.FINAL.ARR = ''
    Y.FINAL.ARR = Y.HEADER:@FM:R.SAT.RPT.ARR
    Y.FINAL.ARR := @FM:'T':DL:TOTAL.LINE.COUNT						;*CPSGMIG-3789-TRAILER-S-E
*   Y.FINAL.ARR = R.SAT.RPT.ARR
    GOSUB WRITE.AMEX.FILE
*
RETURN
*******************************************************************************
ADD.ARRAY:
*********
    !   Y.DESC = R.SAT<SC.CSG.DESCRIPTION>
    !   CONVERT ',' TO '' IN Y.DESC
    IF R.SAT.RPT.ARR EQ '' THEN
        R.SAT.RPT.ARR = 'D':DL:SAT.ID:DL:R.SAT<SC.CSG.DESCRIPTION>:DL:R.SAT<SC.CSG.SHORT.DESCR>:DL:R.SAT<SC.CSG.ASSET.TYPE.CODE>
    END ELSE
        R.SAT.RPT.ARR<-1> = 'D':DL:SAT.ID:DL:R.SAT<SC.CSG.DESCRIPTION>:DL:R.SAT<SC.CSG.SHORT.DESCR>:DL:R.SAT<SC.CSG.ASSET.TYPE.CODE>
    END
RETURN
*******************************************************************************
WRITE.AMEX.FILE:
****************
*R20 UPG -S
	Y.FINAL.ARR = UTF8(Y.FINAL.ARR)
    CALL F.WRITE(FW.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FINAL.ARR)
*R20 UPG -E
RETURN
*******************************************************************************
END
