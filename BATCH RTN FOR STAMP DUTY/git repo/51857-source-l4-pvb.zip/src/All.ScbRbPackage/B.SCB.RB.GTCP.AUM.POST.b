$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.AUM.POST
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-AUM-XX-<start.date>-<end date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SC.POS.ASSET
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_B.SCB.RB.GTCP.AUM.COMMON
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
    Y.FINAL.FILE.NAME = ''
    R.GTCP.AUM.FINAL.ARR = ''
    Y.FINAL.FILE.NAME = 'MFU-T24-AUM-XX-':Y.START.DATE:'-':Y.END.DATE:'.csv'
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = ID.COMPANY[1,2]:'*-MFU-AUM-*':TODAY:'.txt*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.GTCP.AUM.FINAL.ARR EQ '' THEN
                R.GTCP.AUM.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.GTCP.AUM.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
		
		Y.AUM.HEADER  = 'client_id,client_name,ACCT_HOST_NUM,CUST_HOST_NUM,core_banking_rel_number_secondary_1,'
		Y.AUM.HEADER := 'core_banking_rel_number_secondary_2,core_banking_rel_number_secondary_3,INSTM_CURY_CD,'
		Y.AUM.HEADER := 'QTY,UPRC,NET_AMT,aum_amount_in_usd,ACCT_OPEN_DT,ACCT_CLSE_DT,PROD_CD,PROD_DESC,client_segment_code,'
		Y.AUM.HEADER := 'customer_segment_description,FUND_CD,FUND_NM,fund_currency,INSTM_TYPE,document_id,document_type,'
		Y.AUM.HEADER := 'ISIN_CODE,market,corebanking_account_number,EXCH_NM,instrument_id,instrument_name,ACCT_STS_CD,ISU_CTRY,'
		Y.AUM.HEADER := 'ssa_account_number,DATA_SRC_CTRY_CD,DATA_SRC_SYS_NM,W_SNAPSHOT_DT'

		R.GTCP.AUM.FINAL = Y.AUM.HEADER:@FM:R.GTCP.AUM.FINAL.ARR
		WRITE R.GTCP.AUM.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
    END
*
RETURN
*-----------------------------------------------------------------------------
END
