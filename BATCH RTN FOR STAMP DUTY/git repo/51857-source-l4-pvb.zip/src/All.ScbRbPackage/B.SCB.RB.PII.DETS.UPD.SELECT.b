$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PII.DETS.UPD.SELECT
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* ADO Ref				       CPSGMIG-12313
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.PII.DETS.UPD
* Workflow                     This Multi Thread Service will select the SCB.RSG.PARTY.DETAILS table with PII.DETAILS LIKE …FAILED…
*                              and look into the concat table SCB.RSG.EBBS.REL.CONCAT and update the correct value.
*
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        06/Nov/2023     TBD        Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_B.SCB.RB.PII.DETS.UPD.COMMON

	GOSUB PROCESS

	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********

	SEL.CMD = "SELECT ":FN.PARTY.DETS:" WITH PII.DETAILS LIKE ...FAILED..."
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',LIST.CNT,SEL.ERR)

	CALL BATCH.BUILD.LIST("",SEL.LIST)
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END