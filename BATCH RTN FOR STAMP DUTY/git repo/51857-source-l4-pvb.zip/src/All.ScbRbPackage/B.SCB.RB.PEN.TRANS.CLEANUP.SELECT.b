$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PEN.TRANS.CLEANUP.SELECT

*-------------------------------------------------------------------------------------------
* Developed By                   :   Mohammed Haris
* Developed On                   :   07-MAR-2024
* ADO Reference	                 :   7428259,7428290
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Select routine to remove to false portfolio and update the rejected transaction.
*--------------------------------------------------------------------------------------------
* Called From:  TSA.SERVICE>SNG/B.SCB.RB.PEN.TRANS.CLEANUP.ONETIME 
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*--------------------------------------------------------------------------------------------
*

******INSERT FILES**************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.PEN.TRANS.CLEANUP.COMMON

********************************

*****Selecting the records based on condition from SCB.RB.PENDING.TRANSACTION*****

    SelCmd="SELECT ":FnPendingTransaction:" WITH @ID NE ''"
    SelList=""
    NoOfRecords=""
    SelErr=""

    CALL EB.READLIST(SelCmd,SelList,'',NoOfRecords,SelErr)

***********************************************************************************

************Build The List to be used in main routine******************************
    IF SelList THEN
        CALL BATCH.BUILD.LIST('',SelList)
    END ELSE CALL OCOMO("NO Records available based on the above Selection")

***********************************************************************************
RETURN
END