$PACKAGE All.ScbRbPackage
* @ValidationCode : MjotMjYzMzI1MDkxOkNwMTI1MjoxNjAxMzY5NTM2NzEyOjE2MDEyNzQ6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxODA5LjE6LTE6LTE=
* @ValidationInfo : Timestamp         : 29 Sep 2020 14:22:16
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1601274
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201809.1
SUBROUTINE B.SCB.RB.RE.BLK.DEL.REJECT.ORDER(YId)
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*  Bharathiraja P    17-May-2022         CPSGMIG-565 Settle MF Trade: Cash Debit / Credit in Client's Account
*                                        CPSGMIG-3157 T24 Dev - EBBS Block creation / deletion
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.RE.BLK.DEL.REJECT.ORDER.COMMON
    $INSERT I_F.SCB.CASH.BLK.SETT
    $INSERT I_F.SEC.OPEN.ORDER
    
    
    RecScbCashBlkSet = '' ; ErScbCashBlkSet = ''
    CALL F.READ(FnBlkRej, YId, RecScbCashBlkSet, FBlkRej, ErScbCashBlkSet)
    IF NOT(ErScbCashBlkSet) THEN ;*Proceed to process only if the record exists
        GOSUB Process
    END
    
RETURN

*-----------------------------------------------------------------------------
*** <region name= Processy>:
Process:
*** <desc>update the record in SCB.CASH.BLK.SETT for orders in REJECTED status. </desc>
*-----------------------------------------------------------------------------
    RecSecOrder= '' ; ErSecOrder = ''
    CALL F.READ(FnSooBlkRej, YId, RecSecOrder, FSooBlkRej, ErSecOrder)
    IF (ErSecOrder) THEN ;*Read histroy rec
        RecSecOrder = '' ; ErSecOrder = '' 
        YHisId = YId
        CALL F.READ.HISTORY(FnSooBlkRejHis, YHisId, RecSecOrder, FSooBlkRejHis, ErSecOrder)    
        IF (ErSecOrder) THEN
            RETURN ;*Exit if order record does not exist.
        END
        
    END
    YDealStatus = ''
    YDealStatus = RecSecOrder<SC.SOO.DEAL.STATUS>
    
    IF YDealStatus = "REJECTED" THEN
        YBlockStatus = ''
        YBlockStatus = RecScbCashBlkSet<S.BLOCK.STATUS>
        RecScbCashBlkSet<S.SETT.STATUS>  = "CANCELLED"
        RecScbCashBlkSet<S.STATUS.DATE>  = TODAY
        
        
        BEGIN CASE
            CASE YBlockStatus = "TO_BE_BLOCKED"
                RecScbCashBlkSet<S.BLOCK.STATUS> = "CANCELLED"
                                              
            CASE YBlockStatus = "BLOCKED"
                RecScbCashBlkSet<S.BLOCK.STATUS> = "BLK_TO_BE_CLEARED"
        END CASE
        
        CALL F.WRITE(FnBlkRej, YId, RecScbCashBlkSet)
    END
    
RETURN

END
