$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.TRADE.DOMICILE.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14086 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       13 April 2023
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract the trade domicile details
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.B.TRADE.DOMICILE
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*28/04/2023		1667095			Update mapping for asset name and order type
*15/06/2023             1670271                 UT Trade domicile report-additional fields
*23/06/2023             1648769                 CPSGMIG-29355 - Changes;
*                                                 1. If SP>NOMINEE.CODE is 1 then default ESPD esle check SAM>LR.LIEN.CODE is value exist update else Check the 
*                                                 table SC.SCB.RB.BLOCK>selected portfolio record with SM and Depo combination.If record exist then pick the 
*                                                 value from SC.SCB.RB.BLOCK>LR.LIEN.CODE else LR.LIEN.CODE and LIEN remarks values should be left Blank.
*                                                 2. Lien Remarks, replace ',' to '' to not exceed to next columns.
*13/07/2023             1670271                   Update LR.CLOSING.ID & LR.REFERRAL.ID from SOO instaed of SEC.TRADE.
*                                                  Based on transaction code Settlement order ID and Settlement account number should be taken.
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SC.TRANS.TYPE
	$INSERT I_B.SCB.TRADE.DOMICILE.COMMON
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.DATES
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION
    
    Y.DATA = BATCH.DETAILS<3,1>  ;* Contains the file name
    CONVERT @SM TO @FM IN Y.DATA
    Y.MODE.DET  = FIELD(Y.DATA,'*', 1)   ;* Contain the value as Daily or Monthly
  
* Open files
    FN.SEC.TRADES.TODAY 		= 'F.SEC.TRADES.TODAY'     	; F.SEC.TRADES.TODAY  		= '' ; CALL OPF(FN.SEC.TRADES.TODAY,F.SEC.TRADES.TODAY)
    FN.SEC.TRADES.MDAY  		= 'F.SCB.SEC.TRADES.MDAY'  	; F.SEC.TRADES.MDAY   		= '' ; CALL OPF(FN.SEC.TRADES.MDAY,F.SEC.TRADES.MDAY)
    FN.CUSTOMER             	= 'F.CUSTOMER'              ; F.CUSTOMER             	= '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SEC.TRADE            	= 'F.SEC.TRADE'             ; F.SEC.TRADE            	= '' ; CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    FN.SECURITY.TRANSFER    	= 'F.SECURITY.TRANSFER'     ; F.SECURITY.TRANSFER    	= '' ; CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
    FN.SECURITY.TRANSFER.HIS 	= 'F.SECURITY.TRANSFER$HIS' ; F.SECURITY.TRANSFER.HIS	= '' ; CALL OPF(FN.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS)
    FN.SEC.TRADE.HIS         	= 'F.SEC.TRADE$HIS'         ; F.SEC.TRADE.HIS        	= '' ; CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)
    FN.SC.SCB.LIEN.CODE      	= 'F.SC.SCB.LIEN.CODE'      ; F.SC.SCB.LIEN.CODE      	= '' ; CALL OPF(FN.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE)
    FN.SECURITY.MASTER      	= 'F.SECURITY.MASTER'       ; F.SECURITY.MASTER      	= '' ; CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SEC.OPEN.ORDER        	= 'F.SEC.OPEN.ORDER'        ; F.SEC.OPEN.ORDER         	= '' ; CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    FN.SEC.OPEN.ORDER.HIS    	= 'F.SEC.OPEN.ORDER$HIS'    ; F.SEC.OPEN.ORDER.HIS     	= '' ; CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
    FN.SC.TRA.CODE 			 	= 'F.SC.TRA.CODE' 			; F.SC.TRA.CODE 			= '' ; CALL OPF(FN.SC.TRA.CODE,F.SC.TRA.CODE)
    FN.SC.TRANS.TYPE 		 	= 'F.SC.TRANS.TYPE' 		; F.SC.TRANS.TYPE 			= '' ; CALL OPF(FN.SC.TRANS.TYPE,F.SC.TRANS.TYPE)
    FN.SEC.REVERSAL.TODAY    	= 'F.SEC.REVERSAL.TODAY'    ; F.SEC.REVERSAL.TODAY     	= '' ; CALL OPF(FN.SEC.REVERSAL.TODAY,F.SEC.REVERSAL.TODAY)
    FN.SEC.ACC.MASTER 			= 'F.SEC.ACC.MASTER' 		; F.SEC.ACC.MASTER 			= '' ; CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    FN.SUB.ASSET.TYPE 			= 'F.SUB.ASSET.TYPE' 		; F.SUB.ASSET.TYPE 			= '' ; CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
    FN.SCB.WM.H.LOCAL.PARAM 	= 'F.SCB.WM.H.LOCAL.PARAM' 	; F.SCB.WM.H.LOCAL.PARAM 	= '' ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM, F.SCB.WM.H.LOCAL.PARAM)
    FN.SC.TRANS.NAME 			= 'F.SC.TRANS.NAME' 		; F.SC.TRANS.NAME 			= '' ; CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
    FN.SCB.SEC.TRADES.LDAY   	= 'F.SCB.SEC.TRADES.LDAY'   ; F.SCB.SEC.TRADES.LDAY   	= '' ; CALL OPF(FN.SCB.SEC.TRADES.LDAY,F.SCB.SEC.TRADES.LDAY)
    FN.SC.SCB.RB.BLOCK        = 'F.SC.SCB.RB.BLOCK'        ; F.SC.SCB.RB.BLOCK        = '' ; CALL OPF(FN.SC.SCB.RB.BLOCK,F.SC.SCB.RB.BLOCK)
    FN.SECURITY.POSITION      = 'F.SECURITY.POSITION'      ; F.SECURITY.POSITION      = '' ; CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)

    CALL SCB.GET.ORACLE.VIEWNAME(FN.SECURITY.POSITION,Y.VIEW.NAME)   ;* Get Security Position View Name
    
    R.SCB.H.LOCAL.PARAM = '' ; ERR.SCB.WM.H.LOCAL.PARAM = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,"SCB.CRES.SAT",R.SCB.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOCAL.PARAM)
    Y.ALLOWED.SEGMENT = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.ALLOWED.SAT.LIST  = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
*
    Y.SEG.POS = '' ; Y.SN.SAT.CODES = ''
    LOCATE "SN" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.SN.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.SN.SAT.CODES
    END
*
    Y.SEG.POS = ''; Y.FI.SAT.CODES = ''
    LOCATE "FI" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.FI.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.FI.SAT.CODES
    END
*
    Y.SEG.POS = '';Y.MF.SAT.CODES = ''
    LOCATE "MF" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.MF.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.MF.SAT.CODES
    END
    Y.APP.NAME  = 'CUSTOMER' :@FM: 'SEC.OPEN.ORDER' :@FM: 'SEC.ACC.MASTER' :@FM: 'SEC.TRADE' :@FM: 'SECURITY.TRANSFER':@FM:'SECURITY.MASTER'
    Y.FLD.NAME<1> = 'L.O.B':@VM:'LR.PP.CODE':@VM:'LR.SIGN.MANDATE':@VM:'LR.PFOLIO.KEY':@VM:'LR.EBBS.REL':@VM:'LR.STAFF.IND'
    Y.FLD.NAME<2> = 'LR.RM.DISC.PERC':@VM:'LR.RSP.REF':@VM:'LR.REFERRAL.ID':@VM:'LR.CLOSING.ID'
    Y.FLD.NAME<3> = 'LR.LIEN.CODE'
    Y.FLD.NAME<4> = 'LR.PAY.CASA.ACC':@VM:'LR.REC.CASA.ACC':@VM:'LR.CLOSING.ID':@VM:'LR.REC.CASA.CCY':@VM:'LR.PAY.CASA.CCY':@VM:'LR.NET.SAL.PERC':@VM:'LR.PAYMENT.TYPE':@VM:'LR.LEVERAGE.IND':@VM:'LR.REFERRAL.ID':@VM:'LWM.EDP.REF.NUM':@VM:'LR.OMF.REF.NO':@VM:'TAP.REF.NO'
    Y.FLD.NAME<5> = 'LR.PAYMENT.TYPE'
    Y.FLD.NAME<6> = 'LR.UTS.INS.DESC'
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
*Customer LRT
    Y.LOB.POS = Y.FLD.POS<1,1>
    Y.LR.PP.CODE.POS = Y.FLD.POS<1,2>
    Y.LR.SIGN.MANDATE.POS = Y.FLD.POS<1,3>
    Y.LR.PFOLIO.KEY.POS = Y.FLD.POS<1,4>
    Y.LR.EBBS.REL.POS = Y.FLD.POS<1,5>
    Y.LR.STAFF.IND.POS = Y.FLD.POS<1,6>
*SOO LRT
    Y.LR.RM.DISC.PERC.POS = Y.FLD.POS<2,1>
    Y.LR.RSP.REF.POS = Y.FLD.POS<2,2>
    Y.REFERRAL.ID.POS = Y.FLD.POS<2,3> 
    Y.LR.CLOSING.ID.POS.SO = Y.FLD.POS<2,4>
*SAM LRT
    Y.LR.LIEN.CODE.POS = Y.FLD.POS<3,1>
*Sec Trade LRT
    Y.LR.PAY.CASA.ACC.POS = Y.FLD.POS<4,1>
    Y.LR.REC.CASA.ACC.POS = Y.FLD.POS<4,2>
    Y.LR.CLOSING.ID.POS = Y.FLD.POS<4,3>
    Y.LR.REC.CASA.CCY.POS = Y.FLD.POS<4,4>
    Y.LR.PAY.CASA.CCY.POS = Y.FLD.POS<4,5>
    Y.LR.NET.SAL.PERC.POS = Y.FLD.POS<4,6>
    Y.SCT.LR.PYMT.TYPE.POS = Y.FLD.POS<4,7>
    Y.LR.LEVERAGE.IND.POS = Y.FLD.POS<4,8>
    Y.REFERAL.RM.POS = Y.FLD.POS<4,9>
    Y.LWM.EDP.REF.NUM.POS = Y.FLD.POS<4,10>
    Y.LR.OMF.REF.NO.POS   = Y.FLD.POS<4,11>
    Y.TAP.REF.NO.POS      = Y.FLD.POS<4,12>
* ST LRT
    Y.ST.LR.PYMT.TYPE.POS = Y.FLD.POS<5,1>
*SM LRT
    Y.LR.UTS.INS.DESC.POS = Y.FLD.POS<6,1>
    
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    
    Y.LAST.WORKING.DATE = R.DATES(EB.DAT.LAST.WORKING.DAY)
    IF Y.MODE.DET = 'D' THEN
        Y.TEMP.FILE.NAME = "SGTRADESDOMICILEDLY-":Y.LAST.WORKING.DATE:"-":SESSION.NO:".csv"
    END ELSE
        Y.TEMP.FILE.NAME = "SGTRADESDOMICILEMTH-":Y.LAST.WORKING.DATE:"-":SESSION.NO:".csv"
    END
	
RETURN
END
