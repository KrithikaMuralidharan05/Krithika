$PACKAGE All.ScbRbPackage
*
*Developed by: - Pawan kr(1668106)
*Jira ref:-CPSGMIG-5295
*Description:- Customer Status - A one time data extract from ICM for Individual client
* Implementation of All.ScbRbPackage.bScbRsgIcmCustStatus
*
* yIds(INOUT) :
*
SUBROUTINE B.SCB.RSG.ICM.CUST.STATUS(ICM.IDS)

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RSG.ICM.CUST.STATUS.COMMON
    $INSERT I_F.CUSTOMER
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM

    GOSUB INIT
    GOSUB PROCESS
    
RETURN
******************
INIT:
***************
    Y.REL.ID = ICM.IDS
    Y.FILE.ID = Y.SRC.FILE.NAME
    Y.FILE = Y.SRC.FILEPATH:"/":Y.FILE.ID
                
    Y.GREP.CMD = 'SH -c "grep ':Y.REL.ID:' ':Y.FILE:'"'
    EXECUTE Y.GREP.CMD CAPTURING Y.RESPONSE
    IF Y.RESPONSE EQ "" OR Y.RESPONSE[1,2] EQ 'gr' THEN
        Y.ARR.EXCP = Y.REL.ID:" |t24 Rel Id not found in ICM file"
        CALL OCOMO("Rel ids not found in icm file ":Y.REL.ID)
        GOSUB EXCEPWRITE
	END
    ELSE
        Y.FLAG.IDS = Y.RESPONSE
        CALL OCOMO(Y.FLAG.IDS:" String formed")
    END
 

   
RETURN
*****************
PROCESS:
*************

    FLAG.CNT =DCOUNT(Y.FLAG.IDS,@FM)
    CALL OCOMO(FLAG.CNT:" String combination formed for ":Y.REL.ID)
    ID.CNT =1
    LOOP
    WHILE ID.CNT LE FLAG.CNT

        Y.EBBS.REL.ID = ""
        Y.CUS.ID = ""
        Y.CUST.STATUS = ""
        EXCEP.FLAG = ""
        MIG.DT.FLAG =""

        Y.EBBS.REL.ID = TRIM(FIELD(Y.FLAG.IDS<ID.CNT>,"|",'2'),"",'A')
*
        Y.CUST.STATUS = TRIM(FIELD(Y.FLAG.IDS<ID.CNT>,"|",'3'),"",'A')
        IF Y.EBBS.REL.ID NE "" AND Y.EBBS.REL.ID EQ Y.REL.ID THEN  ;*Compare formed rel.id with t24 rel id
            CALL F.READ(FN.SCB.RSG.PARTD,Y.EBBS.REL.ID,R.SCB.RSG.PARTD,F.SCB.RSG.PARTD,ERR.SCB.RSG.PARTD)
            IF R.SCB.RSG.PARTD THEN
*
                CALL F.READ(FN.SSRER.CONCAT,Y.EBBS.REL.ID,R.SSRER.CONCAT,F.SSRER.CONCAT,SSRER.CON.ERR)
                IF R.SSRER.CONCAT THEN
                    Y.VM.CUS.ID = R.SSRER.CONCAT<1>
                    Y.VM.CUS.TYPE = R.SSRER.CONCAT<3>
                    CUS.CNT = DCOUNT(Y.VM.CUS.ID,@VM)
                    C.CNT =1
                    LOOP
                    WHILE C.CNT LE CUS.CNT
                        EXCEP.FLAG = ""
                        FULL.FLAG = ""
                        Y.CUS.ID = Y.VM.CUS.ID<1,C.CNT>
                        CALL F.READ(FN.CUS,Y.CUS.ID,R.CUS,F.CUS,CUS.ERROR)
						Y.LR.MIG.DT = R.CUS<EB.CUS.LOCAL.REF,Y.LR.MIG.DT.POS>
*
	
                        IF R.CUS THEN
                            Y.LR.EBBS.REL = R.CUS<EB.CUS.LOCAL.REF,Y.LR.EBBS.REL.POS>
                            CONVERT @SM TO @FM IN Y.LR.EBBS.REL
                            EBBS.CNT =DCOUNT(Y.LR.EBBS.REL,@FM)
                            LOCATE Y.EBBS.REL.ID IN Y.LR.EBBS.REL SETTING REL.POS ELSE
                                Y.ARR.EXCP<-1> = Y.EBBS.REL.ID:"|":Y.CUS.ID:"|Customer record not updated in LR.EBBS.REL field"
                                EXCEP.FLAG = '1'
                            END
                            IF BATCH.DETAILS<3,1,2> EQ "FULL" OR BATCH.DETAILS<3,1,2> EQ "Full" THEN
                                FULL.FLAG = 1
                                IF NOT(EXCEP.FLAG) THEN
                                
                                    Y.SCS.ARR =Y.EBBS.REL.ID:"|":Y.CUS.ID:"|":Y.CUST.STATUS
                                    GOSUB FILE.WRITE
                                END
                            END ;* end FOR BATCH DET FLAG CONDITION
                            ELSE

                                IF NOT(EXCEP.FLAG) AND Y.LR.MIG.DT EQ Y.PARAM.FLD.VAL THEN
                                    MIG.DT.FLAG = 1
                                    Y.SCS.ARR =Y.EBBS.REL.ID:"|":Y.CUS.ID:"|":Y.CUST.STATUS
                                    GOSUB FILE.WRITE
                            	END
                                END 			;*END FOR ELSE statment after batch details flag condition
*
                            END
*
                            ELSE
                                Y.ARR.EXCP<-1> = Y.EBBS.REL.ID:"|Rel Id and ST.SCB.RSG.EBBS.REL.CONCAT available but no Customer record "
                                EXCEP.FLAG = '1'
                    
                            END
           
                            C.CNT+=1
                        REPEAT

                        IF FULL.FLAG EQ '1' THEN
*
                            IF NOT(EXCEP.FLAG)  THEN
                                Y.SCS.ARR.PARTY =Y.EBBS.REL.ID:"|":Y.CUS.ID:"|":Y.CUST.STATUS
                                GOSUB FILE.PARTY.WRITE
                    		END
                        END
                        ELSE
                            IF NOT(EXCEP.FLAG) AND MIG.DT.FLAG THEN         ;* Y.LR.MIG.DT EQ Y.PARAM.FLD.VAL
                                Y.SCS.ARR.PARTY =Y.EBBS.REL.ID:"|":Y.CUS.ID:"|":Y.CUST.STATUS
                                GOSUB FILE.PARTY.WRITE
                            END
                        END
                        IF EXCEP.FLAG EQ '1' THEN
                            GOSUB EXCEPWRITE
                        END
                    END
                    ELSE
                        Y.ARR.EXCP = Y.EBBS.REL.ID:"|Rel Id Available  but no entry in ST.SCB.RSG.EBBS.REL.CONCAT"
                        EXCEP.FLAG = '1'
                        GOSUB EXCEPWRITE
                    END
        
                END
            END 		;*END for first if
            ELSE
                Y.ARR.EXCP = Y.REL.ID:"| t24 Rel Id not match with ICM rel id :|":Y.EBBS.REL.ID
                GOSUB EXCEPWRITE
            END
            ID.CNT+=1
        REPEAT

        RETURN
************
FILE.WRITE:
*
        WRITESEQ Y.SCS.ARR APPEND TO Y.SL.FILEPATH ELSE
            CALL OCOMO("UNABLE TO WRITE DMD LOAD FILE forICM status")
        END
        RETURN
**************
FILE.PARTY.WRITE:
*
        WRITESEQ Y.SCS.ARR.PARTY APPEND TO Y.PARTY.FILEPATH ELSE
            CALL OCOMO("UNABLE TO WRITE DMD LOAD FILE forICM status")
        END
        RETURN

************
EXCEPWRITE:
        WRITESEQ Y.ARR.EXCP APPEND TO Y.EXCP.FILEPATH ELSE
            CALL OCOMO("UNABLE TO WRITE Exception FILE for ICM status")
        END
        RETURN
**************
    END