$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SM.STL.PRC.RPT(YID)
*-----------------------------------------------------------------------------
* CPSGMIG-1552 Stale Price Report
*              To view price and date last price for active Structured Note instruments
*              To  identify the Structured Note instrument with stale or missing price
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 27/10/2022 - Swaminathan.S.R - OPENSEQ moved inside condition loop, to avoid Too many open files issue
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_F.SC.PRICE.CHANGE
    $INSERT I_B.SCB.SM.STL.PRC.RPT.COMMON
    
    GOSUB GET.STARTED
    GOSUB CHECK.PRICE.DATE
    IF STALE.PRICE.REP THEN
        GOSUB FORM.RET.ARRY
    END

RETURN

GET.STARTED:
**************
    STALE.PRICE.REP = ''          ;*Flag to set for reporting
*Get SM record from the selected SN Ids
    R.SECURITY.MASTER = ''
    YERR = ''
    SECURITY.MASTER.ID = YID
    CALL F.READ(FN.SECURITY.MASTER,SECURITY.MASTER.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,YERR)
RETURN
CHECK.PRICE.DATE:
*****************
*Check the condition for stale price, no change or no update from past 21 days
    LAST.PRICE = R.SECURITY.MASTER<SC.SCM.LAST.PRICE>
    DATE.LAST.PRICE = R.SECURITY.MASTER<SC.SCM.DATE.LAST.PRICE>
    ISSUE.DATE = R.SECURITY.MASTER<SC.SCM.ISSUE.DATE>
    IF ISSUE.DATE GT LAST.DATE.TB THEN
        RETURN  ;* New Instrument added between the 3 weeks
    END
    IF NOT(DATE.LAST.PRICE) THEN
        CALL OCOMO("Not a Stale price instrument":SC.PRICE.CHANGE.ID:" WITH SM LAST.PRICE ":LAST.PRICE:" no last update date":DATE.LAST.PRICE)
        RETURN    ;* Assuming this SM as new or never got any price so far
    END
    IF DATE.LAST.PRICE AND DATE.LAST.PRICE LE LAST.DATE.TB THEN       ;*If last updated date is less than 21 days from today report it
        STALE.PRICE.REP = 1
        RETURN
    END
*If there is a recent updates check for LAST.PRICE change if not report else ignore
    SC.UPD.DATE = DATE.LAST.PRICE
    NOT.STALE.PRICE = ''
    YI = 1
    LOOP
    WHILE YI LE 21
        NEW.PRICE = ''
        OLD.PRICE = ''
        CALL CDT("",SC.UPD.DATE,"-1C")
        IF SC.UPD.DATE GT LAST.DATE.TB THEN
            SC.PRICE.CHANGE.ID = SECURITY.MASTER.ID:'.':SC.UPD.DATE
            GOSUB READ.PRICE.CHANGE
        END
        IF NEW.PRICE AND NEW.PRICE NE LAST.PRICE THEN
            NOT.STALE.PRICE = 1
            STALE.PRICE.REP = ''   ;* Not a Stale price instrument
*            CALL OCOMO(YI:" Not a Stale price instrument":SC.PRICE.CHANGE.ID:" WITH SM LAST.PRICE ":LAST.PRICE:" OLD.PRICE ":OLD.PRICE:" New Price ":NEW.PRICE)
            YI = 21
        END
    
*TO BE REMOVED ONCE UT BELOW IF
        IF NOT(NOT.STALE.PRICE) THEN
*            CALL OCOMO(YI:" In LOOP Last ID ":SC.PRICE.CHANGE.ID:" last Price ":LAST.PRICE:" OLD.PRICE ":OLD.PRICE:" New Price":NEW.PRICE:" yerr ":YERR)
        END
        YI ++
    REPEAT
    
    IF LAST.PRICE AND LAST.PRICE NE 0 AND NOT(NOT.STALE.PRICE) THEN
        STALE.PRICE.REP = 1          ;* There is a price in instrument and constant from PAST 21 days
        RETURN
    END
    
RETURN

READ.PRICE.CHANGE:
******************
    R.SC.PRICE.CHANGE = ''
    YERR = ''
    CALL F.READ(FN.SC.PRICE.CHANGE,SC.PRICE.CHANGE.ID,R.SC.PRICE.CHANGE,F.SC.PRICE.CHANGE,YERR)
    IF R.SC.PRICE.CHANGE THEN
        OLD.PRICE = R.SC.PRICE.CHANGE<SC.PCH.OLD.PRICE>
        NEW.PRICE = R.SC.PRICE.CHANGE<SC.PCH.NEW.PRICE>
    END
RETURN


FORM.RET.ARRY:
**************
    ISIN = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
    SHORT.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME>
    MARGIN.RATE = R.SECURITY.MASTER<SC.SCM.MARGIN.RATE>
    SAT = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
    PRICE.CURRENCY = R.SECURITY.MASTER<SC.SCM.PRICE.CURRENCY>
    SEC.CCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
    GOSUB FORM.CLIENT.HOLDINGS
    CHANGE @VM TO " " IN SHORT.NAME
    CHANGE @SM TO " " IN SHORT.NAME
    
    NOF.DAYS = ''
    YY.TODAY = TODAY
    CALL CDD('',DATE.LAST.PRICE,YY.TODAY,NOF.DAYS)
    
    EXCEPTION.REASON = ''
    IF LAST.PRICE EQ 0 THEN
        EXCEPTION.REASON = "Missing Price"
    END ELSE
        EXCEPTION.REASON = "Stale Price"
    END

    Y.SM.DATA = YID:'|':ISIN:'|':SHORT.NAME:'|':MARGIN.RATE:'|':SAT:'|':PRICE.CURRENCY:'|':SEC.CCY:'|':LAST.PRICE:'|':DATE.LAST.PRICE:'|':NOF.DAYS:'|':EXCEPTION.REASON:'|':CLIENT.HOLDINGS
*    CALL OCOMO(Y.SM.DATA)
    GOSUB WRITE.TO.FILE
RETURN
FORM.CLIENT.HOLDINGS:
*********************
    CLIENT.HOLDINGS = 0
    SEL.CMD = 'SELECT ':FN.SECURITY.POSITION:" WITH @ID LIKE ...":YID:"... AND CLOSING.BAL.NO.NOM NE '' AND CLOSING.BAL.NO.NOM NE 0"
    SECURITY.POISTION.LIST = ''
    LIST.NAME = ''
    SELECTED = ''
    SYSTEM.RETURN.CODE = ''
    CALL EB.READLIST(SEL.CMD,SECURITY.POISTION.LIST,LIST.NAME,SELECTED,SYSTEM.RETURN.CODE)
    LOOP
        REMOVE SECURITY.POISTION.LIST.ID FROM SECURITY.POISTION.LIST SETTING SECURITY.POISTION.LIST.MARK
    WHILE SECURITY.POISTION.LIST.ID : SECURITY.POISTION.LIST.MARK
        R.SECURITY.POSITION = ''
        YERR = ''
        CALL F.READ(FN.SECURITY.POSITION,SECURITY.POISTION.LIST.ID,R.SECURITY.POSITION,F.SECURITY.POSITION,YERR)
        IF R.SECURITY.POSITION THEN
            CURR.HOLDS = R.SECURITY.POSITION<SC.SCP.CLOSING.BAL.NO.NOM>
            CLIENT.HOLDINGS = CLIENT.HOLDINGS + R.SECURITY.POSITION<SC.SCP.CLOSING.BAL.NO.NOM>
        END
    REPEAT

RETURN
WRITE.TO.FILE:
**************
    OPENSEQ AMEXPATH,Y.FILE.NAME TO FP.SEC.MAS.LIST ELSE
        CREATE FP.SEC.MAS.LIST ELSE
            CALL OCOMO("UNABLE TO CREATE FILES ":FP.SEC.MAS.LIST)
        END
    END
*
* Write the security master data to AMEX.FILES from where the file will be transfered to
*
    WRITESEQ Y.SM.DATA APPEND TO FP.SEC.MAS.LIST ELSE
        CRT "UNABLE TO WRITE SECURITY.MASTER EXTRACT"
    END
    CLOSESEQ FP.SEC.MAS.LIST
*
RETURN
END
