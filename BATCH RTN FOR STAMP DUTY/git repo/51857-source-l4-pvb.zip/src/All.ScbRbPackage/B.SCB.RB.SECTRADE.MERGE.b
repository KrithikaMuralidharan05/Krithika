$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>118</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.SECTRADE.MERGE
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This routine is used to generate a report based on the Authorise SEC.TRADE,reversal SEC.TRADE and entitlement
* Copy of existing B.SCB.ST.PBDW.MERGE with change in file name for RB and removal of REV and ENT extract logic.
*-----------------------------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 13-Apr-2022       Lavanya L       CPSGMIG-2420        Initial Creation
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY       ;*SSE_DAY3
*-----------------------------------------------------------------------------
    
    GOSUB INIT.PARA
    GOSUB PROCESS.PARA
    GOSUB OCTAL.VALUE.CHANGE       ;*PVBCOREBAU-311
RETURN

INIT.PARA:
    Y.TEMP.FINAL.ID = ''
    Y.FILE.ARRAY = ''
    COUNTRY.CODE = ID.COMPANY[7,3]
    COUNTRY.NAME = ID.COMPANY[1,2]
    IF COUNTRY.NAME = 'GB' THEN COUNTRY.NAME = 'UK'
    IF COUNTRY.NAME = 'CH' THEN COUNTRY.NAME = 'GE'
    TOTAL.LINE.COUNT = ''
    LINE.COUNT = ''
    ! Modification - S- 03-nov-2011
    LINE.COUNT.1 = ''
    LINE.COUNT.2 = ''
    TOTAL.LINE.COUNT = ''
    TOTAL.LINE.COUNT.1 = ''
    TOTAL.LINE.COUNT.2 = ''
    ! Modification - E - 03-nov-2011

    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    ! Master File Name
    Y.FINAL.ID = 'T24-SG-RB-SECTRADE-':TODAY:'.TXT'
    ! Trade File Name
    Y.EXTRACT.ID = COUNTRY.NAME:'-RB-MANTAS-SECTRADE-':TODAY:'.TXT-...'
    ! Reversal Trade Name
    Y.EXTRACT.REV.ID = COUNTRY.NAME:'-RB-MANTAS-SECTRADE-REV-':TODAY:'.TXT-...'
    ! Modification - S- 03-nov-2011
    ! Entilement Trade Name
    Y.EXTRACT.ENT.ID = COUNTRY.NAME:'-RB-MANTAS-ENT-':TODAY:'.TXT-...'
    ! Modification - E - 03-nov-2011
RETURN

PROCESS.PARA:
    
    !Extracting the Trades files and append to one Master File
* R20_TAFJ_UPG - Start
*   SEL.CMD = 'SELECT ':FN.APPEND.FILES:' WITH @ID LIKE ': Y.EXTRACT.ID
*   CALL EB.READLIST(SEL.CMD,SEL.FILE.ID,'',NO.OF.IDS,ID.ERR)
    Y.UDFILE       = 'AMEX.FILES'
    Y.ST.CRITERIA  = COUNTRY.NAME:'-RB-MANTAS-SECTRADE-':TODAY:'.TXT-*'
    SEL.FILE.ID    = ''
    Y.ST.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.CRITERIA, SEL.FILE.ID, Y.ST.CNT)
* R20_TAFJ_UPG - End
    Y.DEL.FILE.ID = SEL.FILE.ID
    LOOP
        REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
    WHILE Y.FILE.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.PBDW.REC,F.APPEND.FILES,APP.ERR)
        IF R.PBDW.REC NE  '' THEN
            Y.FILE.ARRAY<-1> = R.PBDW.REC
            LINE.COUNT = DCOUNT(R.PBDW.REC, @FM)
            TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
        LINE.COUNT = ''
    REPEAT

* 1436383_14001763_SEHK_SSE_North Bound/S
***SG PvB SSE STP(S)
*    IF R.COMPANY(EB.COM.FINANCIAL.MNE) EQ 'HKB' THEN        ;*SSE_DAY3
***SG PvB SSE STP(E)
    SSE.ARR = Y.FILE.ARRAY
    CALL B.SCB.SSE.ST.DAILY.EXTRACT(SSE.ARR)
* END ;***SG PvB SSE STP(S/E)
* 1436383_14001763_SEHK_SSE_North Bound/E

    !Extracting the Reversal Trade files and append to the Master File
* R20_TAFJ_UPG - Start
*   SEL.CMD = 'SELECT ':FN.APPEND.FILES:' WITH @ID LIKE ': Y.EXTRACT.REV.ID
*   CALL EB.READLIST(SEL.CMD,SEL.FILE.REV.ID,'',NO.OF.IDS,ID.ERR)
    
    Y.UDFILE           = 'AMEX.FILES'
    Y.ST.REV.CRITERIA  = COUNTRY.NAME:'-RB-MANTAS-SECTRADE-REV-':TODAY:'.TXT-*'
    SEL.FILE.REV.ID    = ''
    Y.ST.REV.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.REV.CRITERIA, SEL.FILE.REV.ID, Y.ST.REV.CNT)
* R20_TAFJ_UPG - End
    Y.DEL.FILE.REV.ID = SEL.FILE.REV.ID
    LOOP
        REMOVE Y.FILE.REV.ID FROM SEL.FILE.REV.ID SETTING POS
    WHILE Y.FILE.REV.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.REV.ID,R.PBDW.REV.REC,F.APPEND.FILES,APP.ERR)
        IF R.PBDW.REV.REC NE '' THEN
            Y.FILE.ARRAY<-1> = R.PBDW.REV.REC
            LINE.COUNT.1 = DCOUNT(R.PBDW.REV.REC, @FM)
            TOTAL.LINE.COUNT.1 = TOTAL.LINE.COUNT.1 + LINE.COUNT.1
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.REV.ID)
        LINE.COUNT.1 = ''
    REPEAT

    !Modification Start - S - 03-nov-2011
    !Extracting the Entitlement files and append to the Master File
* R20_TAFJ_UPG - Start
*   SEL.CMD = 'SELECT ':FN.APPEND.FILES:' WITH @ID LIKE ': Y.EXTRACT.ENT.ID
*   CALL EB.READLIST(SEL.CMD,SEL.FILE.ENT.ID,'',NO.OF.IDS,ID.ERR)
    
    Y.UDFILE        = 'AMEX.FILES'
    Y.ENT.CRITERIA  = COUNTRY.NAME:'-RB-MANTAS-ENT-':TODAY:'.TXT-*'
    SEL.FILE.ENT.ID = ''
    Y.ENT.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ENT.CRITERIA, SEL.FILE.ENT.ID, Y.ENT.CNT)
* R20_TAFJ_UPG - End
    LOOP
        REMOVE Y.FILE.ENT.ID FROM SEL.FILE.ENT.ID SETTING POS
    WHILE Y.FILE.ENT.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ENT.ID,R.PBDW.ENT.REC,F.APPEND.FILES,APP.ERR)
        IF R.PBDW.ENT.REC NE '' THEN
            Y.FILE.ARRAY<-1> = R.PBDW.ENT.REC
            LINE.COUNT.2 = DCOUNT(R.PBDW.ENT.REC, @FM)
            TOTAL.LINE.COUNT.2 = TOTAL.LINE.COUNT.2 + LINE.COUNT.2
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ENT.ID)
        LINE.COUNT.2 = ''
    REPEAT
    !Modification End - E-03-nov-2011

    ACT.DATE = OCONV(ICONV(TODAY,'D4-'),'D4-')
    Y.STAMP = OCONV(TIME(),"MTS")
    Y.FILE.ARRAY<-1> = COUNTRY.NAME:',':ACT.DATE:'/':Y.STAMP[1,5]:',':TOTAL.LINE.COUNT + TOTAL.LINE.COUNT.1 + TOTAL.LINE.COUNT.2
    Y.TEMP.FINAL.ID = "TEMP.FILE-":Y.FINAL.ID
*    CALL F.WRITE(FN.APPEND.FILES,Y.TEMP.FINAL.ID,Y.FILE.ARRAY)     
     WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.TEMP.FINAL.ID 
    CALL OCOMO("Temporary File SEC TRADE File ID ":Y.TEMP.FINAL.ID) 
RETURN
*PVBCOREBAU-311-Start
OCTAL.VALUE.CHANGE:
    
    Y.VM.CONV.FILE = ''
    Y.SRC.PATH = ''
    Y.SRC.FILE.NAME = ''
    ARG1 = 'AMEX.FILES'
    ARG2 = ''
    ARG3 = ''
    CALL SCB.GET.ORACLE.FILENAME(ARG1,ARG2,ARG3)
    
    Y.SRC.PATH = ARG3
    Y.VM.CONV.FILE = Y.TEMP.FINAL.ID
    Y.SRC.FILE.NAME = Y.FINAL.ID
    SM.AVAILABLE = '0'

    EXE.SM.CMD = "SH -c grep -o -E $'\277' ":Y.SRC.PATH:"/":Y.TEMP.FINAL.ID:" | wc -l"
    EXECUTE EXE.SM.CMD CAPTURING SM.AVAILABLE
    CALL OCOMO("Count for Octal Value 277 are ":SM.AVAILABLE)

    CALL OCOMO('Sub Value conversion from double byte to single byte - Start')

    CALL OCOMO('Delete the Octal value 277 in the file')
    EXE.CMD = "SH -c ":"tr -d '\277' < ":Y.SRC.PATH:"/":Y.VM.CONV.FILE:" > ":Y.SRC.PATH:"/":Y.SRC.FILE.NAME
    EXECUTE EXE.CMD

    EXE.FILE.DEL.CMD = "SH -c ":"rm ":Y.SRC.PATH:"/":Y.VM.CONV.FILE
    EXECUTE EXE.FILE.DEL.CMD

    CALL OCOMO('Sub Value conversion from double byte to single byte - Completed')

RETURN
*PVBCOREBAU-311-End
*-----------------------------------------------------------------------------
END
