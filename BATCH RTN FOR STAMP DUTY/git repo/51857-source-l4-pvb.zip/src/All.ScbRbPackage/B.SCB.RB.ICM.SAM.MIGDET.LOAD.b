$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ICM.SAM.MIGDET.LOAD
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-22772 - JEWEL_T24_PROJECT
* Developed By                   :       Revathi G
* Developed On                   :       5thMay2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is a multi threaded Routine which extract details of SAM
* with LR.POS.MIG.DT EQ TODAY for ICM
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.ICM.SAM.MIGDET.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.CUSTOMER


    GOSUB INIT    ;*To initialise the variables AND open files

RETURN
******
INIT:
******

    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER  = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)

    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.AMEX.FILES = "AMEX.FILES"
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    Y.APPL = "SEC.ACC.MASTER":@FM:"CUSTOMER"
    Y.FLD = "LR.POS.MIG.DT":@VM:"LR.PFOLIO.KEY":@FM:"L.O.B"
    Y.POS = ''

    CALL MULTI.GET.LOC.REF(Y.APPL, Y.FLD,Y.POS)
    Y.MIG.DAT.POS = Y.POS<1,1>
    Y.LR.PFOLIO.KEY.POS = Y.POS<1,2>
    Y.L.O.B = Y.POS<2,1>
	
    AMEX.FILES.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME('AMEX.FILES', '', AMEX.FILES.PATH)
    Y.FILE.ID = ID.COMPANY[1,2]:'.SAM.UPDATE.':TODAY:'-':SESSION.NO

    Y.PARAM.ID = 'SCB.CUST.SEG'; Y.ALLOW.SEG = 'RET'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)

RETURN
************************************************************
END