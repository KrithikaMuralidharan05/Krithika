* @ValidationCode : MjotNzcyNzEyNjc6SVNPLTg4NTktMToxNjgzOTc4MTIwMjAwOjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 13 May 2023 17:12:00
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FUND.HOLDING.EXT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-17751 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       10 Jan 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract iBanking Fund Holding details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.HOLDING.EXT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 10-Apr-2023   1663000          CPSGMIG-23263 - To remove duplicates in Holding file
* 17-Apr-2023   1663000          CPSGMIG-24759 - Exclude CPF/SRS Position
* 02-Jun-2023   1648769          CPSGMIG-27441 - Customer records should be taken from IBANKING_RELIDS.txt and file is read from &SAVEDLISTS&.
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_B.SCB.FUND.HOLDING.EXT.COMMON
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT                             ;*CPSGMIG-23263 -s/e
*-------------------------------------------------------------------------------------------- 
    IF ID.COMPANY[1,2] EQ "SG" THEN
        GOSUB INITIALISE                         ;*CPSGMIG-23263 -S/E
        GOSUB DO.PROCESS
    END

RETURN
*---------*
INITIALISE:
*---------*
    
    FN.SL               = '&SAVEDLISTS&'                    ; F.SL              = '' ; CALL OPF(FN.SL,F.SL)
    FN.EBBS.REL.CONCAT  = 'F.ST.SCB.RSG.EBBS.REL.CONCAT'  ; F.EBBS.REL.CONCAT = '' ; CALL OPF(FN.EBBS.REL.CONCAT,F.EBBS.REL.CONCAT)
  
    ARG2 = ''
    SAVE.LIST.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME(FN.SL, ARG2, SAVE.LIST.PATH)
    
    Y.FUND.REQ.FILE = FIELD(BATCH.DETAILS<3,1>,'*',1) ;* CPSGMIG-24759 -s/e
    CALL B.SCB.C.CONV.FILE.NAME(Y.FUND.REQ.FILE)
        
RETURN
*---------*
DO.PROCESS:
*---------*
    
    OPEN SAVE.LIST.PATH TO SL.PATH THEN
        READ R.FILE.DATA FROM SL.PATH,Y.FUND.REQ.FILE THEN
            CALL BATCH.BUILD.LIST('', R.FILE.DATA)                
        END ELSE
            CALL OCOMO("Unable to read iBanking Request file from In-Directory")
        END
    END ELSE
        CALL OCOMO("Unable to open iBanking Request File")
    END

RETURN
END