$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.CONSOL.XML.ADV.RB.SELECT
*-----------------------------------------------------------------------------
* Created by    : Sasikumar Kannan
* Creation Date : 28/06/2012
* Modified by	: Avinash
*-----------*
*DESCRIPTION:
*-----------*
* This is a BATCH routine is used for consolidating all the XML advices generated.
* This is a requirement for DE-PERSONALISATION Project.
* Routine attached to the BATCH Application
* XXX/B.SCB.CONSOL.XML.ADV(Online Generation with Interval of 30 mins in Business days.
*------------------------------------------------------------------------------------------
* PVB-60661 - 9-10-2020 - Kapil K - SMS Post Trade Notification - cross compiled
*------------------------------------------------------------------------------------------
* PVB-60661  - 6-11-2020       Kapil K        SMS Post Trade Notification Post-Live changes -cross compile
* TAFJUPG    -                                Code conversion for TAFJ upgrade - no changes.
* 25-04-2022  - CPSGMIG-1081    Avinash        This Routine copied from B.SCB.CONSOL.XML.ADV.SELECT to 
*                                              B.SCB.CONSOL.XML.ADV.RB.SELECT to select retail advices and consolidate.
*-----------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.DP.XML.ADV.STATUS
    $INSERT I_B.SCB.CONSOL.XML.ADV.RB.COMMON
*---------------------------------------------------------------------------------*
    SEL.CMD = ''; SEL.LIST = ''; SEL.CNT = ''
    SEL.CMD = "SELECT ":FN.SCB.DP.XML.ADV.STATUS:" WITH PROCESS.STATUS EQ '' AND WITH COMPANY EQ " :ID.COMPANY[1,2]:" AND WITH L.O.B EQ 'RET'"
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,'')
*
    CALL BATCH.BUILD.LIST('',SEL.LIST)
*
RETURN
*---------------------------------------------------------------------------------
END
