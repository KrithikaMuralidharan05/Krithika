$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EDM.FEE.CHRG.EXT.MERGE
*-------------------------------------------------------------------------------------------------------
* Modification History :- 
* 22/07/2022 - Shreekantha. G  - NEW - CPSGMIG-4971
* Description 	: The routine is used to merge the generated files to a single file to send to eDMP.
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SC.CHARGE.TAX.CALC.CREATE
	$INSERT I_F.FT.COMMISSION.TYPE
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
	$INSERT I_B.SCB.RB.EDM.FEE.CHRG.EXT.COMMON
	$INSERT I_F.DATES
*	
	FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
*	
*	Y.NEXT.WORK.DAY = R.DATES(EB.DAT.NEXT.WORKING.DAY)
	*Y.FINAL.FILE.NAME = 'T24-RBSG-Charges-Commission.':TODAY:'.csv'
	 Y.FINAL.FILE.NAME = 'T24-RB-Fee-Charge-':TODAY:'.csv'						;*CPSGMIG-4971
*
	GOSUB GET.HEADER
	GOSUB REMOVE.DUP.LINE
	GOSUB WRITE.DETS
*		
	RETURN
*--------------------------------------------------------------------------------------------------------
GET.HEADER:
*---------*
*
    Y.HEADER = ''
    DL = CHAR(01)
    Y.HEADER = 'H':DL:'T24':DL:'SG':DL:TODAY:@FM
	Y.HEADER := 'D':DL:'Activity':DL:'Charge_Tax_Type':DL:'Stock_Exchange':DL:'Sec_Type':DL:'Sec_Domicile':DL:'Txn_Type':DL:'Cust_Group':DL
	Y.HEADER := 'Base_Amount':DL:'Chg_Comm_Code':DL:'Tax_Code':DL:'Till_Date':DL:'Source':DL:'Last_Upd_Date':DL:'Charge_Type':DL
	Y.HEADER := 'Charge_Description':DL:'Calculation_Basis':DL:'Currency':DL:'Percentage':DL:'Comm_Upd_Date'
*
	RETURN
*--------------------------------------------------------------------------------------------------------
REMOVE.DUP.LINE:
*--------------*
*	
	ARG1 = 'AMEX.FILES'
    ARG2 = ''
    AMEX.FILES.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME(ARG1,ARG2,AMEX.FILES.PATH)
*
    FILE.PATH.ORG = AMEX.FILES.PATH
    CALL SCB.REMOVE.DUPLICATE.LINE(FILE.PATH.ORG,Y.FINAL.FILE.NAME)
*
	RETURN
*--------------------------------------------------------------------------------------------------------
WRITE.DETS:
*---------*
* Select all the files with file name like T24.TAX.CALC...
* and consolidate into a single file.
* Footer of the file contains total record count, time stamp, and next working date
*
    Y.UDFILE    = 'AMEX.FILES'
    Y.CRITERIA  = 'T24.RB.EDM.TAX.CALC*'
    SEL.FILE.ID = ''
    NO.OF.IDS   = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, SEL.FILE.ID, NO.OF.IDSD)
*
    IF SEL.FILE.ID THEN
        Y.FILE.ARRAY = Y.HEADER
        Y.DEL.FILE.ID = SEL.FILE.ID
        LOOP
            REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
        WHILE Y.FILE.ID:POS
            CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.AMEX.FILES,F.APPEND.FILES,APP.ERR)
            ! Checking whether the file contains any record
            IF R.AMEX.FILES NE '' THEN
                Y.FILE.ARRAY := @FM:R.AMEX.FILES
* Count the number of records in the file to get the total count of CUSTOMER
                LINE.COUNT = 0
                LINE.COUNT = DCOUNT(R.AMEX.FILES, @FM)
                TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
            END
* Delete the file after forming the array
            CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
            LINE.COUNT = ''
        REPEAT
    END
*
    WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME
    CALL F.READ(FN.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FILE.ARRAY,F.APPEND.FILES,READ.ERR1)
    TOTAL.LINE.COUNT = DCOUNT(Y.FILE.ARRAY,@FM)-2
*
    Y.STAMP = OCONV(TIME(),"MTS")
*
* Footer should be in the following format
* EOF,2012-03-09 00:32,3086,2012-03-12
*
	*Y.FILE.ARRAY := @FM:'EOF':',':TODAY[1,4]:'-':TODAY[5,2]:'-':TODAY[7,2]:' ':Y.STAMP[1,5]:',':TOTAL.LINE.COUNT
    *Y.FILE.ARRAY := ',':R.DATES(EB.DAT.NEXT.WORKING.DAY)[1,4]:'-':R.DATES(EB.DAT.NEXT.WORKING.DAY)[5,2]:'-':R.DATES(EB.DAT.NEXT.WORKING.DAY)[7,2]
	Y.FILE.ARRAY := @FM:'T':DL:TOTAL.LINE.COUNT
*
* Finally write the single file to the AMEX.FILES path
*    
	Y.FILE.ARRAY = UTF8(Y.FILE.ARRAY)
	WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME
*
	RETURN
*--------------------------------------------------------------------------------------------------------
END
*--------------------------------------------------------------------------------------------------------

	