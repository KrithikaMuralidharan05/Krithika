$PACKAGE All.ScbRbPackage
SUBROUTINE B.TAP.NTW.PFOLIO.DEL.REPORTS
*****************************************************************************************************************************
* Description : - Utility to clean up TAP.NTW.PORTFOLIO processed files from SAVEDLIST
* Developer : -  Mithun Abinesh XJ
***************************************************************************************************************************** 
*
* 13-FEB-2024	Kavitha R -  ADO-2865634- SG - RTOB & TAP channel classification
******************************************************************************************************************************

$INSERT I_COMMON
$INSERT I_EQUATE

GOSUB INIT
GOSUB PROCESS

RETURN

********************
INIT:
********************

FN.SAVE = "&SAVEDLISTS&"
F.SAVE = ""
CALL OPF(FN.SAVE,F.SAVE)

Y.DATE = OCONV(DATE(),'D4-')

Y.CUR.DATE = Y.DATE[7,4]:Y.DATE[1,2]:Y.DATE[4,2]

CALL CDT('',Y.CUR.DATE,'-5C')

Y.PREV.DAY = Y.CUR.DATE


RETURN

*****************
PROCESS:
*****************


SEL.CMD = "SELECT ":FN.SAVE:" WITH @ID LIKE ":"...NTW.PFOLIO...PROCESSED" ;* ADO-2865634-S/E

SEL.CMD.EXCP = "SELECT ":FN.SAVE:" WITH @ID LIKE NTW.CUS.SEC-DEL.LIST-..."
SEL.LIST.EXCP = ""
CALL EB.READLIST(SEL.CMD.EXCP,SEL.LIST.EXCP,"",NO.OF.REC.EXCP,ERR.EXCP)

CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR)
SEL.LIST = SEL.LIST:@FM:SEL.LIST.EXCP

IF SEL.LIST THEN
   FOR I = 1 TO DCOUNT(SEL.LIST,@FM)
       Y.ID = SEL.LIST<I>
       Y.REC.DATE = FIELD(Y.ID,"-",4)
       IF Y.REC.DATE LE Y.PREV.DAY THEN
          CALL F.DELETE(FN.SAVE,Y.ID)
       END
    NEXT I
END

RETURN

