* @ValidationCode : MjotNDk2MjY4ODM5OkNwMTI1MjoxNzg5NDY5MjE0NDI0OjgyMzM0Njk6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1A1Mi4wOi0xOi0x
* @ValidationInfo : Timestamp         : 15 Sep 2026 16:16:54
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 8233469
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP52.0
$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.CAPE.FT.ADV.MAPPING(CAPE.CA.REF.ID,TRANS.REF.ID,MAT HANDOFF.REC)

**************************************************************************************************************************************************************************************
* Description: - Pawan Kr
*ADO - 10962475  Description - Merging of Payment Posting feed_Advice generation
*                             Attached to DE.MAPPING
* Modification History:
*-------------------------------------------------------------------------------------------------------------
* 15/09/2026 - Girija S/Miruthulaa P -  16132929 - Added a condition to fetch and display the correct accrual start and end date in advices for coupon.
***********************************************************************************************************************************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SCB.L.CAPE.CA.REF
    $INSERT I_F.FUNDS.TRANSFER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.SCB.CAPE.EVENT.PARAM
    $INSERT I_F.SECURITY.TRANSFER
 
    GOSUB INIT
    GOSUB PROCESS
    GOSUB UPDATE.USR.DEF.VALUE
RETURN
*****************
INIT:
    FnClientOutputParam= 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    FClientOutputParam = ''
    CALL OPF(FnClientOutputParam,FClientOutputParam)
*
    FnSecAccMaster = 'F.SEC.ACC.MASTER'
    FvSecAccMaster = ''
    CALL OPF(FnSecAccMaster,FvSecAccMaster)

    fnFundsTransfer = "F.FUNDS.TRANSFER"
    fvFundsTransfer = ""
    CALL OPF(fnFundsTransfer,fvFundsTransfer)
    
    fnSecurityTransfer = "F.SECURITY.TRANSFER"
    fvSecurityTransfer = ""
    CALL OPF(fnSecurityTransfer,fvSecurityTransfer)
  
    fnFundsTransferHis = "F.FUNDS.TRANSFER$HIS"
    fvFundsTransferHis = ""
    CALL OPF(fnFundsTransferHis,fvFundsTransferHis)

    
    fnScbLCapeCaref = "F.SCB.L.CAPE.CA.REF"
    fvScbLCapeCaref = ""
    CALL OPF(fnScbLCapeCaref ,fvScbLCapeCaref)

    fnScbCapeEventParam = "F.SCB.CAPE.EVENT.PARAM"
    fvScbCapeEventParam = ""
    CALL OPF(fnScbCapeEventParam,fvScbCapeEventParam)

 
    FnSecMaster = "F.SECURITY.MASTER"
    FvSecMaster = ""
    CALL OPF(FnSecMaster,FvSecMaster )

    fnScbWmHLocalParam = "F.SCB.WM.H.LOCAL.PARAM"
    fvScbWmHLocalParam = ""
    CALL OPF(fnScbWmHLocalParam ,fvScbWmHLocalParam)

    
    fnCustomer = "F.CUSTOMER"
    fvCustomer = ""
    CALL OPF(fnCustomer,fvCustomer)

    yParamId = 'SCB.CRES.SAT'
    CALL F.READ(fnScbWmHLocalParam ,yParamId,rLocalRec,fvScbWmHLocalParam,rLocalRecErr)
    IF NOT(rLocalRecErr) THEN
        yProdCodes = rLocalRec<SCBWM.PRM.FIELD.VALUE>
        yProdNames= RAISE(rLocalRec<SCBWM.PRM.FIELD.NAME>)
      

        YAppName = 'CUSTOMER':@FM:'SECURITY.MASTER':@FM:'FUNDS.TRANSFER':@FM:"SECURITY.TRANSFER"
        YFldName = 'L.O.B':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.EBBS.REL':@FM:'LR.UTS.INS.DESC':@FM:'L.SEC.ACC.NO':@VM:"CAPE.EVENT.ID"
        YFldName:= @VM:"CAPE.EVENT.TYPE":@VM:"L.SECURITY.NO":@VM:"NOMINEE.CODE":@VM:"L.QUAL.HOLDING":@VM:"LR.REC.CASA.ACC":@VM:"L.RATE":@VM:"LWM.EX.DATE"
        YFldName:= @VM:"L.TAX.AMOUNT":@VM:"L.ACR.INT":@VM:"L.CASH.PAY.DATE":@VM:'CA.EVENT.DESC':@FM:"LR.SN.STRK.PERC":@VM:"LR.SN.KI.PERC"
        YFldName:= @VM:"LR.SN.KO.PERC":@VM:"LR.FIXING.DATE":@VM:"L.OPTION.NOM"
        YFldPos  = ""
        CALL MULTI.GET.LOC.REF(YAppName,YFldName,YFldPos)
        YLobPos          = YFldPos<1,1>
        YStfPos          = YFldPos<1,2>
        YPfolPos         = YFldPos<1,3>
        YEbbsRelIdpos    = YFldPos<1,4>
        YUtsPos          = YFldPos<2,1>
        ySecAccPos = YFldPos<3,1>
        yCapeEventPos = YFldPos<3,2>
        yCapeEventTypePos = YFldPos<3,3>
        ySecurityNoPos =   YFldPos<3,4>
        yNomCodePos = YFldPos<3,5>
        yQualHoldPos = YFldPos<3,6>
        yRecAcctPos = YFldPos<3,7>
        yRatePos = YFldPos<3,8>
        yLExDatePos = YFldPos<3,9>
        yLTaxAmtPos = YFldPos<3,10>
        yAccrdIntPos = YFldPos<3,11>
        yCashPayDtPos = YFldPos<3,12>
        yCashCaDesc = YFldPos<3,13>
        yLrSnStrkPercPos = YFldPos<4,1>
        yLrSnKiPercPos = YFldPos<4,2>
        yLrSnKoPercPos =YFldPos<4,3>
        yLrFixingDatePos = YFldPos<4,4>
        yStOptionNomPos = YFldPos<4,5>
    

        yFtId = ""
        yStId = ""
        yTxnId = TRANS.REF.ID
        IF CAPE.CA.REF.ID THEN
            yFtId = FIELD(CAPE.CA.REF.ID,'*',1)
            yStId = FIELD(CAPE.CA.REF.ID,'*',2)
            CHANGE @SM TO @FM IN yStId
        END

        RETURN
***********************

PROCESS:

        CALL F.READ(fnFundsTransfer,yTxnId,rFtRecord,fvFundsTransfer,ftError)
        IF NOT(rFtRecord) THEN
 
            CALL EB.READ.HISTORY.REC(fvFundsTransferHis,yTxnId,rFtRecord,ftError)

        END
        IF yStId THEN
            yStOptionNominal = ""
            yAccruedInterest = ""
            ySnStrikePerc = ""
            yKnockInPerc = ""
            yKnockOutPerc = ""
            yValuationDate = ""
            CALL F.READ(fnSecurityTransfer,yStId<1> ,rStRecord,fvSecurityTransfer,stError)
            yStOptionNominal = rStRecord<SC.STR.LOCAL.REF,yStOptionNomPos>
            yAccruedInterest = rStRecord<SC.STR.INTEREST.AMT>
            ySnStrikePerc = rStRecord<SC.STR.LOCAL.REF,yLrSnStrkPercPos>
            yKnockInPerc = rStRecord<SC.STR.LOCAL.REF,yLrSnKiPercPos>
            yKnockOutPerc = rStRecord<SC.STR.LOCAL.REF,yLrSnKoPercPos>
            yValuationDate = rStRecord<SC.STR.LOCAL.REF,yLrFixingDatePos>

        END
        yPortfolioId = rFtRecord<FT.LOCAL.REF,ySecAccPos>
        yCaEventId = rFtRecord<FT.LOCAL.REF,yCapeEventPos>
        yCapeEventType = rFtRecord<FT.LOCAL.REF,yCapeEventTypePos>
        yCashCaDesc = rFtRecord<FT.LOCAL.REF,yCashCaDesc>
        ySecurityNo = rFtRecord<FT.LOCAL.REF,ySecurityNoPos>
        yValueDate = rFtRecord<FT.DEBIT.VALUE.DATE>
        yTotHoldings = rFtRecord<FT.LOCAL.REF,yQualHoldPos>
        yTradeCurrency = rFtRecord<FT.DEBIT.CURRENCY>
        yNetAmt = rFtRecord<FT.AMOUNT.CREDITED>[4,99]
        yCommAmt = rFtRecord<FT.COMMISSION.AMT>
        yExchRate = rFtRecord<FT.IN.EXCH.RATE>
        ySettleAccnt = rFtRecord<FT.LOCAL.REF,yRecAcctPos>
        yLNomineeCode = rFtRecord<FT.LOCAL.REF,yNomCodePos>
        yRate = rFtRecord<FT.LOCAL.REF,yRatePos>
        yLExDate = rFtRecord<FT.LOCAL.REF,yLExDatePos>
        yLTaxAmt = rFtRecord<FT.LOCAL.REF,yLTaxAmtPos>
        yAccrdInt = rFtRecord<FT.LOCAL.REF,yAccrdIntPos>
        yCashPymtDate = rFtRecord<FT.LOCAL.REF,yCashPayDtPos>

        yTelNo = 'TNO'
        yLending = 'No'
        IF yLNomineeCode EQ 1 THEN
            yLending = 'Yes'
        END
        

        CALL F.READ(FnSecMaster,ySecurityNo,RSecurityMaster,FvSecMaster,YSecErr)
        Y.SM.DESCRIPTION  = RSecurityMaster<SC.SCM.DESCRIPT>
        Y.SM.CURRENCY = RSecurityMaster<SC.SCM.SECURITY.CURRENCY>
        YSmNewDescription = RSecurityMaster<SC.SCM.LOCAL.REF,YUtsPos>
    
        yLastPrice = RSecurityMaster<SC.SCM.LAST.PRICE>
*16132929_S
*ySmDate = RSecurityMaster<SC.SCM.ACCRUAL.START.DATE>
*IF ySmDate THEN
*GOSUB DATE.FORMAT
* yAccrualStartDt = returnDate
*END
* ySmDate = ""
     
*  ySmDate = RSecurityMaster<SC.SCM.INT.PAYMENT.DATE>
* IF ySmDate THEN
* GOSUB DATE.FORMAT
*  yIntPymtDt  = returnDate
* END
        yAccrualStartDt = RSecurityMaster<SC.SCM.ACCRUAL.START.DATE>
        yIntPymtDt = RSecurityMaster<SC.SCM.INT.PAYMENT.DATE>
        yPrevAccrStartDt = RSecurityMaster<SC.SCM.PREV.ACCR.STR.DATE>
*16132929_E
        Y.SAT = RSecurityMaster<SC.SCM.SUB.ASSET.TYPE>
        yProdType = ""
        FINDSTR Y.SAT IN yProdCodes SETTING fmPos,vmPos,smPos THEN
            yProdType = yProdNames<vmPos>
            BEGIN CASE
                CASE yProdType EQ 'MF'
                    yProdType = 'Funds'
                CASE yProdType EQ 'SN'
                    yProdType = "Structured Products"
                CASE yProdType EQ 'FI'
                    yProdType = 'Fixed Income'
            END CASE
        END
        Y.ISIN      = RSecurityMaster<SC.SCM.I.S.I.N.>
        YInvestType = RSecurityMaster<SC.SCM.INVEST.OPTION.TYPE>
        yIssuerName = RSecurityMaster<SC.SCM.ISSUER.NAME>
        yIssuePrice = RSecurityMaster<SC.SCM.ISSUE.PRICE>
        yIssueDate = RSecurityMaster<SC.SCM.ISSUE.DATE>
        yMatDate = RSecurityMaster<SC.SCM.MATURITY.DATE>
        yUnderlyingDesc = CHANGE(RSecurityMaster<SC.SCM.UNDERLYING.DESCRIPTION>,@VM,"|")
        ySpotPrice = CHANGE(RSecurityMaster<SC.SCM.SPOT.PRICE>,@VM,"|")
        yStrikePrice = CHANGE(RSecurityMaster<SC.SCM.STRIKE.PRICE>,@VM,"|")
        yPriceBarrierType = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE>
        yNotePriceBarrier= RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER>
        yIssuer = CHANGE(RSecurityMaster<SC.SCM.ISSUER>,@VM,"|")
   
        yKnockInPrice = ""
        yKnockOutPrice = ""
        yUnderlyingCnt = DCOUNT(yUnderlyingDesc,"|")
        FOR I = 1 TO yUnderlyingCnt
            yPriceBarrierType = RSecurityMaster<SC.SCM.PRICE.BARRIER.TYPE,I>
            yNotePriceBarrier= RSecurityMaster<SC.SCM.NOTE.PRICE.BARRIER,I>
            yKnockInOutDataCnt = DCOUNT(yPriceBarrierType,@SM)

            FINDSTR "KNOCK.IN" IN yPriceBarrierType SETTING fmPos,vmPos,smPos THEN
                yKnockInPrice<-1> = yNotePriceBarrier<1,vmPos,smPos>
            END
            FINDSTR "KNOCK.OUT" IN yPriceBarrierType SETTING fmPos,vmPos,smPos THEN
                yKnockOutPrice<-1> = yNotePriceBarrier<1,vmPos,smPos>
            END
        NEXT I
        CHANGE @FM TO "|" IN yKnockInPrice
        CHANGE @FM TO "|" IN yKnockOutPrice
**************************************To be concluded
*
** Logic to get the Product Group
*  CALL SCB.GET.PRODUCT.API(Y.SECURITY.NO, ProductGrp) ;* Get the Product Type FI SN or Funds
    
        GOSUB GET.SM.DESC
        yLCapeCaRefId = yCaEventId:'*':yPortfolioId   ;*to read the Live template SCB.L.CAPE.CA.REF

        yCustomerId = FIELD(yPortfolioId,'-',1)

        CALL F.READ(fnCustomer,yCustomerId,rCustomer,fvCustomer,CUST.ERR)
        L.O.B = rCustomer<EB.CUS.LOCAL.REF,YLobPos>
        LR.PFOLIO.KEY.VAL = rCustomer<EB.CUS.LOCAL.REF,YPfolPos>
        PriAcctHolder = FIELD(LR.PFOLIO.KEY.VAL,':',1)
        JntHolder = LR.PFOLIO.KEY.VAL
        CHANGE ':' TO '|' IN JntHolder
* As per the new logic for cleint Identifier provided as on 20220208
        STAFF.IND = rCustomer<EB.CUS.LOCAL.REF,YStfPos>
*
        BEGIN CASE
            CASE rCustomer<EB.CUS.SECTOR> EQ "21"
                yClientIdentifier = "SG.RETAIL"
            CASE rCustomer<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
                yClientIdentifier = "SG.RETAIL"
            CASE rCustomer<EB.CUS.SECTOR> EQ "23"
                yClientIdentifier = "SG.RET.CB.BB"
        END CASE
        CALL F.READ(FnSecAccMaster,yPortfolioId,rSecAccMaster,FvSecAccMaster,errorSecAcc)
        yAdviceIndex = rSecAccMaster<SC.SAM.ADVICE.INDEX>

        GOSUB READ.LIVE.REF.TABLE

        yDescName = Y.DESC.NAME
        IF rCapeEventParam NE '' THEN
        
            BEGIN CASE
                CASE ProductGrpValue EQ 'FIXEDINCOME'
                    YAssetName = yDescName
                CASE  ProductGrpValue EQ 'FUNDS'
                    GOSUB GET.FUND.VALUE
                CASE  ProductGrpValue EQ 'STRUCTUREDPRODUCTS'
                    YAssetName = yDescName
            END CASE
        END
*16132929_S
        GOSUB GET.COUPON.ACCR.START.DATE
*16132929_E
    

        RETURN
**********************
DATE.FORMAT:
        returnDate = ""
        CALL DIETER.DATE(ySmDate,returnDate,'D')

        RETURN
*********************
GET.SM.DESC:
*----------
** Logic to form the Asset Name
        IF YSmNewDescription THEN
            Y.DESC.NAME = YSmNewDescription
        END ELSE
            Y.DESC.NAME = Y.SM.DESCRIPTION
        END
        CHANGE @SM TO '' IN Y.DESC.NAME

*
        RETURN
**************************
GET.FUND.VALUE:
*--------------*
        IF YInvestType NE '' THEN
            YInvestOption = 'INVEST.OPTION'
            CALL F.READ(FnClientOutputParam,YInvestOption,RInvestLocalParam,FClientOutputParam,YInvestErr)
            InvestFieldName = RInvestLocalParam<SC.CO.FIELD.NAME>
            LOCATE YInvestType IN InvestFieldName<1,1> SETTING YInvestPos THEN
                YDepoAsset = RInvestLocalParam<SC.CO.FIELD.SUB.VALUE,YInvestPos>
            END
        END
*
        IF YDepoAsset NE '' THEN
            YAssetName = yDescName:' ':YDepoAsset
        END ELSE
            YAssetName = yDescName
        END

        RETURN
*************************
READ.LIVE.REF.TABLE:

        CALL F.READ(fnScbLCapeCaref,yLCapeCaRefId,rLCapeCaRec,fvScbLCapeCaref,errorLCape)

        IF rLCapeCaRec THEN
            yCapeEventDets = rLCapeCaRec<SCBCA.CAPE.EVENT.DETS>
            yRecStatus = rLCapeCaRec<SCBCA.EVENT.STATUS>
            IF yRecStatus EQ 'AUTH' ELSE RETURN              ;*TO BE UPDATE FOR REVERSAL
            CALL F.READ(fnScbCapeEventParam,yCapeEventDets,rCapeEventParam,fvScbCapeEventParam,errorCapeEventParam)
            IF rCapeEventParam THEN
                yClientOutputParamId = rCapeEventParam<SCBCE.CLIENT.PARAM.ID>

                GOSUB GET.ADVICE.FIELD.VALUE
            END
        END
        RETURN

**********************************
*********************************************

GET.ADVICE.FIELD.VALUE:

        ProductGrpValue = FIELD(yClientOutputParamId,'-',2)

        CALL F.READ(FnClientOutputParam,yClientOutputParamId,RClientOutputParam,FClientOutputParam,YAdviceErr)
        EventTypeArr = RClientOutputParam<SC.CO.EVENT.TYPE>
        CHANGE @VM TO @FM IN EventTypeArr
        LOCATE yRecStatus IN EventTypeArr SETTING AdvPos THEN
            AdviceId      = RClientOutputParam<SC.CO.ADVICE.ID,AdvPos>
            ConsolId      = RClientOutputParam<SC.CO.CONSOL.ID,AdvPos>
            DisclaimerId  = RClientOutputParam<SC.CO.DISCLAMIER.ID,AdvPos>
            ConfNotice    = RClientOutputParam<SC.CO.CONFIRMATION.NOTICE,AdvPos>
            DelMode       = RClientOutputParam<SC.CO.DELIVERY.MODE,AdvPos>
        END
        CALL SCB.CLIENTIDEN.R2WFOLD.RTN(yClientIdentifier,R2wFolder)
        RETURN
*******************
*16132929_S
**************************************
GET.COUPON.ACCR.START.DATE:
**************************************
        
        IF(yValueDate > yAccrualStartDt) OR (yValueDate <= yAccrualStartDt AND yPrevAccrStartDt EQ '') THEN
            ySmDate = yAccrualStartDt
            GOSUB DATE.FORMAT
            yStartDate = returnDate
        
            ySmDate=""
            ySmDate = yIntPymtDt
            GOSUB DATE.FORMAT
            yEndDate = returnDate
        END ELSE
            ySmDate = yPrevAccrStartDt
            GOSUB DATE.FORMAT
            yStartDate = returnDate
            ySmDate=""
            ySmDate = yAccrualStartDt
            GOSUB DATE.FORMAT
            yEndDate = returnDate
        END
*16132929_E
    
***************************************
UPDATE.USR.DEF.VALUE:

***Common value assignment for all event types
        yGrossAmt = yNetAmt+yLTaxAmt
        IF INDEX(yGrossAmt,'.',1) ELSE
            yGrossAmt = yGrossAmt:'.00'
        END
        HANDOFF.REC(9)<1> = ""
        HANDOFF.REC(9)<2> = yAdviceIndex
        HANDOFF.REC(9)<3> = TODAY
        HANDOFF.REC(9)<4> = AdviceId
        HANDOFF.REC(9)<6> = YAssetName
        HANDOFF.REC(9)<8> = yClientIdentifier
    
        HANDOFF.REC(9)<9> = ConfNotice
        HANDOFF.REC(9)<10> = ConsolId
        HANDOFF.REC(9)<14> = Y.SM.CURRENCY
        HANDOFF.REC(9)<16> =  DisclaimerId
        HANDOFF.REC(9)<21> = Y.ISIN
        HANDOFF.REC(9)<32> = yLending
        HANDOFF.REC(9)<34> = yNetAmt
 
        HANDOFF.REC(9)<49> = JntHolder
        HANDOFF.REC(9)<50> = yPortfolioId
        HANDOFF.REC(9)<52> = PriAcctHolder
        HANDOFF.REC(9)<54> = yProdType
        HANDOFF.REC(9)<56> = R2wFolder
        HANDOFF.REC(9)<57> = yRate
        HANDOFF.REC(9)<61> = ySettleAccnt
        HANDOFF.REC(9)<68> = 'TNO'
        HANDOFF.REC(9)<69> = yTotHoldings
        HANDOFF.REC(9)<70> = yTradeCurrency
        HANDOFF.REC(9)<72> = yCaEventId   ;*  yTxnId   populating event id in place of txn id
        HANDOFF.REC(9)<73> = yCapeEventType
        HANDOFF.REC(9)<77> = yValueDate
        HANDOFF.REC(9)<79> = yNetAmt

************************
**************

*****************
        
        BEGIN CASE

            CASE yCapeEventType EQ 'DIVIDENDS' OR yCapeEventType EQ 'COUPON' OR yCapeEventType EQ 'INTEREST'

                IF yCapeEventType EQ 'DIVIDENDS' THEN
                    HANDOFF.REC(9)<73> = 'Cash Dividend'
                END
                IF ProductGrpValue EQ 'FIXEDINCOME' THEN
*16132929_S
*HANDOFF.REC(9)<12> = yAccrualStartDt :' TO ':yIntPymtDt
                    HANDOFF.REC(9)<12> = yStartDate :' TO ':yEndDate
*16132929_E
                    HANDOFF.REC(9)<13> = yRate

                    HANDOFF.REC(9)<20> = yGrossAmt
                    HANDOFF.REC(9)<53> = yTotHoldings
                    HANDOFF.REC(9)<57> = ""
                    HANDOFF.REC(9)<62> = yTradeCurrency
  
                    HANDOFF.REC(9)<65> = yLTaxAmt
                    HANDOFF.REC(9)<69> = ''
                    HANDOFF.REC(9)<70> = ""
                    IF yCapeEventType EQ 'COUPON' THEN
                        HANDOFF.REC(9)<73> = 'Coupon'
                        HANDOFF.REC(9)<34> = ''
                        HANDOFF.REC(9)<78> = yGrossAmt   ;*coupon due
                    END
 

                END
                IF ProductGrpValue EQ 'STRUCTUREDPRODUCTS' AND (yCapeEventType EQ 'COUPON' OR yCapeEventType EQ 'INTEREST') THEN
                    HANDOFF.REC(9)<57> = ""
                    HANDOFF.REC(9)<34> = ''
                    HANDOFF.REC(9)<55> = yTotHoldings
                    HANDOFF.REC(9)<62> = yTradeCurrency
                    HANDOFF.REC(9)<63> = yNetAmt
                    HANDOFF.REC(9)<69> = yTotHoldings
                    HANDOFF.REC(9)<78> = yGrossAmt    ;*coupon due

                    IF yCapeEventType EQ 'INTEREST' THEN
                        HANDOFF.REC(9)<73> = 'Interest Payment'
                    END
                END
              
**********************************************************
******************

            CASE yCapeEventType EQ 'REDEMPTION' OR yCapeEventType EQ 'E.REDEMPTION'
                yLOptionNominal = ""
                ySnStrikePerc = ""
                yKnockInPerc = ""
                yKnockOutPerc = ""
                yValuationDate = ""
                yRedemAmt = yNetAmt+yLTaxAmt+yCommAmt
                IF INDEX(yRedemAmt,'.',1) ELSE
                    yRedemAmt = yRedemAmt:'.00'
                END
                HANDOFF.REC(9)<19> = yExchRate
                HANDOFF.REC(9)<34> = ""  ;*net amt
                HANDOFF.REC(9)<51> = yLastPrice
                HANDOFF.REC(9)<59> = yRedemAmt
                HANDOFF.REC(9)<63> = yNetAmt
                HANDOFF.REC(9)<69> = ""   ;*tot holdings
                HANDOFF.REC(9)<71> = yLExDate

                IF yCashCaDesc EQ 'TERMINATION' THEN
                    HANDOFF.REC(9)<73> = 'TERMINATION'
                END
                HANDOFF.REC(9)<75> =  yTotHoldings


                IF ProductGrpValue EQ 'FIXEDINCOME' THEN

                    HANDOFF.REC(9)<33> = yMatDate
                    HANDOFF.REC(9)<44> = yTotHoldings  ;*NOMINAL AMT
                    HANDOFF.REC(9)<53> = yGrossAmt  ;*principal amt
                    HANDOFF.REC(9)<75> =  yTotHoldings  ;*UNITS

                    IF yCashCaDesc EQ 'PUT.REDEMPTION' OR yCashCaDesc EQ 'REPURCHASE.OFFER' THEN
                        HANDOFF.REC(9)<1> = yAccruedInterest
                        HANDOFF.REC(9)<14> = yTradeCurrency
  
                        HANDOFF.REC(9)<46> = ''   ;*commision amt
                        HANDOFF.REC(9)<63> = yNetAmt
                        HANDOFF.REC(9)<65> = ''

                        HANDOFF.REC(9)<69> = ""
                        HANDOFF.REC(9)<70> = ""

                        HANDOFF.REC(9)<71> = yLExDate
       
                        HANDOFF.REC(9)<73> = yCapeEventType
         
                    END
                    IF yCapeEventType  EQ 'REDEMPTION' THEN
                        HANDOFF.REC(9)<73> = 'REDEMPTION'
                    END ELSE
                        HANDOFF.REC(9)<73> = 'EARLY REDEMPTION'
                    END
                END
********************


                IF ProductGrpValue EQ 'STRUCTUREDPRODUCTS' THEN
 

                    HANDOFF.REC(9)<22> = yIssueDate
                    HANDOFF.REC(9)<23> = yIssuePrice
           
                    HANDOFF.REC(9)<25> = yIssueDate
                    HANDOFF.REC(9)<26> = yIssuerName
                    HANDOFF.REC(9)<28> = yKnockInPerc
                    HANDOFF.REC(9)<29> = yKnockInPrice
                    HANDOFF.REC(9)<30> = yKnockOutPerc
                    HANDOFF.REC(9)<31> = yKnockOutPrice
                    HANDOFF.REC(9)<33> = yMatDate
                    HANDOFF.REC(9)<44> = yStOptionNominal   ;*Nominal amt

                    HANDOFF.REC(9)<57> = ""   ;*rate
                    HANDOFF.REC(9)<60> = ySpotPrice

                    HANDOFF.REC(9)<70> = ""   ;*trade currency
                    HANDOFF.REC(9)<61> = ""  ;*settle acnt
                    HANDOFF.REC(9)<62> = yTradeCurrency
                    HANDOFF.REC(9)<66> = ySnStrikePerc
                    HANDOFF.REC(9)<67> = yStrikePrice

                    HANDOFF.REC(9)<73> = yCapeEventType
                    IF yCapeEventType  EQ 'REDEMPTION' THEN
                        HANDOFF.REC(9)<73> = 'REDEMPTION'
                    END ELSE
                        HANDOFF.REC(9)<73> = 'EARLY REDEMPTION'
                    END 

                    HANDOFF.REC(9)<76> = yValuationDate
                    HANDOFF.REC(9)<74> = yUnderlyingDesc
                    HANDOFF.REC(9)<75> =  ""
                END


        END CASE
        RETURN
**********************************************************************************************************************
    END


