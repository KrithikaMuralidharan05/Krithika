$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.UTS.HIST.PROD.ACNO(R.DETS.ARR)
*--------------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------------
* Modification History :
*---------------------------------------------------------------------------------------
* Multithread routine to update SCB.UTS.HIST.PROD.ACNO table
* 17/01/2023 - Drafted by - Raja Prabhu S
* 06/07/2023 - Mithun - Handled to update log for existing record amendment
* Jira id - CPSGMIG-17731
*----------------------------------------------------------------------------------------------------------------------------------------


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.UTS.HIST.PROD.ACNO.COMMON
    $INSERT I_BATCH.FILES
    
    
    
    GOSUB PROCESS

RETURN
*---------
PROCESS:
*-------------
    Y.IN.ID = FIELD(R.DETS.ARR,'|',1)
    Y.FILE.LOG = ''
    CALL F.READ(FN.SCB.UTS.HIST.PROD.ACNO,Y.IN.ID,R.PROD.ACNO,F.SCB.UTS.HIST.PROD.ACNO,ERR.PRD)
    IF R.PROD.ACNO THEN
        Y.PRD.APD = FIELD(R.DETS.ARR,'|',2)
        CHANGE '::' TO @FM IN Y.PRD.APD
        R.PROD.ACNO = R.PROD.ACNO:@FM:Y.PRD.APD         
        CALL F.WRITE(FN.SCB.UTS.HIST.PROD.ACNO,Y.IN.ID,R.PROD.ACNO)
        Y.FILE.LOG = Y.IN.ID:" - EXISTING RECORD APPEND TO THE TABLE"
        GOSUB FILE.WRITE
    END ELSE       
        Y.PRD.APD = FIELD(R.DETS.ARR,'|',2)
        CHANGE '::' TO @FM IN Y.PRD.APD
        R.PROD.ACNO = Y.PRD.APD          
        CALL F.WRITE(FN.SCB.UTS.HIST.PROD.ACNO,Y.IN.ID,R.PROD.ACNO)
        Y.FILE.LOG = Y.IN.ID:" - NEW RECORD WRITTEN TO THE TABLE"
        GOSUB FILE.WRITE
    END
RETURN
*------------------------------------------------
FILE.WRITE:
*---------------------------
    
    WRITESEQ Y.FILE.LOG APPEND TO Y.NS.FILEPATH ELSE
        CALL OCOMO("WRITE PRODACCNO")
    END
RETURN

END
*------------------------------------------------------------------------------
