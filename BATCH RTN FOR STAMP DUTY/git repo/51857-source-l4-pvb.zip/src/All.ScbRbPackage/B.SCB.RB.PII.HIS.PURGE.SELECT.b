$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PII.HIS.PURGE.SELECT
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
*
* ADO Ref				       2653147
*
* Routine Type                 BATCH Job
*
* Attached To                  BATCH>SNG/B.SCB.RB.PII.HIS.PURGE
*
* Workflow                     This Multi Thread Service will first look for the file presence in SAVEDLISTS>PARTY.PURGE.REL.IDS
*
*                              - If above said file present in SL then service will execute only purging of underlying history
*                              records of those REL-IDS by keeping CURR.NO EQ "1" and no.of records parameterized.
*                               
*                              - If there is no file present in SL then service will select the SCB.RSG.PARTY.DETAILS table and
*                              proceed with the purging activity accordingly.
*
*                              - In both the cases, if the Live CURR.NO < Hist Retain Value (Param Value + 1) then purging activity
*                              aganist that RELID will be skipped and proceed with next in the loop.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        05/Jan/2024      2653147             Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_B.SCB.RB.PII.HIS.PURGE.COMMON

	GOSUB PROCESS

	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********

	READLIST SEL.LIST FROM 'PARTY.PURGE.REL.IDS' ELSE 
		SEL.CMD = "SELECT ":FN.PARTY.DETS:" WITH CURR.NO GT '":Y.HIST.RETAIN.VAL:"'"
		CALL EB.READLIST(SEL.CMD,SEL.LIST,'',LIST.CNT,SEL.ERR)
	END
	
	CALL BATCH.BUILD.LIST("",SEL.LIST)
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END