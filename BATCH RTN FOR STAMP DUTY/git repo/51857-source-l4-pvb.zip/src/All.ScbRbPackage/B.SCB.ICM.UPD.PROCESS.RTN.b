* @ValidationCode : MjotNDY3MDQwNzEyOklTTy04ODU5LTE6MTY5MTEyOTQ4NzU1MzoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 04 Aug 2023 11:41:27
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.ICM.UPD.PROCESS.RTN
*----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-30972
* Developed By                   :       1667095
* Developed On                   :       05-Jul-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* The purpose of this routine is to trigger UpdateProductLinkage ICM call using Consumer API during SAM Creation
*--------------------------------------------------------------------------------------------
* Called From:  Batch SNG/SCB.RSG.ONLINE.API.CALL
*--------------------------------------------------------------------------------------------
* Modification History :
* 11/07/2023	1667095		CPSGMIG-29618 Changes done to default consol flag for NTW flow and
*											handled error messages to update Live table
* 17/07/2023	1667095		CPSGMIG-31269 Changes done to send the correct profile role
* 04/08/2023    1663000     CPSGMIG-32579 Changes to use T24 Format API response for validation
* 10-Aug-2023   1648769         CPSGMIG-32375 - Rel ID Delimiters needs to be fixed from '-' to ':' for Joint Accounts.
*---------------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT
    $INSERT I_F.SCB.RB.ICM.PSS.LIV
    $INSERT I_F.ST.SCB.RB.SAM.AUTH.API.CONCAT

    GOSUB INITIALISE
    GOSUB SELECTION.PROCESS

    
RETURN
*---------*
INITIALISE:
*---------*
   
* Open Files
    FN.CUSTOMER             = 'F.CUSTOMER'                    ; F.CUSTOMER             = '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.EBBS.REL.CONCAT      = 'F.ST.SCB.RSG.EBBS.REL.CONCAT'  ; F.EBBS.REL.CONCAT      = '' ; CALL OPF(FN.EBBS.REL.CONCAT,F.EBBS.REL.CONCAT)
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'        ;	F.SCB.WM.H.LOCAL.PARAM = '' ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
    FN.SCB.RB.ICM.PSS.LIV   = 'F.SCB.RB.ICM.PSS.LIV'          ; F.SCB.RB.ICM.PSS.LIV   = '' ; CALL OPF(FN.SCB.RB.ICM.PSS.LIV,F.SCB.RB.ICM.PSS.LIV)
	
	FN.SL  = '&SAVEDLISTS&' ; F.SL = '' ; CALL OPF(FN.SL,F.SL)
    R.SL   = '' ; SL.ERR = ''
    
* Initialise Variables
    YDL              = '|'
    Y.ICM.ARR        = ''
    
    FN.ST.SCB.RB.SAM.AUTH.API.CONCAT = 'F.ST.SCB.RB.SAM.AUTH.API.CONCAT'
    FV.ST.SCB.RB.SAM.AUTH.API.CONCAT = ''
    CALL OPF(FN.ST.SCB.RB.SAM.AUTH.API.CONCAT,FV.ST.SCB.RB.SAM.AUTH.API.CONCAT)
    
    FN.SAM = 'F.SEC.ACC.MASTER'
    FV.SAM = ''
    CALL OPF(FN.SAM,FV.SAM)
    
RETURN

*-----------------*
SELECTION.PROCESS:
*-----------------*
    SEL.CMD = "SELECT ":FN.ST.SCB.RB.SAM.AUTH.API.CONCAT
    SEL.LIST =""
    CALL EB.READLIST(SEL.CMD,SEL.LIST,"",NO.REC,ERR.LIST)
    Y.CONCAT.TXN.ID = ''
    TXN.POS = ''
    LOOP
        REMOVE Y.CONCAT.TXN.ID FROM SEL.LIST SETTING TXN.POS
    WHILE Y.CONCAT.TXN.ID : TXN.POS
        Y.SAM.ID = FIELD(Y.CONCAT.TXN.ID,'*',1)
        R.SAM.REC = ''
        E.SAM.ERR = ''
        CALL F.READ(FN.SAM,Y.SAM.ID,R.SAM.REC,FV.SAM,E.SAM.ERR)
        Y.BLOCKING.DATE = R.SAM.REC<SC.SAM.BLOCKING.DATE>
        Y.CLOSURE.DATE = R.SAM.REC<SC.SAM.CLOSURE.DATE>
        Y.START.DATE = R.SAM.REC<SC.SAM.START.DATE>
        Y.DATE.TIME = R.SAM.REC<SC.SAM.DATE.TIME>
        Y.REFERENCE.CURRENCY = R.SAM.REC<SC.SAM.REFERENCE.CURRENCY>
        Y.ADVICE.INDEX = R.SAM.REC<SC.SAM.ADVICE.INDEX>
        
        GOSUB GET.VALUES
        GOSUB DO.PROCESS
    REPEAT
RETURN

*---------*
GET.VALUES:
*---------*

* Get LRF Position
    LOC.REF.APP = 'CUSTOMER'
    LOC.REF.FLD = 'LR.PFOLIO.KEY' :@VM: 'L.O.B' :@VM: 'LR.POS.MIG.DT'
    LOC.REF.POS = ''
    CALL MULTI.GET.LOC.REF(LOC.REF.APP,LOC.REF.FLD,LOC.REF.POS)

    Y.LRPFOLIO.POS = LOC.REF.POS<1,1>
    Y.LOB.POS      = LOC.REF.POS<1,2>
    Y.POSMIG.POS   = LOC.REF.POS<1,3>
       
* Read Parameter
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,"SCB.ICM.UPL.PARM",R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.PARAM)
    Y.FIELD.NAME  = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.FIELD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>

    LOCATE "CUST.SECTOR" IN Y.FIELD.NAME<1,1> SETTING Y.FL.POS THEN              ;* Sector Code to Identify ICM Portfolios
        Y.CU.SECTOR.LIST = Y.FIELD.VALUE<1,Y.FL.POS>
        CONVERT @SM TO @VM IN Y.CU.SECTOR.LIST
    END
    
    LOCATE "ERROR.CODE" IN Y.FIELD.NAME<1,1> SETTING Y.FL.POS THEN              ;* Error Code to validate from ICM response
        Y.ERR.CODE.LIST = Y.FIELD.VALUE<1,Y.FL.POS>
        CONVERT @SM TO @VM IN Y.ERR.CODE.LIST
    END
    
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    
    R.CUSTOMER = '' ; CUST.ERR = ''
    Y.CUS.ID = FIELD(Y.SAM.ID,'-',1)
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUSTOMER,F.CUSTOMER,CUST.ERR)
    Y.CUS.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
            
RETURN
*---------*
DO.PROCESS:
*---------*
    IF (R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS> MATCHES Y.ALLOWED.LOB) AND (R.CUSTOMER<EB.CUS.SECTOR> MATCHES Y.CU.SECTOR.LIST) AND (R.CUSTOMER<EB.CUS.LOCAL.REF,Y.POSMIG.POS> NE "") THEN

        IF (Y.BLOCKING.DATE EQ "") AND (Y.CLOSURE.DATE EQ "") THEN         ;*product reference status
            Y.PROD.REF.STAT = "01"                                   ;* Active/Normal
        END ELSE
            IF (Y.CLOSURE.DATE NE "") AND (Y.CLOSURE.DATE LE TODAY) THEN
                Y.PROD.REF.STAT = "04"                               ;* Closed
            END ELSE
                Y.PROD.REF.STAT = "03"                               ;* Suspend
            END
        END
    
*product-open-date
        Y.SAM.OPEN.DATE = '' ; Y.SAM.OPEN.DATE = Y.START.DATE
        Y.SAM.OPEN.DATE = Y.SAM.OPEN.DATE[1,4]:'-':Y.SAM.OPEN.DATE[5,2]:'-':Y.SAM.OPEN.DATE[7,2]
    
*tp-status-changed-date
        Y.SAM.DATE.TM  = '' ; Y.SAM.DATE = ''
        Y.SAM.DATE.TM  = Y.DATE.TIME
        Y.SAM.DATE     = OCONV(ICONV(Y.SAM.DATE.TM[1,6]<1,1>,'D'),'D')
        Y.SAM.DATE     = Y.SAM.DATE[8,4]:'-':Y.SAM.DATE.TM[3,2]:'-':Y.SAM.DATE.TM[5,2]

        Y.LR.PFOLIO.ARR = '' ; Y.LR.PFOLIO.ARR = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LRPFOLIO.POS>
        Y.PRIM.REL.NUM  = '' ; Y.PRIM.REL.NUM  = FIELD(Y.LR.PFOLIO.ARR,':',1)
        CHANGE ':' TO @FM IN Y.LR.PFOLIO.ARR
        
        R.SLREC = "" ; Y.ERROR.CODE = "" ; Y.ERROR.DESC = ""
        Y.FLAG = "N"
                              
        LOOP
            REMOVE Y.REL.ID FROM Y.LR.PFOLIO.ARR SETTING Y.PFOLIO.POS
        WHILE Y.REL.ID : Y.PFOLIO.POS
        
            IF Y.ERROR.CODE OR Y.ERROR.DESC THEN                ;* Do not proceed with next Relid if Failure identified
                BREAK
            END ELSE
                R.EBBS.REL.CONCAT = '' ; ERR.REL.CONCAT = '' ; Y.PFOLIO.ROLE = '' ; Y.MANDATE.KEY = '' ; Y.PRI.SEC.IND = ''
                CALL F.READ(FN.EBBS.REL.CONCAT,Y.REL.ID,R.EBBS.REL.CONCAT,F.EBBS.REL.CONCAT,ERR.REL.CONCAT)
        
                Y.MANDATE.KEY  = R.EBBS.REL.CONCAT<ST.RSG.EBBS.MANDATE.KEY>
                Y.PRI.SEC.IND  = R.EBBS.REL.CONCAT<ST.RSG.EBBS.PRIM.SEC.INDICATOR>
            
                CHANGE @VM TO @FM IN Y.MANDATE.KEY
                CHANGE @VM TO @FM IN Y.PRI.SEC.IND
                Y.REL.POS = ''
                LOCATE Y.CUS.ID IN Y.MANDATE.KEY SETTING Y.REL.POS THEN              ;* Check Primary/Secondary
                    
                    IF Y.PRI.SEC.IND<Y.REL.POS> EQ 'Primary' THEN
                        Y.PFOLIO.ROLE = 'PRI'
                    END ELSE
                        Y.PFOLIO.ROLE = 'SEC'
                    END
                
                    Y.CONSOL.FLAG = 'N'
                    R.SLREC<-1> = 'CONSOLIDATE FLAG VALUE - ': Y.CONSOL.FLAG
           
                    Y.ICM.ARR  = '' ; GOSUB FRAME.DATA
                    IF Y.PFOLIO.ROLE EQ 'PRI' THEN
                        Y.PARAM.ID = "UPL.TRIGGER.T24.TO.ICM"
                    END ELSE
                        Y.PARAM.ID = "UPL.TRIGGER.T24.TO.ICM.SEC"
                    END
                    GOSUB SEND.TO.ICM
                        
                END ELSE
                    Y.FLAG = "Y"
                END
                GOSUB CAPTURE.ICM.RESP
            END
        REPEAT
       
        IF R.SLREC THEN
            Y.SL.ID = "SAM.UPL.":Y.SAM.ID
            CALL F.WRITE(FN.SL,Y.SL.ID,R.SLREC)
        END
    
    END
    
RETURN
*---------*
FRAME.DATA:
*---------*

    Y.ICM.ARR  = Y.SAM.ID                                :YDL          ;*  1. Portfolio Id of the Customer
    Y.ICM.ARR := Y.REFERENCE.CURRENCY      :YDL          ;*  2. Portfolio Currency
    Y.ICM.ARR := Y.PFOLIO.ROLE                         :YDL          ;*  3. Profile Role to indicator Primary or Secondary
    Y.ICM.ARR := Y.PROD.REF.STAT                       :YDL          ;*  4. Product Reference Status
    
    IF Y.PFOLIO.ROLE EQ 'PRI' THEN
        Y.ICM.ARR := Y.ADVICE.INDEX        :YDL          ;*  5. Product attached to the Address Type
    END
    
    Y.ICM.ARR := Y.REL.ID                              :YDL          ;*  6. Relationship of the Customer
    Y.ICM.ARR := Y.PRIM.REL.NUM                        :YDL          ;*  7. Primary Relationship of the Customer
    Y.ICM.ARR := Y.SAM.OPEN.DATE                       :YDL          ;*  8. product-open-date
    Y.ICM.ARR := Y.SAM.DATE                            :YDL          ;*  9. tp-status-changed-date
    Y.ICM.ARR := Y.CONSOL.FLAG                         :YDL          ;* 10. consolidate-flag
    
RETURN
*----------*
SEND.TO.ICM:
*----------*
    
    JSON.RESP = "" ; FMT.API.RESP = "" ; DEFINED.RESP.T24.FMT = "" ; Y.CONSOL.FLAG = ''
    
    CALL SCB.GET.API.RESPONSE(Y.PARAM.ID,Y.ICM.ARR,JSON.RESP,FMT.API.RESP,DEFINED.RESP.T24.FMT)

    R.SLREC<-1> = "SCB.API.CONSUMER REC ID - ":Y.PARAM.ID
    R.SLREC<-1> = "--------------------------INCOMING API VALUES FOR RELID - ":Y.REL.ID:" ------------------------------"
    R.SLREC<-1> = Y.ICM.ARR
    R.SLREC<-1> = "--------------------------JSON.RESP ARG VALUE------------------------------"
    R.SLREC<-1> = JSON.RESP
    R.SLREC<-1> = "--------------------------FMT.API.RESP ARG VALUE---------------------------"
    R.SLREC<-1> = FMT.API.RESP
    R.SLREC<-1> = "--------------------------DEFINED.RESP.T24.FMT ARG VALUE-------------------"
    R.SLREC<-1> = DEFINED.RESP.T24.FMT
    R.SLREC<-1> = "----------------------------------------------------------------------------------------------------------------------------------"

* Temp code to store json message for dev testing -s
  
    Y.FILE = 'JSON.':Y.REL.ID                                          ;* For UPL Trigger
    CALL F.READ(FN.SL,Y.FILE,R.SL,F.SL,SL.ERR)
    IF R.SL THEN DEFINED.RESP.T24.FMT = R.SL
*Temp -e

    Y.ERROR.CODE     = '' ; Y.ERROR.DESC  = '' ; Y.STATUS.ARR     = '' ; Y.TITLE.ARR   = '' ; Y.MSG.ARR    = '' ; Y.ERROR.CODE.ARR  = '' ; Y.ERROR.DESC.ARR = ''
    Y.MSG.ARR        = FIELD(DEFINED.RESP.T24.FMT<1>,"=",2)               ;* Extract message
 
    IF Y.MSG.ARR NE '' AND Y.MSG.ARR NE 'null' THEN
        Y.ERROR.CODE = "UPSTREAM.SERVER.TIMEOUT"
        Y.ERROR.DESC = Y.MSG.ARR
    END ELSE
* To Check Status Error Codes
        Y.STATUS.ARR     = FIELD(DEFINED.RESP.T24.FMT<2>,"=",2)                ;* Extract status code
        Y.TITLE.ARR      = FIELD(DEFINED.RESP.T24.FMT<3>,"=",2)                ;* Extract title
    
        IF (Y.STATUS.ARR NE '') AND (Y.STATUS.ARR NE 'null') THEN
            LOOP
                REMOVE Y.STAT.CODE FROM Y.ERR.CODE.LIST SETTING Y.CODE.POS
            WHILE Y.STAT.CODE : Y.CODE.POS
                IF (Y.STAT.CODE EQ Y.STATUS.ARR) THEN
                    Y.ERROR.CODE = Y.STAT.CODE
                    Y.ERROR.DESC = Y.TITLE.ARR
                END
            REPEAT
        END ELSE
            Y.ERROR.CODE.ARR = FIELD(DEFINED.RESP.T24.FMT<4>,"=",2)               ;* Extract error-code
            Y.ERROR.DESC.ARR = FIELD(DEFINED.RESP.T24.FMT<5>,"=",2)               ;* Extract error-description
           
* To capture ICM defined response Errors
            IF NOT(Y.ERROR.CODE) AND (Y.ERROR.CODE.ARR NE 'null') AND (Y.ERROR.DESC.ARR NE 'null') THEN
                Y.ERROR.CODE = Y.ERROR.CODE.ARR
                Y.ERROR.DESC = Y.ERROR.DESC.ARR
            END
        END
    END

    R.SLREC<-1> = "DEFINED.RESP.T24.FMT After conversion - ": DEFINED.RESP.T24.FMT
    R.SLREC<-1> = "REL ID - "     :Y.REL.ID
    R.SLREC<-1> = "ERROR CODES - ":Y.ERROR.CODE
    R.SLREC<-1> = "ERROR DESC  - ":Y.ERROR.DESC
    
RETURN
*---------------*
CAPTURE.ICM.RESP:
*---------------*
    
    Y.ICM.RESP.ID = Y.SAM.ID:'*':Y.REL.ID:'*':TODAY
    
    R.SCB.RB.ICM.PSS.LIV = '' ; SCB.RB.ICM.PSS.LIV.ERR = ''
    CALL F.READ(FN.SCB.RB.ICM.PSS.LIV,Y.ICM.RESP.ID,R.SCB.RB.ICM.PSS.LIV,F.SCB.RB.ICM.PSS.LIV,SCB.RB.ICM.PSS.LIV.ERR)
            
    IF NOT(R.SCB.RB.ICM.PSS.LIV) THEN
        R.SCB.RB.ICM.PSS.LIV<ICM.PSS.CUSTOMER.NO>   = Y.CUS.ID
        R.SCB.RB.ICM.PSS.LIV<ICM.PSS.PORTFOLIO.NO>  = Y.SAM.ID
        R.SCB.RB.ICM.PSS.LIV<ICM.PSS.MESSAGE.DATE>  = TODAY
        R.SCB.RB.ICM.PSS.LIV<ICM.PSS.REL.ID>        = Y.REL.ID
    END
    
    BEGIN CASE
        
        CASE Y.FLAG EQ "Y"
            R.SCB.RB.ICM.PSS.LIV<ICM.PSS.ERROR.CODE> = "T24.INVALID.PFOLIO.LINK"
            R.SCB.RB.ICM.PSS.LIV<ICM.PSS.ERROR.DESC> = "Portfolio linked to Invalid RelId"
            R.SCB.RB.ICM.PSS.LIV<ICM.PSS.STATUS> = "FAILURE"
 
        CASE Y.FLAG EQ "N"

            IF Y.ERROR.CODE OR Y.ERROR.DESC THEN                         ;* To update ErrorCode/ErrorMessage for ICM failure
                R.SCB.RB.ICM.PSS.LIV<ICM.PSS.ERROR.CODE> = Y.ERROR.CODE
                R.SCB.RB.ICM.PSS.LIV<ICM.PSS.ERROR.DESC> = Y.ERROR.DESC
                R.SCB.RB.ICM.PSS.LIV<ICM.PSS.STATUS> = "FAILURE"
            END ELSE
                R.SCB.RB.ICM.PSS.LIV<ICM.PSS.ERROR.CODE> = ''
                R.SCB.RB.ICM.PSS.LIV<ICM.PSS.ERROR.DESC> = ''
                R.SCB.RB.ICM.PSS.LIV<ICM.PSS.STATUS> = "SUCCESS"
            END
	
    END CASE
    CALL F.WRITE(FN.SCB.RB.ICM.PSS.LIV,Y.ICM.RESP.ID,R.SCB.RB.ICM.PSS.LIV)
            
    R.SLREC<-1> = "R.SCB.RB.ICM.PSS.LIV - ":R.SCB.RB.ICM.PSS.LIV
   
      
RETURN
END
