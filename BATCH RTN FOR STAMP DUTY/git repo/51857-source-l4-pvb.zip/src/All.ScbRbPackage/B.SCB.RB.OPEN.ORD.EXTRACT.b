$PACKAGE All.ScbRbPackage
	SUBROUTINE B.SCB.RB.OPEN.ORD.EXTRACT
*-----------------------------------------------------------------------------
* DESCRIPTION:
*------------
* This routine is used to generate a report based on the local table SCB.SEC.OPEN.ORD.TRD.STATUS.
*---------------------------------------------------------------
* Attached To : COB
* Attached As : Batch routine
*-----------------------------------------------
* Dependencies:
*---------------
* CALLS : -NA-
* CALLED BY : -NA-
*
* Revision History:
*------------------
*   Date               who           Reference            Description
* 12-Apr-2022       Lavanya L       CPSGMIG-2420        Initial Creation
*----------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.SCB.SEC.OPEN.ORD.TRD.STATUS
	$INSERT I_F.DATES
	
	GOSUB INITIALISE
	GOSUB HDR.DETAILS
	GOSUB SEL.PROCESS
	GOSUB WRITE.DETS
	
	RETURN
*-----------------------------------------------------------------------------------	
INITIALISE:
*----------
	FN.TRD.STATUS = 'F.SCB.SEC.OPEN.ORD.TRD.STATUS'
	F.TRD.STATUS = ''
	CALL OPF(FN.TRD.STATUS,F.TRD.STATUS)
	
	FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
	
	Y.FINAL.FILE.NAME = 'T24-SG-RB-PENDSUBRED-ORDERS-':TODAY:'.CSV'
	Y.ARRAY = ''
	
	SEL.LIST = ''
	NO.OF.REC = ''
	ERR.LIST = ''
	Y.INT = 1
	
	RETURN
*-----------------------------------------------------------------------------------	
HDR.DETAILS:
*-----------
	Y.HDR.ARRAY = 'Order Id,Order Date'
	Y.HDR.ARRAY := ',Customer No'
	Y.HDR.ARRAY := ',Portfolio No'
	Y.HDR.ARRAY := ',Security Code'
	Y.HDR.ARRAY := ',Book Nominals'
	Y.HDR.ARRAY := ',Depository'
	Y.HDR.ARRAY := ',Value in Settlement Ccy'
	Y.HDR.ARRAY := ',Buy Sell'
	Y.HDR.ARRAY := ',Nominee'
	Y.HDR.ARRAY := ',LR.PAYMENT.TYPE'
	Y.HDR.ARRAY := ',Deal Status'
	Y.HDR.ARRAY := ',Order  Status'
	Y.HDR.ARRAY := ',Trade Id'
	Y.HDR.ARRAY := ',Trade Status'
	
	RETURN
*-----------------------------------------------------------------------------------
SEL.PROCESS:
*-----------

	SEL.CMD = 'SELECT ':FN.TRD.STATUS
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.LIST)
	LOOP
	WHILE Y.INT LE NO.OF.REC
		GOSUB PROCESS
	Y.INT++
	REPEAT
	
	RETURN
*-----------------------------------------------------------------------------------	
PROCESS:
*-------
	Y.FILE.ARRAY = ''
	Y.SEL.ID = SEL.LIST<Y.INT>
	CALL F.READ(FN.TRD.STATUS,Y.SEL.ID,R.TRD.STATUS,F.TRD.STATUS,ERR.TRD.STATUS)
	Y.FILE.ARRAY = Y.SEL.ID
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.ORDER.DATE> 
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.CUSTOMER.NO> 
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.PORTFOLIO.NO>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.SECURITY.CODE>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.BOOK.NOMINALS>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.DEPOSITORY>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.VALUE.CCY>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.BUY.SELL>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.NOMINEE>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.PAYMENT.TYPE>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.DEAL.STATUS>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.ORDER.STATUS>
	Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.TRADE.ID>
    Y.FILE.ARRAY := ',':R.TRD.STATUS<SCB.TRADE.STATUS>
	
	Y.ARRAY<-1> = Y.FILE.ARRAY
	RETURN
*-----------------------------------------------------------------------------------	
WRITE.DETS:
*----------
* Change the time stamp to the external format
*
    Y.STAMP = OCONV(TIME(),"MTS")
*
* Footer should be in the following format
* EOF,2012-03-09 00:32,3086,2012-03-12
*
    Y.TRAILER.ARRAY = 'EOF':',':TODAY[1,4]:'-':TODAY[5,2]:'-':TODAY[7,2]:' ':Y.STAMP[1,5]:',':NO.OF.REC
    Y.TRAILER.ARRAY := ',':R.DATES(EB.DAT.NEXT.WORKING.DAY)[1,4]:'-':R.DATES(EB.DAT.NEXT.WORKING.DAY)[5,2]:'-':R.DATES(EB.DAT.NEXT.WORKING.DAY)[7,2]
*
* Finally write the single file to the AMEX.FILES path
*
*	IF Y.ARRAY THEN
		Y.FINAL.ARRAY = Y.HDR.ARRAY:@FM:Y.ARRAY:@FM:Y.TRAILER.ARRAY
		WRITE Y.FINAL.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME
*	END
	RETURN
