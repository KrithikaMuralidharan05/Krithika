$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.PORTFOL.EXTRACT.M(Y.SAM.ID)
*----------------------------------------------------------------------------------------
*
*
*------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864
*
* 17-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
*
* 27/10/2022 - Swaminathan.S.R - CPSGMIG-13848 - Report modification to send ISA details
*                                Copy of existing B.SCB.RB.EBBS.PORTFOL.EXTRACT routine + ISA Details added as per CPSGMIG-13848
*
* 30/10/2022 - Swaminathan.S.R - CPSGMIG-13848 - Day0 file doesnt require date check, so date check is removed
*                                For Porfolio records, ACTION.TYPE = 'A' has been set & ACTION.STATUS = '1' has been set
*                                For ISA records, ACTION.TYPE = 'C' has been set & ACTION.STATUS = '4' has been set
*
* 04/12/2022 - Sasi V - PF.SKIP - To suppress configured portfolio in SCB.WM.H.LOCAL.PARAM>SCB.RB.DPL.PF
* 24-Mar-2023 - Lavanya L - CPSGMIG-21169 - Tranche requirement
* 08-Aug-2023   Prabhu.L          CPSGMIG-32375 - Rel ID Delimiters needs to be fixed for Joint Accounts
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM    ;*CPSGMIG-13878 S/E
    $INSERT I_B.SCB.RB.EBBS.PORTFOL.EXT.M.COMMON
*------------------------------------------------------------------------------------------
* PF.SKIP - S
	LOCATE Y.SAM.ID IN Y.PF.LIST<1> SETTING PF.SKIP.POS THEN
		RETURN
	END
* PF.SKIP - E
*CPSGMIG-13878 Start
    GOSUB CHECK.CUS.ALLOWED.LIST
**CPSGMIG-21169 - S
*    IF (Y.CUS.ALLOWED.FLAG EQ 1) OR (Y.SECTOR EQ '23') THEN
	IF Y.FILE.FLAG EQ "TRANCHE" AND (Y.MIG.DAT EQ TODAY) THEN
*CPSGMIG-21169 - E
*CPSGMIG-13878 End
        	Y.DELIM = '|'
*IF Y.LOB.VAL EQ '8' AND TODAY[3,6] = Y.DATE.TIME[1,6] THEN  ;* Day0 file doesnt require date check, so date check is removed
*        IF Y.LOB.VAL EQ '8' THEN ;*Moved to .SELECT routine.
            GOSUB PROCESS
            GOSUB WRITE.DETS
*CPSGMIG-21169 - S            
*            Y.TP.ACCT.NO = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS>
*            IF Y.TP.ACCT.NO NE '' THEN
*                GOSUB ISA.PROCESS
*            END
*        END

	END  ;*CPSGMIG-13878 S/E
	ELSE IF Y.FILE.FLAG EQ "FULL" THEN
        Y.DELIM = '|'
        GOSUB PROCESS
        GOSUB WRITE.DETS    
    END
**CPSGMIG-21169 - E
	RETURN
*
*------------------------------------------------------------------------------------------
CHECK.CUS.ALLOWED.LIST:
*------------------------------------------------------------------------------------------
*CPSGMIG-21169 - S
*    Y.CUS.ALLOWED.FLAG = '' ; CUST.POS = ''
*    Y.CUS.ID = FIELD(Y.SAM.ID,'-',1)
*    LOCATE Y.CUS.ID IN Y.LOC.CUST.LIST<1,1> SETTING CUST.POS THEN
*        Y.CUS.ALLOWED.FLAG = 1
*    END
**CPSGMIG-21169 - E
    R.SAM = ''
    Y.SAM.ERR = ''
    CALL F.READ(FN.SEC.ACC.MAST,Y.SAM.ID,R.SAM,F.SEC.ACC.MAST,Y.SAM.ERR)
    Y.CUST.NO = R.SAM<SC.SAM.CUSTOMER.NUMBER>
    Y.DATE.TIME = R.SAM<SC.SAM.DATE.TIME,1>
    Y.MIG.DAT = R.SAM<SC.SAM.LOCAL.REF,Y.LR.POS.MIG.DT.POS>			;**CPSGMIG-21169 - S/E	
    R.CUST = ''
    ERR.CUST = ''
    CALL F.READ(FN.CUST,Y.CUST.NO,R.CUST,F.CUST,ERR.CUST)
*    Y.LOB.VAL = R.CUST<EB.CUS.LOCAL.REF,Y.CUST.LOB.POS>
	Y.SECTOR  = R.CUST<EB.CUS.SECTOR>
    
*
RETURN
*
*------------------------------------------------------------------------------------------
PROCESS:
*------------------------------------------------------------------------------------------
*
    Y.DATE.OPEN = R.SAM<SC.SAM.START.DATE>
	Y.DATE.CLOSE = R.SAM<SC.SAM.CLOSURE.DATE>
	Y.SETT.CURR = R.SAM<SC.SAM.REFERENCE.CURRENCY>
*CPSGMIG-13848 Start
    Y.ACT.STATUS = '01'
    Y.ACTION.TYPE = 'A'
*CPSGMIG-13848 End
	Y.EBBS.REL.ID1 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,1>
	Y.EBBS.REL.ID2 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,2>
	Y.EBBS.REL.ID3 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,3>
	Y.EBBS.REL.ID4 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,4>
*
	Y.PRIM.SEC.ID1 = UPCASE(R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,1>)
	Y.PRIM.SEC.ID2 = UPCASE(R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,2>)
	Y.PRIM.SEC.ID3 = UPCASE(R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,3>)
	Y.PRIM.SEC.ID4 = UPCASE(R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,4>)
*
	BEGIN CASE
        CASE Y.PRIM.SEC.ID1 = 'PRIMARY'
            Y.PRIM.SEC.ID1  = 'PRI'
        CASE Y.PRIM.SEC.ID1 = 'SECONDARY'
            Y.PRIM.SEC.ID1  = 'SEC'
	END CASE
*
	BEGIN CASE
        CASE Y.PRIM.SEC.ID2 = 'PRIMARY'
            Y.PRIM.SEC.ID2  = 'PRI'
        CASE Y.PRIM.SEC.ID2 = 'SECONDARY'
            Y.PRIM.SEC.ID2  = 'SEC'
	END CASE
*
	BEGIN CASE
        CASE Y.PRIM.SEC.ID3 = 'PRIMARY'
            Y.PRIM.SEC.ID3  = 'PRI'
        CASE Y.PRIM.SEC.ID3 = 'SECONDARY'
            Y.PRIM.SEC.ID3  = 'SEC'
	END CASE
*
	BEGIN CASE
        CASE Y.PRIM.SEC.ID4 = 'PRIMARY'
            Y.PRIM.SEC.ID4  = 'PRI'
        CASE Y.PRIM.SEC.ID4 = 'SECONDARY'
            Y.PRIM.SEC.ID4  = 'SEC'
	END CASE
*
    Y.DAT.IND = 'D'
    Y.SAM.DATA = Y.DAT.IND:Y.DELIM					;* Data Indicator
    Y.SAM.DATA := Y.ACTION.TYPE:Y.DELIM			    ;* Action Type
*
    Y.SAM.DATA := Y.SAM.ID:Y.DELIM			       	;* SAM_ID
    Y.SAM.DATA := Y.EBBS.REL.ID1:Y.DELIM			;* CUST-ID-01
    Y.SAM.DATA := Y.PRIM.SEC.ID1:Y.DELIM			;* CUST-A/C- REL-01
    Y.SAM.DATA := Y.EBBS.REL.ID2:Y.DELIM		    ;* CUST-ID-02
    Y.SAM.DATA := Y.PRIM.SEC.ID2:Y.DELIM			;* CUST-A/C- REL-02
    Y.SAM.DATA := Y.EBBS.REL.ID3:Y.DELIM			;* CUST-ID-03
    Y.SAM.DATA := Y.PRIM.SEC.ID3:Y.DELIM			;* CUST-A/C- REL-03
    Y.SAM.DATA := Y.EBBS.REL.ID4:Y.DELIM			;* CUST-ID-04
    Y.SAM.DATA := Y.PRIM.SEC.ID4:Y.DELIM			;* CUST-A/C- REL-04
*
    Y.SAM.DATA := '':Y.DELIM					    ;* ISCI-AC-PRD
    Y.SAM.DATA := '':Y.DELIM					    ;* ACCOUNT-BRANCH
*
    Y.SAM.DATA := Y.DATE.OPEN:Y.DELIM				;* DATE-OPENED
    Y.SAM.DATA := Y.ACT.STATUS:Y.DELIM				;* ACT-STATUS
    Y.SAM.DATA := Y.DATE.CLOSE:Y.DELIM				;* DATE-CLOSED
    Y.SAM.DATA := Y.SETT.CURR:Y.DELIM			    ;* SETTLE-CURRCODE
*
    Y.SAM.DATA := ''								;* SETTLE-ACT-NUMBER
*
RETURN
*
*------------------------------------------------------------------------------------------
ISA.PROCESS:
*------------------------------------------------------------------------------------------
*
    Y.DATE.OPEN = R.SAM<SC.SAM.START.DATE>
	Y.DATE.CLOSE = TODAY
	Y.SETT.CURR = R.SAM<SC.SAM.REFERENCE.CURRENCY>
*CPSGMIG-13848 Start
    Y.ACT.STATUS = '04'
    Y.ACTION.TYPE = 'C'
*CPSGMIG-13848 End
    Y.PFOLIO.KEY = R.SAM<SC.SAM.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
    PFOLIO.KEY.PRIMARY = FIELD(Y.PFOLIO.KEY,":",1)
	Y.PRIM.SEC.ID1 = 'PRI'
    PFOLIO.SECONDARY1  = FIELD(Y.PFOLIO.KEY,":",2)
	Y.PRIM.SEC.ID2 = ''
	IF PFOLIO.SECONDARY1 NE '' THEN
        Y.PRIM.SEC.ID2 = 'SEC'
	END
    PFOLIO.SECONDARY2  = FIELD(Y.PFOLIO.KEY,":",3)
	Y.PRIM.SEC.ID3 = ''
	IF PFOLIO.SECONDARY2 NE '' THEN
        Y.PRIM.SEC.ID3 = 'SEC'
	END
    PFOLIO.SECONDARY3  = FIELD(Y.PFOLIO.KEY,":",4)
	Y.PRIM.SEC.ID4 = ''
	IF PFOLIO.SECONDARY3 NE '' THEN
        Y.PRIM.SEC.ID4 = 'SEC'
	END
*
    CHANGE @SM TO @FM IN Y.TP.ACCT.NO
    TP.ACCT.CNT = DCOUNT(Y.TP.ACCT.NO,@FM)
*
    IF Y.SECTOR EQ "23" THEN
        GOSUB CORP.ISA
    END ELSE
        GOSUB INDIV.ISA
    END
*
RETURN
*
*------------------------------------------------------------------------------------------
CORP.ISA:
*------------------------------------------------------------------------------------------
    IF TP.ACCT.CNT LE 1 THEN
        I = 1
        GOSUB ARRAY.FORMATION
    END ELSE
        I = 1
        LOOP
        WHILE I LE TP.ACCT.CNT
            GOSUB ARRAY.FORMATION
            I+=1
        REPEAT
    END
*
RETURN
*
*------------------------------------------------------------------------------------------
INDIV.ISA:
*------------------------------------------------------------------------------------------
    IF TP.ACCT.CNT LE 1 AND Y.TP.ACCT.NO MATCHES ISA.LISTS THEN   ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed
        I = 1
        GOSUB ARRAY.FORMATION
    END ELSE
        I = 1
        LOOP
        WHILE I LE TP.ACCT.CNT
            IF Y.TP.ACCT.NO<I> MATCHES ISA.LISTS THEN    ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed
                GOSUB ARRAY.FORMATION
            END
            I+=1
        REPEAT
    END
*
RETURN
*
*------------------------------------------------------------------------------------------
ARRAY.FORMATION:
*------------------------------------------------------------------------------------------
    Y.DAT.IND = 'D'
    Y.SAM.DATA  = Y.DAT.IND:Y.DELIM					;* Data Indicator
    Y.SAM.DATA := Y.ACTION.TYPE:Y.DELIM			    ;* Action Type
*
    Y.SAM.DATA := Y.TP.ACCT.NO<I>:Y.DELIM			;* ACT -Number
    Y.SAM.DATA := PFOLIO.KEY.PRIMARY:Y.DELIM		;* CUST-ID-01
    Y.SAM.DATA := Y.PRIM.SEC.ID1:Y.DELIM			;* CUST-A/C- REL-01
    Y.SAM.DATA := PFOLIO.SECONDARY1:Y.DELIM		    ;* CUST-ID-02
    Y.SAM.DATA := Y.PRIM.SEC.ID2:Y.DELIM			;* CUST-A/C- REL-02
    Y.SAM.DATA := PFOLIO.SECONDARY2:Y.DELIM			;* CUST-ID-03
    Y.SAM.DATA := Y.PRIM.SEC.ID3:Y.DELIM			;* CUST-A/C- REL-03
    Y.SAM.DATA := PFOLIO.SECONDARY3:Y.DELIM			;* CUST-ID-04
    Y.SAM.DATA := Y.PRIM.SEC.ID4:Y.DELIM			;* CUST-A/C- REL-04
*
    Y.SAM.DATA := '':Y.DELIM					    ;* ISCI-AC-PRD
    Y.SAM.DATA := '':Y.DELIM					    ;* ACCOUNT-BRANCH
*
    Y.SAM.DATA := Y.DATE.OPEN:Y.DELIM				;* DATE-OPENED
    Y.SAM.DATA := Y.ACT.STATUS:Y.DELIM				;* ACT-STATUS
    Y.SAM.DATA := Y.DATE.CLOSE:Y.DELIM				;* DATE-CLOSED
    Y.SAM.DATA := Y.SETT.CURR:Y.DELIM			    ;* SETTLE-CURRCODE
*
    Y.SAM.DATA := ''								;* SETTLE-ACT-NUMBER
*
    GOSUB WRITE.DETS
*
RETURN
*
*------------------------------------------------------------------------------------------
WRITE.DETS:
*---------*
    OPENSEQ Y.APPEND.FILE,Y.FILE.NAME TO FP.SEC.ACC.MAS.LIST ELSE
    	CREATE FP.SEC.ACC.MAS.LIST ELSE
            CRT " UNABLE TO OPEN AMEX.FILES"
    	END
    END
*
* Write the Security Account Master data to AMEX.FILES
*
    WRITESEQ Y.SAM.DATA APPEND TO FP.SEC.ACC.MAS.LIST ELSE
        CRT "UNABLE TO WRITE SECURITY.MASTER EXTRACT"
    END
    CLOSESEQ FP.SEC.ACC.MAS.LIST
*
RETURN
*
*------------------------------------------------------------------------------------------
END
*------------------------------------------------------------------------------------------