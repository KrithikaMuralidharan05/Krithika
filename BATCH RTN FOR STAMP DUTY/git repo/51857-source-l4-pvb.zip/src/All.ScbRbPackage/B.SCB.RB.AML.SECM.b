$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.AML.SECM
*------------------------------------------------------------------------------------------
* This mainline routine is attched to the Batch SNG/SCB.RB.AML.SECM. This routine
* extracts the details of Security transactions and writes into a csv file.
*------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*------------------------------------------------------------------------------------------
*
* 21/07/2022 - Shreekantha. G - CPSGMIG-4971 - Copy of the existing routine AEB.AML.SECM
* 22/11/2023 - ADO-2133376    - Tejomurthy M - Introduction of PRICE column.
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.POSITION.TRANSFER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.SECURITY.TRANS
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.COMPANY.CHECK
    $INSERT I_F.AEB.PRODUCT.PARAM
    $INSERT I_F.SCB.CTP2.PROD.PARAM
    $INSERT I_F.SECURITY.SUPP
    $INSERT I_F.CUSTOMER
    $INSERT I_F.DATES
*------------------------------------------------------------------------------------------
    GOSUB INITIALISE
    GOSUB OPEN.FILES
    GOSUB FORM.HEADER			;*CPSGMIG-4971 - S/E
    GOSUB SELECT.SEC.TXN.TODAY
    GOSUB MAIN

    RETURN
*------------------------------------------------------------------------------------------
INITIALISE:
*---------*
* Initialise the variables
*
    DL = CHAR(01)
    CR = "CR"
    AML.REC.WRITE = ''
    SORTED.TXN.KEYS=''
    BRANCH.ID = ''
*
    Y.GROSS.AMT.SEC.CCY = ''
    Y.CHARGES = ''
    Y.LOCAL.TAX = ''
    Y.CU.COMMISSION = ''
    Y.CU.TAX = ''
    Y.INTEREST.AMT = ''
    Y.DEPOSITORY = ''
    SEC.STATUS = ''
*
    Y.CU.ACCOUNT.NO = ''
    Y.PRODTYPE = ''
*
    Y.CU.TAX.LCY = ''
    Y.CU.TAX.TCY = ''
    Y.MAN.TAX.TCY = ''
    Y.MAN.TAX.LCY = ''
    Y.CGT.TAX.AMT = ''
*
    Y.BR.NET.AMT = ''
*
    Y.COST = '' ; Y.NET.AMT.SEC = ''; Y.SEC.EXCH.RATE = '' ; Y.INTEREST.RATE = '' ;Y.LED.ORIG.MUREX = '' ;Y.LED.ASSOC.MUREX = ''
*
    RETURN
*------------------------------------------------------------------------------------------
OPEN.FILES:
*---------*
* opens the required files
*

    F.CUST = ""
    FN.CUST = 'F.CUSTOMER'
    CALL OPF(FN.CUST,F.CUST)
*
    F.SEC.TODAY = ""
    FN.SEC.TODAY = 'F.SEC.TRADES.TODAY'
    CALL OPF(FN.SEC.TODAY,F.SEC.TODAY)
*
    F.SEC.TRANSFER = ""
    FN.SEC.TRANSFER = 'F.SECURITY.TRANSFER'
    CALL OPF(FN.SEC.TRANSFER,F.SEC.TRANSFER)
*
    F.POS.TRANSFER = ""
    FN.POS.TRANSFER = 'F.POSITION.TRANSFER'
    CALL OPF(FN.POS.TRANSFER,F.POS.TRANSFER)
*
    F.SEC.TRANS = ""
    FN.SEC.TRANS = 'F.SECURITY.TRANS'
    CALL OPF(FN.SEC.TRANS,F.SEC.TRANS)
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
    FN.AEB.PRODUCT.PARAM = 'F.AEB.PRODUCT.PARAM'
    F.AEB.PRODUCT.PARAM = ''
    CALL OPF(FN.AEB.PRODUCT.PARAM, F.AEB.PRODUCT.PARAM)
*
    FN.SEC.SUPP = 'F.SECURITY.SUPP'
    F.SEC.SUPP = ''
    CALL OPF(FN.SEC.SUPP,F.SEC.SUPP)
*
    FN.SCB.CTP2.PROD.PARAM = 'F.SCB.CTP2.PROD.PARAM'
    F.SCB.CTP2.PROD.PARAM = ''
    CALL OPF(FN.SCB.CTP2.PROD.PARAM,F.SCB.CTP2.PROD.PARAM)
*
    FN.SEC.REV.TODAY = 'F.SEC.REVERSAL.TODAY'
    F.SEC.REV.TODAY = ''
    CALL OPF(FN.SEC.REV.TODAY,F.SEC.REV.TODAY)
*
    F.SEC.TRANSFER.HIS = ""
    FN.SEC.TRANSFER.HIS = 'F.SECURITY.TRANSFER$HIS'
    CALL OPF(FN.SEC.TRANSFER.HIS,F.SEC.TRANSFER.HIS)
*
    F.POS.TRANSFER.HIS = ""
    FN.POS.TRANSFER.HIS = 'F.POSITION.TRANSFER$HIS'
    CALL OPF(FN.POS.TRANSFER.HIS,F.POS.TRANSFER.HIS)
*
    Y.IM.USER = ''
    LOC.REF.APP = '' ; LOC.REF.FLD = '' ; LOC.REF.POS = ''
*
    LOC.REF.APP = 'SECURITY.SUPP':@FM:'SECURITY.TRANSFER':@FM:'POSITION.TRANSFER':@FM:'CUSTOMER'			;*CPSGMIG-4971 - S/E
    LOC.REF.FLD = 'LED.OP.PROD.TYP'
    LOC.REF.FLD := @FM:'LED.IM.REQ':@VM:'LED.TICKET.TYPE':@VM:'BO.STATUS':@VM:'BO.NAME':@VM:'CROSS.CCY.TXN':@VM:'LED.ORIG.MUREX':@VM:'LED.ASSOC.MUREX'
*
    LOC.REF.FLD := @VM:'SIG.ORD.REF':@VM:'ORD.TYPE':@VM:'RDR.FEE':@VM:'EDR.TRADE.DATE'
*
    LOC.REF.FLD := @VM:'TAP.REF.NO'
*
    LOC.REF.FLD := @FM:'BO.STATUS':@VM:'BO.NAME':@VM:'SIG.ORD.REF':@VM:'ORD.TYPE':@VM:'RDR.FEE':@VM:'EDR.TRADE.DATE'
*
	LOC.REF.FLD := @FM:'L.O.B'				;*CPSGMIG-4971 - S/E
	
    CALL MULTI.GET.LOC.REF(LOC.REF.APP,LOC.REF.FLD,LOC.REF.POS)
    Y.PRODTYP.POS = LOC.REF.POS<1,1>
    Y.ST.IMREQ.POS = LOC.REF.POS<2,1>
    Y.TICK.TYPE.POS = LOC.REF.POS<2,2>
*
    Y.ST.BO.STATUS.POS = LOC.REF.POS<2,3>
    Y.ST.BO.NAME.POS   = LOC.REF.POS<2,4>
    Y.CROSS.CCY.POS    = LOC.REF.POS<2,5>         
*
    Y.LED.ORIG.MUREX.POS = LOC.REF.POS<2,6>
    Y.LED.ASSOC.MUREX.POS = LOC.REF.POS<2,7>
*
    Y.ST.SIG.ORD.REF.POS = LOC.REF.POS<2,8>
    Y.ST.ORD.TYPE.POS = LOC.REF.POS<2,9>
    Y.ST.RDR.FEE.POS = LOC.REF.POS<2,10>
    Y.ST.EDR.TRADE.DATE.POS = LOC.REF.POS<2,11>
*
    Y.TAP.REF.NO.POS = LOC.REF.POS<2,12>
*
    Y.PT.BO.STATUS.POS = LOC.REF.POS<3,1>
    Y.PT.BO.NAME.POS   = LOC.REF.POS<3,2>
*
    Y.PT.SIG.ORD.REF.POS = LOC.REF.POS<3,3>
    Y.PT.ORD.TYPE.POS = LOC.REF.POS<3,4>
    Y.PT.RDR.FEE.POS = LOC.REF.POS<3,5>
    Y.PT.EDR.TRADE.DATE.POS = LOC.REF.POS<3,6>
*
	Y.LOB.POS = LOC.REF.POS<4,1>				;* CPSGMIG-4971 - S/E
	
    CALL F.READ(FN.AEB.PRODUCT.PARAM,'SYSTEM',RE.PROD.PARAM,F.AEB.PRODUCT.PARAM,REPROD.ERR)
    Y.AQDQ.KEY = RE.PROD.PARAM<AEB.PPR.KEY.NAME>
    LOCATE 'AQDQ.SAT' IN Y.AQDQ.KEY<1,1> SETTING AQDQ.POS THEN
        Y.AQDQ.SAT = RE.PROD.PARAM<AEB.PPR.VALUE,AQDQ.POS>
    END
*
    CALL AEB.GET.VAL('SYSTEM','MXG.SAT',PARAM.VAL.OUT1,PARAM.CNT.OUT1,ERR.PARAM.OUT1)     
    Y.MXG.SAT = PARAM.VAL.OUT1          
*
    BEGIN CASE
        CASE ID.COMPANY EQ "CH2920660"
            BRANCH.ID = "MO"
        CASE ID.COMPANY EQ "CH2920764"
            BRANCH.ID = "GE"
        CASE ID.COMPANY EQ "GB0930264"
            BRANCH.ID = "UK"
        CASE ID.COMPANY EQ "HK1000215"
            BRANCH.ID = "HK"
        CASE ID.COMPANY EQ "SG1090400"
            BRANCH.ID = "SG"
        CASE ID.COMPANY EQ "SG1090401"
            BRANCH.ID = "SG"
    END CASE
*
*	Y.NEXT.WORK.DAY = R.DATES(EB.DAT.NEXT.WORKING.DAY)
    SEQ.FILE = BRANCH.ID:'-RB-AML-SECM-':TODAY:'.CSV'					;*CPSGMIG-4971					
*
* Open the directory where the csv fiel to be written
    OPEN '','AMEX.FILES' TO AMEX.FILES.AML ELSE
    END
*	
    COUNTER = 0
*
    RETURN
*------------------------------------------------------------------------------------------
SELECT.SEC.TXN.TODAY:
*-------------------*
* Selects records from SEC.TRADE.TODAY for the company , loops through each id and
* sorts the transaction based on transaction key
    Y.COMP.ID = ID.COMPANY
* T24 - Multi Book
    IF R.COMPANY(EB.COM.BOOK) EQ "" THEN
        SEL.CMD = 'SSELECT ':FN.SEC.TODAY:' WITH @ID LIKE ...':ID.COMPANY:'...'
    END ELSE
		SEL.CMD = 'SSELECT ':FN.SEC.TODAY:' WITH @ID LIKE ':BRANCH.ID:'...'
	END
*/ T24 End - to adress the Multibook
*
    CALL EB.READLIST(SEL.CMD,ID.LIST,'','',ER)
    IF ID.LIST THEN
        LOOP
            REMOVE TODAY.TRADE.ID FROM ID.LIST SETTING MARKER
        WHILE TODAY.TRADE.ID:MARKER
            CALL F.READ(FN.SEC.TODAY,TODAY.TRADE.ID,TXN.KEYS,F.SEC.TODAY,ETEXT)
            GOSUB SORT.STORE.TXNS
        REPEAT
    END
*
    SEL.CMD = '' ; ID.LIST = '' ;
    IF R.COMPANY(EB.COM.BOOK) EQ "" THEN
        SEL.CMD = 'SSELECT ':FN.SEC.REV.TODAY:' WITH @ID LIKE ...':ID.COMPANY:'...'
    END ELSE
        SEL.CMD = 'SSELECT ':FN.SEC.REV.TODAY:' LIKE ':BRANCH.ID:'...'
    END
    CALL EB.READLIST(SEL.CMD,ID.LIST,'','',ER)

    IF ID.LIST THEN
        LOOP
            REMOVE TODAY.TRADE.ID FROM ID.LIST SETTING MARKER
        WHILE TODAY.TRADE.ID:MARKER
            TXN.KEYS = FIELD(TODAY.TRADE.ID,"*",2)
            GOSUB SORT.STORE.TXNS
        REPEAT
    END
*
    RETURN
*------------------------------------------------------------------------------------------
SORT.STORE.TXNS:
*--------------*
* Sorts the transactions based on Transaction Key
    LOOP
        REMOVE TXN.KEY FROM TXN.KEYS SETTING MORE
    WHILE TXN.KEY
        TXN.TYPE = TXN.KEY[1,4]
        BEGIN CASE
            CASE TXN.KEY[1,4] = 'POST' OR TXN.KEY[1,4] = 'SECT'
                GOSUB TRADE.TXN
            CASE 1
                NULL
        END CASE
    REPEAT
*
    RETURN
*------------------------------------------------------------------------------------------
TRADE.TXN:
*--------*
* Sorts the transactions based on Transaction Key
    IF SORTED.TXN.KEYS = "" THEN
        SORTED.TXN.KEYS<1> = TXN.KEY
    END ELSE
        LOCATE TXN.KEY IN SORTED.TXN.KEYS<1> BY 'AR' SETTING POS ELSE POS = -1
        SORTED.TXN.KEYS = INSERT(SORTED.TXN.KEYS,1,POS,0,TXN.KEY)
    END
*
    RETURN
*------------------------------------------------------------------------------------------
MAIN:
*---*
* Loops through each id and extracts the details
    LOOP
        TXN.KEY = SORTED.TXN.KEYS<1,1>
        Y.CU.ACCOUNT.CCY = ''
        Y.CUST.NET.AMT   = ''
        Y.PRICE          = ''
        BEGIN CASE
            CASE TXN.KEY[1,4] = 'POST'
                GOSUB PROCESS.POS.TRANSFER
            CASE TXN.KEY[1,4] = 'SECT'
                GOSUB PROCESS.SEC.TRANSFER
            CASE 1
                NULL
        END CASE
        DEL SORTED.TXN.KEYS<1,1>
    WHILE SORTED.TXN.KEYS DO REPEAT
*
* Writes the data to flat file
    GOSUB AML.SEC.WRITE
*
    RETURN
*------------------------------------------------------------------------------------------
PROCESS.SEC.TRANSFER:
*-------------------*
* Extracts the details from SECURITY.TRANSFER
    CALL F.READ(FN.SEC.TRANSFER,TXN.KEY,EXTRACT.REC,F.SEC.TRANSFER,ETEXT)
*
    IF EXTRACT.REC THEN
        SEC.STATUS = "ACTIVE"
    END ELSE
        CALL EB.READ.HISTORY.REC(F.SEC.TRANSFER.HIS,TXN.KEY,EXTRACT.REC,ETEXT)
        TXN.KEY = FIELD(TXN.KEY,';',1)
        SEC.STATUS = "REVERSED"
    END
*
    COMPANY.CODE=EXTRACT.REC<SC.STR.CO.CODE>
    NARRATIVE.1=EXTRACT.REC<SC.STR.CUST.REMARKS,1>
    NARRATIVE.2=''
*
    Y.ST.IMREQ = EXTRACT.REC<SC.STR.LOCAL.REF,Y.ST.IMREQ.POS>
    Y.ST.TICK.TYPE = EXTRACT.REC<SC.STR.LOCAL.REF,Y.TICK.TYPE.POS>

    Y.INPUTTER = EXTRACT.REC<SC.STR.INPUTTER,1>
    Y.INPUTTER = FIELD(Y.INPUTTER,'_',2,1)
    Y.AUTHORISER = EXTRACT.REC<SC.STR.AUTHORISER>
    Y.AUTHORISER = FIELD(Y.AUTHORISER,'_',2,1)
    FOR J=2 TO DCOUNT(EXTRACT.REC<SC.STR.CUST.REMARKS>,@VM)
        IF NARRATIVE.2 THEN
            NARRATIVE.2=NARRATIVE.2:'///'
            EXIT
        END
        NARRATIVE.2=NARRATIVE.2:EXTRACT.REC<SC.STR.CUST.REMARKS,J>
    NEXT J
*
    Y.GROSS.AMT.SEC.CCY = EXTRACT.REC<SC.STR.GROSS.AMT.SEC.CCY>
    Y.CHARGES = EXTRACT.REC<SC.STR.CHARGES>
    Y.LOCAL.TAX = EXTRACT.REC<SC.STR.LOCAL.TAX>
    Y.CU.COMMISSION = EXTRACT.REC<SC.STR.CU.COMMISSION>
    Y.CU.TAX = EXTRACT.REC<SC.STR.CU.TAX>
    Y.INTEREST.AMT = EXTRACT.REC<SC.STR.INTEREST.AMT>
    Y.DEPOSITORY = ''
*
    Y.CU.ACCOUNT.NO = EXTRACT.REC<SC.STR.CU.ACCOUNT.NO>
*
    Y.CU.TAX.LCY = EXTRACT.REC<SC.STR.CU.TAX.LCY>
    CONVERT @VM TO "|" IN Y.CU.TAX.LCY
    Y.CU.TAX.TCY = EXTRACT.REC<SC.STR.CU.TAX.TCY>
    CONVERT @VM TO "|" IN Y.CU.TAX.TCY
    Y.MAN.TAX.TCY = EXTRACT.REC<SC.STR.MAN.TAX.TCY>
    CONVERT @VM TO "|" IN Y.MAN.TAX.TCY
    Y.MAN.TAX.LCY = EXTRACT.REC<SC.STR.MAN.TAX.LCY>
    CONVERT @VM TO "|" IN Y.MAN.TAX.LCY
    Y.CGT.TAX.AMT = EXTRACT.REC<SC.STR.CGT.TAX.AMT>
    CONVERT @VM TO "|" IN Y.CGT.TAX.AMT
*
    Y.DATE.TIME = ''
    Y.CURR.NO   = ''
														
*
    Y.DATE.TIME = EXTRACT.REC<SC.STR.DATE.TIME,1>
    Y.CURR.NO   = EXTRACT.REC<SC.STR.CURR.NO>
*
    Y.CU.ACCOUNT.CCY = EXTRACT.REC<SC.STR.CU.ACCOUNT.CCY>
    Y.CUST.NET.AMT   = EXTRACT.REC<SC.STR.CUST.NET.AMT>
*
    Y.BO.STATUS.VAL = '' ; Y.BO.NAME.VAL = '' ; Y.BROKER.NO.VAL = '' ; Y.DEPT.CODE.VAL = ''
    Y.BO.STATUS.VAL  = EXTRACT.REC<SC.STR.LOCAL.REF,Y.ST.BO.STATUS.POS>
    Y.BO.NAME.VAL    = EXTRACT.REC<SC.STR.LOCAL.REF,Y.ST.BO.NAME.POS>
    Y.BROKER.NO.VAL  = EXTRACT.REC<SC.STR.BROKER.NO>
    Y.DEPT.CODE.VAL  = EXTRACT.REC<SC.STR.DEPT.CODE>
*
    Y.BR.NET.AMT = EXTRACT.REC<SC.STR.BR.NET.AMT>
*
    Y.COST = '' ; Y.COST = EXTRACT.REC<SC.STR.COST>
    Y.NET.AMT.SEC = ''; Y.NET.AMT.SEC = EXTRACT.REC<SC.STR.NET.AMT.SEC.CCY>
    Y.SEC.EXCH.RATE = ''; Y.SEC.EXCH.RATE = EXTRACT.REC<SC.STR.SEC.EXCH.RATE>
    Y.INTEREST.RATE = ''; Y.INTEREST.RATE = EXTRACT.REC<SC.STR.INTEREST.RATE>
    Y.LED.ORIG.MUREX = '' ;    Y.LED.ORIG.MUREX = EXTRACT.REC<SC.STR.LOCAL.REF,Y.LED.ORIG.MUREX.POS>
    Y.LED.ASSOC.MUREX = '' ;    Y.LED.ASSOC.MUREX = EXTRACT.REC<SC.STR.LOCAL.REF,Y.LED.ASSOC.MUREX.POS>
*
    Y.SIG.ORD.REF = '' ; Y.ORD.TYPE = '' ; Y.RDR.FEE = '' ; Y.EDR.TRADE.NAME = '' ; Y.SECT.POS.PRICE = ''
    Y.SIG.ORD.REF = EXTRACT.REC<SC.STR.LOCAL.REF,Y.ST.SIG.ORD.REF.POS>
    Y.ORD.TYPE = EXTRACT.REC<SC.STR.LOCAL.REF,Y.ST.ORD.TYPE.POS>
    Y.RDR.FEE = EXTRACT.REC<SC.STR.LOCAL.REF,Y.ST.RDR.FEE.POS>
    Y.EDR.TRADE.DATE = EXTRACT.REC<SC.STR.LOCAL.REF,Y.ST.EDR.TRADE.DATE.POS>
	Y.SECT.POS.PRICE = EXTRACT.REC<SC.STR.PRICE>
*
    GOSUB PROCESS.SEC.TRANS
*
RETURN
*------------------------------------------------------------------------------------------
PROCESS.POS.TRANSFER:
*-------------------*
* Extracts the details from POSITION.TRANSFER
    CALL F.READ(FN.POS.TRANSFER,TXN.KEY,EXTRACT.REC,F.POS.TRANSFER,ER)
*
    IF EXTRACT.REC THEN
        SEC.STATUS = "ACTIVE"
    END ELSE
        CALL EB.READ.HISTORY.REC(F.POS.TRANSFER.HIS,TXN.KEY,EXTRACT.REC,ETEXT)
        TXN.KEY = FIELD(TXN.KEY,';',1)
        SEC.STATUS = "REVERSED"
    END
*
    Y.INPUTTER = EXTRACT.REC<SC.PST.INPUTTER,1>
    Y.INPUTTER = FIELD(Y.INPUTTER,'_',2,1)
    Y.AUTHORISER = EXTRACT.REC<SC.PST.AUTHORISER>
    Y.AUTHORISER = FIELD(Y.AUTHORISER,'_',2,1)

    COMPANY.CODE=EXTRACT.REC<SC.PST.CO.CODE>
    NARRATIVE.1=EXTRACT.REC<SC.PST.CUST.NARRATIVE,1>
    NARRATIVE.2=''
    FOR J=2 TO DCOUNT(EXTRACT.REC<SC.PST.CUST.NARRATIVE>,@VM)
        IF NARRATIVE.2 THEN
            NARRATIVE.2=NARRATIVE.2:'///'
            EXIT
        END
        NARRATIVE.2=NARRATIVE.2:EXTRACT.REC<SC.PST.CUST.NARRATIVE,J>
    NEXT J
*
    Y.GROSS.AMT.SEC.CCY = ''
    Y.CHARGES = ''
    Y.LOCAL.TAX = ''
    Y.CU.COMMISSION = ''
    Y.CU.TAX = ''
    Y.INTEREST.AMT = ''
*   
    Y.CU.TAX.LCY = ''
    Y.CU.TAX.TCY = ''
    Y.MAN.TAX.TCY = ''
    Y.MAN.TAX.LCY = ''
    Y.CGT.TAX.AMT = ''
*
    Y.DATE.TIME = ''
    Y.CURR.NO   = ''
    Y.DATE.TIME = EXTRACT.REC<SC.PST.DATE.TIME,1>
    Y.CURR.NO   = EXTRACT.REC<SC.PST.CURR.NO>
*
    Y.BO.STATUS.VAL = '' ; Y.BO.NAME.VAL = '' ; Y.BROKER.NO.VAL = '' ; Y.DEPT.CODE.VAL = ''
    Y.BO.STATUS.VAL  = EXTRACT.REC<SC.PST.LOCAL.REF,Y.PT.BO.STATUS.POS>
    Y.BO.NAME.VAL    = EXTRACT.REC<SC.PST.LOCAL.REF,Y.PT.BO.NAME.POS>
    Y.BROKER.NO.VAL  = ''     ;* BROKER.NO
    Y.DEPT.CODE.VAL  = EXTRACT.REC<SC.PST.DEPT.CODE>
*
    Y.SIG.ORD.REF = '' ; Y.ORD.TYPE = '' ; Y.RDR.FEE = '' ; Y.EDR.TRADE.NAME = '' ; Y.SECT.POS.PRICE = ''  
    Y.SIG.ORD.REF = EXTRACT.REC<SC.PST.LOCAL.REF,Y.PT.SIG.ORD.REF.POS>
    Y.ORD.TYPE = EXTRACT.REC<SC.PST.LOCAL.REF,Y.PT.ORD.TYPE.POS>
    Y.RDR.FEE = EXTRACT.REC<SC.PST.LOCAL.REF,Y.PT.RDR.FEE.POS>
    Y.EDR.TRADE.DATE = EXTRACT.REC<SC.PST.LOCAL.REF,Y.PT.EDR.TRADE.DATE.POS>
	Y.SECT.POS.PRICE = EXTRACT.REC<SC.PST.PRICE,1>	;* Always first position Value.
*
    GOSUB PROCESS.SEC.TRANS
*
    RETURN
*------------------------------------------------------------------------------------------
PROCESS.SEC.TRANS:
*----------------*
    TXN.ID=TXN.KEY
    GOSUB FIND.SEC.TRANS.ID
    FOR I=1 TO DCOUNT(SEC.TRANS.IDS,@FM)
        Y.PRODTYPE = ''       
        TRANS.REC=''
        TXN.ID.NEW=SEC.TRANS.IDS<I>
        CALL F.READ(FN.SEC.TRANS,SEC.TRANS.IDS<I>,TRANS.REC,F.SEC.TRANS,ER)
        TRADE.DATE=TRANS.REC<SC.SCT.TRADE.DATE>
        VALUE.DATE=TRANS.REC<SC.SCT.VALUE.DATE>
        TXN.TYPE=TRANS.REC<SC.SCT.TRANS.TYPE>
        SECURITY.ACC=TRANS.REC<SC.SCT.SECURITY.ACCOUNT>
        !To skipp the depository records -999
        IF SECURITY.ACC MATCHES '...-999' THEN CONTINUE
        CUSTOMER.ID=SECURITY.ACC['-',1,1]
*CPSGMIG-4971 - S
		Y.PARAM.ID    = 'SCB.CUST.SEG'	
		Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
		Y.ALLOWED.LOB = ''
		CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
		R.CUST = ''
		ERR.CUST = ''
		CALL F.READ(FN.CUST,CUSTOMER.ID,R.CUST,F.CUST,ERR.CUST)
		Y.CUST.LOB = R.CUST<EB.CUS.LOCAL.REF,Y.LOB.POS>
		LOBPOS = ''
		
*CPSGMIG-4971 - E
		LOCATE Y.CUST.LOB IN Y.ALLOWED.LOB<1,1> SETTING LOBPOS THEN
        !muli value field each occurrence to be processed as separate transfer
        SECURITY.NO=TRANS.REC<SC.SCT.SECURITY.NUMBER>
        R.SECURITY.MASTER = ''          
        Y.ERR = ''
        CALL F.READ(FN.SECURITY.MASTER,SECURITY.NO,R.SECURITY.MASTER,F.SECURITY.MASTER,Y.ERR)
*
        Y.SAT = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
*
        IF Y.SAT EQ Y.AQDQ.SAT OR Y.SAT MATCHES Y.MXG.SAT THEN        
*
            R.SEC.SUPP = ''
            CALL F.READ(FN.SEC.SUPP,SECURITY.NO,R.SEC.SUPP,F.SEC.SUPP,SUPP.ERR)
            IF R.SEC.SUPP THEN
                Y.PRODTYPE = R.SEC.SUPP<SC.SSP.LOCAL.REF,Y.PRODTYP.POS>
            END
*
            R.PROD.PARAM = ''
            CALL F.READ(FN.SCB.CTP2.PROD.PARAM,'SYSTEM',R.PROD.PARAM,F.SCB.CTP2.PROD.PARAM,PROD.ERR)
            IF R.PROD.PARAM THEN
                Y.PROD.PARAM = R.PROD.PARAM<CTP2.PROD.OPT.PROD.TYPE>
            END
*
            LOCATE Y.PRODTYPE IN Y.PROD.PARAM<1,1> SETTING PROD.POS THEN
                Y.PROD.IMREQ = R.PROD.PARAM<CTP2.PROD.IM.REQUIRED,PROD.POS>
            END
            Y.IM.USER = ''
*
            IF (Y.ST.IMREQ NE '' AND Y.ST.IMREQ NE Y.PROD.IMREQ) AND ((Y.ST.TICK.TYPE EQ 'SEC.TRANSFER-AQDQ' OR Y.ST.TICK.TYPE = 'SEC.TRADE-OPT') OR (Y.ST.TICK.TYPE EQ 'SECURITY.TRANSFER' OR Y.ST.TICK.TYPE EQ 'SEC.TRADE')) THEN
                Y.IM.USER = 'Y'
            END
        END
*  
        SECURITY.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME,1>        
*
        SECURITY.CURRENCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>         
        NOMINAL=TRANS.REC<SC.SCT.NO.NOMINAL.TOTAL>
        TRANSACTION.VALUE=FMT(TRANS.REC<SC.SCT.NET.AMT.TRADE>,"R2")
        !SECURITY.TRANS needs to be accessed
        AMOUNT.TO.CONVERT = TRANSACTION.VALUE
        CCY.TO.CONVERT = SECURITY.CURRENCY
        GOSUB CONVERT.AMT
        AMOUNT.USD = FMT(AMT2,"R2")
*
        GOSUB CONVERT.AMT.LCY
        AMOUNT.VAL.LCY = FMT(AMT2,"R2")
*
        !To deliberately excluded from the extract
*
        Y.DEPOSITORY = TRANS.REC<SC.SCT.DEPOSITORY>
*
        Y.PRICE      = TRANS.REC<SC.SCT.PRICE>
        CONVERT @VM TO "|" IN Y.PRICE
*
        
        GOSUB AML.SEC.EXTRACT
        GOSUB AML.APPEND.WRITE.EXTRACT
		END
    NEXT I
*
    RETURN
*------------------------------------------------------------------------------------------
FIND.SEC.TRANS.ID:
*----------------*
    SEC.TRANS.IDS=''
    SEC.TR.ID=TXN.ID:'.1'
    I=2
    LOOP
        SEC.REC=''
        CALL F.READ(FN.SEC.TRANS,SEC.TR.ID,SEC.REC,F.SEC.TRANS,ER)
    WHILE SEC.REC DO
        SEC.TRANS.IDS<-1>=SEC.TR.ID
        SEC.TR.ID=TXN.ID:'.':I
        I=I+1
    REPEAT
*
RETURN
*------------------------------------------------------------------------------------------
FORM.HEADER:
*----------*

    Y.HEADER = ''
    
    Y.HEADER = 'H':DL:'T24':DL:'SG':DL:TODAY:@FM			
    Y.HEADER := "D":DL:"COMPANY_CODE":DL:"REFERENCE_NO":DL:"TRADE_DATE":DL:"VALUE_DATE":DL:"TRANSACTION_TYPE"
    Y.HEADER := DL:"CUSTOMER":DL:"SSEC_ACCOUNT":DL:"SEC_NO":DL:"SHORT_NAME":DL:"SEC_CCY"
    Y.HEADER := DL:"NOMINAL":DL:"GROSS_AMOUNT":DL:"AMOUNT_USD":DL:"CUST_REMARKS1":DL:"CUST_REMARKS2"
    Y.HEADER := DL:"IM_USER":DL:"INPUTTER":DL:"AUTHORISER":DL:"DEPOSITORY":DL:"SAT_CODE"
    Y.HEADER := DL:"LED_PROD_TYPE":DL:"st_tick_type":DL:"DATE_TIME":DL:"CURR_NO":DL:"BO_STATUS"
    Y.HEADER := DL:"BO_NAME":DL:"BROKER_NO":DL:"DEPT_CODE":DL:"status":DL:"total_value_lcy":DL:"Price"

    AML.REC.WRITE = Y.HEADER	

RETURN

*------------------------------------------------------------------------------------------
AML.SEC.EXTRACT:
*--------------*
* Constructs the output array
    AML.REC = ''
    AML.REC = 'D':DL:COMPANY.CODE:DL   			;! CO.CODE
    AML.REC:= TXN.ID.NEW:DL     			;! REFERENCE.NO
    AML.REC:= TRADE.DATE:DL   						;! TRADE.DATE
    AML.REC:= VALUE.DATE:DL   						;! VALUE.DATE
    AML.REC:= TXN.TYPE:DL       			;! TRANSACTION.TYPE
    AML.REC:= CUSTOMER.ID:DL    			;! CUSTOMER.NO
    AML.REC:= SECURITY.ACC:DL   			;! SECURITY.ACC
    AML.REC:= SECURITY.NO:DL    			;! SECURITY.NO - SECURITY.CODE
    SECURITY.NAME=EREPLACE(SECURITY.NAME, '"', "'")
    AML.REC:= SECURITY.NAME:DL  			;! SECURITY.NO - SECURITY.MASTER field SHORT.NAME
    AML.REC:= SECURITY.CURRENCY:DL        	;! SECURITY.CCY
    AML.REC:= NOMINAL:DL      						;! NO.NOMINAL
    AML.REC:= ABS(TRANSACTION.VALUE):DL 			;! GROSS.AMT.SEC.CCY
    AML.REC:= ABS(AMOUNT.USD):DL        			;! USD equivalent of TRANSACTION.VALUE
    NARRATIVE.1=EREPLACE(NARRATIVE.1, '"', "'")
    NARRATIVE.1=EREPLACE(NARRATIVE.1, ',', "")    	;* QC588 - S/E
    AML.REC:= NARRATIVE.1:DL    			;! CUST.REMARKS (1st line)
    NARRATIVE.2=EREPLACE(NARRATIVE.2, '"', "'")
    NARRATIVE.2=EREPLACE(NARRATIVE.2, ',', "")    	;* QC588 - S/E
    AML.REC:= NARRATIVE.2       			;! CUST.REMARKS (2st line)
    AML.REC:= DL:Y.IM.USER:DL
    AML.REC:= Y.INPUTTER:DL       			;! INPUTTER
    AML.REC:= Y.AUTHORISER        			;! AUTHORISER

    AML.REC:= DL:Y.DEPOSITORY
    AML.REC:= DL:Y.SAT

    AML.REC:= DL:Y.PRODTYPE
	AML.REC:= DL:Y.ST.TICK.TYPE

    AML.REC:= DL:Y.DATE.TIME
    AML.REC:= DL:Y.CURR.NO

    AML.REC:= DL:Y.BO.STATUS.VAL
    AML.REC:= DL:Y.BO.NAME.VAL
    AML.REC:= DL:Y.BROKER.NO.VAL
    AML.REC:= DL:Y.DEPT.CODE.VAL
	AML.REC:= DL:SEC.STATUS
    AML.REC:= DL:ABS(AMOUNT.VAL.LCY)      ;! LCCY equivalent of TRANSACTION.VALUE
	AML.REC:= DL:Y.SECT.POS.PRICE
*
    RETURN
*------------------------------------------------------------------------------------------
AML.APPEND.WRITE.EXTRACT:
*-----------------------*
* Stores the data in output array
    IF NOT(AML.REC) THEN RETURN
    
    AML.REC.WRITE<-1> = AML.REC
    COUNTER = COUNTER + 1
*
    RETURN
*------------------------------------------------------------------------------------------
AML.SEC.WRITE:
*------------*
* Write the data to flat file
    DT = OCONV(DATE(),"D-")
    TM = OCONV(TIME(),'MT')
    DT.TIME = DT:"/":TM
*   AML.REC = BRANCH.ID:DL:DT.TIME:DL:COUNTER
    
    AML.REC = 'T':DL:COUNTER											
    AML.REC.WRITE<-1> = AML.REC											;*CPSGMIG-4971
*
	AML.REC.WRITE = UTF8(AML.REC.WRITE)
    
	WRITE AML.REC.WRITE ON AMEX.FILES.AML,SEQ.FILE ON ERROR
        GOTO FATAL.ERROR
    END
*
RETURN
*------------------------------------------------------------------------------------------
CONVERT.AMT:
*----------*
* Converts the amt to USD
    E="" ; ETEXT="" ; RET.CODE=""
    Y3 = '' ; Y5 = '' ; Y6 = ''
    XCHANGE = '' ; AMT1 = '' ; AMT2 = ''
    CCY1 = CCY.TO.CONVERT
    AMT1 = AMOUNT.TO.CONVERT
    CCY2 = 'USD'
    IF NOT(AMT1) THEN
        AMT2 = 0
        Y6 = 0
        RETURN
    END
    CALL EXCHRATE(1,CCY1,AMT1,CCY2,AMT2,Y3,XCHANGE,Y5,Y6,RET.CODE)
    IF ETEXT THEN TEXT = ETEXT ; GOTO FATAL.ERROR
*
	RETURN
*------------------------------------------------------------------------------------------
CONVERT.AMT.LCY:
*--------------*
* Converts the amt to LCY
    E="" ; ETEXT="" ; RET.CODE=""
    Y3 = '' ; Y5 = '' ; Y6 = ''
    XCHANGE = '' ; AMT1 = '' ; AMT2 = ''
    CCY1 = CCY.TO.CONVERT
    AMT1 = AMOUNT.TO.CONVERT
    CCY2 = LCCY
    IF NOT(AMT1) THEN
        AMT2 = 0
        Y6 = 0
        RETURN
    END
    CALL EXCHRATE(1,CCY1,AMT1,CCY2,AMT2,Y3,XCHANGE,Y5,Y6,RET.CODE)
    IF ETEXT THEN TEXT = ETEXT ; GOTO FATAL.ERROR
*
	RETURN
*------------------------------------------------------------------------------------------
FATAL.ERROR:
*----------*
    CALL FATAL.ERROR('AEB.AML.SECM - ':ID.COMPANY)
*	
	RETURN
*------------------------------------------------------------------------------------------
END
*------------------------------------------------------------------------------------------
