$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.LIEN.MARK.POST
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 14/04/2023 - Sasi V - To create POSITION.TRANSFER records for Lien/Unlien request
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.EB.API
	$INSERT I_F.SCB.RB.LIEN.MARKING
    $INSERT I_B.SCB.RB.LIEN.MARK.COMMON
*
	GOSUB INIT
*
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SCB.RB.LIEN.MARKING:" WITH STATUS EQ 'IN.PROGRESS'"
*
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
	LOOP
        REMOVE Y.UNIQ.ID FROM SEL.LIST SETTING UNIQ.POS
	WHILE Y.UNIQ.ID:UNIQ.POS
        R.SCB.RB.LIEN.MARKING = '' ; SCB.RB.LIEN.MARKING.ERR = '' ; Y.OFS.RESPONSE = '' ; Y.TRANS.STATUS = ''
        CALL F.READ(FN.SCB.RB.LIEN.MARKING,Y.UNIQ.ID,R.SCB.RB.LIEN.MARKING,F.SCB.RB.LIEN.MARKING,SCB.RB.LIEN.MARKING.ERR)
        Y.OFS.RESPONSE = R.SCB.RB.LIEN.MARKING<LIEN.MARK.OFS.RESPONSE>
		Y.TRANS.STATUS = FIELD(Y.OFS.RESPONSE,',',1,1)
		IF Y.TRANS.STATUS[1] = '1' THEN
			Y.SEC.ACCT.FROM = ''
			Y.SEC.ACCT.FROM  = R.SCB.RB.LIEN.MARKING<LIEN.MARK.SEC.ACCT.FROM>
			SAVE.APPLICATION = APPLICATION
			APPLICATION = 'ENQUIRY.SELECT'
			CALL SC.OL.VAL.SEC(Y.SEC.ACCT.FROM)
			APPLICATION = SAVE.APPLICATION
		END
*
        GOSUB CONVERT.MSG
        GOSUB POST.MSG
*
        R.SCB.RB.LIEN.MARKING<LIEN.MARK.STATUS> = 'COMPLETED'
        CALL F.WRITE(FN.SCB.RB.LIEN.MARKING,Y.UNIQ.ID,R.SCB.RB.LIEN.MARKING)
	REPEAT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
	FN.EB.API = 'F.EB.API'
	F.EB.API = ''
	CALL OPF(FN.EB.API,F.EB.API)

    FN.SCB.RB.LIEN.MARKING = 'F.SCB.RB.LIEN.MARKING'
    F.SCB.RB.LIEN.MARKING = ''
    CALL OPF(FN.SCB.RB.LIEN.MARKING, F.SCB.RB.LIEN.MARKING)

RETURN
*-----------------------------------------------------------------------------
CONVERT.MSG:
*-----------
	OUT.OFS.MSG   = Y.OFS.RESPONSE
    Y.OUT.OFS.MSG = 'SCB.RB.LIEN.MARKING,SC.API.SCB.LIEN.MARK.1.0.0~':OUT.OFS.MSG
    OUT.OFS.MSG   = Y.OUT.OFS.MSG
	Y.CORRELATION.ID = FIELD(OUT.OFS.MSG,'/',2,1)
*
	R.EB.API = '' ; EB.API.ERR = '' ; THIS.PACKAGE.CLASS = '' ; THIS.METHOD = ''
	CALLJ.ARGUMENTS = '' ; CALLJ.RESPONSE = '' ; CALLJ.ERROR = ''
*
	CALL F.READ(FN.EB.API,'SCB.CONVERT.OFS.TO.JSON',R.EB.API,F.EB.API,EB.API.ERR)
	THIS.PACKAGE.CLASS = R.EB.API<EB.API.JAVA.PACKAGE>:'.':R.EB.API<EB.API.JAVA.CLASS>
	THIS.METHOD        = R.EB.API<EB.API.JAVA.METHOD>
	CALLJ.ARGUMENTS    = OUT.OFS.MSG
*
	CALL EB.CALLJ(THIS.PACKAGE.CLASS,THIS.METHOD,CALLJ.ARGUMENTS,CALLJ.RESPONSE,CALLJ.ERROR)
	OUT.OFS.MSG = CALLJ.RESPONSE
*
	IF CALLJ.ERROR THEN
		LOG.TEXT = "Correlation ID: ":Y.CORRELATION.ID:" - CALLJ Error ":CALLJ.ERROR:" # CALLJ Response: ":CALLJ.RESPONSE
	END ELSE
		LOG.TEXT = "Correlation ID: ":Y.CORRELATION.ID:" - CALLJ Executed successfully # CALLJ Response: ":CALLJ.RESPONSE
	END
*
	LOG.LEVEL = "3" ;* Denotes ERROR which is the default level set in TAFJTrace
	LoggerPrint("", LOG.LEVEL, LOG.TEXT) ;* Log will be captured in basic.log under log_tafj
*
RETURN
*-----------------------------------------------------------------------------
POST.MSG:
*--------
	DFE.PARAM.ID = 'SCB.ESPEED.POST' ; Y.RETURN.MSG = ''
	Y.OUT.MSG    = OUT.OFS.MSG
*
	IF DFE.PARAM.ID THEN
		CALL SCB.CALLJEE.WRAPPER(DFE.PARAM.ID,Y.OUT.MSG,Y.CORRELATION.ID,Y.RETURN.MSG)
		IF Y.RETURN.MSG EQ '0' THEN
			LOG.TEXT = "Correlation ID: ":Y.CORRELATION.ID:" - Response posted to eSpeed successfully"
		END ELSE
			LOG.TEXT = "Correlation ID: ":Y.CORRELATION.ID:" - Error while posting CALLJEE. Error msg ":Y.RETURN.MSG:". Refer mdb.log"
		END
	END
*
	LOG.LEVEL = "3" ;* Denotes ERROR which is the default level set in TAFJTrace
	LoggerPrint("", LOG.LEVEL, LOG.TEXT) ;* Log will be captured in basic.log under log_tafj
*
RETURN
*-----------------------------------------------------------------------------
END
