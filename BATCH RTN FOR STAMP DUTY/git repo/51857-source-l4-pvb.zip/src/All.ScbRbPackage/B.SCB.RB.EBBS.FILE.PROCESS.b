$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EBBS.FILE.PROCESS(Y.FILE.ID)

* This is BATCH routine which is attached to the SNG/SCB.EBBS.FILE.PROCESS. This routine
* process the EBBS incoming file and recorded all values in to t24 system.
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
* 10-Apr-2022 -	Jaheer Hussain	- CPSGMIG-1490  - Development
*
* 05-Sep-2022 - kalaikumaranp 	- CPSGMIG-1490  - EBBS file processing
*
* 08-Sep-2022 - kalaikumaranp 	- CPSGMIG-1490  - EBBS Date Format changed to YYYYMMDD.
*
* 22-Sep-2022 - kalaikumaranp 	- Only ISA Product code to be in SCB.EBBS.FILE.PARAM
*
* 08-Dec-2023 - Loganathan G  	- ADO-2339312   - Exception handling in case of incorrect /incomplete EBBS request file for RB SG Statement via Locking.
*
* 04-Nov-2025 - 1657186 		- ADO-9331821  - Last Statement Date should be Portfolio Start date for newly Created Portfolio when Very First statement.
*-------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SCB.EBBS.FILE.PARAM
    $INSERT I_F.SCB.EBBS.FILE.PROCESS.COMMON
    $INSERT I_F.LOCKING
    $INSERT I_F.SEC.ACC.MASTER
    
    GOSUB PROCESS.PARA
	
RETURN
*----------------------------------------------------------------------------*
PROCESS.PARA:
*************      
   
   OPENSEQ ERRFILE.PATH,INW.ERR.NAME TO FP.EBBS.ERR ELSE CREATE FP.EBBS.ERR ELSE
        CALL OCOMO("UNABLE TO OPEN EBBS ERROR FILE PATH")
   END 
    
   GOSUB READ.INW.FILE	 
   
   IF R.INWFILE THEN
      GOSUB VALIDATE.REC.COUNT     
   END
   
   IF NOT(Y.MISMATCH) THEN
     GOSUB GET.DATA.VAL.UPD 
   END    

   GOSUB MOVE.TO.BKP
   
   CLOSESEQ FP.EBBS.ERR
   
RETURN
*----------------------------------------------------------------------------*
VALIDATE.REC.COUNT:
*******************
    Y.CNT = 0; INW.FILE.POS = ''; Y.FILE.CNT = 0; Y.I = 0;
	Y.MISMATCH = ''; Y.INW.FILE.CONT = ''; Y.FAILED.FLG = ''
	Y.FILE.STATUS = ''
 
*----------------------------------------------------------------------------
    R.INWFILE = TRIM(R.INWFILE)
    Y.REC.CNT = DCOUNT(R.INWFILE, @FM)
	Y.INIT.CNT = 1
	LOOP
	WHILE Y.INIT.CNT LE Y.REC.CNT
	  Y.REC.LINE = R.INWFILE<Y.INIT.CNT>
	
       BEGIN CASE
         CASE Y.REC.LINE[1,1] EQ '0'
            GOSUB GET.HEADER.VALUES
	     CASE Y.REC.LINE[1,1] EQ '2'
		    GOSUB GET.FOOTER.VALUES
         CASE Y.REC.LINE[1,1] EQ '1'
            Y.FILE.CNT = Y.FILE.CNT+1		
       END CASE 
	   
       Y.INIT.CNT = Y.INIT.CNT + 1	  
	   
	REPEAT
*ADO-2339312-Start
        Y.LOCK.ID = 'RBSG.INWARD.FILE.STATUS'
	R.LOCKING = ''
        Y.LOCK.VALUE = ''
	CALL F.READ(YF.LOCKING,Y.LOCK.ID,R.LOCKING,FP.LOCKING,LOCK.ERR)
        Y.LOCK.VALUE = R.LOCKING<EB.LOK.CONTENT>

	IF Y.FILE.CNT NE Y.REC.TOT.CNT THEN
	   Y.MISMATCH = 1
           Y.FILE.STATUS = 1
	   CALL OCOMO("EBBS FILE COUNT MISMATCH WITH TOTAL COUNT")
           IF Y.LOCK.VALUE NE "MISMATCH" THEN
		R.LOCKING<EB.LOK.CONTENT> = "MISMATCH"
	   	CALL F.WRITE(YF.LOCKING,Y.LOCK.ID,R.LOCKING)
	   END
	   RETURN
	END ELSE
           IF Y.LOCK.VALUE NE "MATCH" THEN
		R.LOCKING<EB.LOK.CONTENT> = "MATCH"
	   	CALL F.WRITE(YF.LOCKING,Y.LOCK.ID,R.LOCKING)
	   END
        END
*ADO-2339312-End
RETURN
*----------------------------------------------------------------------------*
GET.HEADER.VALUES:
******************
   CONVERT '|' TO @VM IN Y.REC.LINE
   Y.FILE.NAME = Y.REC.LINE<1,2>
   Y.BRNCH.MNE = Y.REC.LINE<1,3>
   Y.PROCESS.DAT = Y.REC.LINE<1,4>

RETURN
*----------------------------------------------------------------------------*
GET.DATA.VAL.UPD:
***************** 
    DAT.FILE.POS = ''
    Y.FST.STMT.FLG = ''
    Y.I = 1
	CHANGE @FM TO @VM IN R.INWFILE 
	REC.CNT = DCOUNT(R.INWFILE, @VM)
	
    LOOP
*   WHILE Y.I LE REC.CNT 
    REMOVE Y.RECFILE.CONT FROM R.INWFILE SETTING FILE.POS 
     WHILE Y.RECFILE.CONT:FILE.POS
	   Y.FILE.RECLINE = Y.RECFILE.CONT[1,1]
         
	     IF Y.FILE.RECLINE EQ '1' THEN
			CONVERT '|' TO @VM IN Y.RECFILE.CONT
            Y.FST.STMT.FLG = ''
			Y.REC.RECTYPE    = Y.RECFILE.CONT<1,1>
			Y.REC.RELTION.NO = Y.RECFILE.CONT<1,2>
			Y.REC.SEQ.NO     = Y.RECFILE.CONT<1,3>
   
			Y.REC.MAS.DETS.SORT = Y.RECFILE.CONT<1,4>
			Y.REC.STMT.TYP.CODE = Y.RECFILE.CONT<1,5>
			Y.REC.FREQUENCY     = Y.RECFILE.CONT<1,6>
			Y.REC.LST.STMT.DATE = Y.RECFILE.CONT<1,7>
			Y.REC.NXT.STMT.DATE = Y.RECFILE.CONT<1,8>
			Y.REC.MVMT.FREQ     = Y.RECFILE.CONT<1,9>
			Y.REC.HLD.MAIL.FLAG = Y.RECFILE.CONT<1,10>
   
			Y.REC.MAKERID       = Y.RECFILE.CONT<1,11>
			Y.REC.MAKER.DATE    = Y.RECFILE.CONT<1,12>
			Y.REC.MAKER.BRNCH   = Y.RECFILE.CONT<1,13>
			Y.REC.STATUS.FLAG   = Y.RECFILE.CONT<1,14>
			Y.REC.CCY.CODE      = Y.RECFILE.CONT<1,15>
			Y.REC.PORTFOLIO.NO  = Y.RECFILE.CONT<1,16>
			GOSUB READ.SEC.ACC.MASTER
			Y.FAILED.FLG = ''
			IF NOT(R.SAM) THEN
                Y.FAILED.FLG = 1 
            END ELSE
            	GOSUB READ.FILE.PARM
                IF NOT(R.FILE.PARAM) THEN
                    Y.FST.STMT.FLG = 1
                END
            END
			Y.REC.DEAL.ACCT.NO  = Y.RECFILE.CONT<1,17>
   
			Y.REC.LINK.SEQ.NO   = Y.RECFILE.CONT<1,18>
			Y.REC.PRD.CODE      = Y.RECFILE.CONT<1,19>
			Y.REC.INCLUDE.DATE  = Y.RECFILE.CONT<1,20>
			Y.REC.CSEQ.NO       = Y.RECFILE.CONT<1,21>
			Y.REC.ADD.TYPE.CODE = Y.RECFILE.CONT<1,22>
			Y.REC.CON.TYPE.CODE = Y.RECFILE.CONT<1,23>
			Y.REC.CON.SEQ.NO    = Y.RECFILE.CONT<1,24>
   
			Y.REC.SORT.CODE     = Y.RECFILE.CONT<1,25>
			Y.REC.MM.BRANCH     = Y.RECFILE.CONT<1,26>
			Y.REC.MAIL.NAME1    = Y.RECFILE.CONT<1,27>
			Y.REC.MAIL.NAME2    = Y.RECFILE.CONT<1,28>
			Y.REC.FILTER1       = Y.RECFILE.CONT<1,29>
			Y.REC.FILTER2       = Y.RECFILE.CONT<1,30>
* S --Allow only ISA product code to be in SCB.EBBS.FILE.PARAM table.
            IF Y.REC.PRD.CODE EQ "ISA" AND Y.REC.MAS.DETS.SORT EQ "MASTER" THEN 
				GOSUB WRITE.EBBS.FILE.PARAM
			END
* E --Allow only ISA product code to be in SCB.EBBS.FILE.PARAM table.			  
        END			
        Y.RECFILE.CONT = ''
*		Y.I = Y.I+1
	REPEAT
	
RETURN
*----------------------------------------------------------------------------*
GET.FOOTER.VALUES:
******************
    CONVERT '|' TO @VM IN Y.REC.LINE
    Y.FTR.FILE.DATA = COUNT(Y.REC.LINE, @VM)
	Y.TOT.REC.CNT   = Y.REC.LINE<1,2>
    Y.REC.TOT.CNT   = TRIM(Y.TOT.REC.CNT, '0', 'L') 

RETURN
*----------------------------------------------------------------------------*
WRITE.EBBS.FILE.PARAM:
**********************
  R.EBBS.FILE.PARAM<SCB.EBBS.RECORD.TYPE>     = Y.REC.RECTYPE
  R.EBBS.FILE.PARAM<SCB.EBBS.RELATIONSHIP.NO> = Y.REC.RELTION.NO
  R.EBBS.FILE.PARAM<SCB.EBBS.SEQ.NUMBER> = Y.REC.SEQ.NO
  R.EBBS.FILE.PARAM<SCB.EBBS.MASTER.DETS.SORT> = Y.REC.MAS.DETS.SORT
  R.EBBS.FILE.PARAM<SCB.EBBS.STMT.TYPE.CODE>   = Y.REC.STMT.TYP.CODE
  R.EBBS.FILE.PARAM<SCB.EBBS.FREQUENCY>        = Y.REC.FREQUENCY 
  
  CHANGE '-' TO '' IN Y.REC.LST.STMT.DATE
  R.EBBS.FILE.PARAM<SCB.EBBS.LAST.STMT.DATE> = Y.REC.LST.STMT.DATE
  IF Y.FST.STMT.FLG EQ 1 THEN
    Y.START.DATE = R.SAM<SC.SAM.START.DATE>
    CALL CDT ('',Y.START.DATE,'-1W')
    R.EBBS.FILE.PARAM<SCB.EBBS.LAST.STMT.DATE> = Y.START.DATE
  END
  CHANGE '-' TO '' IN Y.REC.NXT.STMT.DATE
  R.EBBS.FILE.PARAM<SCB.EBBS.NEXT.STMT.DATE> = Y.REC.NXT.STMT.DATE
  
  R.EBBS.FILE.PARAM<SCB.EBBS.MOVEMENT.FREQ>  = Y.REC.MVMT.FREQ    
  R.EBBS.FILE.PARAM<SCB.EBBS.HOLD.MAIL.FLAG> = Y.REC.HLD.MAIL.FLAG
  R.EBBS.FILE.PARAM<SCB.EBBS.MAKER.ID>      = Y.REC.MAKERID
  
  CHANGE '-' TO '' IN Y.REC.MAKER.DATE 
  R.EBBS.FILE.PARAM<SCB.EBBS.MAKER.DATE>    = Y.REC.MAKER.DATE  
  
  R.EBBS.FILE.PARAM<SCB.EBBS.MAKER.BRANCH>  = Y.REC.MAKER.BRNCH 
  R.EBBS.FILE.PARAM<SCB.EBBS.STATUS.FLAG>   = Y.REC.STATUS.FLAG 
  R.EBBS.FILE.PARAM<SCB.EBBS.CURRENCY.CODE> = Y.REC.CCY.CODE    
  R.EBBS.FILE.PARAM<SCB.EBBS.REFERENCE.NO>  = Y.REC.PORTFOLIO.NO     
  R.EBBS.FILE.PARAM<SCB.EBBS.DEAL.OR.ACCT.FLAG> = Y.REC.DEAL.ACCT.NO
  R.EBBS.FILE.PARAM<SCB.EBBS.LINK.SEQ.NO>   = Y.REC.LINK.SEQ.NO 
  R.EBBS.FILE.PARAM<SCB.EBBS.PRODUCT.CODE>  = Y.REC.PRD.CODE    
  R.EBBS.FILE.PARAM<SCB.EBBS.INCLUD.DATE>   = Y.REC.INCLUDE.DATE
  
  R.EBBS.FILE.PARAM<SCB.EBBS.CSEQ.NO>       = Y.REC.CSEQ.NO      
  R.EBBS.FILE.PARAM<SCB.EBBS.ADD.TYPE.CODE> = Y.REC.ADD.TYPE.CODE
  R.EBBS.FILE.PARAM<SCB.EBBS.CONTACT.TYPE.CODE> = Y.REC.CON.TYPE.CODE
  R.EBBS.FILE.PARAM<SCB.EBBS.CONTACT.SEQ.NO>    = Y.REC.CON.SEQ.NO   
  R.EBBS.FILE.PARAM<SCB.EBBS.SORT.CODE>  = Y.REC.SORT.CODE  
  R.EBBS.FILE.PARAM<SCB.EBBS.MMBRANCH>   = Y.REC.MM.BRANCH  
  R.EBBS.FILE.PARAM<SCB.EBBS.MAILNAME.1> = Y.REC.MAIL.NAME1 
  R.EBBS.FILE.PARAM<SCB.EBBS.MAILNAME.2> = Y.REC.MAIL.NAME2 
  R.EBBS.FILE.PARAM<SCB.EBBS.FILTER.1>   = Y.REC.FILTER1    
  R.EBBS.FILE.PARAM<SCB.EBBS.FILTER.2>   = Y.REC.FILTER2
  IF Y.FAILED.FLG THEN  
    R.EBBS.FILE.PARAM<SCB.EBBS.STATUS> = 'FAILED'
  END ELSE
    R.EBBS.FILE.PARAM<SCB.EBBS.STATUS> = 'PROCESSED'
  END   
  
  Y.DATE = TODAY
  Y.FILE.PROCESS.DATE = Y.DATE
  R.EBBS.FILE.PARAM<SCB.EBBS.PROCESS.DATE> = Y.FILE.PROCESS.DATE
  
  Y.UPD.FILE.ID = Y.REC.PORTFOLIO.NO
   
  IF Y.FAILED.FLG THEN
    Y.ERROR.REC = R.EBBS.FILE.PARAM
    GOSUB WRITE.ERROR.RECORDS
  END ELSE
  	WRITE R.EBBS.FILE.PARAM TO F.SCB.EBBS.FILE.PARAM, Y.UPD.FILE.ID
  END
      
  R.EBBS.FILE.PARAM = ''
  Y.UPD.FILE.ID = ''
  Y.FAILED.FLG  = ''
  
RETURN
*----------------------------------------------------------------------------*
MOVE.TO.BKP:
************
   
   SH.CMD = "SH -c cp -f ":INFILE.PATH:"/":Y.FILE.ID:" ":BKPFILE.PATH
   EXECUTE SH.CMD

   SH.DEL.CMD = 'SH -c "rm -f ':INFILE.PATH:'/':Y.FILE.ID:' "'
   EXECUTE SH.DEL.CMD

RETURN
*----------------------------------------------------------------------------*
READ.INW.FILE:
**************
   R.INWFILE = ''
   ERR.INWFILE = ''
   CALL F.READ(FN.INW.FILE,Y.FILE.ID,R.INWFILE,F.INW.FILE, ERR.INWFILE)

RETURN
*----------------------------------------------------------------------------*
READ.SEC.ACC.MASTER:
********************
   R.SAM = ''
   ERR.SAM = ''
   CALL F.READ(FN.SAM,Y.REC.PORTFOLIO.NO,R.SAM,F.SAM,ERR.SAM)

RETURN
*----------------------------------------------------------------------------*
WRITE.ERROR.RECORDS:
********************
    
    WRITESEQ Y.ERROR.REC APPEND TO FP.EBBS.ERR ELSE
        *CALL OCOMO("UNABLE TO WRITE EBBS ERROR RECORD")
    END
	
    Y.REC.OUTPUT = ''
    REC.DET.CNT += 1

RETURN
*----------------------------------------------------------------------------*
READ.FILE.PARM:
**************
   R.FILE.PARAM = ''
   ERR.PARAM = ''
   CALL F.READ(FN.SCB.EBBS.FILE.PARAM,Y.REC.PORTFOLIO.NO,R.FILE.PARAM,F.SCB.EBBS.FILE.PARAM,ERR.PARAM)

RETURN
*----------------------------------------------------------------------------*
END