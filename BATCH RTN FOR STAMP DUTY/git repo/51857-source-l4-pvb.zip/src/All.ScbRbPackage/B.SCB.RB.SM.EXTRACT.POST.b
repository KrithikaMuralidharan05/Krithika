* @ValidationCode : MjoyNDIwODY3OTk6SVNPLTg4NTktMToxNjgyNTg0OTY1NTMzOjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 27 Apr 2023 14:12:45
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SM.EXTRACT.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5311 - JEWEL_T24_PROJECT
* Developed By                   :       1494730
* Developed On                   :       21 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Post Routine to Merge the SM Extract
*--------------------------------------------------------------------------------------------
* Called From:
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 17-Apr-2023   1648769         CPSGMIG-14065 - Update mapping Asset Fee & Charge Detail
* 26-Apr-2023   1663000         CPSGMIG-21498 - Filename Change
* 20-Jan-2025	Padmapriya		6893710 - Added one column 'Depository'� to the Report which has the Depo details.
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES  ;*CPSGMIG-21498
    
    GOSUB INITIALISE
    GOSUB PROCESS
	 
RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

    AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
    
    Y.SM.FILE.ID    = BATCH.DETAILS<3,1>

    Y.LWD           = R.DATES(EB.DAT.LAST.WORKING.DAY)           ;* CPSGMIG-21498
    Y.SM.FILE.ID    = EREPLACE(Y.SM.FILE.ID,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
   
    Y.FINAL.FILE.ID = Y.SM.FILE.ID:".csv"
    
    Y.ARRAY = "Asset Type,Product Provider name,Asset Code,UT Asset Code,Asset Class,"
    Y.ARRAY:= "Asset Name,Switch Group,Status,Currency Code,Price Indicator,"
    Y.ARRAY:= "GST required,Commission Formula,Decimal Places (Unit),Div Instruction (Unit/Cash),"
    Y.ARRAY:= "Launch Date,Domicile Country,First Time Min. Subs Amount,Min. Subs Amount,"
    Y.ARRAY:= "Min. Redemption Amount,Maturity Date,Cash Account No,Reinvest Account No,"
    Y.ARRAY:= "Lot Size,Par Value,ISIN Code,Aggregation Cutoff Time,Amount Round To Decimal,"
    Y.ARRAY:= "Cancellation,Vestima,RIC IDENTIFIER,EFFECTIVE DATE,SEDOL Code,Unit holdings,"
*CPSGMIG-14065-S
    Y.ARRAY:= "NAV Price,TR Fee code,TR Fee Description,Upto Amount,TR Fee Percentage,"
    Y.ARRAY:= "MAKER ID,CHECKER ID,MAKER /AUTHORIZATION DATE,"
	Y.ARRAY:= "Depository" ;*6893710-S/E
*CPSGMIG-14065-E

RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.UTS.ARR = '' ; Y.FINAL.UTS.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = Y.SM.FILE.ID:"*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.AMEX.FILE THEN
                Y.ARRAY<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT
	    WRITE Y.ARRAY TO F.AMEX.FILES,Y.FINAL.FILE.ID
    END

RETURN

END
