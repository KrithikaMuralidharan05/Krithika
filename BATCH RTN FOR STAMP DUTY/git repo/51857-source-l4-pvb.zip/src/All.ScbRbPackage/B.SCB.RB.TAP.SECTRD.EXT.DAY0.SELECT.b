$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.SECTRD.EXT.DAY0.SELECT
**--------------------------------------------------------------------------------------------------------------------
    ! DESCRIPTION : THIS IS A SELECT FILE WHICH WILL SELECT ALL THE TRADE TRASACTION HAPPENED ON A DAY TO DAY BASIS
    !               FOR EXTRACTION.
**--------------------------------------------------------------------------------------------------------------------
*
* 16/08/2022 - Shreekantha. G - CPSGMIG-5346 - Copy of Existing Routine B.SCB.RB.EDM.SECTRD.EXT.SELECT.b
*
*---------------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.TAP.SECTRD.EXTRACT.COMMON
    $INSERT I_BATCH.FILES
*
	IF NOT(CONTROL.LIST) THEN
        CONTROL.LIST = "TRD.LIVE"	
    END
	Y.PILOT.DATE = '20221205'
    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "TRD.LIVE"
			SEL.CMD = "SSELECT ":FN.SEC.TRADE:" WITH VALUE.DATE GE ":Y.PILOT.DATE          
*		CASE CONTROL.LIST<1,1> = "TRD.REVE"
*			SEL.CMD = "SSELECT ":FN.SEC.TRADE.HIS:" WITH VALUE.DATE GE ":Y.PILOT.DATE 
	END CASE
	CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)	
	CALL BATCH.BUILD.LIST('',SEC.ID)		
    RETURN
*
*---------------------------------------------------------------------------------------------------------------------
END
*---------------------------------------------------------------------------------------------------------------------
