$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-40</Rating>
*-----------------------------------------------------------------------------
	SUBROUTINE B.SCB.RB.EDM.CUS.SEC.EXTRACT(Y.CUS.SEC.ID)
**************************************************************************
* 25 Feb 2016 - FCC EDMP - Subramanian M
*             - This routine will generate the Customer Security Dump in AMEX.FILES.
**************************************************************************
*******************************************************************************
*Modification History:
************************
* 27-May-2022 - CPSGMIG-3321 - Lavanya L - Copy of the existing routine B.SCB.EDM.CUS.SEC.EXTRACT
*
* 17-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
* 23-Mar- 2023 - CPSGMIG-18238 - Lakshmi PR- Parameterised the customer tranche records
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER.SECURITY
    $INSERT I_F.CUSTOMER
    $INSERT I_B.SCB.RB.EDM.CUS.SEC.EXTRACT.COMMON
    
    
*
*CPSGMIG-13878(S)
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM

 

    GOSUB CHECK.CUS.ALLOWED.LIST
*   IF Y.CUS.ALLOWED.FLAG EQ 1 OR Y.SECTOR EQ '23' THEN
*CPSGMIG-13878(E)


*CPSGMIG-18238- Start
   Y.MIG.DAT = R.CUST<EB.CUS.LOCAL.REF,Y.MIG.DAT.POS>
   IF Y.FILE.FLAG EQ "TRANCHE" AND (Y.MIG.DAT NE '' OR Y.SECTOR EQ '23') THEN
    GOSUB INIT
    GOSUB PROCESS
   END ELSE
   IF Y.FILE.FLAG EQ "FULL" THEN
    GOSUB INIT
    GOSUB PROCESS
	 END
   END
*CPSGMIG-18238- End


*   END 
*
RETURN
*CPSGMIG-13878(S)
*----------------------
CHECK.CUS.ALLOWED.LIST:
*----------------------
Y.CUS.ALLOWED.FLAG = ''

*
ID.LOC.PARAM = 'RSG.PILOT.IND.CUST'
Y.FIND.FIELD.NAME = 'UTS.IND.CUST'
  
	CALL F.READ(FN.LOC.PARAM,ID.LOC.PARAM,R.LOC.PARAM,F.LOC.PARAM,LOC.ERR)	      
        IF R.LOC.PARAM THEN
	      Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
          LOCATE Y.FIND.FIELD.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
           Y.LOC.CUST.LIST = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>
           CONVERT SM TO VM IN Y.LOC.CUST.LIST
          END
	  LOCATE Y.CUS.SEC.ID IN Y.LOC.CUST.LIST<1,1> SETTING CUST.POS THEN
            Y.CUS.ALLOWED.FLAG = 1
          END
	END
	R.CUST = ''
    ERR.CUST = ''
  	CALL F.READ(FN.CUST,Y.CUS.SEC.ID,R.CUST,F.CUST,ERR.CUST)
    Y.SECTOR = R.CUST<EB.CUS.SECTOR>
RETURN
*CPSGMIG-13878(E)

*******************************************************************************
INIT:
****
	DL = CHAR(01)
    Y.FILE.NAME = '' ; Y.COMP.NAME = ''
    Y.COMP.NAME = ID.COMPANY
    Y.FILE.NAME = Y.COMP.NAME:"-":SESSION.NO:"-RB-CUSSECURITY-":TODAY:".CSV"			;*CPSGMIG-3321 - S/E
RETURN
*********************************************************************************************
PROCESS:
********
    R.CUS.SEC = '' ; CUS.SEC.ERR = ''
    R.CUS.SEC.ERR = ''
    CALL F.READ(FN.CUSTOMER.SECURITY,Y.CUS.SEC.ID,R.CUS.SEC,F.CUSTOMER.SECURITY,CUS.SEC.ERR)
    IF R.CUS.SEC THEN
        R.CUS.SEC.ERR = 'D':DL:Y.CUS.SEC.ID:DL:R.CUS.SEC<SC.CSC.CUSTOMER.TYPE>
        GOSUB WRITE.AMEX.FILE
    END
RETURN
*********************************************************************************************
WRITE.AMEX.FILE:
****************
    R.AMEX.FILE = '' ; AMEX.ERR = ''
    CALL F.READ(FN.AMEX.FILES,Y.FILE.NAME,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
    IF R.AMEX.FILE THEN
        R.AMEX.FILE := @FM:R.CUS.SEC.ERR
    END ELSE
        R.AMEX.FILE = R.CUS.SEC.ERR
    END
*R20 UPG -S
    CALL F.WRITE(FW.AMEX.FILES,Y.FILE.NAME,R.AMEX.FILE)
*R20 UPG -E
	RETURN
*********************************************************************************************
END
