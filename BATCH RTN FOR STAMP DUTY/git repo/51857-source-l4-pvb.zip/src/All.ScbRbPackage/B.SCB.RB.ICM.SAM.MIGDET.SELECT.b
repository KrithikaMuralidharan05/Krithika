$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ICM.SAM.MIGDET.SELECT
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-22772 - JEWEL_T24_PROJECT
* Developed By                   :       Revathi G
* Developed On                   :       5thMay2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is a multi threaded Routine which extract details of SAM
* with LR.POS.MIG.DT EQ TODAY for ICM
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.ICM.SAM.MIGDET.COMMON

 
    SEL.SAM.CMD = "SELECT ": FN.SEC.ACC.MASTER : " WITH LR.POS.MIG.DT EQ ":TODAY
    CALL OCOMO("Selecting SAM Records with LR.POS.MIG.DT eq Today")

    CALL EB.READLIST(SEL.SAM.CMD,SEL.LIST,'',NO.REC,RET.CODE)

    CALL OCOMO(SEL.SAM.CMD)
    CALL OCOMO("No of Records Selected for Processing ":NO.REC)
    
    IF SEL.LIST THEN
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    END


RETURN
END
