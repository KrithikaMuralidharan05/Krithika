$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.TXN.DETS.PDW.EXT.SELECT
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 04/08/2022 - kalaikuamran p - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_TransDets_YYYYMMDD.txt
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.TXN.DETS.PDW.EXT.COMMON
*
*    GOSUB CHECK.DAY
    GOSUB SEL.TRN.CON.DATE
    GOSUB SEL.ORDER
    
    IF TRANS.ID.LIST THEN
        CALL BATCH.BUILD.LIST('',TRANS.ID.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
SEL.TRN.CON.DATE:
*----------------
    SEL.CMD = '' ; TRN.CON.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = '';TRANS.ID.LIST = ''
    SEL.CMD = "SELECT ":FN.TRN.CON.DATE
*
    CALL EB.READLIST(SEL.CMD,TRN.CON.LIST,'',NO.OF.RECS,SEL.ERR)
    TRANS.ID.LIST = TRN.CON.LIST
*
RETURN
*-----------------------------------------------------------------------------
SEL.ORDER:
*---------
    SEL.SOO = '' ; SOO.LIST = '' ; NO.OF.SOO = '' ; SOO.ERR = ''
    SEL.SOO = "SELECT ":FN.SEC.OPEN.ORDER
*
    CALL EB.READLIST(SEL.SOO,SOO.LIST,'',NO.OF.SOO,SOO.ERR)
    TRANS.ID.LIST<-1> = SOO.LIST
*
RETURN
*-----------------------------------------------------------------------------
CHECK.DAY:
*--------
    FROM.DATE = '' ; TO.DATE = ''
    IF OCONV(TODAY,'DWA') EQ 'FRIDAY' THEN
        FROM.DATE = TODAY
        CALL CDT("",FROM.DATE,"-6C")
        TO.DATE = TODAY
    END ELSE
    	BEGIN CASE
            CASE OCONV(TODAY,'DWA') EQ 'MONDAY'
                FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-2C")
                TO.DATE = TODAY
            CASE OCONV(TODAY,'DWA') EQ 'TUESDAY'
            	FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-3C")
                TO.DATE = TODAY
            CASE OCONV(TODAY,'DWA') EQ 'WEDNESDAY'
            	FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-4C")
                TO.DATE = TODAY
            CASE OCONV(TODAY,'DWA') EQ 'THURSDAY'
            	FROM.DATE = TODAY
                CALL CDT("",FROM.DATE,"-5C")
                TO.DATE = TODAY
        END CASE
    END
*
RETURN
*-----------------------------------------------------------------------------
