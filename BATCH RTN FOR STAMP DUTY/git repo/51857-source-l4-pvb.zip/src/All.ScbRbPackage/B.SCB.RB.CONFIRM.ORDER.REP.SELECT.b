* @ValidationCode : MjotMjIzMjQ0MzE6SVNPLTg4NTktMToxNjkzMjk3OTE3MTU3OjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 29 Aug 2023 14:01:57
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CONFIRM.ORDER.REP.SELECT
*-----------------------------------------------------------------------------
* Project Name                   :      CPSGMIG-34072
* Developed By                   :      1670271
* Developed On                   :      07-Sep-2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* Batch report to generate the confirmed order from SEC.TRADE & SECURITY.TRANSFER
*-------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_TSA.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.CONFIRM.ORDER.REP.COMMON
*-----------------------------------------------------------------------------
    
    Y.DATA = BATCH.DETAILS<3,1>
    CONVERT @SM TO @FM IN Y.DATA
    MTH.DAILY.FLAG  = FIELD(Y.DATA,'*', 1)   ;* Contain the value as Daily or Monthly
    
    IF MTH.DAILY.FLAG EQ "D" THEN
        SEL.CMD = 'SELECT ':FN.SEC.TRADES.LDAY:' WITH @ID LIKE SG...*SCTRSC... OR WITH @ID LIKE SG...*SECTSC...'      ;* CPSGMIG-21498 - Daily Report
    END ELSE
        SEL.CMD = 'SELECT ':FN.SCB.SEC.TRADES.MDAY:' WITH @ID LIKE SG...*SCTRSC... OR WITH @ID LIKE SG...*SECTSC...'  ;* Monthly Report
    END

    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
	
	IF SEL.LIST THEN
    CALL BATCH.BUILD.LIST('',SEL.LIST)
	END
	
RETURN
END
