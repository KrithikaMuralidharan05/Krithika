* @ValidationCode : Mjo5Mjg0OTQ3NDM6SVNPLTg4NTktMToxNjc3NDgwNTEyNTQyOjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 27 Feb 2023 12:18:32
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
SUBROUTINE B.SCB.FUND.PRICE.EXT.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13123 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       23 December 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Post Routine to merge the generated price batch file for iBanking from SECURITY.MASTER
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.PRICE.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 27-Feb-2023   1663000          CPSGMIG-19423 - Generate the file with "-" inorder to push it to NAS path
* 06-Jun-23     1648769          CPSGMIG-27441 - File name should set the date as -1C calendar date.
* 04-Jun-23     1648769          CPSGMIG-29571 - To hardcode dummy line for SM(000000-000) in the file with date format
* 17-Jun-23     1667095          CPSGMIG-31215 - Correction done to update Footer count including dummy line
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_B.SCB.FUND.PRICE.EXT.COMMON
   
    GOSUB INIT
    GOSUB PROCESS
RETURN

*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX.FILES,F.AMEX.FILES,AMEXPATH)
*
    R.FUND.PRICE.RPT.FINAL.ARR = ''
    Y.FUND.PRICE.HEADER = ''
    Y.FUND.PRICE.FOOTER = ''
    Y.HEADER.ID = "0"
    Y.FOOTER.ID = "9"
    Y.COMPANY.ID = "2000"
    Y.SYSDATE     = OCONV(DATE(),"D4/")
    Y.SYSDATE     = FIELD(Y.SYSDATE,'/',3):FIELD(Y.SYSDATE,'/',1):FIELD(Y.SYSDATE,'/',2)
    Y.LAST.SYSDATE = Y.SYSDATE
    CALL CDT('',Y.LAST.SYSDATE,'-1C')

    Y.FINAL.FILE.NAME = BATCH.DETAILS<3,1>
    Y.FINAL.FILE.NAME = EREPLACE(Y.FINAL.FILE.NAME,"<LSYSDATE>",Y.LAST.SYSDATE,-1)
*

RETURN

*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    
    Y.UDFILE = 'AMEX.FILES'
    SEL.CMD  = 'T24SGFUNDPRICE_':TODAY:'*.txt'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*

    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.FUND.PRICE.RPT.FINAL.ARR EQ '' THEN
                R.FUND.PRICE.RPT.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.FUND.PRICE.RPT.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
*
        R.FUND.DUMMY.LINE   = '1000000-000                                                     999901010000000000000000000000000000000000000'
        R.FUND.PRICE.RPT.FINAL.ARR :=@FM:R.FUND.DUMMY.LINE
        NO.OF.RECORDS = DCOUNT(R.FUND.PRICE.RPT.FINAL.ARR,@FM)
        Y.FUND.PRICE.HEADER = Y.HEADER.ID:Y.COMPANY.ID:FMT(Y.LAST.SYSDATE,"R%8")
        Y.FUND.PRICE.FOOTER = Y.FOOTER.ID:Y.COMPANY.ID:FMT(Y.LAST.SYSDATE,"R%8"):FMT(NO.OF.RECORDS,"R%9")
        R.FUND.PRICE.RPT.FINAL = Y.FUND.PRICE.HEADER:@FM:R.FUND.PRICE.RPT.FINAL.ARR:@FM:Y.FUND.PRICE.FOOTER
*
        WRITE R.FUND.PRICE.RPT.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
*
    END
RETURN

END
