$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.STMT.FILE.PROCESS.SELECT

* This is BATCH routine which is attached to the SNG/SCB.EBBS.FILE.PROCESS. This routine
* loads the requested files and to process the EBBS incoming file.
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
*
* 05-Sep-2022 - kalaikumaranp - CPSGMIG-798 - Statement file generation
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_SCB.RBSTMT.PROCESS.COMMON
	$INSERT I_F.SCB.EBBS.FILE.PARAM
	$INSERT I_F.DATES


	Y.LWORK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
	
	SEL.CMD = 'SELECT ':FN.SCB.EBBS.FILE.PARAM:' WITH NEXT.STMT.DATE GE ':Y.LWORK.DAY
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
	
	IF SEL.LIST THEN
    CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
	
	RETURN
	
END
	