$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-34</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.CONSOL.XML.ADV.RB(Y.DOH.ID)
* Created by    : Sasikumar Kannan
* Creation Date : 28/06/2012
*-----------*
*DESCRIPTION:
*-----------*
* This is a BATCH routine is used for consolidating all the XML advices generated.
* This is a requirement for DE-PERSONALISATION Project.
* Routine attached to the BATCH Application
* XXX/B.SCB.CONSOL.XML.ADV.RB(Online Generation with Interval of 30 mins in Business days.
*------------------------------------------------------------------------------------------
* PVB-60661 - 9-10-2020 - Kapil K - SMS Post Trade Notification
*------------------------------------------------------------------------------------------
* PVB-60661 - 6-11-2020 - Kapil K - SMS Post Trade Notification Post-Live changes
*
* TAFJUPG - Code conversion for TAFJ upgrade - CHAR(13):CHAR(10) included to bring XML array in multiple lines.
*
* 23-Jul-2021- 1389710                        Changes done in WRITESEQ usage for R20 multi server environment(TAFJUPG-MS)
*
* 25-04-2022  - CPSGMIG-1081    Avinash        This Routine copied from B.SCB.CONSOL.XML.ADV to
*                                              B.SCB.CONSOL.XML.ADV.RB to consolidate for retail advices.
* 19-05-2025 - ADO-7884637 - Prithi Koppolu - To update RECON.STATUS field to the SCB.DP.XML.ADV.STATUS table
*------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DE.HEADER
    $INSERT I_F.SCB.DP.XML.ADV.STATUS
    $INSERT I_B.SCB.CONSOL.XML.ADV.RB.COMMON

*--------
PROCESS:
*-------
*
    CALL F.READ(FN.SCB.DP.XML.ADV.STATUS,Y.DOH.ID,R.SCB.DP.XML.ADV.STATUS,F.SCB.DP.XML.ADV.STATUS,Y.STAT.ERR)
	
    IF R.SCB.DP.XML.ADV.STATUS THEN
        Y.DE.O.HIST.ID = R.SCB.DP.XML.ADV.STATUS<XML.ADV.DE.O.HIST.ID>
        CALL F.READ(FN.DE.O.HISTORY,Y.DE.O.HIST.ID,R.DE.O.HISTORY,F.DE.O.HISTORY,Y.REC.ERR)
        IF R.DE.O.HISTORY THEN
            CHANGE @FM TO CHAR(13):CHAR(10) IN R.DE.O.HISTORY			;* TAFJUPG -S/E
* TAFJUPG-MS(S)
            F.SCB.RB.DP.XML.FILES = ''
            OPENSEQ FN.SCB.RB.DP.XML.FILES, Y.DPFILE.ID TO F.SCB.RB.DP.XML.FILES ELSE
                CREATE F.SCB.RB.DP.XML.FILES ELSE
                    ETEXT = "CANNOT CREATE SEQUENTIAL FILE"
                    CALL OCOMO(ETEXT)		;* TAFJUPG -S/E
                    RETURN
                END
            END
* TAFJUPG-MS(E)
*
            WRITESEQ R.DE.O.HISTORY APPEND TO F.SCB.RB.DP.XML.FILES THEN
                GOSUB UPDATE.DOH.STATUS
            END
* TAFJUPG-MS(S)
            CLOSESEQ F.SCB.RB.DP.XML.FILES
* TAFJUPG-MS(E)
        END
    END
*
RETURN
*------------------------------------------------------------------------------------*
*-----------------
UPDATE.DOH.STATUS:
*-----------------
*
    Y.TIMEDATE   = TIMEDATE()
    CALL F.READ(FN.DE.O.HEADER,Y.DOH.ID,R.DE.O.HEADER,F.DE.O.HEADER,Y.HDR.ERR)
*
    R.SCB.DP.XML.ADV.STATUS<XML.ADV.DATE>        = Y.TIMEDATE[10,11]
    R.SCB.DP.XML.ADV.STATUS<XML.ADV.BANK.DATE>   = R.DE.O.HEADER<DE.HDR.BANK.DATE>
    R.SCB.DP.XML.ADV.STATUS<XML.ADV.TIME.STAMP>  = Y.TIMEDATE[1,8]
    R.SCB.DP.XML.ADV.STATUS<XML.ADV.CUSTOMER.ID> = R.DE.O.HEADER<DE.HDR.CUSTOMER.NO>
    R.SCB.DP.XML.ADV.STATUS<XML.ADV.PROCESS.STATUS> ='PROCESSED'
    R.SCB.DP.XML.ADV.STATUS<XML.ADV.RECON.STATUS> = TODAY ;* ADO-7884637-S/E
	WRITE R.SCB.DP.XML.ADV.STATUS TO F.SCB.DP.XML.ADV.STATUS,Y.DOH.ID
*
RETURN
*------------------------------------------------------------------------------------*
END