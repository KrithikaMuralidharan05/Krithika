$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgEbbsW8W9ProcessSelect
*
*
SUBROUTINE B.SCB.RSG.EBBS.W8.W9.PROCESS.SELECT
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.EBBS.W8.W9.PROCESS.COMMON
    $INSERT I_BATCH.FILES
    
  
    CALL OCOMO("Start check common variable")
FILE.DATA.PATH.CNT =DCOUNT(Y.SRC.FILEPATH,"/")
FILE.DATA.PATH = FIELD(Y.SRC.FILEPATH,"/",FILE.DATA.PATH.CNT)
    GOSUB DATA.ARCH

    GOSUB SELECT.FILE

Y.IDS.CNT = DCOUNT(Y.FLAG.IDS,@FM)
CALL OCOMO(Y.IDS.CNT:" No. of job to be passed to main rtn")

    CALL BATCH.BUILD.LIST('',Y.FLAG.IDS)
RETURN
***************
*

SELECT.FILE:
*

    SEL.CMD = "SELECT ":FN.EBBS.CONCAT:" WITH CLIENT.TYPE EQ 'RSG.BB'"
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.REC,RET.CODE)

    SEL.FILE.CMD = "SELECT ":FILE.DATA.PATH:" WITH @ID LIKE ...SG_EBBS_RDD..."
   CALL EB.READLIST(SEL.FILE.CMD,FILE.LISTS,"",NO.LIST,ERR.LIST)

  REL.ARR =""
SEL.CNT = DCOUNT(SEL.LIST,@FM)
CALL OCOMO(NO.REC:" Selected t24 Rel ids")
    LOOP
        REMOVE Y.REL.ID FROM SEL.LIST SETTING Y.POS
    WHILE Y.REL.ID:Y.POS
        LOCATE Y.REL.ID IN REL.ARR SETTING S.POS ELSE
      *
            REL.ARR<-1> = Y.REL.ID
            J =1
            LOOP
            WHILE J LE NO.LIST
                Y.FILE.ID = FILE.LISTS<J>
                Y.FILE = Y.SRC.FILEPATH:"/":Y.FILE.ID
                
                Y.GREP.CMD = 'SH -c "grep ':Y.REL.ID:' ':Y.FILE:'"'
                EXECUTE Y.GREP.CMD CAPTURING Y.RESPONSE
                IF Y.RESPONSE EQ "" ELSE

                    Y.FLAG.IDS<-1> = Y.RESPONSE
                END
                J+=1
            REPEAT
        END
    REPEAT


RETURN
******************
DATA.ARCH:
SEL.FILE.CMD = "SELECT ":FILE.DATA.PATH:" WITH @ID LIKE ...SG.EBBS.RDD..."
   CALL EB.READLIST(SEL.FILE.CMD,Y.SEL.FILES,"",NO.DATA.LIST,ERR.LIST)
IF Y.SEL.FILES THEN
 K=1
    LOOP

    WHILE K LE NO.DATA.LIST

		CALL OCOMO("Archiving the uploaded file ":Y.SEL.FILES<K>:" after w8w9 flag updation")
        EXE.CMD = "SH -c 'mv ":Y.T24.UPLOAD.PATH:"/":Y.SEL.FILES<K>:" ":Y.T24.UPLOAD.ARC.PATH:"/'"
        CALL OCOMO("File movement command:- ":EXE.CMD)
        EXECUTE EXE.CMD
        K= K+1
    REPEAT
END
RETURN
******************
END
