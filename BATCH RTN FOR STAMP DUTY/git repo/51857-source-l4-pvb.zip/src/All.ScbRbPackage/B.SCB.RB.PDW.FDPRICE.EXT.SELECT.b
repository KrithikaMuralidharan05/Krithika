$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.PDW.FDPRICE.EXT.SELECT
*----------------------------------------------------------------------------
*Modification History:
*---------------------
* 07/09/2022 - Lavanya L - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_FundPrice_YYYYMMDD.csv
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.PDW.FDPR.EXT.COMMON
	
	GOSUB SEL.PROCESS
*
RETURN
*-----------------------------------------------------------------------------
SEL.PROCESS:
*-----------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SECURITY.MASTER
*
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
END