$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SAM.PF.FEE.OFS.UPD.SELECT
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-16591
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.SAM.PF.ZERO.UPD
* Workflow                     This routine will select the SEC.ACC.MASTER table and look for the L.O.B
*                              value of that particular customer. If the customer is retail category then
*                              update PORTFOLIO.FEES field value to 'NONE' through OFS.
*
**************************
* EXTRA CARE MUST BE TAKEN
**************************
* This service has to be run only when it is really required as it will affect the majority of the 
* SEC.ACC.MASTER records.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        25/Nov/2022     CPSGMIG-16591        Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.CUSTOMER
	$INSERT I_F.SEC.ACC.MASTER
	$INSERT I_B.SCB.RB.SAM.PF.FEE.OFS.UPD.COMMON
	
	SEL.CMD = 'SELECT ':FN.SAM:' WITH L.O.B EQ "8"'
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',LIST.CNT,SEL.ERR)

    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST("", SEL.LIST)
    END  
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END