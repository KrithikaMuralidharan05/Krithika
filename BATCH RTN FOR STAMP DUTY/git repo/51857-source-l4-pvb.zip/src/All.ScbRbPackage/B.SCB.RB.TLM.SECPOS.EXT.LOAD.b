$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------------------------------------------------------
* <Rating>-30</Rating>
*-----------------------------------------------------------------------------------------------------------------------------
   SUBROUTINE B.SCB.RB.TLM.SECPOS.EXT.LOAD
*-----------------------------------------------------------------------------------------------------------------------------
* DESCRIPTION:
*-------------
* New routine developed for TLM interface.
* File Name and Variables are initialized in this Routine. 
* 
*-----------------------------------------------------------------------------------------------------------------------------
* Revision History:
*------------------
*   Date               who           	Reference            Description
* 03-Aug-2022        Shreekantha. G     CPSGMIG-5235       Initial Creation
* 25-Apr-2023		 1657186			CPSGMIG-22402	   External Sakekeeping Account Changes.
* 25-Nov-2025        1526956            10607079 		   SN-Swift - Exclusion of Aggregated Security Transfer transaction as part of the downstream reporting_PVB & RBSG
*-----------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.TLM.SECPOS.EXT.COMMON
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM ;*10607079(S/E)
*
    GOSUB INIT
    GOSUB OPEN.FILES
*
    RETURN
*-----------------------------------------------------------------------------------------------------------------------------
INIT:
*----
*
    Y.DELIM = '|'
*
    Y.COMPANY.ID = ID.COMPANY[1,2]
    IF ID.COMPANY EQ 'CH2920660' THEN
        Y.COMPANY.ID = 'MC'
    END
*
    Y.OUT.FILE = '' 
*

    REP.NAME = 'T24_':Y.COMPANY.ID:'_RBSP_':TODAY:'_':SESSION.NO:'.dat'					;* CPSGMIG-5235-S/E
*	
    Y.APP = 'CUSTOMER':@FM:'SECURITY.MASTER'
    Y.FLD = 'L.O.B'
    Y.FLD<-1> := 'MF.ISSUER.NAME'
    Y.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FLD,Y.POS)
    Y.LOB.POS = Y.POS<1,1>
    Y.MF.ISSUER.NAME.POS = Y.POS<2,1>
	Y.PARAM.ID    = 'SCB.CUST.SEG'	
        Y.ALLOW.SEG   = 'RET'			;* Only Retail customer 
        Y.ALLOWED.LOB = ''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
*
    RETURN
*
*-----------------------------------------------------------------------------------------------------------------------------
OPEN.FILES:
*----------
*
    FN.SECURITY.POSITION = 'F.SECURITY.POSITION'
    F.SECURITY.POSITION = ''
    CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)
*
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
*
    FN.SEC.ACC.MASTER = 'F.SEC.ACC.MASTER'
    F.SEC.ACC.MASTER = ''
    CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
*
    AMEX.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME('AMEX.FILES','',AMEX.PATH)
*
* CPSGMIG-22402
	FN.CUSTOMER.SECURITY = 'F.CUSTOMER.SECURITY'
    F.CUSTOMER.SECURITY = ''
    CALL OPF(FN.CUSTOMER.SECURITY,F.CUSTOMER.SECURITY)
* CPSGMIG-22402
***10607079 -S
	FN.SCB.WM.H.LOCAL.PARAM   = 'F.SCB.WM.H.LOCAL.PARAM'  
	F.SCB.WM.H.LOCAL.PARAM 	= ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
*
	R.LOC.PARAM = '' ; LOC.PARAM.ERR = '' ; Y.FIELD.NAME = '' ; Y.FIELD.VALUE = ''
	RB.SG.CUS.POS = '' ; RB.SG.CUST = '' ; PARAM.ID = 'SNSWIFT.DETS'
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,PARAM.ID,R.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,LOC.PARAM.ERR)
	IF R.LOC.PARAM THEN
		Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
		Y.FIELD.VALUE = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE>
		LOCATE 'RB.SG.CUS' IN Y.FIELD.NAME<1,1> SETTING RB.SG.CUS.POS THEN
			RB.SG.CUST = Y.FIELD.VALUE<1,RB.SG.CUS.POS>
			CHANGE @SM TO @VM IN RB.SG.CUST
		END
	END
***10607079 -E
  RETURN
*
*------------------------------------------------------------------------------------------------------------------------------  
END
*-----------------------------------------------------------------------------------------------------------------------------
