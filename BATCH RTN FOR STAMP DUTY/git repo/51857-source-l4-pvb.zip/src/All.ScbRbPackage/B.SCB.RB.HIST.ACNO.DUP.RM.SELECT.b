$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.HIST.ACNO.DUP.RM.SELECT
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Remove Duplicate Txn Ids from SCB.UTS.HIST.PROD.ACNO Table.
*
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 21-Nov-2023 - ADO-2100833 - kalaikumaranp- Remove Duplicate Txn Ids from SCB.UTS.HIST.PROD.ACNO Table.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.RB.HIST.ACNO.DUP.RM.COMMON
    
    GOSUB INIT

    
 RETURN
 *-----------------------------------------------------------------------------
 INIT:
*---
	SEL.LIST = '' ; NO.OF.REC = '' ; RET.CODE = ''
 	SEL.CMD = 'SELECT ':FN.SCB.UTS.HIST.PROD.ACNO
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
    	CALL BATCH.BUILD.LIST('',SEL.LIST)
    END   
 RETURN
 *-----------------------------------------------------------------------------
END   