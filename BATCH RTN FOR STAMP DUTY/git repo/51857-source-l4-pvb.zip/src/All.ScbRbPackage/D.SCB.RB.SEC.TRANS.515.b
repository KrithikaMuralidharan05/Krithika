$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.RB.SEC.TRANS.515(MAT HANDOFF.REC, ERR.MSG)
*-----------------------------------------------------------------------------
* CPSGMIG-779 Asset Transfer External
* Date 23-06-2022
* By   Jewel 2
* Routine is attached to DE.MAPPING>515.SC.0004
* PVB mapping routine is called as is if LOB is of RB further mapping continues
* In Arguments  : HEADER.REC
* Out Arguments : HANDOFF.REC, ERR.MSG
*--------------------------------------------
*-----------------------------------------------------------------------------
* Modification History :
* CPSGMIG-11857 -Sasikumar Kannan- Fatal Out during reversal.
* Call routine SCB.REVERSAL.TRANS.CHK commented.
* CPSGMIG-13129 - Header not populated in Reversal Scenario.
*-----------------------------------------------------------------------------
*CPSGMIG-14526 - Transaction Type to be changed for RB for Advices for Transfers.
*CPSGMIG-15175 -1389710-Removing space in Asset Description.
* 28-Feb-22 -CPSGMIG-19407-1667095-ReversalFlag passed SAME/NEXT
* 08-Aug-2023 CPSGMIG-32375 1670271 Rel ID Delimiters needs to be fixed for Joint Accounts
* 22-Oct-2025 ADO-10849423 - Prithi Koppolu - Removal of T24 security master code from Asset Name in RBSG Contract Notes
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER      ;*CPSGMIG-2417 s/e
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.SECURITY.SUPP
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.POSITION.TRANSFER
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM ;*CPSGMIG-14526(S/E)

* PVB mapping routine as is
    CALL AEB.DE.SC.515(MAT HANDOFF.REC, ERR.MSG)
    IF ID.COMPANY[1,2] NE "SG" THEN
        RETURN    ;*  to be impacted only from Singapore company
    END
* Below mapping change applys to only SNG company trades
    GOSUB INIT
    GOSUB PROCESS

RETURN
*----------------------------------------------------------------------------------------*
INIT:
*----*

    Y.TRANS.ARR = HANDOFF.REC(1)
    Y.HEADER.ARR = HANDOFF.REC(8)
*   Y.REV.ARR = HANDOFF.REC(7) ; *CPSGMIG-13129(S/E)
    Y.SECURITY.NO= Y.TRANS.ARR<9>
    Y.CUST.TRANS.CODE= Y.TRANS.ARR<6>
    Y.CUST.NO = Y.TRANS.ARR<1>
    Y.PORT.NO = Y.TRANS.ARR<40>
    Y.TRANS.ID = HANDOFF.REC(4)<1>
    Y.COMPANY.CODE = Y.HEADER.ARR<2>
*CPSGMIG-13129(S)
*   Y.REV.FLG = Y.REV.ARR<3>
    Y.REV.FLAG = HANDOFF.REC(3)<1>
*CPSGMIG-13129(E)
    Y.DEPOSITORY = HANDOFF.REC(4)<4>
*
    FN.SEC.MASTER = 'F.SECURITY.MASTER'
    F.SEC.MASTER = ''
    CALL OPF(FN.SEC.MASTER,F.SEC.MASTER)
*
    FN.CLIENT.OUTPUT.PARAM = 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    F.CLIENT.OUTPUT.PARAM = ''
    CALL OPF(FN.CLIENT.OUTPUT.PARAM,F.CLIENT.OUTPUT.PARAM)
*
    FN.SECURITY.TRANSFER = 'F.SECURITY.TRANSFER'
    F.SECURITY.TRANSFER = ''
    CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
*
    FN.SC.TRANS.NAME = 'F.SC.TRANS.NAME'
    F.SC.TRANS.NAME = ''
    CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
*
    FN.CUST = 'F.CUSTOMER'
    F.CUST = ''
    CALL OPF(FN.CUST,F.CUST)
* CPSGMIG-14526(S)
    FN.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.LOC.PARAM  = ''
    CALL OPF(FN.LOC.PARAM,F.LOC.PARAM)
*
    Y.LP.ID = 'RS.SC.TRANS.NAME' ; R.LOC.PARAM = ''; Y.LP.ERR = '' ; Y.TRANS.NAME.LIST = ''; Y.TRANS.DESC.LIST = ''
    CALL F.READ(FN.LOC.PARAM,Y.LP.ID,R.LOC.PARAM,F.LOC.PARAM,Y.LP.ERR)
*
    Y.TRANS.NAME.LIST  = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.TRANS.DESC.LIST  = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE>
* CPSGMIG-14526(E)
    APP.NAME = APPLICATION
*
    Y.APP.NAME = 'SECURITY.TRANSFER':@FM:'CUSTOMER':@FM:'SECURITY.MASTER' ;*Included Customer application for fetching Portfolio key
    Y.FLD.NAME = 'LR.PAY.CASA.ACC':@VM:'LR.PAY.CASA.CCY'
	Y.FLD.NAME<-1> = 'LR.PFOLIO.KEY':@VM:'LR.STAFF.IND':@VM:'L.O.B'
	Y.FLD.NAME<-1> = 'LR.UTS.INS.DESC'
    Y.FLD.POS = ""
*
	CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
    Y.PAY.CASA.ACC.POS = Y.FLD.POS<1,1>
    Y.PAY.CASA.CCY.POS = Y.FLD.POS<1,2>
	
	YPfolPos = Y.FLD.POS<2,1>
	YStfPos =  Y.FLD.POS<2,2>
    Y.LOB.POS   =  Y.FLD.POS<2,3>
	YUtsPos  = Y.FLD.POS<3,1>

    CLIENT.IDENTIFIER = ''
    ADVICE.ID = ''
    CONSOL.ID = ''
    R2W.FOLDER = ''
    DEL.MODE = ''
    DISCLAIMER.ID = ''
    CONF.NOTICE = ''
    REVERSAL.FLAG = ''
    PRI.ACCT.HOLDER = ''
    JNT.HOLDER = ''
    Y.CHARGES = 0
    SEGMENT.ID = 'SEGMENT'
    TRF.FEE.ID = 'TRANSFER.FEE'

    CALL F.READ(FN.CUST,Y.CUST.NO,R.CUST,F.CUST,CUST.ERR)
	LR.PFOLIO.KEY = R.CUST<EB.CUS.LOCAL.REF,YPfolPos>
    Y.LOB = R.CUST<EB.CUS.LOCAL.REF,Y.LOB.POS>
    STAFF.IND = R.CUST<EB.CUS.LOCAL.REF,YStfPos>
    PRI.ACCT.HOLDER = FIELD(LR.PFOLIO.KEY,':',1)
    JNT.HOLDER = LR.PFOLIO.KEY
    CHANGE ':' TO '|' IN JNT.HOLDER
	BEGIN CASE
        CASE R.CUST<EB.CUS.SECTOR> EQ "21"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "23"
            YY.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE

RETURN
*----------------------------------------------------------------------------------------*
PROCESS:
*-------*
* Get the list of PVB LOB
    Y.PARAM.ID =''; Y.ALLOW.SEG ='PVB'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    IF Y.LOB MATCHES Y.ALLOWED.LOB THEN
        RETURN   ;* As the customer is private return, no need of further processing and mapping
    END ELSE
        ERR.MSG = ''           ;*If any error w.r.t PVB mapping routine can be ignored as we have all tags mapping below which r not liasing with Pb rtn
    END
* For Position Transfer Application, Mapping for the below scenario's are covered in VERSION.CONTROL level.
* Hence routine execution should be skipped.
* 1) Position Transfer between Nominee for the same Portfolio
* 2) Position Transfer between different Depository (Cash to Unit or Unit to Cash) for the same Portfolio.
   
    IF APPLICATION EQ 'POSITION.TRANSFER' THEN
        IF R.NEW(SC.PST.SEC.ACCT.FROM) EQ R.NEW(SC.PST.SEC.ACCT.TO) THEN
            RETURN
        END
    END

    GOSUB GET.REQ.FIELDS
    
    CHANGE @VM TO @FM IN SEG.FIELD.NAME
    LOCATE Y.COMPANY.CODE IN SEG.FIELD.NAME SETTING SegPos THEN
        SEG.PARAM.VALUE = R.SEG.LOCAL.PARAM<SC.CO.FIELD.VALUE><1,SegPos>
    END
    IF Y.NOMINEE.CODE EQ '' THEN
        LENDING = 'No'
    END ELSE
        LENDING = 'Yes'
    END
*CPSGMIG-19407(S)
    Y.ENT.REC = HANDOFF.REC(4)
    BEGIN CASE
        CASE APPLICATION EQ "SECURITY.TRANSFER"
            Y.DEL.KEY = Y.ENT.REC<77>
            Y.DEL.KEY = FIELD(Y.DEL.KEY,@VM,1)
            Y.RSTATUS = R.NEW(SC.STR.RECORD.STATUS)
        CASE APPLICATION EQ "POSITION.TRANSFER"
            Y.ENT.REC = R.NEW(58)
            Y.DEL.KEY = FIELD(Y.ENT.REC,@VM,1)
            Y.RSTATUS = R.NEW(SC.PST.RECORD.STATUS)
    END CASE
    Y.BANK.DATE = Y.DEL.KEY[2,8]
    Y.CUR.REC.STATUS = Y.RSTATUS[1,1]
    ReversalFlag = ''
    IF (Y.REV.FLAG EQ '1') OR ( Y.CUR.REC.STATUS EQ 'R' ) THEN
        Y.REV.FLG.VALUE = 'REVE'
        BEGIN CASE
            CASE Y.BANK.DATE EQ TODAY
                ReversalFlag = 'SAME'
            CASE Y.BANK.DATE NE TODAY
                ReversalFlag = 'NEXT'
        END CASE
    END ELSE
        Y.REV.FLG.VALUE ='AUTH'
    END
*CPSGMIG-19407(E)
    IF PRODUCT.GRP NE '' THEN
        GOSUB GET.ADVICE.FIELD.VALUE
        GOSUB GET.ASSET.NAME
    END
    GOSUB UPDATE.USR.DEF.VALUE
RETURN
*----------------------------------------------------------------------------------------*
GET.REQ.FIELDS:
    
    CALL F.READ(FN.SEC.MASTER,Y.SECURITY.NO,R.SECURITY.MASTER,F.SEC.MASTER,Y.SEC.ERR)
    Y.SM.DESCRIPTION = R.SECURITY.MASTER<SC.SCM.DESCRIPT>
	YSmNewDescription = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,YUtsPos>
	IF YSmNewDescription THEN
        Y.DESC.NAME = YSmNewDescription                  ;* As per new mapping on 21 Feb 2022 Client Advice impacts
    END ELSE
*CPSGMIG-15175(S)
*       Y.DESC.CNT = DCOUNT(Y.SM.DESCRIPTION,@VM)
*       CNT = 1
*       LOOP
*       WHILE CNT LE Y.DESC.CNT
*           Y.DESC.NAME<-1> = Y.SM.DESCRIPTION<1,CNT,1>
*           CNT = CNT + 1
*       REPEAT
        Y.DESC.NAME = Y.SM.DESCRIPTION
    END
    CHANGE @SM TO '' IN Y.DESC.NAME ;*CPSGMIG-15175(E)

    Y.ISIN.CODE = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
    Y.SUB.ASSET.TYPE.VALUE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
    Y.OPTION.DEPOSITORY = R.SECURITY.MASTER<SC.SCM.OPTION.DEPOSITORY>

    Y.MUTUAL.FUND.FLAG = ''
    Y.MUTUAL.FUND.FLAG = R.SECURITY.MASTER<SC.SCM.MUTUAL.FUND>

    CALL SCB.GET.PRODUCT.API(Y.SECURITY.NO, PRODUCT.GRP)
* CPSGMIG-14526(S)
*   CALL F.READ(FN.SC.TRANS.NAME,Y.CUST.TRANS.CODE,R.SC.TRANS.NAME,F.SC.TRANS.NAME,Y.TRANS.ERR)
*   Y.TRANS.NAME = R.SC.TRANS.NAME<SC.TNM.SHORT.NAME,1>
    LOCATE  Y.CUST.TRANS.CODE IN Y.TRANS.NAME.LIST<1,1> SETTING Y.TRANS.POS THEN
        Y.TRANS.NAME = Y.TRANS.DESC.LIST<1,Y.TRANS.POS>
    END
* CPSGMIG-14526(E)
    IF APPLICATION EQ 'SECURITY.TRANSFER' THEN
        Y.CU.CHRG.TAX.TYPE.LIST = R.NEW(SC.STR.CU.CHARGE.TAX.TYPE)
        Y.CU.CHRG.TAX.AMT.LIST = R.NEW(SC.STR.CU.CHARGE.TAX.AMT)
        Y.SECURITY.CCY = R.NEW(SC.STR.SECURITY.CCY)

        Y.PRICE = R.NEW(SC.STR.PRICE)
        Y.NOMINAL = R.NEW(SC.STR.NO.NOMINAL)
        Y.NOMINEE.CODE = R.NEW(SC.STR.NOMINEE.CODE)
        Y.GROSS.AMT = R.NEW(SC.STR.GROSS.AMT.SEC.CCY)

        Y.PAY.CASA.ACC = R.NEW(SC.STR.LOCAL.REF)<1,Y.PAY.CASA.ACC.POS>
        Y.PAY.CASA.CCY = R.NEW(SC.STR.LOCAL.REF)<1,Y.PAY.CASA.CCY.POS>
    
        Y.ACCT.CCY = R.NEW(SC.STR.CU.ACCOUNT.CCY)
        Y.EXCH.RATE = R.NEW(SC.STR.SEC.EXCH.RATE)
        Y.REV.FLG.CHECK = R.NEW(SC.STR.RECORD.STATUS)
    END
    CALL F.READ(FN.CLIENT.OUTPUT.PARAM,TRF.FEE.ID,R.LOCAL.PARAM,F.CLIENT.OUTPUT.PARAM,Y.PARAM.ERR)
    TRF.FEE.NAME = R.LOCAL.PARAM<SC.CO.FIELD.NAME>
    
    CALL F.READ(FN.CLIENT.OUTPUT.PARAM,SEGMENT.ID,R.SEG.LOCAL.PARAM,F.CLIENT.OUTPUT.PARAM,Y.SEG.ERR)
    SEG.FIELD.NAME = R.SEG.LOCAL.PARAM<SC.CO.FIELD.NAME>
    CHANGE @VM TO @FM IN TRF.FEE.NAME
    LOCATE "GST.FEE" IN TRF.FEE.NAME SETTING FIELD.POS THEN
        GST.FEE.PARAM = R.LOCAL.PARAM<SC.CO.FIELD.VALUE><1,FIELD.POS>
    END
RETURN
*---------------------------------------------------------------------------------
GET.ADVICE.FIELD.VALUE:
*----------------------*
    PRODUCT.GRP.VALUE = TRIM(PRODUCT.GRP," ","A")
    PRODUCT.GRP.VALUE = UPCASE(PRODUCT.GRP.VALUE)
    Y.REC.ID = APP.NAME:"-":PRODUCT.GRP.VALUE:"-":Y.CUST.TRANS.CODE
    
	CALL F.READ(FN.CLIENT.OUTPUT.PARAM,Y.REC.ID,R.CLIENT.OUTPUT.PARAM,F.CLIENT.OUTPUT.PARAM,Y.ADVICE.ERR)
    EVENT.TYPE.ARR = R.CLIENT.OUTPUT.PARAM<SC.CO.EVENT.TYPE>
    CHANGE @VM TO @FM IN EVENT.TYPE.ARR
    LOCATE Y.REV.FLG.VALUE IN EVENT.TYPE.ARR SETTING ADV.POS THEN
        ADVICE.ID = R.CLIENT.OUTPUT.PARAM<SC.CO.ADVICE.ID><1,ADV.POS>
        CONSOL.ID = R.CLIENT.OUTPUT.PARAM<SC.CO.CONSOL.ID><1,ADV.POS>
        DISCLAIMER.ID = R.CLIENT.OUTPUT.PARAM<SC.CO.DISCLAMIER.ID><1,ADV.POS>
        CONF.NOTICE = R.CLIENT.OUTPUT.PARAM<SC.CO.CONFIRMATION.NOTICE><1,ADV.POS>
        DEL.MODE = R.CLIENT.OUTPUT.PARAM<SC.CO.DELIVERY.MODE><1,ADV.POS>

*  CALL SCB.ACCT.HOLDER.RTN(Y.PORT.NO,CLIENT.IDENTIFIER,PRI.ACCT.HOLDER,JNT.HOLDER) ;* Direct mapping is available in CUSTOMER application
    END
    CALL SCB.CLIENTIDEN.R2WFOLD.RTN(YY.CLIENT.IDENTIFIER,R2W.FOLDER)

RETURN
*---------------------------------------------------------------------------------
GET.ASSET.NAME:
*-------------*
    IF PRODUCT.GRP.VALUE EQ 'FUNDS' THEN
        IF Y.OPTION.DEPOSITORY NE '' THEN
            Y.INVEST.OPTION = 'INVEST.OPTION'
            CALL F.READ(FN.CLIENT.OUTPUT.PARAM,Y.INVEST.OPTION,R.INVEST.LOCAL.PARAM,F.CLIENT.OUTPUT.PARAM,Y.INVEST.ERR)
            INVEST.FIELD.NAME = R.INVEST.LOCAL.PARAM<SC.CO.FIELD.NAME>
            Y.INVEST.OPTION.TYPE.ARR = R.SECURITY.MASTER<SC.SCM.INVEST.OPTION.TYPE>
        
            LOCATE Y.DEPOSITORY IN Y.OPTION.DEPOSITORY<1,1> SETTING Y.DEPO.POS THEN
            	Y.OPTION.DEPOSITORY = Y.INVEST.OPTION.TYPE.ARR<1,Y.DEPO.POS>
                LOCATE Y.OPTION.DEPOSITORY IN INVEST.FIELD.NAME<1,1> SETTING Y.INVEST.POS THEN
                    Y.DEPO.ASSET = R.INVEST.LOCAL.PARAM<SC.CO.FIELD.SUB.VALUE><1,Y.INVEST.POS>
                END
            END
        END

        IF Y.DEPO.ASSET NE '' THEN
            Y.ASSET.NAME = Y.DESC.NAME:' ':Y.DEPO.ASSET
        END ELSE
            Y.ASSET.NAME = Y.DESC.NAME
        END
    END ELSE
        Y.ASSET.NAME = Y.DESC.NAME
    END
RETURN
*---------------------------------------------------------------------------------
UPDATE.USR.DEF.VALUE:
*----------------------*
*	IF YY.CLIENT.IDENTIFIER THEN
    HANDOFF.REC(9)<25,1> = YY.CLIENT.IDENTIFIER ;*As per the new logic for client Identifier provided as on 20220208
*    END ELSE
*        HANDOFF.REC(9)<25,1> = CLIENT.IDENTIFIER
*	END
    *Y.ASSET.NAME = Y.SECURITY.NO :' ':Y.ASSET.NAME
    Y.ASSET.NAME = Y.ASSET.NAME ;* ADO-10849423(S/E)
    HANDOFF.REC(9)<27,1> = ADVICE.ID
    HANDOFF.REC(9)<26,1> = CONSOL.ID
    HANDOFF.REC(9)<36,1> = DISCLAIMER.ID
    HANDOFF.REC(9)<29,1> = R2W.FOLDER
    HANDOFF.REC(9)<28,1> = CONF.NOTICE
    HANDOFF.REC(9)<34,1> = PRODUCT.GRP
    HANDOFF.REC(9)<30,1> = PRI.ACCT.HOLDER
    HANDOFF.REC(9)<31,1> = JNT.HOLDER
    HANDOFF.REC(9)<35,1> = LENDING
    HANDOFF.REC(9)<32,1> = Y.ASSET.NAME
    HANDOFF.REC(9)<33,1> = Y.ISIN.CODE
    HANDOFF.REC(1)<4> = Y.TRANS.NAME ;* CPSGMIG-14526(S/E)
    HANDOFF.REC(9)<37,1> = "TNO" 		;* new tag telno introduced for CPSGMIG-779
    HANDOFF.REC(9)<38,1> = ReversalFlag ;**CPSGMIG-19407(S/E)
    IF APPLICATION EQ 'POSITION.TRANSFER' THEN
        HANDOFF.REC(1)<12> = ""   ;* Price is not required for the advices generated for Position Transfer
*  HANDOFF.REC(1)<4> = Y.TRANS.NAME;* Transaction Type Desc is not mapped by core.
    END

RETURN
*---------------------------------------------------------------------------------
END