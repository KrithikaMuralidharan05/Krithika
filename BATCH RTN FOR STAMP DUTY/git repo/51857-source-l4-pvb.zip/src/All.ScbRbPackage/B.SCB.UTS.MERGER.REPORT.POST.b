* @ValidationCode : MjotMTgyNTA2ODc0NDpJU08tODg1OS0xOjE2ODI1ODA5NTQ4OTA6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 27 Apr 2023 13:05:54
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.UTS.MERGER.REPORT.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5332 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       13 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* POST Routine to merge the Trade details and generate final report
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SCB.UTS.MERGER.REPORT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 07-11-2022    1663000          CPSGMIG-15197 - Update Header for Paytype
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename/Date Change
* 03-12-2025    Anitha Rani S    ADO-11478838    To add additional attribute 'Transaction Date' in the report
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
	GOSUB PROCESS
	 
RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
    
    Y.UTS.FINAL.FILE    = BATCH.DETAILS<3,1>
    Y.LWD               = R.DATES(EB.DAT.LAST.WORKING.DAY) ;* CPSGMIG-21498
    Y.UTS.FINAL.FILE = EREPLACE(Y.UTS.FINAL.FILE,"<LWD>",Y.LWD,-1)    ;*CPSGMIG-21498

    YDL = ','

RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.UTS.ARR = '' ; Y.FINAL.UTS.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = "SGINQSUBSREDEMPSWISWO-" :TODAY:"-*.csv*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(R.UTS.ARR) THEN
                R.UTS.ARR = R.AMEX.FILE
            END ELSE
                R.UTS.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

* Include the Header part
        Y.UTS.HDR  = 'Trade Reference'    :YDL: 'ORDER_TYPE'                 :YDL: 'PROD_TYPE'                     :YDL: 'ASSET_CODE'      :YDL: 'SAT'             :YDL
        Y.UTS.HDR := 'ORDER_DATE'         :YDL: 'SUB_UNIT/RED_UNIT/SWT_UNIT' :YDL: 'SUB_VALUE/RED_VALUE/SWT_VALUE' :YDL: 'SUB_ORDER_NO'    :YDL: 'SUB_FE_ORDER_NO' :YDL
        Y.UTS.HDR := 'ACA_AC_NO'          :YDL: 'SALES_CHARGE'               :YDL: 'COMMISSION'                    :YDL: 'ORDER_CREATE_ID' :YDL: 'RELATIONSHIP_ID' :YDL
        Y.UTS.HDR := 'TRANSACTION_STATUS' :YDL: 'DETAIL ON ORDER TYPE'       :YDL: 'TRANSACTION_DATE'   ;*CPSGMIG-15197  ;* ADO-11478838

        Y.FINAL.UTS.ARR     = Y.UTS.HDR
        Y.FINAL.UTS.ARR<-1> = R.UTS.ARR
    
	    WRITE Y.FINAL.UTS.ARR TO F.AMEX.FILES,Y.UTS.FINAL.FILE
    END

RETURN
END
