* @ValidationCode : MjozNjkwODk2OTA6SVNPLTg4NTktMToxNjc4Njg2NDQ5MjQ3OjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 13 Mar 2023 11:17:29
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.MTM.BOOKBUILD(YSECTRID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14087 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       16 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .PROCESS Routine to extract Unsettled Trades
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 13-Mar-2023   1663000          CPSGMIG-21143 - Include ClientIdentifier & PrimaryAccountHolder columns
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.MTM.BOOKBUILD.COMMON
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.CUSTOMER
*--------------------------------------------------------------------------------------------

    GOSUB DO.PROCESS

RETURN
*---------*
DO.PROCESS:
*---------*
    
    R.SEC.TRADE = ''; SEC.TRADE.ERR = ''
    CALL F.READ(FN.SEC.TRADE,YSECTRID,R.SEC.TRADE,F.SEC.TRADE,SEC.TRADE.ERR)
    
    IF R.SEC.TRADE THEN
        Y.CUST.NO  = R.SEC.TRADE<SC.SBS.CUSTOMER.NO>
        Y.SM.ID    = R.SEC.TRADE<SC.SBS.SECURITY.CODE>
        Y.TRADE.DT = OCONV(ICONV(R.SEC.TRADE<SC.SBS.TRADE.DATE>,'D4'),'D4')
        Y.VALUE.DT = OCONV(ICONV(R.SEC.TRADE<SC.SBS.VALUE.DATE>,'D4'),'D4')
           
* Get Customer
        R.CUSTOMER = '' ; CUSTOMER.ERR = '' ; Y.LOB = ''
        CALL F.READ(FN.CUSTOMER,Y.CUST.NO,R.CUSTOMER,F.CUSTOMER,CUSTOMER.ERR)
        Y.LOB              = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
        Y.CUS.PRIMARY.HLDR = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.CUS.LRPFOLIO.POS>         ;* CPSGMIG-21143 -S
        Y.SECTOR           = R.CUSTOMER<EB.CUS.SECTOR>
        Y.STAFF.IND        = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.CU.STAFFIND.POS>
    
        Y.CLIENT.IDENTIFIER = ""
        BEGIN CASE
            CASE Y.SECTOR EQ "21"
                Y.CLIENT.IDENTIFIER = "SG.RETAIL"
            CASE Y.SECTOR EQ "51" AND Y.STAFF.IND EQ "Y"
                Y.CLIENT.IDENTIFIER = "SG.RETAIL"
            CASE Y.SECTOR EQ "23"
                Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
        END CASE                                                                    ;* CPSGMIG-21143 -E

* Get SM
        R.SECURITY.MASTER = '' ; SM.ERR = '' ; Y.SN.FLAG = ''
        CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,F.SECURITY.MASTER,SM.ERR)
        Y.SAT.VAL     = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
        IF Y.SAT.VAL MATCHES Y.SN.PARAM.FLD.VALUE THEN
            Y.SN.FLAG = 'Y'
        END
    
        IF (Y.LOB MATCHES Y.ALLOWED.LOB) AND (Y.SN.FLAG EQ 'Y') THEN
            GOSUB WRITE.TO.FILE
        END
    END
    
RETURN
*------------*
WRITE.TO.FILE:
*------------*

    Y.OUT.ARR  = ''
    Y.OUT.ARR  = YSECTRID                                                       ;*  1. Transaction Reference
    Y.OUT.ARR := ','                                                            ;*  2. Customer Name
    Y.OUT.ARR := ',': R.SEC.TRADE<SC.SBS.SECURITY.CODE>                         ;*  3. Asset Code
    Y.OUT.ARR := ',': Y.TRADE.DT                                                ;*  4. Trade Date
    Y.OUT.ARR := ',': Y.VALUE.DT                                                ;*  5. Value Date
    Y.OUT.ARR := ','                                                            ;*  6. Branch Code
    Y.OUT.ARR := ',': R.SEC.TRADE<SC.SBS.CUST.SEC.ACC>                          ;*  7. ISA
    Y.OUT.ARR := ',': R.SEC.TRADE<SC.SBS.CUST.TRANS.CODE>                       ;*  8. Transaction Type
    Y.OUT.ARR := ',': R.SEC.TRADE<SC.SBS.TRADE.CCY>                             ;*  9. Currency
    Y.OUT.ARR := ',': R.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>                         ;* 10. Amount
    Y.OUT.ARR := ',': Y.CLIENT.IDENTIFIER                                       ;* 11. ClientIdentifier      ;* CPSGMIG-21143
    Y.OUT.ARR := ',': Y.CUS.PRIMARY.HLDR                                        ;* 12. PrimaryAccountHolder  ;* CPSGMIG-21143
  
    OPENSEQ AMEX.FILES,Y.TEMP.FILE TO FP.AMEX.FILES ELSE
    END
    WRITESEQ Y.OUT.ARR APPEND TO FP.AMEX.FILES ELSE
        CALL OCOMO("Unable to Write txn details for MTM Bookbuild Report")
    END
    CLOSESEQ FP.AMEX.FILES
    
RETURN
END
