* @ValidationCode : MjoxMTE4NDQ1Mzk0OklTTy04ODU5LTE6MTY4MjMzMzc1Njc4MzoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 24 Apr 2023 16:25:56
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SETT.UNSETT.TRADES.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14422 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       18 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .POST Routine to extract Daily Trasaction details for the current month.
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
* 04-Jan-2023 - 1404392          CPSGMIG-17782 - Vestima Flag introduction and new requirement changes
* 03-Apr-2023   1663000          CPSGMIG-18645 & 14067 - PII Column Included
* 26-Apr-2023   1663000          CPSGMIG-21498 - Filename Change
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES ;* CPSGMIG-21498
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
	GOSUB PROCESS
	 
RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.TXN.FINAL.FILE    = BATCH.DETAILS<3,1>
    Y.LWD            = R.DATES(EB.DAT.LAST.WORKING.DAY) ;* CPSGMIG-21498
    Y.TXN.FINAL.FILE = EREPLACE(Y.TXN.FINAL.FILE,"<LWD>",Y.LWD,-1) ;* CPSGMIG-21498
    
    YDL = ','

RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.TXN.ARR = '' ; Y.FINAL.TXN.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = "SCBSETTUNSETTMTHREPT-" :TODAY:"-*.csv*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(R.TXN.ARR) THEN
                R.TXN.ARR = R.AMEX.FILE
            END ELSE
                R.TXN.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

* Include the Header part
        Y.TXN.HDR  = 'Account Type':YDL: 'Order No' :YDL: 'Product Provider Order No' :YDL: 'Order Date' :YDL: 'Transaction Date'  :YDL
        Y.TXN.HDR := 'Confirmation Date' :YDL: 'Order Transaction Type' :YDL: 'Order Type' :YDL: 'Transaction Status' :YDL: 'Product Provider Name' :YDL
        Y.TXN.HDR := 'Asset Code'  :YDL: 'Asset Name'   :YDL: 'Asset Currency'   :YDL: 'Dividend Instruction' :YDL: 'Transaction Unit' :YDL
        Y.TXN.HDR := 'Asset CASH Account No' :YDL: 'Asset REINVESTMENT Account No' :YDL: 'ISIN Code' :YDL: 'CPFOA' :YDL: 'CPFSA' :YDL: 'SRS':YDL: 'Vestima' :YDL: ;*CPSGMIG-18645 & 14067 -S
        Y.TXN.HDR := 'Client NRIC' :YDL:'Client Name':YDL:'Transaction Amount':YDL:'SCB Rebate (Amt CCY)':YDL:'SCB Charge (Amt CCY)':YDL:'Asset UT Code':YDL:'ClientIdentifier' :YDL
        Y.TXN.HDR := 'PrimaryAccHolder' :YDL:'Discount Percentage': YDL: 'Price': YDL:'Country Code' :YDL:'RM Name':YDL:'Portfolio No':YDL:'Account Holder DOB': YDL:'ID':YDL:'Account Opening Branch Code':YDL:
        Y.TXN.HDR := 'Customer Type'    :YDL:'Sales Code'                 ;*CPSGMIG-18645 & 14067 -E
        Y.FINAL.TXN.ARR     = Y.TXN.HDR
        Y.FINAL.TXN.ARR<-1> = R.TXN.ARR
    
	    WRITE Y.FINAL.TXN.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
    END

RETURN
END

