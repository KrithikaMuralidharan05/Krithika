* @ValidationCode : MjotMjIzMjQ0MzE6SVNPLTg4NTktMToxNjkzMjk3OTE3MTU3OjE2NjMwMDA6LTE6LTE6MDowOmZhbHNlOk4vQTpSMjBfU1AxMC4wOi0xOi0x
* @ValidationInfo : Timestamp         : 29 Aug 2023 14:01:57
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.DAILY.TXN.ORDER.LOAD
*-----------------------------------------------------------------------------
* Jira ref                       :      ADO-11887708
* Developed By                   :      8219622
* Developed On                   :      20-Feb-2026
*-----------------------------------------------------------------------------
* Description:
*-------------
* Batch report attached to SNG/SCB.RB.DAILY.TXN.ORDER inorder to generate report for daily transactions of SEC.TRADE,SEC.OPEN.ORDER AND SECURITY.TRANSFER 
* regardless of whether it is in authorized, unauthorized or hold status
*-------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 29/05/2026  Anitha Rani S  ADO-14141490 - Channel Info to be displayed for SEC.OPEN.ORDER 
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_F.DATES
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.DAILY.TXN.ORDER.COMMON
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    GOSUB OPENFILES

RETURN
*---------*
INITIALISE:
*---------*
    
* Get LRT Values
    Y.APP.NAME<1> = 'CUSTOMER'
    Y.APP.NAME<2> = 'SEC.OPEN.ORDER'
    Y.APP.NAME<3> = 'SEC.ACC.MASTER'
    Y.APP.NAME<4> = 'SEC.TRADE'
    Y.APP.NAME<5> = 'SECURITY.TRANSFER'
    Y.APP.NAME<6> = 'SECURITY.MASTER'
    
    Y.FLD.NAME<1> = 'LR.EBBS.REL':@VM:'REL.CIF.NO':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.SIGN.MANDATE'
    Y.FLD.NAME<2> = 'LR.RSP.REF':@VM:'LR.REFERRAL.ID':@VM:'LR.CLOSING.ID'       
	Y.FLD.NAME<2>:= @VM:'LR.OMF.REF.NO':@VM:'TAP.REF.NO'                                       ;*ADO-14141490
    Y.FLD.NAME<3> = 'LR.LIEN.CODE'
    Y.FLD.NAME<4> = 'LR.CLOSING.ID':@VM:'LWM.EDP.REF.NUM':@VM:"LR.OMF.REF.NO":@VM:"TAP.REF.NO":@VM:'LR.REFERRAL.ID'
    Y.FLD.NAME<5> = 'LWM.EDP.REF.NUM'
    Y.FLD.NAME<6> = 'LR.UTS.INS.DESC'
    
    Y.FLD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP.NAME,Y.FLD.NAME,Y.FLD.POS)
    
*Customer LRT
    Y.LR.EBBS.REL.POS   = Y.FLD.POS<1,1>
    Y.REL.CIF.NO.POS    = Y.FLD.POS<1,2>
    Y.LR.STAFF.IND.POS  = Y.FLD.POS<1,3>
    Y.LR.PFOLIO.KEY.POS = Y.FLD.POS<1,4>
    Y.LR.SIGN.MANDT.POS = Y.FLD.POS<1,5>
    
*SOO LRT
    Y.LR.RSP.REF.POS   = Y.FLD.POS<2,1>
    Y.REFERRAL.ID.POS = Y.FLD.POS<2,2>
    Y.LR.CLOSING.ID.POS.SO = Y.FLD.POS<2,3>
*ADO-14141490-S
	Y.LR.OMF.REF.NO.POS.SO = Y.FLD.POS<2,4>    
	Y.TAP.REF.NO.POS.SO = Y.FLD.POS<2,5>
*ADO-14141490-E
    
*SAM LRT
    Y.LR.LIEN.CODE.POS = Y.FLD.POS<3,1>
    
*Sec Trade LRT
    Y.LR.ORD.CLOSE.ID.POS = Y.FLD.POS<4,1>
    Y.LWM.EDP.REF.NUM.POS = Y.FLD.POS<4,2>
    Y.LR.OMF.REF.NO.POS   = Y.FLD.POS<4,3>
    Y.TAP.REF.NO.POS      = Y.FLD.POS<4,4>
    Y.LR.REF.POS          = Y.FLD.POS<4,5>
     
*Security Transfer LRT
    Y.LWM.EDP.REF.NUM.ST.POS = Y.FLD.POS<5,1>
    
*Security Master LRT
    Y.LR.UTS.DESC.POS = Y.FLD.POS<6,1>

    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
	
	Y.TEMP.FILE = "DAILYORDERTXN-":TODAY:"-":SESSION.NO:".csv"
    
    Y.DELIM          = ","
    
RETURN
*--------*
OPENFILES:
*--------*
             
    FN.CUSTOMER               = 'F.CUSTOMER'              ; F.CUSTOMER               = '' ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SEC.TRADE              = 'F.SEC.TRADE'             ; F.SEC.TRADE              = '' ;	CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    FN.SC.TRANS.NAME          = 'F.SC.TRANS.NAME'         ; F.SC.TRANS.NAME          = '' ;	CALL OPF(FN.SC.TRANS.NAME,F.SC.TRANS.NAME)
    FN.SECURITY.MASTER        = 'F.SECURITY.MASTER'       ; F.SECURITY.MASTER        = '' ;	CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SEC.OPEN.ORDER         = 'F.SEC.OPEN.ORDER'        ; F.SEC.OPEN.ORDER         = '' ;	CALL OPF(FN.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER)
    FN.SEC.OPEN.ORDER.HIS     = 'F.SEC.OPEN.ORDER$HIS'    ; F.SEC.OPEN.ORDER.HIS     = '' ;	CALL OPF(FN.SEC.OPEN.ORDER.HIS,F.SEC.OPEN.ORDER.HIS)
    FN.SEC.OPEN.ORDER.NAU     = 'F.SEC.OPEN.ORDER$NAU'    ; F.SEC.OPEN.ORDER.NAU     = '' ;	CALL OPF(FN.SEC.OPEN.ORDER.NAU,F.SEC.OPEN.ORDER.NAU)
	FN.SUB.ASSET.TYPE         = 'F.SUB.ASSET.TYPE'        ; F.SUB.ASSET.TYPE         = '' ;	CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
    FN.SECURITY.TRANSFER      = 'F.SECURITY.TRANSFER'     ; F.SECURITY.TRANSFER      = '' ;	CALL OPF(FN.SECURITY.TRANSFER,F.SECURITY.TRANSFER)
    FN.SEC.ACC.MASTER         = 'F.SEC.ACC.MASTER'        ; F.SEC.ACC.MASTER         = '' ; CALL OPF(FN.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
    FN.SC.SCB.LIEN.CODE       = 'F.SC.SCB.LIEN.CODE'      ; F.SC.SCB.LIEN.CODE       = '' ;	CALL OPF(FN.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE)
    FN.SEC.TRADE.HIS          = 'F.SEC.TRADE$HIS'         ; F.SEC.TRADE.HIS          = '' ; CALL OPF(FN.SEC.TRADE.HIS,F.SEC.TRADE.HIS)
	FN.SEC.TRADE.NAU          = 'F.SEC.TRADE$NAU'         ; F.SEC.TRADE.NAU          = '' ; CALL OPF(FN.SEC.TRADE.NAU,F.SEC.TRADE.NAU)
    FN.SECURITY.TRANSFER.HIS  = 'F.SECURITY.TRANSFER$HIS' ; F.SECURITY.TRANSFER.HIS  = '' ; CALL OPF(FN.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS)
	FN.SECURITY.TRANSFER.NAU  = 'F.SECURITY.TRANSFER$NAU' ; F.SECURITY.TRANSFER.NAU  = '' ; CALL OPF(FN.SECURITY.TRANSFER.NAU,F.SECURITY.TRANSFER.NAU)
    FN.SC.SCB.RB.BLOCK        = 'F.SC.SCB.RB.BLOCK'       ; F.SC.SCB.RB.BLOCK        = '' ; CALL OPF(FN.SC.SCB.RB.BLOCK,F.SC.SCB.RB.BLOCK)
    FN.SECURITY.POSITION      = 'F.SECURITY.POSITION'     ; F.SECURITY.POSITION      = '' ; CALL OPF(FN.SECURITY.POSITION,F.SECURITY.POSITION)
    FN.SCB.WM.H.LOCAL.PARAM   = 'F.SCB.WM.H.LOCAL.PARAM'  ; F.SCB.WM.H.LOCAL.PARAM 	 = '' ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
	FN.DATES                  = 'F.DATES'                 ; F.DATES                  = '' ; CALL OPF(FN.DATES,F.DATES)
	FN.SCB.RB.DAILY.TXN.DETAILS = 'FSNG.SCB.RB.DAILY.TXN.DETAILS' ; F.SCB.RB.DAILY.TXN.DETAILS = '' ; CALL OPF(FN.SCB.RB.DAILY.TXN.DETAILS,F.SCB.RB.DAILY.TXN.DETAILS)
	
    CALL SCB.GET.ORACLE.VIEWNAME(FN.SECURITY.POSITION,Y.VIEW.NAME)   ;* Get Security Position View Name

    R.SCB.H.LOCAL.PARAM = '' ; ERR.SCB.WM.H.LOCAL.PARAM = '' ; Y.ALLOWED.SEGMENT = '' ; Y.ALLOWED.SAT.LIST = '' 
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,"SCB.CRES.SAT",R.SCB.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,ERR.SCB.WM.H.LOCAL.PARAM)
    Y.ALLOWED.SEGMENT = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.NAME>
    Y.ALLOWED.SAT.LIST  = R.SCB.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
	
	Y.SEG.POS = ''; Y.FI.SAT.CODES = ''
    LOCATE "FI" IN Y.ALLOWED.SEGMENT<1,1> SETTING Y.SEG.POS THEN
        Y.FI.SAT.CODES = Y.ALLOWED.SAT.LIST<1,Y.SEG.POS>
        CONVERT @SM TO @VM IN Y.FI.SAT.CODES
    END

    R.LOC.PARAM = '' ; LOC.PARAM.ERR = '' ; Y.FIELD.NAME = '' ; Y.FIELD.VALUE = ''
	RB.SG.CUS.POS = '' ; RB.SG.CUST = '' ; PARAM.ID = 'SNSWIFT.DETS'
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,PARAM.ID,R.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,LOC.PARAM.ERR)
	IF R.LOC.PARAM THEN
		Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
		Y.FIELD.VALUE = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE>
		LOCATE 'RB.SG.CUS' IN Y.FIELD.NAME<1,1> SETTING RB.SG.CUS.POS THEN
			RB.SG.CUST = Y.FIELD.VALUE<1,RB.SG.CUS.POS>
			CHANGE @SM TO @VM IN RB.SG.CUST
		END
	END
   
RETURN
END