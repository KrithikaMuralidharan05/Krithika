$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CS.TR.FEE.UPD.LOAD
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-12313
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.CS.TR.FEE.UPD
* Workflow                     This routine will select the customer security table and look for the L.O.B
*                              value of that particular customer. If the customer LOB other than RET L.O.B
*                              list available in Common Parameter then system will update EXCL.TRAIL.FEE
*                              field value as 'YES'
*
**************************
* EXTRA CARE MUST BE TAKEN
**************************
* This Service has to be run only when it is really required as it will affect the majority of the 
* customer security records.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        22/Dec/2022     CPSGMIG-12313        Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
    $INSERT I_B.SCB.RB.CS.TR.FEE.UPD.COMMON
	
	GOSUB INIT

	RETURN
*--------------------------------------------------------------------------------------------------------
INIT:
*****

	FN.CUS = 'F.CUSTOMER'
	FV.CUS = ''
	CALL OPF(FN.CUS,FV.CUS)
	
	FN.CUS.SEC = 'F.CUSTOMER.SECURITY'
	FV.CUS.SEC = ''
	CALL OPF(FN.CUS.SEC,FV.CUS.SEC)

	FN.SL = "&SAVEDLISTS&"
	FV.SL = ''
	CALL OPF(FN.SL,FV.SL)
	
	Y.APPL = 'CUSTOMER'
	Y.LOC.FLD = 'L.O.B'
	CALL MULTI.GET.LOC.REF(Y.APPL,Y.LOC.FLD,Y.FLDPOS)
	Y.LOB.POS = Y.FLDPOS<1,1>
	
    Y.PARAM.ID  = 'SCB.CUST.SEG'
    Y.ALLOW.SEG = 'RET'
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END