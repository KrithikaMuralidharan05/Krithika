$PACKAGE All.ScbRbPackage
	SUBROUTINE B.SCB.RB.ASSETLIAB.SAM.VAL(Y.PORT.ID)
* -------------------------------------------------------------------------------------
* Multithread routine for the file generation of SG-RB-ASSET-LIAB-<date>.csv to EDMP
*
**---------------------------------------------------------------------------------------------------------------------------------------------------
*
* Modification History : 
*
* 31/10/2022 - Lavanya L - CPSGMIG-291 - DAY 0 file generation
*--------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_BATCH.FILES
	$INSERT I_B.SCB.RB.ASSETLIAB.SAM.VAL.COMMON
		
	CALL OCOMO("### SC.OL.VAL.SEC Start ":OCONV(TIME(),'MTS'):" ###")
	CALL SC.OL.VAL.SEC(Y.PORT.ID) 
	
	RETURN
END