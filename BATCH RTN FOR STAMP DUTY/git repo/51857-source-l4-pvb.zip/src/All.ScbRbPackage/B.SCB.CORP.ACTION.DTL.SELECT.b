$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CORP.ACTION.DTL.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14066 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       08 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract Daily corporate action details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CORP.ACTION.DTL.LOAD
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.CORP.ACTION.DTL.COMMON
*--------------------------------------------------------------------------------------------

    GOSUB SELECT.RECORDS

RETURN
*-------------*
SELECT.RECORDS:
*-------------*
    
* Select Transaction details for the Current Month
    COUNTRY.NAME = ID.COMPANY[1,2]
    SEL.CMD = "SELECT ":FN.SEC.TRADES.MDAY:" WITH @ID LIKE ":COUNTRY.NAME:"...*DIAR..."
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)
    CALL BATCH.BUILD.LIST('',SEL.LIST)

RETURN


END
