$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CUST.ACCT.INFO.EXT.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13123 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       30 December 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Main Routine to extract Customer Info batch for iBanking from CUSTOMER and SAM
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CUST.ACCT.INFO.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 23-Mar- 2023 - CPSGMIG-18238 - Lakshmi PR- Parameterised the customer tranche records
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_B.SCB.CUST.ACCT.INFO.EXT.COMMON
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM ;*CPSGMIG-18238- Start/End
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.SAM = "F.SEC.ACC.MASTER"
    FV.SAM = ""
    CALL OPF(FN.SAM,FV.SAM)
    
    FN.EBBS.REL.CONCAT = 'F.ST.SCB.RSG.EBBS.REL.CONCAT'
    FV.EBBS.REL.CONCAT = ''
    CALL OPF(FN.EBBS.REL.CONCAT,FV.EBBS.REL.CONCAT)

    FN.SEC.ACC.CUST = 'F.SEC.ACC.CUST'
    F.SEC.ACC.CUST = ''
    CALL OPF(FN.SEC.ACC.CUST,F.SEC.ACC.CUST)
	

    FN.CUSTOMER = "F.CUSTOMER"
    F.CUSTOMER = ""
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)
	
*CPSGMIG-18238- Start
	FN.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
    F.LOC.PARAM = ''
    CALL OPF(FN.LOC.PARAM,F.LOC.PARAM)
	
*CPSGMIG-18238- End	
    Y.APP = 'CUSTOMER'
    Y.FIELD = 'LR.EBBS.REL':@VM:'L.O.B':@VM:'LR.SIGN.MANDATE':@VM:'LR.PRIM.SEC.ID':@VM:'LR.POS.MIG.DT' ;*CPSGMIG-18238- Start/End
    Y.FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    Y.EBBS.CUST.REL.ID.POS = Y.FIELD.POS<1,1>
    Y.LOB.POS = Y.FIELD.POS<1,2>
    Y.LR.SIGN.MANDATE.POS = Y.FIELD.POS<1,3>
    Y.PRIM.SEC.POS = Y.FIELD.POS<1,4>
	
	Y.MIG.DAT.POS = Y.FIELD.POS<1,5> ; *CPSGMIG-18238- Start/End
    
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    
    AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
*
	FILE.NAME = "T24RbsgIbankCustInfo_":TODAY:"_":SESSION.NO:".txt"

*CPSGMIG-18238- Start	
	Y.FILE.FLAG =  ''
   ID.LOC.PARAM = 'SCB.RB.CUST.FULL.TRANCHE'
   Y.FIND.FILE.NAME = 'T24_RBSG_IBANK_CUSTINFO'
   CALL F.READ(FN.LOC.PARAM,ID.LOC.PARAM,R.LOC.PARAM,F.LOC.PARAM,LOC.ERR)
   IF R.LOC.PARAM THEN
      Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
          LOCATE Y.FIND.FILE.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
           Y.FILE.FLAG = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>
           CONVERT SM TO VM IN Y.FILE.FLAG
           Y.FILE.FLAG = Y.FILE.FLAG<1,2>
          END
   END 
 *CPSGMIG-18238- End  
	
*
RETURN
*-----------------------------------------------------------------------------
END
