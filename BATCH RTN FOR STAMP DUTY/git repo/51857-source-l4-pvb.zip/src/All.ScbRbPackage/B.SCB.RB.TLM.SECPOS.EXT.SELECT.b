$PACKAGE All.ScbRbPackage
*---------------------------------------------------------------------------------------
* <Rating>-10</Rating>
*---------------------------------------------------------------------------------------
   SUBROUTINE B.SCB.RB.TLM.SECPOS.EXT.SELECT
*---------------------------------------------------------------------------------------
* DESCRIPTION:
*------------*
* New routine developed for TLM interface.
* Select the Record from SECURITY.POSITION 
* 
*---------------------------------------------------------------------------------------
* Revision History:
*------------------
*   Date               who           	Reference            Description
* 03-Aug-2022       Shreekantha. G      CPSGMIG-5237         Initial Creation
*---------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.TLM.SECPOS.EXT.COMMON
*
*---------------------------------------------------------------------------------------
*
    SEL.CMD.SEC.POS = 'SELECT ': FN.SECURITY.POSITION : ' WITH VALUE.DATED.POSN GT 0'
    CALL EB.READLIST(SEL.CMD.SEC.POS, SEC.POS.ID.LIST, '', NO.OF.REC, Y.SEC.POS.ERR)
*
    CALL BATCH.BUILD.LIST('',SEC.POS.ID.LIST)
*
    RETURN
*---------------------------------------------------------------------------------------
END
*---------------------------------------------------------------------------------------
