$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.AM.EXTRACT(Y.SAM.ID)
*----------------------------------------------------------------------------------------
* 
* 
*------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864
** 17-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer. 
*
* 04/12/2022 - Sasi V - PF.SKIP - To suppress configured portfolio in SCB.WM.H.LOCAL.PARAM>SCB.RB.DPL.PF
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_B.SCB.RB.EBBS.AM.EXT.COMMON
    $INSERT I_F.DATES
*------------------------------------------------------------------------------------------
* PF.SKIP - S
	LOCATE Y.SAM.ID IN Y.PF.LIST<1> SETTING PF.SKIP.POS THEN
		RETURN
	END
* PF.SKIP - E
*
*CPSGMIG-13878(S)
   $INSERT I_F.SCB.WM.H.LOCAL.PARAM
   GOSUB CHECK.CUS.ALLOWED.LIST
   IF Y.CUS.ALLOWED.FLAG EQ 1 OR Y.SECTOR.VAL EQ '23' THEN
*CPSGMIG-13878(E)
    Y.DELIM = '|' 

    OPENSEQ Y.APPEND.FILE,Y.FILE.NAME TO FP.SEC.ACC.MAS.LIST ELSE 
    	CREATE FP.SEC.ACC.MAS.LIST ELSE
		CRT " UNABLE TO OPEN AMEX.FILES"
    	END
    END
    
    
	    Y.LOB.VAL = R.CUST<EB.CUS.LOCAL.REF,Y.CUST.LOB.POS>
*        IF Y.LOB.VAL EQ '8' AND TODAY[3,6] = Y.DATE.TIME[1,6] THEN			;*CPSGMIG-17671 - S/E
		IF Y.LOB.VAL EQ '8' AND (Y.DATE.OPEN EQ TODAY OR Y.DATE.TIME GT Y.LWD) THEN
	        GOSUB PROCESS
			GOSUB WRITE.DETS
        END
*
*CPSGMIG-13878(S)
    END
*CPSGMIG-13878(E)
RETURN
*--------------------------------------------------------------------------------
*CPSGMIG-13878(S)
*----------------------
CHECK.CUS.ALLOWED.LIST:
*----------------------
	Y.CUS.ALLOWED.FLAG = ''
	FN.LOC.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.LOC.PARAM = ''
	CALL OPF(FN.LOC.PARAM,F.LOC.PARAM)
	ID.LOC.PARAM = 'RSG.PILOT.IND.CUST'
	Y.FIND.FIELD.NAME = 'UTS.IND.CUST'
	IF Y.SAM.ID THEN
		Y.CUS.ID = FIELD(Y.SAM.ID,'-',1)
			CALL F.READ(FN.LOC.PARAM,ID.LOC.PARAM,R.LOC.PARAM,F.LOC.PARAM,LOC.ERR)	      
			IF R.LOC.PARAM THEN
			Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
			LOCATE Y.FIND.FIELD.NAME IN Y.FIELD.NAME<1,1> SETTING PATH.POS THEN
			Y.LOC.CUST.LIST = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE><1,PATH.POS>
			CONVERT SM TO VM IN Y.LOC.CUST.LIST 
			END
		LOCATE Y.CUS.ID IN Y.LOC.CUST.LIST<1,1> SETTING CUST.POS THEN
				Y.CUS.ALLOWED.FLAG = 1
			END
		END
	END
	R.SAM = ''
    Y.SAM.ERR = ''
    CALL F.READ(FN.SEC.ACC.MAST,Y.SAM.ID,R.SAM,F.SEC.ACC.MAST,Y.SAM.ERR)
	Y.CUST.NO = R.SAM<SC.SAM.CUSTOMER.NUMBER>
	Y.DATE.TIME = R.SAM<SC.SAM.DATE.TIME,1>[1,6]
     Y.DATE.OPEN = R.SAM<SC.SAM.START.DATE>	
    Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)[3,6]
	R.CUST = ''
	ERR.CUST = ''
    CALL F.READ(FN.CUST,Y.CUST.NO,R.CUST,F.CUST,ERR.CUST)
	IF ERR.CUST THEN RETURN
	Y.SECTOR.VAL = R.CUST<EB.CUS.SECTOR>
	RETURN
*CPSGMIG-13878(E)

*------------------------------------------------------------------------------------------
PROCESS:
*------------------------------------------------------------------------------------------
*      
   		
	Y.DATE.CLOSE = R.SAM<SC.SAM.CLOSURE.DATE>
	Y.SETT.CURR = R.SAM<SC.SAM.REFERENCE.CURRENCY>
    Y.CURR = R.SAM<SC.SAM.CURR.NO>
*
	IF Y.DATE.CLOSE EQ '' OR Y.DATE.CLOSE GT TODAY THEN
	    Y.ACT.STATUS = '01'
	END ELSE
	    Y.ACT.STATUS = '04'
	END
*
	Y.ACTION.TYPE = ''
*CPSGMIG-17671 - S
*	BEGIN CASE
*	CASE Y.DATE.TIME EQ TODAY AND Y.CURR EQ '1' 
*		Y.ACTION.TYPE = 'A'
*	CASE Y.DATE.OPEN NE TODAY AND Y.CURR NE '1' 
*		Y.ACTION.TYPE = 'C'
*	END CASE
	
    BEGIN CASE
	CASE Y.DATE.OPEN EQ TODAY 
		Y.ACTION.TYPE = 'A'
	CASE Y.DATE.TIME GT Y.LWD AND Y.CURR NE '1' 
		Y.ACTION.TYPE = 'C'
	END CASE
*CPSGMIG-17671 - E
	Y.EBBS.REL.ID1 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,1>
	Y.EBBS.REL.ID2 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,2>
	Y.EBBS.REL.ID3 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,3>
	Y.EBBS.REL.ID4 = R.CUST<EB.CUS.LOCAL.REF,Y.EBBS.CUST.REL.ID.POS,4>
*	
	Y.PRIM.SEC.ID1 = R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,1>
	Y.PRIM.SEC.ID2 = R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,2>
	Y.PRIM.SEC.ID3 = R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,3>
	Y.PRIM.SEC.ID4 = R.CUST<EB.CUS.LOCAL.REF,Y.PRI.SEC.ID.POS,4>
*
	BEGIN CASE
	CASE Y.PRIM.SEC.ID1 = 'Primary'
		Y.PRIM.SEC.ID1  = 'PRI'
	CASE Y.PRIM.SEC.ID1 = 'Secondary'
		Y.PRIM.SEC.ID1  = 'SEC'
	END CASE
*
	BEGIN CASE
	CASE Y.PRIM.SEC.ID2 = 'Primary'
		Y.PRIM.SEC.ID2  = 'PRI'
	CASE Y.PRIM.SEC.ID2 = 'Secondary'
		Y.PRIM.SEC.ID2  = 'SEC'
	END CASE
*	
	BEGIN CASE
	CASE Y.PRIM.SEC.ID3 = 'Primary'
		Y.PRIM.SEC.ID3  = 'PRI'
	CASE Y.PRIM.SEC.ID3 = 'Secondary'
		Y.PRIM.SEC.ID3  = 'SEC'
	END CASE
*	
	BEGIN CASE
	CASE Y.PRIM.SEC.ID4 = 'Primary'
		Y.PRIM.SEC.ID4  = 'PRI'
	CASE Y.PRIM.SEC.ID4 = 'Secondary'
		Y.PRIM.SEC.ID4  = 'SEC'
	END CASE
*
    Y.DAT.IND = 'D'
    Y.SAM.DATA = Y.DAT.IND:Y.DELIM					;* Data Indicator
    Y.SAM.DATA := Y.ACTION.TYPE:Y.DELIM			    ;* Action Type
*
	Y.SAM.DATA := Y.SAM.ID:Y.DELIM			       	;* SAM_ID
	Y.SAM.DATA := Y.EBBS.REL.ID1:Y.DELIM			;* CUST-ID-01
    Y.SAM.DATA := Y.PRIM.SEC.ID1:Y.DELIM			;* CUST-A/C- REL-01
	Y.SAM.DATA := Y.EBBS.REL.ID2:Y.DELIM		    ;* CUST-ID-02
	Y.SAM.DATA := Y.PRIM.SEC.ID2:Y.DELIM			;* CUST-A/C- REL-02
	Y.SAM.DATA := Y.EBBS.REL.ID3:Y.DELIM			;* CUST-ID-03
	Y.SAM.DATA := Y.PRIM.SEC.ID3:Y.DELIM			;* CUST-A/C- REL-03
	Y.SAM.DATA := Y.EBBS.REL.ID4:Y.DELIM			;* CUST-ID-04
	Y.SAM.DATA := Y.PRIM.SEC.ID4:Y.DELIM			;* CUST-A/C- REL-04
*
	Y.SAM.DATA := '':Y.DELIM					    ;* ISCI-AC-PRD
	Y.SAM.DATA := '':Y.DELIM					    ;* ACCOUNT-BRANCH
*
	Y.SAM.DATA := Y.DATE.OPEN:Y.DELIM				;* DATE-OPENED
	Y.SAM.DATA := Y.ACT.STATUS:Y.DELIM				;* ACT-STATUS
	Y.SAM.DATA := Y.DATE.CLOSE:Y.DELIM				;* DATE-CLOSED
	Y.SAM.DATA := Y.SETT.CURR:Y.DELIM			    ;* SETTLE-CURRCODE
*
	Y.SAM.DATA := ''								;* SETTLE-ACT-NUMBER
*	
	RETURN
*
*------------------------------------------------------------------------------------------
WRITE.DETS:
*---------*
*
* Write the Security Account Master data to AMEX.FILES
*
    WRITESEQ Y.SAM.DATA APPEND TO FP.SEC.ACC.MAS.LIST ELSE
        CRT "UNABLE TO WRITE SECURITY.MASTER EXTRACT"
    END
    CLOSESEQ FP.SEC.ACC.MAS.LIST
*
    RETURN
*
*------------------------------------------------------------------------------------------	
END
*------------------------------------------------------------------------------------------