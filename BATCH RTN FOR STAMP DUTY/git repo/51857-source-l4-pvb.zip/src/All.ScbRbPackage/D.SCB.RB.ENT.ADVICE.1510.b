$PACKAGE All.ScbRbPackage
SUBROUTINE D.SCB.RB.ENT.ADVICE.1510(MAT HANDOFF.REC,ERR.MSG)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Vinothkumar M(1519171)
* CPSGMIG-775
* New Routine attached into DE.MAPPING of 1510.SC.003
* AEB.SET.SC.ISIN - Its an existing routine which is already attached into DE.MAPPING>1510.SC.003
* This routine will be triggered first and do the mapping as per PVB BAU.
* This new routine will execute the flow only if the customer is RB
* CPSGMIG-5868- Usage of LR.RB.EX.DATE field instead of EX.DATE for RB clients.
* Cross Compilation for CPSGMIG-775
* 10/10/22 - CPSGMIG -14110 -Ananthy.S - Convert UTS Description from @SM to null.
* 11/10/22 - CPSGMIG-14212- Added price tag in Stock.Split event.
*
* 19-Oct-22 -CPSGMIG-14681-Ananthy.S-For Merger event to update correct values(asset name, asset type & currency) for new security.
* 14-Nov-22 -CPSGMIG-16460-1389710-New Security no Changed for Merger Event. Security No added for Security Switch.SM last price value changed.
* 24-Nov-22 -CPSGMIG-17252-1389710-Wrong value in merge in Fund.
* 06-Feb-2023 - CPSGMIG-18068 - kalaikumaranp - Handle MergeTo tag for one to Many CA Merger Event
* 28-Feb-22 -CPSGMIG-19407-1667095-ReversalFlag passed SAME/NEXT
* 10-Mar-2023 - CPSGMIG-20941 - kalaikumaranp - Assetname prints in multiple tags.
* 14-Mar-2023 - CPSGMIG-20938 - kalaikumaranp - NewSecurityValues are not diplayed for MERGER event..
* 22-Mar-2023 - CPSGMIG-21312 - Kalaikumaranp - Rounding NewAssetValue to two decimal place.
* 10-Aug-2023 - CPSGMIG-32375 - 1648769       - Rel ID Delimiters needs to be fixed from '-' to ':' for Joint Accounts.
* 02-Dec-2025 - ADO-10849423 - Prithi Koppolu - Removal of T24 security master code from Asset Name in RBSG Contract Notes
* 30-Jan-2026	ADO-6746136       		      - CN unable to show multiple records for switch
*----------------------------------------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SC.SCB.CLIENTOUTPUT.PARAM
    $INSERT I_F.DIARY.TYPE
    $INSERT I_F.DIARY
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.ASSET.TYPE

*
* PVB mapping routine as is
    CALL AEB.SET.SC.ISIN(MAT HANDOFF.REC,ERR.MSG)
*
    IF ID.COMPANY[1,2] NE "SG" THEN
        RETURN    ;*  to be impacted only from Singapore company
    END
* Below mapping change applys to only SNG company trades
    IF HANDOFF.REC(10)<1> EQ '1510.SC.003' THEN
        GOSUB INIT
        GOSUB PROCESS
    END
RETURN
*----*
INIT:
*-----*
    Y.CUSTOMER.NO = FIELD(R.NEW(SC.ENT.PORTFOLIO.NO),'-',1)
    Y.SECURITY.NO = R.NEW(SC.ENT.SECURITY.NO)
*
    FnClientOutputParam= 'F.SC.SCB.CLIENTOUTPUT.PARAM'
    FClientOutputParam = ''
    CALL OPF(FnClientOutputParam,FClientOutputParam)
*
    FnSecAccMaster = 'F.SEC.ACC.MASTER'
    FSecAccMaster = ''
    CALL OPF(FnSecAccMaster,FSecAccMaster)
*
    FN.DIARY.TYPE = 'F.DIARY.TYPE'
    F.DIARY.TYPE  = ''
    CALL OPF(FN.DIARY.TYPE,F.DIARY.TYPE)
*
    FN.DIARY = 'F.DIARY'
    F.DIARY  = ''
    CALL OPF(FN.DIARY,F.DIARY)
*
    FnSecMaster = 'F.SECURITY.MASTER'
    FSecMaster = ''
    CALL OPF(FnSecMaster,FSecMaster)
*
    FN.SAT = 'F.SUB.ASSET.TYPE'
    F.SAT  = ''
    CALL OPF(FN.SAT,F.SAT)
*
    FN.AT = 'F.ASSET.TYPE'
    F.AT  = ''
    CALL OPF(FN.AT,F.AT)
*
    YAppName = 'CUSTOMER':@FM:'SECURITY.MASTER':@FM:'DIARY':@FM:'ENTITLEMENT'
    YFldName = 'L.O.B':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LR.EBBS.REL':@FM:'LR.UTS.INS.DESC':@FM:'LR.RB.EX.DATE':@FM:'LR.INT.AMOUNT'
    YFldPos  = ""
    CALL MULTI.GET.LOC.REF(YAppName,YFldName,YFldPos)
    YLobPos          = YFldPos<1,1>
    YStfPos          = YFldPos<1,2>
    YPfolPos         = YFldPos<1,3>
    YEbbsRelIdpos    = YFldPos<1,4>
    YUtsPos          = YFldPos<2,1>
    Y.RB.EX.DATE.POS = YFldPos<3,1>
    Y.LR.INT.AMT.POS = YFldPos<4,1>
*
* Nullify the values
    ClientIdentifier = ''
    AdviceId = ''
    ConsolId = ''
    R2wFolder = ''
    DelMode = ''
    DisclaimerId = ''
    ConfNotice = ''
    ReversalFlag = ''
    PriAcctHolder = ''
    JntHolder = ''
    yDescName = ''
    Y.TRANS.TYPE = ''
    Y.QUALIFY.HOLDING = ''
    Y.ISIN = ''
    Y.PAY.DATE = ''
    Y.EX.DATE = ''
    Y.TRANS.TYPE = ''
    Y.DIARY.TYPE = ''
    Y.ENT.ID = ''
    Y.PRICE = ''
    Y.RATIO = ''
    Y.ENT.PRICE = ''
    Y.ENT.LEND = ''
    Y.ENT.LENDING = ''
    Y.NOMINAL = ''
    Y.NEW.MKT.PRICE = ''
    Y.VALUE.DATE = ''
    Y.BOOK.COST = '0.00'
    Y.LR.INT.AMT  = '0.00'
    Y.DESC.NAME = ''
    Y.NEW.SEC.NO = ''
    Y.NEWSEC.ISIN = ''
    Y.NEW.SM.CCY = ''
    Y.ENT.AMT = ''
    Y.NET.AMOUNT = ''
    Y.COMMISSION.AMT  = ''
    Y.NEWSM.LAST.PRICE = '' ;*CPSGMIG-16460(S/E)
* CPSGMIG-18068
    Y.MRG.PAY.DATE = ''
    Y.MRG.ENT.LENDING = ''
    Y.MRG.ASSET.VAL = ''
    Y.MRG.NEW.ASSET.NAME = ''
* CPSGMIG-18068   
*
* Fetch LOB value
    FN.CUST = 'F.CUSTOMER'
    F.CUST = ''
    CALL OPF(FN.CUST,F.CUST)
*
    CALL F.READ(FN.CUST,Y.CUSTOMER.NO,R.CUST,F.CUST,CUST.ERR)
    L.O.B = R.CUST<EB.CUS.LOCAL.REF,YLobPos>
    LR.PFOLIO.KEY.VAL = R.CUST<EB.CUS.LOCAL.REF,YPfolPos>
    PriAcctHolder = FIELD(LR.PFOLIO.KEY.VAL,':',1)
    JntHolder = LR.PFOLIO.KEY.VAL
    CHANGE ':' TO '|' IN JntHolder
* As per the new logic for cleint Identifier provided as on 20220208
    STAFF.IND = R.CUST<EB.CUS.LOCAL.REF,YStfPos>
*
    BEGIN CASE
        CASE R.CUST<EB.CUS.SECTOR> EQ "21"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "51" AND STAFF.IND EQ "Y"
            YY.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUST<EB.CUS.SECTOR> EQ "23"
            YY.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
*
RETURN
*------*
PROCESS:
*------*
* Get the list of PVB LOB
    Y.PARAM.ID =''; Y.ALLOW.SEG ='PVB'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
    IF L.O.B MATCHES Y.ALLOWED.LOB THEN
        RETURN   ;* As the customer is private return, no need of further processing and mapping
    END ELSE
        ERR.MSG = ''           ;*If any error w.r.t PVB mapping routine can be ignored as we have all tags mapping below which r not liasing with Pb rtn
    END
    GOSUB GET.REQ.FIELDS        ;* Fetch the necessary field values from trade sm and param tables
*
    IF YNomineeCode EQ '' THEN
        Lending = 'No'
    END ELSE
        Lending = 'Yes'
    END
*CPSGMIG-19407(S)
    Y.ENT.REC = HANDOFF.REC(2)
    Y.DEL.KEY = Y.ENT.REC<146>
    Y.DEL.KEY = FIELD(Y.DEL.KEY,@VM,1)
    Y.BANK.DATE = Y.DEL.KEY[2,8]

    Y.RECORD.STATUS = R.NEW(SC.ENT.RECORD.STATUS)
    IF (YRevFlg NE '') OR (Y.RECORD.STATUS[1,1] EQ "R") THEN
        YRevFlgValue = 'REVE'
        BEGIN CASE
            CASE Y.BANK.DATE EQ TODAY
                ReversalFlag = 'SAME'
            CASE Y.BANK.DATE NE TODAY
                ReversalFlag = 'NEXT'
        END CASE
    END ELSE
        YRevFlgValue ='AUTH'
    END
*CPSGMIG-19407(E)

    IF ProductGrp NE '' THEN
        GOSUB GET.ADVICE.FIELD.VALUE
        BEGIN CASE
            CASE ProductGrpValue EQ 'FIXEDINCOME'
                YAssetName = yDescName
            CASE  ProductGrpValue EQ 'FUNDS'
                GOSUB GET.FUND.VALUE
            CASE  ProductGrpValue EQ 'STRUCTUREDPRODUCTS'
                YAssetName = yDescName
        END CASE
    END
    GOSUB UPDATE.USR.DEF.VALUE
RETURN
*--------------*
GET.REQ.FIELDS:
*--------------*
** Values from Entitlement
    Y.ENT.ID          = ID.NEW
    YNomineeCode      = FIELD(Y.ENT.ID,'.',4)
    Y.QUALIFY.HOLDING = R.NEW(SC.ENT.QUALIFY.HOLDING)
    Y.CURRENCY        = R.NEW(SC.ENT.CURRENCY)
    Y.FGN.CHARGES.AMT = R.NEW(SC.ENT.FGN.CHARGES.AMT)
    Y.NOMINAL         = R.NEW(SC.ENT.NOMINAL)<1,1>
    Y.RATIO           = R.NEW(SC.ENT.RATIO)
    Y.NOMINAL.AMT     = R.NEW(SC.ENT.OPTION.NOM)<1,1>
    Y.BOOK.COST       = R.NEW(SC.ENT.BOOK.COST)
    Y.ENT.AMT         = R.NEW(SC.INT.ENTITLEMENT.AMT)
    Y.NEW.SEC.NO      = R.NEW(SC.ENT.NEW.SECURITY)
    Y.COMMISSION.AMT  = R.NEW(SC.ENT.COMMISSION.AMT)
    Y.NET.AMOUNT      = R.NEW(SC.ENT.NET.AMOUNT)
    Y.LR.INT.AMT      = R.NEW(SC.ENT.LOCAL.REF)<1,Y.LR.INT.AMT.POS>
*
    Y.ENT.LEND = FIELD(Y.ENT.ID,'.',4)
    IF Y.ENT.LEND EQ '1' THEN
        Y.ENT.LENDING = 'Yes'
    END ELSE
        Y.ENT.LENDING = 'No'
    END
    Y.MRG.ENT.LENDING = Y.ENT.LENDING
*
    CALL F.READ(FnSecMaster,Y.SECURITY.NO,RSecurityMaster,FSecMaster,YSecErr)
    Y.SM.DESCRIPTION  = RSecurityMaster<SC.SCM.DESCRIPT>
    YSmNewDescription = RSecurityMaster<SC.SCM.LOCAL.REF,YUtsPos>
    Y.SM.LAST.PRICE   = RSecurityMaster<SC.SCM.LAST.PRICE>
*
    GOSUB GET.SM.DESC
*CPSGMIG-14681(S)
*    YAssetName =Y.DESC.NAME
    yDescName = Y.DESC.NAME
*CPSGMIG-14681(E)
*
    IF Y.NEW.SEC.NO THEN
        R.SM = '' ; Y.SAT = '' ; Y.AT = ''; Y.AT.DESC = ''
        CALL F.READ(FnSecMaster,Y.NEW.SEC.NO,R.SM,FSecMaster,Y.SEC.ERR)
        IF R.SM THEN
            Y.SM.DESCRIPTION   = R.SM<SC.SCM.DESCRIPT>
            YSmNewDescription  = R.SM<SC.SCM.LOCAL.REF,YUtsPos>
            Y.NEWSEC.ISIN      = R.SM<SC.SCM.I.S.I.N.>
            Y.SAT = R.SM<SC.SCM.SUB.ASSET.TYPE>
*CPSGMIG-14681(S)
            Y.NEW.SM.CCY = R.SM<SC.SCM.SECURITY.CURRENCY>
            CALL SCB.GET.PRODUCT.API(Y.NEW.SEC.NO, NewProductGrp)
*CPSGMIG-14681(E)
            Y.NEWSM.LAST.PRICE = R.SM<SC.SCM.LAST.PRICE>
            GOSUB GET.SM.DESC
            GOSUB GET.AT.DESC
            Y.NEW.ASSET.NAME = Y.DESC.NAME
            CONVERT @VM TO '' IN Y.DESC.NAME ;* CPSGMIG-20941
            Y.MRG.NEW.ASSET.NAME = Y.NEW.SEC.NO:' ':Y.DESC.NAME
        END
    END
*
    Y.ISIN      = RSecurityMaster<SC.SCM.I.S.I.N.>
    YInvestType = RSecurityMaster<SC.SCM.INVEST.OPTION.TYPE>
*
** Logic to get the Product Group
    CALL SCB.GET.PRODUCT.API(Y.SECURITY.NO, ProductGrp) ;* Get the Product Type FI SN or Funds
*
** Get the Diary Details
    R.DIARY = ''; ERR.DIARY = ''
    Y.DIARY.ID = FIELD(Y.ENT.ID,'.',1)
    CALL F.READ(FN.DIARY,Y.DIARY.ID,R.DIARY,F.DIARY,ERR.DIARY)
    Y.PAY.DATE   = R.DIARY<SC.DIA.PAY.DATE>
    Y.EX.DATE    = R.DIARY<SC.DIA.LOCAL.REF><1,Y.RB.EX.DATE.POS>  ;* CPSGMIG-5868(S/E)
    Y.VALUE.DATE = R.DIARY<SC.DIA.VALUE.DATE>
    Y.DIARY.TYPE = R.DIARY<SC.DIA.EVENT.TYPE>
    Y.ENT.PRICE  = R.DIARY<SC.DIA.OLD.MKT.PRC>
    Y.MRG.PAY.DATE = Y.PAY.DATE ;* CPSGMIG-18068
*
    IF Y.ENT.PRICE THEN
        Y.PRICE = Y.ENT.PRICE
    END ELSE
        Y.PRICE  = Y.SM.LAST.PRICE
    END
*
 * 
   Y.NEW.MKT.PRICE  = R.DIARY<SC.DIA.NEW.MKT.PRC><1,1>
    IF NOT(Y.NEW.MKT.PRICE) THEN
        Y.NEW.MKT.PRICE = Y.NEWSM.LAST.PRICE   ;*CPSGMIG-16460(S/E)
    END
* CPSGMIG-21312 - Rounding to two decimal place.
    Y.MRG.ASSET.VAL = FMT((Y.NOMINAL * Y.NEW.MKT.PRICE),'R2') ;*CPSGMIG-18068

    IF Y.DIARY.TYPE THEN
        R.DIARY.TYPE = ''; ERR.DIARY.TYPE = ''
        CALL F.READ(FN.DIARY.TYPE,Y.DIARY.TYPE,R.DIARY.TYPE,F.DIARY.TYPE,ERR.DIARY.TYPE)
        Y.TRANS.TYPE = R.DIARY.TYPE<SC.DRY.EVENT.DESC,1>
    END
*
** Other Values
    YRevFlg = HANDOFF.REC(4)<1> ;* Hold the reversal Flag
*
RETURN
*----------------------------------------------------------------------------------*
GET.ADVICE.FIELD.VALUE:
*-----------------------*
    ProductGrpValue = TRIM(ProductGrp," ","A")
    ProductGrpValue = UPCASE(ProductGrpValue)
    YRecID = APPLICATION:"-":ProductGrpValue:"-":Y.DIARY.TYPE
    CALL F.READ(FnClientOutputParam,YRecID,RClientOutputParam,FClientOutputParam,YAdviceErr)
    EventTypeArr = RClientOutputParam<SC.CO.EVENT.TYPE>
    CHANGE @VM TO @FM IN EventTypeArr
    LOCATE YRevFlgValue IN EventTypeArr SETTING AdvPos THEN
        AdviceId      = RClientOutputParam<SC.CO.ADVICE.ID,AdvPos>
        ConsolId      = RClientOutputParam<SC.CO.CONSOL.ID,AdvPos>
        DisclaimerId  = RClientOutputParam<SC.CO.DISCLAMIER.ID,AdvPos>
        ConfNotice    = RClientOutputParam<SC.CO.CONFIRMATION.NOTICE,AdvPos>
        DelMode       = RClientOutputParam<SC.CO.DELIVERY.MODE,AdvPos>
    END
    CALL SCB.CLIENTIDEN.R2WFOLD.RTN(YY.CLIENT.IDENTIFIER,R2wFolder)
RETURN
*--------------*
GET.FUND.VALUE:
*--------------*
    IF YInvestType NE '' THEN
        YInvestOption = 'INVEST.OPTION'
        CALL F.READ(FnClientOutputParam,YInvestOption,RInvestLocalParam,FClientOutputParam,YInvestErr)
        InvestFieldName = RInvestLocalParam<SC.CO.FIELD.NAME>
        LOCATE YInvestType IN InvestFieldName<1,1> SETTING YInvestPos THEN
            YDepoAsset = RInvestLocalParam<SC.CO.FIELD.SUB.VALUE,YInvestPos>
        END
    END
*
    IF YDepoAsset NE '' THEN
        YAssetName = yDescName:' ':YDepoAsset
    END ELSE
        YAssetName = yDescName
    END
*
* CPSGMIG-18068 - Handle MergerTo Tag for one to Many Merger CA.	
	IF Y.DIARY.TYPE EQ 'MERGER' THEN
    Y.SEC.NO.CNT = DCOUNT(Y.NEW.SEC.NO<1,1>,@SM)
    IF Y.SEC.NO.CNT GT 1 THEN
        Y.NEWSEC.ISIN = '' ;Y.NEW.SM.CCY = '' ; NewMrgProductGrp = '' ; Y.NEWSM.LAST.PRICE = '' ; Y.NEW.ASSET.NAME = '' ; Y.MRG.PAY.DATE = '' ; Y.MRG.ENT.LENDING = ''
        Y.MRG.ASSET.VAL = '' ; Y.MRG.SEC.NO = '' ; Y.MRG.NEW.ASSET.NAME = ''
        Y.NEW.MKT.PRICE = R.DIARY<SC.DIA.NEW.MKT.PRC><1,1>
    	FOR CNT = 1 TO Y.SEC.NO.CNT
     		IF Y.NEW.SEC.NO<1,1,CNT> THEN
      			R.SM = '' ; Y.SAT = '' ; Y.AT = ''; Y.AT.DESC = ''
      			CALL F.READ(FnSecMaster,Y.NEW.SEC.NO<1,1,CNT>,R.SM,FSecMaster,Y.SEC.ERR)
      			IF R.SM THEN
        			Y.SM.DESCRIPTION   = R.SM<SC.SCM.DESCRIPT>
        			YSmNewDescription  = R.SM<SC.SCM.LOCAL.REF,YUtsPos>
* CPSGMIG-20938                    
                    IF R.SM<SC.SCM.I.S.I.N.> EQ '' THEN
        				Y.NEWSEC.ISIN<1,-1> = '|'
                    END ELSE
                    	Y.NEWSEC.ISIN<1,-1> = R.SM<SC.SCM.I.S.I.N.>
                    END
* CPSGMIG-20938                
        			Y.SAT = R.SM<SC.SCM.SUB.ASSET.TYPE>
*CPSGMIG-14681(S)
        			Y.NEW.SM.CCY<1,-1> = R.SM<SC.SCM.SECURITY.CURRENCY>
        			CALL SCB.GET.PRODUCT.API(Y.NEW.SEC.NO<1,1,CNT>, NewProductGrp)
                    NewMrgProductGrp<1,-1> = NewProductGrp
                    Y.MRG.SEC.NO<1,-1> =  Y.NEW.SEC.NO<1,1,CNT>
*CPSGMIG-14681(E)
         			Y.NEWSM.LAST.PRICE<1,-1> = R.SM<SC.SCM.LAST.PRICE>
        			GOSUB GET.SM.DESC
        			Y.NEW.ASSET.NAME<1,-1> = Y.DESC.NAME
                    CONVERT @VM TO '' IN Y.DESC.NAME ;* CPSGMIG-20941
                    Y.MRG.NEW.ASSET.NAME<1,-1> = Y.NEW.SEC.NO<1,1,CNT>:' ':Y.DESC.NAME
                    IF NOT(Y.NEW.MKT.PRICE<1,1,CNT>) THEN
                        Y.NEW.MKT.PRICE<1,1,CNT> = R.SM<SC.SCM.LAST.PRICE>
					END
* CPSGMIG-21312 - Rounding to two decimal place.                
                	Y.MRG.ASSET.VAL<1,-1> = FMT((Y.NOMINAL<1,1,CNT> * Y.NEW.MKT.PRICE<1,1,CNT>),'R2')
      			END
            	Y.MRG.PAY.DATE<1,-1> = Y.PAY.DATE
            	Y.MRG.ENT.LENDING<1,-1> =  Y.ENT.LENDING
			END
		NEXT CNT
    	NewProductGrp = NewMrgProductGrp
		Y.NEW.SEC.NO = Y.MRG.SEC.NO
        CONVERT @SM TO @VM IN Y.NOMINAL
        CONVERT @SM TO @VM IN Y.NEW.MKT.PRICE
        CONVERT '|' TO '' IN Y.NEWSEC.ISIN
* CPSGMIG-20941
	CONVERT @VM TO '|' IN Y.MRG.NEW.ASSET.NAME
    CONVERT @VM TO '|' IN Y.NEWSEC.ISIN
    CONVERT @VM TO '|' IN Y.MRG.PAY.DATE
    CONVERT @VM TO '|' IN NewProductGrp
    CONVERT @VM TO '|' IN Y.MRG.ENT.LENDING
    CONVERT @VM TO '|' IN Y.NEW.SM.CCY
    CONVERT @VM TO '|' IN Y.NOMINAL
    CONVERT @VM TO '|' IN Y.NEW.MKT.PRICE
    CONVERT @VM TO '|' IN Y.MRG.ASSET.VAL
* CPSGMIG-20941        
		END
	END
*
* * CPSGMIG-18068 - Handle MergerTo Tag for one to Many Merger CA.
RETURN
*----------*
GET.SM.DESC:
*----------
** Logic to form the Asset Name
	IF YSmNewDescription THEN
        Y.DESC.NAME = YSmNewDescription
    END ELSE
*CPSGMIG -14110(S)
*        Y.DESC.CNT = DCOUNT(Y.SM.DESCRIPTION,@VM)
*        CNT = 1
*        LOOP
*        WHILE CNT LE Y.DESC.CNT
*            Y.DESC.NAME<-1> = Y.SM.DESCRIPTION<1,CNT,1>
*            CNT = CNT + 1
*        REPEAT
*        CHANGE @FM TO ' ' IN Y.DESC.NAME
        Y.DESC.NAME = Y.SM.DESCRIPTION
    END
    CHANGE @SM TO '' IN Y.DESC.NAME
*CPSGMIG -14110(E)
*
RETURN
*-----------
GET.AT.DESC:
*----------
    R.SAT = ''; R.AT  = ''
    CALL F.READ(FN.SAT,Y.SAT,R.SAT,F.SAT,Y.SAT.ERR)
    IF R.SAT THEN
        Y.AT = R.SAT<SC.CSG.ASSET.TYPE.CODE>
        CALL F.READ(FN.AT,Y.AT,R.AT,F.AT,Y.AT.ERR)
        Y.AT.DESC = R.AT<SC.ASS.ASSET.DESC>
    END
*
RETURN
* ADO-6746136 S/E
*---------------------------
MULTI.VALUE.TAG.UPDATE:
*---------------------------

IF Y.DIARY.TYPE EQ 'SECURITY.SWITCH' THEN
    Y.SEC.NO.CNT = DCOUNT(Y.NEW.SEC.NO<1,1>,@SM)
    IF Y.SEC.NO.CNT GT 1 THEN
        Y.NEWSEC.ISIN = '' ;Y.NEW.SM.CCY = '' ; NewSWProductGrp = '' ; Y.NEWSM.LAST.PRICE = '' ; Y.NEW.ASSET.NAME = '' ; Y.SW.VALUE.DATE = '' ; Y.SW.ENT.LENDING = ''
        Y.MRG.ASSET.VAL = '' ; Y.MRG.SEC.NO = '' ; Y.SW.NEW.ASSET.NAME = '' ; Y.SW.SETTLE.AMT = ''
    	FOR CNT = 1 TO Y.SEC.NO.CNT
     		IF Y.NEW.SEC.NO<1,1,CNT> THEN
      			R.SM = '' ; Y.SAT = '' ; Y.AT = ''; Y.AT.DESC = ''
      			CALL F.READ(FnSecMaster,Y.NEW.SEC.NO<1,1,CNT>,R.SM,FSecMaster,Y.SEC.ERR)
      			IF R.SM THEN
        			Y.SM.DESCRIPTION   = R.SM<SC.SCM.DESCRIPT>
        			YSmNewDescription  = R.SM<SC.SCM.LOCAL.REF,YUtsPos>                   
                    IF R.SM<SC.SCM.I.S.I.N.> EQ '' THEN
        				Y.NEWSEC.ISIN<1,-1> = '|'
                    END ELSE
                    	Y.NEWSEC.ISIN<1,-1> = R.SM<SC.SCM.I.S.I.N.>
                    END               
        			Y.SAT = R.SM<SC.SCM.SUB.ASSET.TYPE>
        			Y.NEW.SM.CCY<1,-1> = R.SM<SC.SCM.SECURITY.CURRENCY>
        			CALL SCB.GET.PRODUCT.API(Y.NEW.SEC.NO<1,1,CNT>, NewProductGrp)
                    NewSWProductGrp<1,-1> = NewProductGrp
         			Y.NEWSM.LAST.PRICE<1,-1> = R.SM<SC.SCM.LAST.PRICE>
        			GOSUB GET.SM.DESC
        			Y.NEW.ASSET.NAME<1,-1> = Y.DESC.NAME
                    CONVERT @VM TO '' IN Y.DESC.NAME 
                    Y.SW.NEW.ASSET.NAME<1,-1> = Y.NEW.SEC.NO<1,1,CNT>:' ':Y.DESC.NAME
      			END
            	Y.SW.VALUE.DATE<1,-1> = Y.VALUE.DATE
            	Y.SW.ENT.LENDING<1,-1> =  Y.ENT.LENDING
				IF Y.BOOK.COST EQ '' THEN 
				Y.SW.SETTLE.AMT<1,-1> = '0.00'
				END ELSE
				Y.SW.SETTLE.AMT<1,-1> = Y.NOMINAL<1,1,CNT> * Y.BOOK.COST<1,1,CNT>
				END
				
			END
		NEXT CNT
    	NewProductGrp = NewSWProductGrp
        CONVERT @SM TO @VM IN Y.NOMINAL
        CONVERT @SM TO @VM IN Y.NEW.MKT.PRICE
		CONVERT @SM TO @VM IN Y.RATIO
		CONVERT @SM TO @VM IN Y.NOMINAL.AMT
        CONVERT '|' TO '' IN Y.NEWSEC.ISIN
	CONVERT @VM TO '|' IN Y.SW.NEW.ASSET.NAME
    CONVERT @VM TO '|' IN Y.NEWSEC.ISIN
    CONVERT @VM TO '|' IN Y.SW.VALUE.DATE
    CONVERT @VM TO '|' IN NewProductGrp
    CONVERT @VM TO '|' IN Y.SW.ENT.LENDING
    CONVERT @VM TO '|' IN Y.NEW.SM.CCY
    CONVERT @VM TO '|' IN Y.NOMINAL     
	CONVERT @VM TO '|' IN Y.NOMINAL.AMT
	CONVERT @VM TO '|' IN Y.RATIO
	CONVERT @VM TO '|' IN Y.SW.SETTLE.AMT
	
		END
	END
	RETURN
*ADO-6746136  S/E	

*--------------------*
UPDATE.USR.DEF.VALUE:
*--------------------*
    *YAssetName = Y.SECURITY.NO:' ':YAssetName ;* Asset name should be prefixed with Security No CPSGMIG-4914
	YAssetName = YAssetName ;* ADO-10849423 - (s/e)
    HANDOFF.REC(9)<1> = YY.CLIENT.IDENTIFIER
    HANDOFF.REC(9)<2> = ConsolId
    HANDOFF.REC(9)<3> = AdviceId
    HANDOFF.REC(9)<4> = ConfNotice
    HANDOFF.REC(9)<5> = R2wFolder
    HANDOFF.REC(9)<6> = PriAcctHolder
    HANDOFF.REC(9)<7> = JntHolder
    HANDOFF.REC(9)<8> = Y.ENT.ID
    HANDOFF.REC(9)<9> = Y.TRANS.TYPE
    HANDOFF.REC(9)<10> = YAssetName
    HANDOFF.REC(9)<11> = Y.ISIN
    HANDOFF.REC(9)<12> = ProductGrp
    HANDOFF.REC(9)<13> = Lending
    HANDOFF.REC(9)<18> = DisclaimerId
    HANDOFF.REC(9)<19> = "TNO"
*
    BEGIN CASE
        CASE Y.DIARY.TYPE EQ 'STOCK.SPLIT'
            HANDOFF.REC(9)<14> = Y.EX.DATE
            HANDOFF.REC(9)<15> = Y.PAY.DATE
            HANDOFF.REC(9)<16> = Y.QUALIFY.HOLDING
            HANDOFF.REC(9)<17> = Y.RATIO
            HANDOFF.REC(9)<20> = Y.NOMINAL
*CPSGMIG-14212(S)
            HANDOFF.REC(9)<55> = Y.SM.LAST.PRICE
*CPSGMIG-14212(E)
        CASE Y.DIARY.TYPE EQ 'MERGER'
            HANDOFF.REC(9)<21> = Y.EX.DATE
            HANDOFF.REC(9)<22> = Y.PAY.DATE
            HANDOFF.REC(9)<23> = Y.QUALIFY.HOLDING
            HANDOFF.REC(9)<24> = Y.CURRENCY
            HANDOFF.REC(9)<25> = Y.PRICE
            HANDOFF.REC(9)<26> = Y.QUALIFY.HOLDING * Y.PRICE
*CPSGMIG-14681(S)- Added asset no
            HANDOFF.REC(9)<27> = Y.MRG.NEW.ASSET.NAME ; *CPSGMIG-16460(S/E)
*CPSGMIG-14681(E)
            HANDOFF.REC(9)<28> = Y.NEWSEC.ISIN
            HANDOFF.REC(9)<29> = Y.MRG.PAY.DATE
            HANDOFF.REC(9)<30> = NewProductGrp   ;*CPSGMIG-14681-Added product type for merger to.
            HANDOFF.REC(9)<31> = Y.MRG.ENT.LENDING
            HANDOFF.REC(9)<32> = Y.NEW.SM.CCY
            HANDOFF.REC(9)<33> = Y.NOMINAL
            HANDOFF.REC(9)<34> = Y.NEW.MKT.PRICE ;*CPSGMIG-16460(S/E)
            HANDOFF.REC(9)<35> = Y.MRG.ASSET.VAL ; *CPSGMIG-17252
        CASE Y.DIARY.TYPE EQ 'SECURITY.SWITCH'
		GOSUB MULTI.VALUE.TAG.UPDATE		;*ADO-6746136  S/E
            HANDOFF.REC(9)<36> = Y.VALUE.DATE
            HANDOFF.REC(9)<37> = Y.VALUE.DATE
            HANDOFF.REC(9)<38> = Y.CURRENCY
* ADO-6746136 - S			
           *HANDOFF.REC(9)<39> = Y.NOMINAL*Y.BOOK.COST
		    HANDOFF.REC(9)<39> =  Y.SW.SETTLE.AMT	
             HANDOFF.REC(9)<40> = Y.NOMINAL.AMT
		    *HANDOFF.REC(9)<41> = Y.NEW.SEC.NO:' ':Y.NEW.ASSET.NAME ; *CPSGMIG-16460(S/E)
			HANDOFF.REC(9)<41> = Y.SW.NEW.ASSET.NAME ; *ADO-6746136
            HANDOFF.REC(9)<42> = Y.NEWSEC.ISIN
            *HANDOFF.REC(9)<43> = Y.AT.DESC
			HANDOFF.REC(9)<43> = NewProductGrp 
            *HANDOFF.REC(9)<44> = Y.ENT.LENDING
			HANDOFF.REC(9)<44> = Y.SW.ENT.LENDING		
            *HANDOFF.REC(9)<45> = Y.VALUE.DATE
			HANDOFF.REC(9)<45> = Y.SW.VALUE.DATE
* ADO-6746136 - E			

            HANDOFF.REC(9)<46> = Y.NEW.SM.CCY
            HANDOFF.REC(9)<47> = Y.FGN.CHARGES.AMT
            HANDOFF.REC(9)<48> = Y.LR.INT.AMT
            HANDOFF.REC(9)<49> = Y.COMMISSION.AMT
            HANDOFF.REC(9)<50> = Y.NOMINAL
            HANDOFF.REC(9)<51> = Y.BOOK.COST
            HANDOFF.REC(9)<52> = Y.RATIO
            HANDOFF.REC(9)<53> = Y.NET.AMOUNT
            HANDOFF.REC(9)<54> = Y.ENT.AMT*Y.LR.INT.AMT
    END CASE
    HANDOFF.REC(9)<56> = ReversalFlag ;*CPSGMIG-19407(S/E)
*
RETURN
END