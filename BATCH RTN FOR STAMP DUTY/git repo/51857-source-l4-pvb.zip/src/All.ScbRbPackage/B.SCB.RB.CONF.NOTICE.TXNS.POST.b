* @ValidationCode : MjotMTM0NDc1NjMzMjpJU08tODg1OS0xOjE2OTM5MDEwNTQ0NzQ6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 05 Sep 2023 13:34:14
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CONF.NOTICE.TXNS.POST
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-34072
* Developed By                   :       1663000
* Developed On                   :       5-Sep-2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .POST Routine to fetch transactions for which Contract notes are generated
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description

*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
*--------------------------------------------------------------------------------------------
    
    GOSUB INITIALISE
    GOSUB DO.PROCESS

RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.TXN.FINAL.FILE = BATCH.DETAILS<3,1>
    Y.LWD            = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.TXN.FINAL.FILE = EREPLACE(Y.TXN.FINAL.FILE,"<LWD>",Y.LWD,-1)
    
    YDL = ','

RETURN
*---------*
DO.PROCESS:
*---------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.TXN.ARR = '' ; Y.FINAL.TXN.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
    SEL.CMD   = "SCBGETCONFNOTICETXNS-" :TODAY:"-*.csv*"
    
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    IF SEL.LIST THEN
        
        LOOP
            REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
        WHILE Y.SEL.ID : SEL.POS
        
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
            IF NOT(R.TXN.ARR) THEN
                R.TXN.ARR = R.AMEX.FILE
            END ELSE
                R.TXN.ARR<-1> = R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
        REPEAT

* Include the Header part
        Y.HDR.ARR       = 'ACA_AC_NO,ORDER NO/DIARY ID,Transaction Ref,SYS CODE DESC,ClientIdentifier,Country Code,PrimaryAcctHolder,ADVICE.INDEX'
        Y.FINAL.TXN.ARR     = Y.HDR.ARR
        Y.FINAL.TXN.ARR<-1> = R.TXN.ARR
    
	    WRITE Y.FINAL.TXN.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
    END
    
RETURN
END