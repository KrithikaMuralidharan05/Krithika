$PACKAGE All.ScbRbPackage
* @ValidationCode : MjotMTQxNjk3NTgxMTpDcDEyNTI6MTU1MTA3NjY1MTg1MjoxNTcxODc4Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTcxMS42Oi0xOi0x
* @ValidationInfo : Timestamp         : 25 Feb 2019 12:07:31
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1571878
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201711.6
* $PACKAGE SC.ScbEbbs
SUBROUTINE B.SCB.RB.RE.BLK.RETRY.PREPROCESS.LOAD
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Revathi G        24-May-2022        CPSGMIG-565        Settle MF Trade: Cash Debit / Credit in Client's Account 
*-----------------------------------------------------------------------------
*** <region name= Inserts>
*** <desc>Inserts </desc>
     $INSERT I_COMMON
     $INSERT I_EQUATE
     $INSERT I_F.SCB.CASH.BLK.SETT
    
*** </region>
*-----------------------------------------------------------------------------

    FN.APP = "F.SCB.CASH.BLK.SETT"
    F.APP = ""
    
    CALL OPF(FN.APP, F.APP)
   
RETURN

END
