* @ValidationCode : MjotMjQ0MDkzNDQyOklTTy04ODU5LTE6MTY4MTExOTY2MjU1MToxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 10 Apr 2023 15:11:02
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SP.EXTRACT.LOAD
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-12700 - JEWEL_T24_PROJECT
* Developed By                   :       Sathish
* Developed On                   :       14 October 2022
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is the multi-threaded routine which generates the spoke monthly
* report to get the SECURITY.POSITION transaction data every month.
*-----------------------------------------------------------------------------
* Modification History :
* 1663000     26-Oct-2022    CPSGMIG-14917   To update FileOpen command for Temp Sequential file.
* 1667095     03-Jan-2023    CPSGMIG-17593   Updating mapping for Divident Type CASH OR REINVEST
* 1663000     27-Feb-2023    CPSGMIG-19026 - Daily Spoke Monthly Report
* 1663000     11-Apr-2023    CPSGMIG-22845 & 22846 - Include Position Migration flag column
* 1648769     28-Apr-2023    CPSGMIG-14070   To includ customer type, Portfolio valuation and the RM details.
* 1648769     10-May-2023    CPSGMIG-26790   Existing mapping changes in AUM column.
* 1671073     05-Jun-2023    CPSGMIG-24900   Adding 2 new fields viz Average Unit Cost & Unrealized P/L
* 1671073     09-Jun-2023    CPSGMIG-24900   Commenting GOSUB SAT.VALUES as we can handle this through SM>BOND.OR.SHARE field
* 1671073     12-Jun-2023    CPSGMIG-24900   Removing SC.POS.ASSET table read as per code review comment
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_TSA.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_B.SCB.RB.SP.EXTRACT.COMMON
    $INSERT I_BATCH.FILES ;*CPSGMIG-14917
    $INSERT I_F.AEB.SEC.PAR ;*CPSGMIG-19026
*CPSGMIG-14070-S
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.SCB.WM.H.SEGMENT
*CPSGMIG-14070-E
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM  ;*CPSGMIG-26790-S/E
*-----------------------------------------------------------------------------
    
    Y.RPT.AGENT.FILE = ''
    FN.SP = 'F.SECURITY.POSITION'
    F.SP = ''
    CALL OPF(FN.SP,F.SP)
    
    FN.SM = "F.SECURITY.MASTER"
    F.SM = ""
    CALL OPF(FN.SM,F.SM)
    
    FN.CUSTOMER = "F.CUSTOMER"
    F.CUSTOMER = ""
    CALL OPF(FN.CUSTOMER,F.CUSTOMER)

    FN.SAM = "F.SEC.ACC.MASTER"
    F.SAM = ""
    CALL OPF(FN.SAM,F.SAM)
	
	F.SUB.ASSET.TYPE = ''
    FN.SUB.ASSET.TYPE = 'F.SUB.ASSET.TYPE'
    CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
	
*
    FN.PT = 'F.PRICE.TYPE'
	F.PT = ''
	CALL OPF(FN.PT,F.PT)
*
    
*CPSGMIG-14070-S
    FN.DAO = 'F.DEPT.ACCT.OFFICER'
    F.DAO  = ''
    CALL OPF(FN.DAO,F.DAO)

    FN.SCB.LWM.PVB = 'F.SCB.WM.H.SEGMENT'
    F.SCB.LWM.PVB  = ''
    CALL OPF(FN.SCB.LWM.PVB,F.SCB.LWM.PVB)
*CPSGMIG-14070-E  
    FN.AEB.SEC.PAR = 'F.AEB.SEC.PAR' ; F.AEB.SEC.PAR = '' ; CALL OPF(FN.AEB.SEC.PAR,F.AEB.SEC.PAR) ;*CPSGMIG-19026

*CPSGMIG-26790-S
    FN.SCB.WM.H.LOCAL.PARAM       = 'F.SCB.WM.H.LOCAL.PARAM'
    F.SCB.WM.H.LOCAL.PARAM       = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)

*CPSGMIG-26790-E

    GOSUB GET.RET.LOB
    
    LOC.REF.APP = 'CUSTOMER':@FM:'SECURITY.MASTER' :@FM: 'SEC.ACC.MASTER'    ;*CPSGMIG-22845 & 22846
    LOC.REF.FLD = 'L.O.B':@VM:'LR.EBBS.REL':@VM:'LR.STAFF.IND':@VM:'LR.PFOLIO.KEY':@VM:'LWM.PVB.IND':@FM:'LR.RETAIL.DEPO':@VM:'LR.UTS.INS.DESC':@VM:'MF.ISSUER.NAME':@VM:'CASH.OR.REINV':@VM:'LM.RET.DEPO.INV'   ;*CPSGMIG-14070-S/E
    LOC.REF.FLD := @FM:'LR.POS.MIG.DT' ;* CPSGMIG-22845 & 22846 -S/E
    LOC.REF.POS = ''
    CALL MULTI.GET.LOC.REF(LOC.REF.APP,LOC.REF.FLD,LOC.REF.POS)
    Y.L.O.B = LOC.REF.POS<1,1>
	Y.LR.EBBS.REL=LOC.REF.POS<1,2>
    Y.LR.STAFF.IND =LOC.REF.POS<1,3>
    Y.LR.PFOLIO.KEY=LOC.REF.POS<1,4>
    Y.LWM.PVB.IND.POS = LOC.REF.POS<1,5>   ;*CPSGMIG-14070-S/E
    Y.LR.RETAIL.DEPO = LOC.REF.POS<2,1>
	Y.LR.UTS.INS.DESC = LOC.REF.POS<2,2>
	Y.MF.ISSUER.NAME = LOC.REF.POS<2,3>
	Y.CASH.OR.REINV = LOC.REF.POS<2,4>
    LM.RET.DEPO.INV.POS	= LOC.REF.POS<2,5> ;*CPSGMIG-17593(S/E)
	Y.SAM.POSMIG.POS = LOC.REF.POS<3,1>  ;*CPSGMIG-22845 & 22846 -S/E
    
	AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    AMEX.FILES = '' ;*CPSGMIG-14917
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2,AMEX.FILES)
    
 
    Y.DATA = BATCH.DETAILS<3,1>                      ;* CPSGMIG-19026 -S
    CONVERT @SM TO @FM IN Y.DATA
    MTH.DAILY.FLAG  = FIELD(Y.DATA,'*', 1)   ;* Contain the value as Daily or Monthly
    
    IF MTH.DAILY.FLAG EQ 'D' THEN
        Y.RPT.AGENT.FILE = 'SpokeDailyDownload-':TODAY:'-':SESSION.NO:'.csv'
    END ELSE
        Y.RPT.AGENT.FILE = 'SpokeMonthlyDownload-':TODAY:'-':SESSION.NO:'.csv' ;*CPSGMIG-14917
    END                                             ;* CPSGMIG-19026 -E
    
   
RETURN
*-----------------------------------------------------------------------------
GET.RET.LOB:
*-----------
    Y.PARAM.ID = 'SCB.CUST.SEG'; Y.ALLOW.SEG = 'RET'; Y.ALLOWED.LOB =''
    CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)

RETURN
*---------------------------------------------------------------------------------------
END