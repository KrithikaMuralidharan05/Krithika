$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.ENT.EXTRACT.DAY0.SELECT
**-------------------------------------------------------------------------------------------------------------------------
    ! CREATED DT  : 
    ! AUTHOR      : 
    ! CC NO       :
    ! DESCRIPTION : THIS IS A SELECT FILE WHICH WILL SELECT ALL THE ENTITLEMENT TRASACTION HAPPENED ON A DAY TO DAY BASIS
    !                FOR EXTRACTION
*
**-------------------------------------------------------------------------------------------------------------------------
*
* 16/08/2022 - Shreekantha. G - CPSGMIG-5346             
*
*--------------------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.TAP.ENT.EXTRACT.COMMON
    $INSERT I_BATCH.FILES
*
    IF NOT(CONTROL.LIST) THEN
        CONTROL.LIST = "ENT.LIVE" 	
	END
	Y.PILOT.DATE = '20221205'
    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "ENT.LIVE"
            SEL.CMD = "SELECT ":FN.ENTITLEMENT:" WITH VALUE.DATE GE ":Y.PILOT.DATE
*		CASE CONTROL.LIST<1,1> = "ENT.REVE"
*            SEL.CMD = ''
*            SEL.CMD = "SELECT ":FN.ENTITLEMENT.HIS:" WITH VALUE.DATE GE ":Y.PILOT.DATE
    END CASE
	
	CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
    CALL BATCH.BUILD.LIST('',SEC.ID)
	
    RETURN
*
*--------------------------------------------------------------------------------------------------------------------------
END
*--------------------------------------------------------------------------------------------------------------------------
