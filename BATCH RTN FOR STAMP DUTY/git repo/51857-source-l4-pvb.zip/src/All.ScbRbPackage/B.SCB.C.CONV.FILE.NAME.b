$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.C.CONV.FILE.NAME(Y.FILE.NAME)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5701 - JEWEL_T24_PROJECT
* Developed By                   :       Sridhar. A
* Developed On                   :       12 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Generic routine to convert the file name.
*--------------------------------------------------------------------------------------------
* Called From:  BATCH
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.DATES
*
    Y.LWD         = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.NWD         = R.DATES(EB.DAT.NEXT.WORKING.DAY)
    Y.SYSDATE     = OCONV(DATE(),"D4/")
    Y.SYSDATE     = FIELD(Y.SYSDATE,'/',3):FIELD(Y.SYSDATE,'/',1):FIELD(Y.SYSDATE,'/',2)
    Y.COMP.MNE    = R.COMPANY(EB.COM.MNEMONIC)
    Y.LAST.SYSDATE = Y.SYSDATE
    CALL CDT('',Y.LAST.SYSDATE,'-1C')

    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<TODAY>",TODAY,-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<LWD>",Y.LWD,-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<NWD>",Y.NWD,-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<SYSDATE>",Y.SYSDATE,-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<LSYSDATE>",Y.LAST.SYSDATE,-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME, "<M>", TODAY[1,6])
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME, "<MD>", TODAY[5,4])
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME, "<Y>", TODAY[3,6])
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME, "<YM>",TODAY[1,4]:"_":TODAY[5,2])
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME, "<YYMM>", TODAY[3,4])
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<COMPANY>",ID.COMPANY,-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<CC>",ID.COMPANY[1,2],-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"<CMNE>",Y.COMP.MNE,-1)
    Y.FILE.NAME = EREPLACE(Y.FILE.NAME,"-","_",-1)
RETURN
END
