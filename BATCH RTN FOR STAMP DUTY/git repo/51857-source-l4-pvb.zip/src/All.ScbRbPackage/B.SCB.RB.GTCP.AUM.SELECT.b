$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.AUM.SELECT
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-AUM-XX-<start.date>-<end date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.GTCP.AUM.COMMON

	GOSUB PROCESS

RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    IF NOT(CONTROL.LIST) THEN
        CONTROL.LIST = "SPA.EXT":@FM:"SAM.SECTOR.EXT":@FM:"SAM.EXT"
    END
*
    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "SPA.EXT"
            SEL.CMD = "SELECT ":FN.SC.POS.ASSET:" WITH L.O.B EQ ":Y.ALLOWED.LOB
            CALL EB.READLIST(SEL.CMD,SPA.ALL.IDS,'',NO.OF.REC,RET.COD)
            CALL BATCH.BUILD.LIST('', SPA.ALL.IDS)
*
        CASE CONTROL.LIST<1,1> = "SAM.SECTOR.EXT"
			SEL.CMD = "SELECT ":FN.SEC.ACC.MASTER:" WITH L.O.B EQ ":Y.ALLOWED.LOB:" AND WITH CUST.SECTOR EQ '23'"
            CALL EB.READLIST(SEL.CMD,Y.SAM.LIST,'',NO.OF.REC,RET.COD)
			CALL BATCH.BUILD.LIST('', Y.SAM.LIST)

        CASE CONTROL.LIST<1,1> = "SAM.EXT"
            CALL BATCH.BUILD.LIST('', Y.MANDATE.LIST)
    END CASE
*
RETURN
*-----------------------------------------------------------------------------
END
