$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.FUND.PRICE.EXT.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-13123 - JEWEL_T24_PROJECT
* Developed By                   :       Sandhya K
* Developed On                   :       23 December 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Select Routine to extract price batch for iBanking from SECURITY.MASTER
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.FUND.PRICE.EXT
*--------------------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 06-Jun-23     1648769          CPSGMIG-27441 - For instrument, price feed record should be considering for holding position when SM>LWM.SEC.POSN.EX is 'Y'.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_B.SCB.FUND.PRICE.EXT.COMMON
*
    GOSUB SEL.PROCESS
*
RETURN
*-----------------------------------------------------------------------------
SEL.PROCESS:
*-----------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SECURITY.MASTER:" WITH LWM.SEC.POSN.EX EQ 'Y'"
*
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
*
RETURN
*-----------------------------------------------------------------------------
END
