$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SM.STL.PRC.RPT.POST
*-----------------------------------------------------------------------------
* CPSGMIG-1552 Stale Price Report
*              To view price and date last price for active Structured Note instruments
*              To  identify the Structured Note instrument with stale or missing price
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES

    GOSUB INIT
    GOSUB PROCESS
    
RETURN
INIT:
****
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    R.SM.RPT.FINAL.ARR = ''
    Y.COMP = ID.COMPANY
    Y.COMP.NAME = ID.COMPANY[1,2]
    
    Y.FINAL.FILE.NAME = 'SCB.SN.STALE.PRICE.REPORT.':TODAY:'.csv'

RETURN
PROCESS:
********
    SEL.CMD = ''
    SEL.ERR = ''
    SEL.LIST = ''
    NO.OF.FILES = ''
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = 'SN.STALE.PRICE.REPORT*':TODAY:'.csv'
    SEL.LIST = ''
    NO.OF.FILES = ''
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.SM.RPT.FINAL.ARR EQ '' THEN
                R.SM.RPT.FINAL.ARR = R.AMEX.FILE
                LINE.COUNT = DCOUNT(R.AMEX.FILE,@FM)
                Y.TOTAL = Y.TOTAL + LINE.COUNT
            END ELSE
                R.SM.RPT.FINAL.ARR :=@FM:R.AMEX.FILE
                LINE.COUNT = DCOUNT(R.AMEX.FILE,@FM)
                Y.TOTAL = Y.TOTAL + LINE.COUNT
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
            LINE.COUNT = ''
        REPEAT
    END
    IF R.SM.RPT.FINAL.ARR THEN
        Y.TOTAL = DCOUNT(R.SM.RPT.FINAL.ARR,@FM)
        ACT.DATE = OCONV(ICONV(TODAY,'D4-'),'D4-')
        Y.STAMP = OCONV(TIME(),"MTS")
    
        FINAL.ARRAY = 'ID|ISIN|SHORT.NAME|MARGIN.RATE|SAT|PRICE.CURRENCY|SEC.CCY|LAST.PRICE|DATE.LAST.PRICE|NOF.DAYS|EXCEPTION.REASON|CLIENT.HOLDINGS'
        FINAL.ARRAY<-1> = R.SM.RPT.FINAL.ARR
        FINAL.ARRAY<-1> = Y.COMP.NAME:',':ACT.DATE:'/':Y.STAMP[1,5]:',':Y.TOTAL
        
        WRITE FINAL.ARRAY TO F.AMEX.FILES,Y.FINAL.FILE.NAME
    END
RETURN
END
