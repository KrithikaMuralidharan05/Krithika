*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.R2W.CPF.SRS.TXNS.POST
*-----------------------------------------------------------------------------
* Description   :  CPSGMIG-5330 -> R2W report -> CPF/ SRS Transaction Details Report
* 				   This routine will merge and generate the CPF/ SRS Transaction Details Report in AMEX.FILES.
* Author        :  Swaminathan
* Date          :  17 Oct 2022
*----------------------
* Modification History:
*----------------------
*
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
*
	GOSUB INITIALISE
	GOSUB PROCESS
	 
RETURN
*-----------------------------------------------------------------------------
INITIALISE:
*---------
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
    Y.FINAL.FILE.NAME = '' ; R.CPF.SRS.ARRAY = '' ; DL = ','
    Y.FINAL.FILE.NAME = ID.COMPANY[1,2]:"-RB-R2W-CPF-SRS-TXNS-":TODAY:".csv"
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = '' ; SEL.POS = ''
*
    Y.UDFILE	= 'AMEX.FILES'
	SEL.CMD     = ID.COMPANY[1,2]:"-RB-R2W-CPF-SRS-TXNS-":TODAY:"-*.csv*"
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.CPF.SRS.ARRAY EQ '' THEN
                R.CPF.SRS.ARRAY = R.AMEX.FILE
            END ELSE
                R.CPF.SRS.ARRAY :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
	END
*
    Y.HEADER.ARR  = 'Product Provider Name':DL:'Asset Name':DL:'Stock Ref':DL:'Stock Ref #':DL
	Y.HEADER.ARR := 'Customer Name':DL:'NRIC/Passport':DL:'Invest Acct No':DL:'CPFIS-OA Acct':DL
	Y.HEADER.ARR := 'CPFIS-SA Acct':DL:'SRS Acct':DL:'Agent Bank':DL:'Address':DL:'Contact No':DL
	Y.HEADER.ARR := 'Nationality':DL:'Date of Birth':DL:'Tax Resident Status':DL:'Dividend Instruction':DL
	Y.HEADER.ARR := 'Subscription Amount':DL:'Subscription Currency':DL:'Redemption Units':DL
    Y.HEADER.ARR := 'Switch From (Units)':DL:'Switch In (Fund Name)':DL:'Postal Code':DL
	Y.HEADER.ARR := 'Product Provider No':DL:'Payment Mode':DL:'Remarks':DL:'Charge':DL
	Y.HEADER.ARR := 'Lr Ebbs Rel':DL:'ClientIdentifier':DL:'PrimaryAcctHolder':DL:'Fund House ID'
*
    IF R.CPF.SRS.ARRAY NE '' THEN
		R.CPF.SRS.ARRAY.FINAL = Y.HEADER.ARR:@FM:R.CPF.SRS.ARRAY
    END ELSE
		R.CPF.SRS.ARRAY.FINAL = Y.HEADER.ARR
    END
    WRITE R.CPF.SRS.ARRAY.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
*
RETURN
END