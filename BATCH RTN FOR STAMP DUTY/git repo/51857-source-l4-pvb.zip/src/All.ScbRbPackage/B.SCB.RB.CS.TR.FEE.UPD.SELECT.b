$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CS.TR.FEE.UPD.SELECT
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-12313
* Routine Type                 BATCH Job
* Attached To                  BATCH>SNG/B.SCB.RB.CS.TR.FEE.UPD
* Workflow                     This routine will select the customer security table and look for the L.O.B
*                              value of that particular customer. If the customer LOB other than RET L.O.B
*                              list available in Common Parameter then system will update EXCL.TRAIL.FEE
*                              field value as 'YES'
*
**************************
* EXTRA CARE MUST BE TAKEN
**************************
* This Service has to be run only when it is really required as it will affect the majority of the 
* customer security records.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        22/Dec/2022     CPSGMIG-12313        Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_F.CUSTOMER.SECURITY
	$INSERT I_B.SCB.RB.CS.TR.FEE.UPD.COMMON

	GOSUB PROCESS

	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********

	SEL.CMD = "SELECT ":FN.CUS.SEC:" WITH L.O.B NE '8'"
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',LIST.CNT,SEL.ERR)

	CALL BATCH.BUILD.LIST("",SEL.LIST)
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END