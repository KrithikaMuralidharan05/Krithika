$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
****-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.BL.SEC.MASTER.EXTRACT.SELECT
*** ----------------------------------------------------------------------------------------
*
* This SELECT routine is done as part of the multiple elimination project for Security Master extract
* Select all the records from security master and send the data to springwatch team 
* ----------------------------------------------------------------------------------------
*
* Modification History :- C.Mohanarangan - NEW - 20120117    ; * CCAPACPSS20120054
*
* S. Naresh Kumar - Just included for cross compilation purpose for the SIP acitivity to include local reference field SCB.MARKETED
*                   No changes done to this routine.
*                   CCAPACPSS20120096
*Sankaranarayan B - Change - 20131024 - HKOE_CR244
* Change done to exclude HKOE Stocks
*
* Murali J  26-Nov-2013 - Changes in record , .LOAD routines and insert files hence included this routine for cross compilation only.
*                       - There are no changes in this routine . SIP_A_95 - Additional fields in Sec Master ad-hoc report.
* Suresh Kannan  10-04-2014 - Changes in record , .LOAD routines and insert files hence included this routine for cross
*                         compilation only.
*                       - There are no changes in this routine. UPP(FATCA) project requirement
*                       - Additional fields in Sec Master ad-hoc report.
*
* 04/11/2014 - PRR SYNC CHANGE - R Sakthi Rani
*              Included for cross compilation to cater to change in I_B.SEC.MAS.EXT.COMMON.
*
* 14/06/2016 - GE_REL_3_MTM_REPORT
*              There is no change in this routine. For cross recompilation purpose, modification history updated.
*
* 20/12/2016 - CAP_Phase_2_ISSUER
*              There is no change in this routine. For cross recompilation purpose, modification history updated.
*
* 05/10/2017 - TAP - Enable 1.2
*                          Included for cross compilation to cater to change in I_B.SEC.MAS.EXT.COMMON.
* 29/01/2018 - ENABLE 1.2 CR Saranya
*                         Included for cross compilation
*** 07/08/2018 - Credit Wealth Lending Change - Aashiq A J - PVB - 9139
*            - Addition Of two cpolumns to the existing Report TRIM_FLAG, TRIM_PRCT
* 22/01/2019 - GE - 2019 - R1 - S Dhinesh Karthick(1524473) - RWA Percentage in SM - PVB-19721
*            - Addition of new local field RWA.PERC
* 22/02/2019 - CAP J4 Requirement - Gayathri Sivaraman - JIRA - PVB-15229 - *CAP-J4-S/E*
*              Recompiled for changes in I_B.SEC.MAS.EXT.COMMON
* 26/11/2019 - CPE - 2020 - R1 - R NAGARAJAN(1602801) - Islamic Sukuk Bond - PVB-31463

* 05/05/2020 - CPE - 2020 - R2 - Kavitha  - Complex Product - PVB-31463 - Addition of new local field Complex Product

*            - Recompiled for changes in I_B.SEC.MAS.EXT.COMMON.

* *27/05/2020 - CPE - 2020 - R3 - Femina   - TDS Recon - PVB-51935 - Addition of new local field DUPL.OF.INSTR
* 02/09/2020 - CPE - 2020 - R3 - Mahesh K - PVB - 32772 - Addition of new local fields
* 16/11/2020 - CAP - Signature Order Mgmt - JIRA - PVB-49549 - Gayathri Sivaraman - *CAP-SIG-2020_S/E*
*            - Recompiled for changes in I_B.SEC.MAS.EXT.COMMON.
*20201106 - 1625136 - Code conversion for T24 R20 TAFJ upgrade - TAFJUPG - no change
* 18/01/2021 - Recompilation Purpose - CPE_STALE
*
*  21-May-2021 - R20 TAFJUPJ Code conversion - Apr retrofit
*  30 Jun 2021 - Change of local field PRICE.FREQUENCY to PRICE.FREQ - 1554806 (PR) - Recompilation purpose
*
* 22/11/2021 - T24-BAU - Stale price report in R2W- JIRA - PVBCOREBAU-437 - Kavitha R- PVBCOREBAU-437-2021_S/E
*
*24-Feb-2022 - T24-BAU - Signatory portfolio DOA changes JIRA - PVBCOREBAU-1496 - Kavitha R- PVBCOREBAU-1496-2021_S/E
* ----------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.RB.BL.SEC.MAS.EXT.COMMON
*
*HKOE_CR244 - S
*    SEL.CMD = 'SELECT ':FN.SECURITY.MASTER
    SEL.CMD = 'SELECT ':FN.SECURITY.MASTER:' WITH PRICE.UPDATE.CODE NE 35' 

*HKOE_CR244 - E

    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END

*
RETURN
* ----------------------------------------------------------------------------------------
END