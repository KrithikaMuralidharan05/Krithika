$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-54</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.COMPANY.EXTRACT
*******************************************************************************
* 25 Feb 2016 - FCC EDMP - Subramanian M
*             - This routine will generate the Company Dump in AMEX.FILES.
*******************************************************************************
*******************************************************************************
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
* Name: Raja Prabhu
* Desc: T24 TAFJ R20 upgrade code conversion
* Changes: No Changes
* Date : 4/11/2020
*
* 29/06/2022 - Shreekantha. G - CPSGMIG-4230 - Copy of the existing routine B.SCB.EDM.COMPANY.EXTRACT
*
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.COMPANY
    $INSERT I_F.DATES
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*******************************************************************************
INIT:
****
    FN.COMPANY = 'F.COMPANY'
    F.COMPANY = ''
    CALL OPF(FN.COMPANY,F.COMPANY)
*
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
 TOTAL.LINE.COUNT = ''

   Y.HEADER = ''
    Y.FINAL.FILE.NAME = '' ; Y.COMP.NAME = ''
    R.COMP.RPT.ARR = ''
    DL = CHAR(01)
**Headers**
	Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
   Y.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
   Y.HEADER<-1> = 'D':DL:'ID':DL:'COMPANY_NAME':DL:'LOCAL_CURRENCY':DL:'FINANCIAL_COM':DL:'FINANCIAL_MNE'
**Headers**
*
    Y.COMP.NAME = ID.COMPANY[1,2]
    IF Y.COMP.NAME EQ 'GB' THEN
        Y.COMP.NAME = 'UK'
    END
    Y.FINAL.FILE.NAME = Y.COMP.NAME:"-RB-COMPANY-":TODAY:".CSV"								;*CPSGMIG-4230-S/E
RETURN
*******************************************************************************
PROCESS:
********
    
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.COMPANY
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        LOOP
            REMOVE COMP.ID FROM SEL.LIST SETTING SEL.POS
        WHILE COMP.ID:SEL.POS
            R.COMP.REC = '' ; COMP.ERR = ''
            CALL F.READ(FN.COMPANY,COMP.ID,R.COMP.REC,F.COMPANY,COMP.ERR)
            IF R.COMP.REC THEN
                GOSUB ADD.ARRAY
            END
        REPEAT
    END
    TOTAL.LINE.COUNT = DCOUNT(R.COMP.RPT.ARR,@FM)
    Y.FINAL.ARR = ''
    Y.FINAL.ARR = Y.HEADER:FM:R.COMP.RPT.ARR
* 'T', Total Record Count
     Y.FINAL.ARR :=@FM:'T':DL:TOTAL.LINE.COUNT				;*CPSGMIG-3789 - S/E
   *Y.FINAL.ARR = R.COMP.RPT.ARR
    GOSUB WRITE.AMEX.FILE
*
RETURN
*******************************************************************************
ADD.ARRAY:
*********
    IF R.COMP.RPT.ARR EQ '' THEN
        R.COMP.RPT.ARR  = 'D':DL:COMP.ID:DL:R.COMP.REC<EB.COM.COMPANY.NAME>:DL:R.COMP.REC<EB.COM.LOCAL.CURRENCY>
        R.COMP.RPT.ARR := DL:R.COMP.REC<EB.COM.FINANCIAL.COM>:DL:R.COMP.REC<EB.COM.FINANCIAL.MNE>
    END ELSE
        TEMP.ARR = ''
        TEMP.ARR = 'D':DL:COMP.ID:DL:R.COMP.REC<EB.COM.COMPANY.NAME>:DL:R.COMP.REC<EB.COM.LOCAL.CURRENCY>
        TEMP.ARR := DL:R.COMP.REC<EB.COM.FINANCIAL.COM>:DL:R.COMP.REC<EB.COM.FINANCIAL.MNE>
        R.COMP.RPT.ARR<-1> = TEMP.ARR
    END
RETURN
*******************************************************************************
WRITE.AMEX.FILE:
****************
	Y.FINAL.ARR = UTF8(Y.FINAL.ARR)
    CALL F.WRITE(FN.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FINAL.ARR)
RETURN
*******************************************************************************
END
