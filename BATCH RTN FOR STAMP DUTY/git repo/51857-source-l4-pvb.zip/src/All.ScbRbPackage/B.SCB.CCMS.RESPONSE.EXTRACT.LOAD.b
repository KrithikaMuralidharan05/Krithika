$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.CCMS.RESPONSE.EXTRACT.LOAD
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Month end job to send the response file to CCMS.
*
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- CCMS - Month end job to send the response file to CCMS.
* 09-Jun-2023 - CPSGMIG-29137 - 1657186 - To update Last working Day.
* 18-Jul-2023 - CPSGMIG-31181 - 1657186 - Aum Calculation for Bonds.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.CCMS.RESPONSE.EXTRACT.COMMON
	$INSERT	I_F.SCB.RB.CCMS.REQUEST.DATA
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_F.DATES
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
*
    FN.SCB.RB.CCMS.REQUEST.DATA = 'F.SCB.RB.CCMS.REQUEST.DATA'
    F.SCB.RB.CCMS.REQUEST.DATA = ''
    CALL OPF(FN.SCB.RB.CCMS.REQUEST.DATA,F.SCB.RB.CCMS.REQUEST.DATA)
*
	FN.SCB.RB.SEC.POS.ACTIVITY = 'F.SCB.RB.SEC.POS.ACTIVITY'
	F.SCB.RB.SEC.POS.ACTIVITY = ''
	CALL OPF(FN.SCB.RB.SEC.POS.ACTIVITY,F.SCB.RB.SEC.POS.ACTIVITY)
*
    FN.EBBS.REL.CNT = 'F.ST.SCB.RSG.EBBS.REL.CONCAT'
    FV.EBBS.REL.CNT = ''
    CALL OPF(FN.EBBS.REL.CNT,FV.EBBS.REL.CNT)
*
    FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.SCB.WM.H.LOCAL.PARAM = ''
    CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
	
	FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
	F.SECURITY.MASTER = ''
	CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
* CPSGMIG-31181 - Start    
    FN.PRICE.TYPE = 'F.PRICE.TYPE'
	F.PRICE.TYPE = ''
	CALL OPF(FN.PRICE.TYPE,F.PRICE.TYPE)
* CPSGMIG-31181 - End
	
    Y.SAT.PARAM = 'SCB.FI.ASSET.TYPES' ; R.SCB.WM.H.LOCAL.PARAM = '' ; Y.SCB.WM.H.LOCAL.PARAM.ERR = ''
   CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.SAT.PARAM,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.SCB.WM.H.LOCAL.PARAM.ERR)
   IF R.SCB.WM.H.LOCAL.PARAM THEN
   Y.FI.PARAM.FLD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
   CONVERT @SM TO @VM IN Y.FI.PARAM.FLD.VALUE
   END
   
   Y.SAT.PARAM = 'SCB.MF.ASSET.TYPES' ; R.SCB.WM.H.LOCAL.PARAM = '' ; Y.SCB.WM.H.LOCAL.PARAM.ERR = ''
   CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.SAT.PARAM,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.SCB.WM.H.LOCAL.PARAM.ERR)
   IF R.SCB.WM.H.LOCAL.PARAM THEN
   Y.MF.PARAM.FLD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
   END
   
   Y.SAT.PARAM = 'SCB.SN.ASSET.TYPES' ; R.SCB.WM.H.LOCAL.PARAM = '' ; Y.SCB.WM.H.LOCAL.PARAM.ERR = ''
   CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.SAT.PARAM,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.SCB.WM.H.LOCAL.PARAM.ERR)
   IF R.SCB.WM.H.LOCAL.PARAM THEN
   Y.SN.PARAM.FLD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
END

	AMEX.FILES.PATH = 'AMEX.FILES' ; ARG2 = '' ; AMEX.FILES = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)

	Y.FILE.NAME = ID.COMPANY[1,2]:"-SCCT.SP.IE52010.T24RE.FILE.":TODAY:"-":SESSION.NO
    
    YLASTWRKDAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
    
	RETURN
*-----------------------------------------------------------------------------
END
