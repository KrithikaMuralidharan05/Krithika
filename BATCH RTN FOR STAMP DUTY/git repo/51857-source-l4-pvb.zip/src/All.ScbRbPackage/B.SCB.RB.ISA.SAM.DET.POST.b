$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.ISA.SAM.DET.POST

* Routine to extract the SAM and its equivalent UTS and ISA Account details that were loaded
*Created by :- 1657186

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    L.WORK.DATE=R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.FINAL.ID = 'SAM.ISA.FILE-':L.WORK.DATE:'.csv'

	Y.UDFILE       = 'AMEX.FILES'
	Y.ST.CRITERIA  = 'SG.SAM.ISA.FILE.':TODAY:'-*'
	Y.FILE.ARRAY = ''
	Y.FILE.ARRAY = "Portfolio ID":",":"Customer ID":",":"ISA":",":"Rel ID(primary)":",":"Rel ID Secondary1":",":"Rel ID Secondary2":",":"Rel ID Secondary3":",":"Rel ID Secondary4":",":"Segment Code":",":"ISA Status"

    SEL.FILE.ID    = ''
    Y.ST.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.CRITERIA, SEL.FILE.ID, Y.ST.CNT)

    Y.DEL.FILE.ID = SEL.FILE.ID
    LOOP
        REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
    WHILE Y.FILE.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.SAM.REC,F.APPEND.FILES,APP.ERR)
        IF R.SAM.REC NE  '' THEN
            Y.FILE.ARRAY<-1> = R.SAM.REC
            LINE.COUNT = DCOUNT(R.SAM.REC, @FM)
            TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
        LINE.COUNT = ''
    REPEAT

	WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID 

RETURN
*****************
END