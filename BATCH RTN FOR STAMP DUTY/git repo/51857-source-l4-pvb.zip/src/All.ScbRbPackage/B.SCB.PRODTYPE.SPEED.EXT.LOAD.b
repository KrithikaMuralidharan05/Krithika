$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.PRODTYPE.SPEED.EXT.LOAD
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 27/04/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> eSpeed
* 						RBSG_ESPEED_PRODTYPE_YYYYMMDD.txt
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.PRODTYPE.SPEED.EXT.COMMON
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.SUB.ASSET.TYPE = 'F.SUB.ASSET.TYPE'
    F.SUB.ASSET.TYPE = ''
    CALL OPF(FN.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE)
*
    FN.ASSET.TYPE = 'F.ASSET.TYPE'
    F.ASSET.TYPE = ''
    CALL OPF(FN.ASSET.TYPE,F.ASSET.TYPE)
*
RETURN
*-----------------------------------------------------------------------------
END
