$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.CORP.ACTION.DTL(Y.ENT.ID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14066 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       08 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Main Routine to extract Daily corporate action details
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.CORP.ACTION.DTL
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author      Jira     		Description
*17-04-2023    1667095 -  CPSGMIG-23276 	Changes done to update Dividedn amount/Asset price/CorporateAction rate
*											Amount/Unit alloted
*27-04-2023    1667095 -  CPSGMIG-25128		Changes done to update zero instead of blank fields
*23-06-2023    1648769    CPSGMIG-29355         Changes;
*                                                 1. If SP>NOMINEE.CODE is 1 then default ESPD esle check SAM>LR.LIEN.CODE is value exist update else Check the 
*                                                 table SC.SCB.RB.BLOCK>selected portfolio record with SM and Depo combination.If record exist then pick the 
*                                                 value from SC.SCB.RB.BLOCK>LR.LIEN.CODE else LR.LIEN.CODE and LIEN remarks values should be left Blank.
*                                                 2. Lien Remarks, replace ',' to '' to not exceed to next columns.
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DIARY
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_B.SCB.CORP.ACTION.DTL.COMMON
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION
    
    GOSUB INIT
    GOSUB PROCESS
     
RETURN
*---------------------
INIT:
*---------------------
    TRANS.ID	=	FIELD(Y.ENT.ID,'*',2)
    Y.DELIM		= 	","	;	Y.DIVIDEND.INSTR	= ''
    Y.ARRAY		=	''	;	Y.POSTAL.CODE		= ''
    Y.BR.CODE	=	''	;	Y.ISA.STATUS		= ''
    Y.PO.BOX	=	''	;	Y.ACCOUNT.TYPE		= ''
    Y.CO.NAME	=	''	;	Y.CORP.ACT.DATE		= ''
    Y.CITY 		= 	''	;	Y.BR.NAME		= ''
    Y.ACCT.HLD.1	= '' ;	Y.ACCT.HLD.2	= ''
    Y.ACCT.HLD.3	= '' ;	Y.ACCT.HLD.4 	= ''
    Y.ADDRESS.1		= '' ;	Y.ADDRESS.2		= ''
    Y.ADDRESS.3		= '' ;	Y.ADDRESS.4		= ''
    Y.SAM.REC 		= '' ;	Y.CO.OPT 		= ''
RETURN
*---------------------
PROCESS:
*---------------------
    R.ENTITLEMENT = '' ; ENTITLEMENT.ERR = ''
    CALL F.READ(FN.ENTITLEMENT,TRANS.ID,R.ENTITLEMENT,F.ENTITLEMENT,ENTITLEMENT.ERR)
    Y.PORTFOLIO.NO 	= 	''	;	Y.PORTFOLIO.NO 	= 	R.ENTITLEMENT<SC.ENT.PORTFOLIO.NO>
    Y.CUST.NO	= '' ; Y.CUST.NO = FIELD(Y.PORTFOLIO.NO,'-',1) ;*Get Customer Id
    Y.DIARY.ID	= '' ; Y.DIARY.ID=	FIELD(TRANS.ID,'.',1) ;*Get Diary Id
    R.DIARY 	= '' ; DIARY.ERR = ''
    CALL F.READ(FN.DIARY,Y.DIARY.ID,R.DIARY,F.DIARY,DIARY.ERR)
    Y.EVENT.TYPE = '' ; Y.EVENT.TYPE = R.DIARY<SC.DIA.EVENT.TYPE>
    Y.EVENT.TYPE.ARR = 'DIVIDENDS':@VM:'STOCK.DIV':@VM:'COUPON':@VM:'REDEMPTION':@VM:'E.REDEMPTION'
    Y.EVENT.FLAG = ''
    IF Y.EVENT.TYPE MATCHES Y.EVENT.TYPE.ARR THEN
        Y.EVENT.FLAG = '1'
    END
    GOSUB CHK.LOB
    IF Y.PROCEED.FLAG AND R.ENTITLEMENT AND Y.EVENT.FLAG THEN
        Y.DEPOSITORY	=	''	;	Y.DEPOSITORY	=	R.ENTITLEMENT<SC.ENT.DEPOSITORY>
        Y.SECURITY.CODE	= 	''	;	Y.SECURITY.CODE	= 	R.ENTITLEMENT<SC.ENT.SECURITY.NO>
        Y.CONF.DATE    	= 	'' 	; 	Y.CONF.DATE    	= 	R.ENTITLEMENT<SC.ENT.DATE.TIME,1>[1,6] ;*date format as YYMMDD
        Y.YEAR 			= OCONV(ICONV(Y.CONF.DATE,'D'),'DY4') ;*CPSGMIG-25128
        Y.CONFIRM.DATE     = Y.YEAR:Y.CONF.DATE[3,4] ;*CPSGMIG-25128 - Format date field as YYYYMMDD
        Y.QUALIFY.HOLD	=	''	;	Y.QUALIFY.HOLD	=	R.ENTITLEMENT<SC.ENT.QUALIFY.HOLDING>
        Y.ENT.AMT		=	''	;	Y.ENT.AMT		=	R.ENTITLEMENT<SC.ENT.ENTITLEMENT.AMT>
        Y.NOMINAL		=	''	;	Y.NOMINAL		=	R.ENTITLEMENT<SC.ENT.NOMINAL,1>
        Y.SETT.ACCOUNT	=	''	;	Y.SETT.ACCOUNT	=	R.ENTITLEMENT<SC.ENT.LOCAL.REF,LR.REC.CASA.ACC.POS>
        
        Y.ORD.DATE			=	''	;	Y.ORD.DATE		=	R.DIARY<SC.DIA.RECORD.DATE>
        Y.DIST.DATE			=	''	;	Y.DIST.DATE		=	R.DIARY<SC.DIA.PAY.DATE>
        Y.NEW.RATIO			=	''	;	Y.NEW.RATIO		=	R.DIARY<SC.DIA.NEW.RATIO>
        Y.OLD.RATIO			=	''	;	Y.OLD.RATIO		=	R.DIARY<SC.DIA.OLD.RATIO>
        Y.RATE				=	''	;	Y.RATE			=	R.DIARY<SC.DIA.RATE>
        Y.CORP.ACT.RATE		=	''	;	Y.VESTIMA.FLAG 	= 	''
        Y.ASSET.PRICE		=	''	;	Y.DIV.AMOUNT	=	''
        CALL SCB.RB.VEST.FLAG(Y.DEPOSITORY,Y.VESTIMA.FLAG)
        Y.VESTIMA = Y.VESTIMA.FLAG

        GOSUB GET.SM.DETS
        GOSUB GET.CUST.DETS
        GOSUB GET.SAM.DETS
        GOSUB FORM.ARRAY
    END
RETURN
*---------------------
CHK.LOB:
*---------------------
*Check for retail client
    R.CUSTOMER = '' ; CUSTOMER.ERR = '' ; Y.LOB = ''
    CALL F.READ(FN.CUSTOMER,Y.CUST.NO,R.CUSTOMER,F.CUSTOMER,CUSTOMER.ERR)
    Y.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF,L.O.B.CUS.POS>
    Y.PROCEED.FLAG = ''
    IF Y.LOB AND ( Y.LOB MATCHES Y.ALLOWED.LOB) THEN
        Y.PROCEED.FLAG = '1'
    END
    
RETURN
*-----------------------------------------------------------------------------
GET.SM.DETS:
*-----------
    R.SECURITY.MASTER = '' ; SECURITY.MASTER.ERR = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SECURITY.CODE,R.SECURITY.MASTER,F.SECURITY.MASTER,SECURITY.MASTER.ERR)
    CALL SCB.WM.GET.PRODUCT.TYPE(Y.SECURITY.CODE,Y.ACCOUNT.TYPE)
*Get asset master details
    Y.ASSET.CCY  = '' ; Y.ASSET.CCY  = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
    Y.ASSET.NAME = '' ; Y.ASSET.NAME = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LR.UTS.INS.DESC.POS>
    Y.ISLAMIC.SUKUK 	=	''	;	Y.ISLAMIC.SUKUK = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,ISLAMIC.SUKUK.POS>
    Y.CASH.OR.REINV		=	''	;	Y.CASH.OR.REINV	= R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.CASH.OR.REINV.POS>
    Y.LR.RETAIL.DEPO	=	''	;	Y.LR.RETAIL.DEPO	= R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.RETAIL.DEPO.POS>
    Y.LM.RET.DEPO.INV   =	''	;	Y.LM.RET.DEPO.INV	= R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LM.RET.DEPO.INV.POS>
    IF Y.ASSET.NAME NE '' THEN
        CONVERT @SM TO '' IN Y.ASSET.NAME
        Y.ASSET.NAME = Y.ASSET.NAME ;*CPSGMIG-25128(S/E)
    END ELSE
        Y.ASSET.NAME = R.SECURITY.MASTER<SC.SCM.DESCRIPT,1>
    END
*CPSGMIG-23276(S)
    BEGIN CASE
        CASE Y.ACCOUNT.TYPE EQ "MF"
            GOSUB GET.MF.CASH.OR.REINV
            IF (Y.DIVIDEND.INSTR EQ "CASH") OR (Y.EVENT.TYPE EQ "REDEMPTION") THEN
                Y.DIV.AMOUNT	= "0"
                Y.ASSET.PRICE	= "0"
                Y.CORP.ACT.RATE = Y.RATE
                CALL EB.ROUND.AMOUNT(Y.ASSET.CCY, Y.ENT.AMT, '1', "")
                Y.AMT.UNIT.ALLOT = Y.ENT.AMT
            END
            IF (Y.DIVIDEND.INSTR EQ "REINVEST") AND (Y.EVENT.TYPE NE "REDEMPTION") THEN ;*CPSGMIG-25128(S/E)
                Y.CORP.ACT.RATE 	= Y.NEW.RATIO
                Y.ASSET.PRICE		= Y.OLD.RATIO
                Y.DIV.AMOUNT		= Y.ENT.AMT
                Y.AMT.UNIT.ALLOT = Y.NOMINAL
            END
        CASE Y.ACCOUNT.TYPE AND (Y.ACCOUNT.TYPE NE "MF")
            Y.DIVIDEND.INSTR  	= 'CASH'
            Y.DIV.AMOUNT		= Y.ENT.AMT
            Y.ASSET.PRICE		= "0"
            Y.CORP.ACT.RATE 	= Y.RATE
            CALL EB.ROUND.AMOUNT(Y.ASSET.CCY, Y.ENT.AMT, '1', "")
            Y.AMT.UNIT.ALLOT = Y.ENT.AMT
            IF (Y.EVENT.TYPE EQ "REDEMPTION") OR (Y.EVENT.TYPE EQ "E.REDEMPTION") THEN
                Y.DIV.AMOUNT	= "0"
            END
    END CASE
*CPSGMIG-23276(S)
RETURN
*-----------------------------------------------------------------------------
GET.CUST.DETS:
*---------------
    Y.ACCT.OFFICER	=	''	;	Y.ACCT.OFFICER	=	R.CUSTOMER<EB.CUS.ACCOUNT.OFFICER>
    Y.CLIENT.IDENTIFIER = '' ; R.DAO = '' ; Y.DAO.ERR = ''
    CALL F.READ(FN.DAO,Y.ACCT.OFFICER,R.DAO,F.DAO,Y.DAO.ERR)
    Y.OFFICER.NAME 	=	R.DAO<EB.DAO.NAME>
    Y.LR.ARM.CODE 	=	R.DAO<EB.DAO.LOCAL.REF,LR.ARM.CODE.POS>
    Y.LR.PFOLIO.KEY = R.CUSTOMER<EB.CUS.LOCAL.REF,LR.PFOLIO.KEY.POS>
    Y.LR.STAFF.IND = R.CUSTOMER<EB.CUS.LOCAL.REF,LR.STAFF.IND.POS>
    BEGIN CASE
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ '21'
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ '51' AND Y.LR.STAFF.IND EQ "Y"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ '23'
            Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE

RETURN

*-----------------------------------------------------------------------------
GET.SAM.DETS:
*---------------
    R.SEC.ACC.MASTER   = ''    ;  Y.SAM.ERR = ''
    CALL F.READ(FN.SEC.ACC.MASTER,Y.PORTFOLIO.NO,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,Y.SAM.ERR)
    Y.AC.CLOSE.DT = R.SEC.ACC.MASTER<SC.SAM.CLOSURE.DATE>
    Y.AC.BLK.DT = R.SEC.ACC.MASTER<SC.SAM.BLOCKING.DATE>
    Y.LR.REMARKS       = ''
    GOSUB GET.LIEN.CODE.VAL

*Get Account Status
    BEGIN CASE
        CASE Y.AC.BLK.DT NE ''
            Y.ISA.STATUS = 'SUSPENDED'
        CASE Y.AC.CLOSE.DT NE ''
            Y.ISA.STATUS = 'CLOSED'
        CASE Y.AC.BLK.DT EQ '' AND Y.AC.CLOSE.DT EQ ''
            Y.ISA.STATUS = 'NORMAL'
	END CASE

RETURN
*-----------------------------------------------------------------------------
GET.MF.CASH.OR.REINV:
*--------------------
*CPSGMIG-23276(S)
    BEGIN CASE
        CASE Y.CASH.OR.REINV EQ 'C'
            Y.DIVIDEND.INSTR  = 'CASH'
        CASE Y.CASH.OR.REINV EQ 'R'
            Y.DIVIDEND.INSTR	= 'REINVEST'
        CASE Y.CASH.OR.REINV EQ ''
            IF Y.DEPOSITORY EQ Y.LR.RETAIL.DEPO THEN
                Y.DIVIDEND.INSTR  = 'CASH'
            END ELSE
                IF Y.DEPOSITORY EQ Y.LM.RET.DEPO.INV THEN
                    Y.DIVIDEND.INSTR	= 'REINVEST'
                END
            END
    END CASE
    
RETURN
*CPSGMIG-23276(E)
*------------------*
GET.LIEN.CODE.VAL:
*------------------*
* Get Security Position based on Portfolio
   SEL.CMD    = "SELECT RECID FROM ":Y.VIEW.NAME:" WHERE SECURITY_ACCOUNT = '":Y.PORTFOLIO.NO:"' AND SECURITY_NUMBER = '":Y.SECURITY.CODE:"'"
   SEL.CMD    := "AND DEPOSITORY = '":Y.DEPOSITORY:"' ORDER BY SECURITY_NUMBER"
   SEL.CMD    = TRIM(SEL.CMD)

   TRANSLATE.QUERY = '' ; RESULT.SET = "" ; ERR.CODE   = "" ; ERR.MSG    = "" ; UNIQUE.ID = OPERATOR:"-":TNO:"-LIENREP-":TIME()
   CALL SCB.CALL.ORACLE.SQL(TRANSLATE.QUERY, UNIQUE.ID, SEL.CMD, RESULT.SET, ERR.CODE, ERR.MSG)
   LOOP
        REMOVE Y.SP.ID FROM RESULT.SET SETTING SP.POS
   WHILE Y.SP.ID : SP.POS
     R.SECURITY.POSITION = '' ; SECURITY.POSITION.ERR = '' ; Y.NOM.CODE = ''
     CALL F.READ(FN.SECURITY.POSITION,Y.SP.ID,R.SECURITY.POSITION,F.SECURITY.POSITION,SECURITY.POSITION.ERR)
       Y.NOM.CODE     = R.SECURITY.POSITION<SC.SCP.NOMINEE.CODE>
       IF Y.NOM.CODE EQ '1' THEN        
        Y.LR.LIEN.CODE = 'ESPD'
       END
       GOSUB GET.LIEN.CODE.VAL1
   REPEAT
   IF Y.LR.LIEN.CODE EQ '' THEN
      GOSUB GET.LIEN.CODE.VAL1
   END

RETURN
*------------------*
GET.LIEN.CODE.VAL1:
*------------------*

     IF Y.LR.LIEN.CODE EQ '' THEN
           Y.LR.LIEN.CODE     = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,LR.LIEN.CODE.POS>
      IF Y.LR.LIEN.CODE EQ '' THEN
         R.SC.SCB.RB.BLOCK = ''   ; Y.SC.SCB.RB.BLOCK.ERR = ''
         CALL F.READ(FN.SC.SCB.RB.BLOCK,Y.SP.ID,R.SC.SCB.RB.BLOCK,FN.SC.SCB.RB.BLOCK,Y.SC.SCB.RB.BLOCK.ERR)
         Y.LR.LIEN.CODE = R.SC.SCB.RB.BLOCK<RB.BLK.LR.LIEN.CODE>
      END
     END

     IF Y.LR.LIEN.CODE THEN
      R.SC.SCB.LIEN.CODE = ''  ;  Y.SC.SCB.LIEN.CODE.ERR = ''
      CALL F.READ(FN.SC.SCB.LIEN.CODE,Y.LR.LIEN.CODE,R.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE,Y.SC.SCB.LIEN.CODE.ERR)
      Y.LR.REMARKS = R.SC.SCB.LIEN.CODE<SC.SCBL.DESC>
      Y.LR.REMARKS  = EREPLACE(Y.LR.REMARKS, ",", " ")
     END

RETURN
*-----------------------------------------------------------------------------
FORM.ARRAY:
*---------------
    IF NOT(Y.QUALIFY.HOLD) THEN ;*CPSGMIG-25128(S)
        Y.QUALIFY.HOLD = '0'
    END
    IF NOT(Y.DIV.AMOUNT) THEN
        Y.DIV.AMOUNT = '0'
    END
    IF NOT(Y.ASSET.PRICE) THEN
        Y.ASSET.PRICE = '0'
    END
    IF NOT(Y.CORP.ACT.RATE) THEN
        Y.CORP.ACT.RATE = '0'
    END
    IF NOT(Y.AMT.UNIT.ALLOT) THEN
        Y.AMT.UNIT.ALLOT = '0'
    END ;*CPSGMIG-25128(E)
    
    Y.ARRAY = Y.VESTIMA
    Y.ARRAY := Y.DELIM:Y.BR.CODE
    Y.ARRAY := Y.DELIM:Y.BR.NAME
    Y.ARRAY := Y.DELIM:Y.DIVIDEND.INSTR
    Y.ARRAY := Y.DELIM:Y.CONFIRM.DATE ;*CPSGMIG-25128(S/E)
    Y.ARRAY := Y.DELIM:Y.ORD.DATE
    Y.ARRAY := Y.DELIM:Y.DIST.DATE
    Y.ARRAY := Y.DELIM:Y.PORTFOLIO.NO
    Y.ARRAY := Y.DELIM:Y.ACCT.HLD.1
    Y.ARRAY := Y.DELIM:Y.ACCT.HLD.2
    Y.ARRAY := Y.DELIM:Y.ACCT.HLD.3
    Y.ARRAY := Y.DELIM:Y.ACCT.HLD.4
    Y.ARRAY := Y.DELIM:Y.ADDRESS.1
    Y.ARRAY := Y.DELIM:Y.ADDRESS.2
    Y.ARRAY := Y.DELIM:Y.ADDRESS.3
    Y.ARRAY := Y.DELIM:Y.ADDRESS.4
    Y.ARRAY := Y.DELIM:Y.CITY
    Y.ARRAY := Y.DELIM:Y.POSTAL.CODE
    Y.ARRAY := Y.DELIM:Y.PO.BOX
    Y.ARRAY := Y.DELIM:Y.CO.NAME
    Y.ARRAY := Y.DELIM:Y.ACCOUNT.TYPE
    Y.ARRAY := Y.DELIM:Y.SECURITY.CODE
    Y.ARRAY := Y.DELIM:Y.ASSET.CCY
    Y.ARRAY := Y.DELIM:DQUOTE(Y.ASSET.NAME) ;*CPSGMIG-25128(S/E)
    Y.ARRAY := Y.DELIM:Y.QUALIFY.HOLD
    Y.ARRAY := Y.DELIM:Y.CORP.ACT.RATE
    Y.ARRAY := Y.DELIM:Y.DIV.AMOUNT
    Y.ARRAY := Y.DELIM:Y.ASSET.PRICE
    Y.ARRAY := Y.DELIM:Y.AMT.UNIT.ALLOT
    Y.ARRAY := Y.DELIM:Y.SETT.ACCOUNT
    Y.ARRAY := Y.DELIM:Y.ISA.STATUS
    Y.ARRAY := Y.DELIM:TRANS.ID
    Y.ARRAY := Y.DELIM:Y.DIARY.ID
    Y.ARRAY := Y.DELIM:Y.EVENT.TYPE
    Y.ARRAY := Y.DELIM:Y.ISLAMIC.SUKUK
    Y.ARRAY := Y.DELIM:DQUOTE(Y.OFFICER.NAME)
    Y.ARRAY := Y.DELIM:Y.LR.ARM.CODE
    Y.ARRAY := Y.DELIM:Y.LR.REMARKS
    Y.ARRAY := Y.DELIM:Y.CLIENT.IDENTIFIER
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.KEY
* Write to Temp File
    IF Y.ARRAY THEN
        OPENSEQ AMEX.FILES,Y.TEMP.FILE TO F.AMEX.FILES ELSE  CREATE F.AMEX.FILES ELSE
            CALL OCOMO("Error opening ":Y.TEMP.FILE)
        END

        WRITESEQ Y.ARRAY APPEND TO F.AMEX.FILES ELSE
            CALL OCOMO('Unable to write ':F.AMEX.FILES)
        END
        CLOSESEQ F.AMEX.FILES
    END

RETURN
*-----------------------------------------------------------------------------

END
