*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.R2W.CPF.SRS.TXNS.SELECT
*-----------------------------------------------------------------------------
* Description   :  CPSGMIG-5330 -> R2W report -> CPF/ SRS Transaction Details Report Select Routine
* 				   This routine will generate the CPF/ SRS Transaction Details Report in AMEX.FILES.
* Author        :  Swaminathan
* Date          :  17 Oct 2022
*----------------------
* Modification History:
*----------------------
* 1/11/2022 - Swaminathan.S.R - CPSGMIG-15119 -> DEAL.STATUS EQ 'TRANSMITTED' logic moved to Process routine
* 8/11/2022 - Swaminathan.S.R - CPSGMIG-5330 Select table logic changed to SEC.OPEN.ORDER instead of SCB.SEC.OPEN.ORD.TRD.STATUS
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.R2W.CPF.SRS.TXNS.COMMON
*
    SEL.CMD = '' ; SOO.IDS = '' ; NO.OF.REC = '' ; RET.COD = ''
    SEL.CMD = "SELECT ":FN.SEC.OPEN.ORDER:" WITH (DATE.TO.BROKER EQ ":TODAY:") AND (DEAL.STATUS EQ 'TRANSMITTED')"
    CALL EB.READLIST(SEL.CMD,SOO.IDS,'',NO.OF.REC,RET.COD)
    CALL BATCH.BUILD.LIST('', SOO.IDS)
*
RETURN
END