$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.HOLDING.SPEED.EXT.POST
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 09/05/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> eSpeed
*						RBSG_ESPEED_HOLDING_YYYYMMDD.txt
*
* 25/07/2022 - kalaikumaran P - CPSGMIG-3138 - eSpeed RBSG_ESPEED_HOLDING_YYYYMMDD.txt
* 12/08/2022 - kalaikumaran P - CPSGMIG-3138 - Calculation of Hash256 Checksum value of Body portion of the Interface file.
* 26-Apr-2023 - 1657186 - CPSGMIG-23326 - File date changed to last calendar date.
* 25-Oct-2023 - 1664794 - AWMQPR-6021   - Hard Code to Soft Code of Flow Identifier.
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_B.SCB.HOLDING.SPEED.EXT.COMMON
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM
*
    GOSUB INIT
    GOSUB PROCESS
    GOSUB FILE.TRANSFER
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	FN.SCB.HOLD.SAM.CONCAT = 'F.SCB.HOLD.SAM.CONCAT'
	F.SCB.HOLD.SAM.CONCAT = ''
	CALL OPF(FN.SCB.HOLD.SAM.CONCAT,F.SCB.HOLD.SAM.CONCAT)
    
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
*
	Y.TIMEDATE.STP = TIMEDATE()
* CPSGMIG-23326-S    
    L.WORK.DATE=OCONV(DATE(),'D-') ;*MM-DD-YYYY
    L.WORK.DATE= L.WORK.DATE[7,4]:L.WORK.DATE[1,2]:L.WORK.DATE[4,2]
    CALL CDT("",L.WORK.DATE,"-1C")
* CPSGMIG-23326-E
    Y.TIMESTAMP = L.WORK.DATE:Y.TIMEDATE.STP[1,2]:Y.TIMEDATE.STP[4,2]:Y.TIMEDATE.STP[7,2]
    Y.FINAL.FILE.NAME = ''
    R.HOLDING.RPT.FINAL.ARR = ''
    Y.FINAL.FILE.NAME = 'T24_SG_HOLDING_':Y.TIMESTAMP:'.txt'
*
	FN.SCB.WM.H.LOCAL.PARAM = 'F.SCB.WM.H.LOCAL.PARAM'
	F.SCB.WM.H.LOCAL.PARAM = ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
	
	Y.PARAM.ID = 'SCB.RBSPEED.FLOW.ID' ; R.PARAM.REC = '' 		; Y.PARAM.ERR = ''
	Y.PARAM.FLDNAME = ''		       ; Y.PARAM.FLDVAL = ''
	
	CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.PARAM.ID,R.PARAM.REC,F.SCB.WM.H.LOCAL.PARAM,Y.PARAM.ERR)
    Y.PARAM.FLDNAME = R.PARAM.REC<SCBWM.PRM.FIELD.NAME>
	Y.PARAM.FLDVAL = R.PARAM.REC<SCBWM.PRM.FIELD.VALUE>
	CONVERT @SM TO @VM IN Y.PARAM.FLDVAL
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
	EXECUTE "CLEAR-FILE ":FN.SCB.HOLD.SAM.CONCAT
    
    Y.UDFILE = 'AMEX.FILES'
    SEL.CMD  = ID.COMPANY[1,2]:'*-HOLDING-FILE-*':TODAY:'.csv-*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
			IF R.AMEX.FILE THEN
                IF R.HOLDING.RPT.FINAL.ARR EQ '' THEN
                    R.HOLDING.RPT.FINAL.ARR = R.AMEX.FILE
                END ELSE
                    R.HOLDING.RPT.FINAL.ARR :=@FM:R.AMEX.FILE
                END
			END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
    END
*
*---Call Java API to get Hash256 Sum value ----*
    Y.INPUT.PARAM = R.HOLDING.RPT.FINAL.ARR
    CHANGE @FM TO "" IN Y.INPUT.PARAM

    class_name = "com.hash.main.Sha256Utility"
    method_name = "sumValue"
    param = Y.INPUT.PARAM

    CALLJ class_name, method_name, param SETTING ret
 
 

    Y.HASH256SUM.VALUE = ret

*---Call Java API to get Hash256 Sum value ----*

	NO.OF.RECORDS = DCOUNT(R.HOLDING.RPT.FINAL.ARR,@FM)
	Y.HOLDING.HEADER = 'H|':Y.TIMESTAMP
	Y.HOLDING.FOOTER = 'T|':NO.OF.RECORDS:'|':Y.HASH256SUM.VALUE:'|':Y.TIMESTAMP
	IF NO.OF.RECORDS GT 0 THEN
	    R.HOLDING.RPT.FINAL = Y.HOLDING.HEADER:@FM:R.HOLDING.RPT.FINAL.ARR:@FM:Y.HOLDING.FOOTER
	END ELSE
	    R.HOLDING.RPT.FINAL = Y.HOLDING.HEADER:@FM:Y.HOLDING.FOOTER
	END
*
    WRITE R.HOLDING.RPT.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
*
RETURN
*-----------------------------------------------------------------------------
*-------------
FILE.TRANSFER:
*-------------
*
    FILE.NAME = ''; RECORD.NAME = ''; TARGET.FILE.NAME = ''
*    
    FLOW.IDENTIFER.ID = Y.PARAM.FLDVAL<1,1>
*    
    FILE.NAME = AMEXPATH
    RECORD.NAME = Y.FINAL.FILE.NAME
    TARGET.FILE.NAME = Y.FINAL.FILE.NAME
    CALL SCB.FILEIT.POST(FLOW.IDENTIFER.ID,FILE.NAME,RECORD.NAME,TARGET.FILE.NAME,'')

RETURN
*----------------------------------------------------------------------------------
END