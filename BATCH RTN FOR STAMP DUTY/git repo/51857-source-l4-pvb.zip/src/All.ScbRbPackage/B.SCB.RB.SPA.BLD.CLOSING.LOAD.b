$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-35</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.SPA.BLD.CLOSING.LOAD
*--------------------------------------------------------------------------------------------------------*
* Description:
*-------------------------------------------------------------------------------------------------------------
* Daily job to update closing bal no nom in SCB.RB.SEC.POS.ACTIVITY.
*-------------------------------------------------------------------------------------------------------------
* Modification History:
*-------------------------------------------------------------------------------------------------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- Daily job to update closing bal no nom in SCB.RB.SEC.POS.ACTIVITY.
* 13-Apr-2023 - CPSGMIG-312 - kalaikumaranp - CPF and SRS Exclusion for MF.
* 09-Jun-2023 - CPSGMIG-29137 - kalaikumaranp - Update Date as Last working day.
*-------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SCB.RB.SEC.POS.ACTIVITY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_SCB.RB.SPA.BLD.CLOSING.COMMON
    $INSERT I_F.COMPANY
*
    YF.SECURITY.POSITION = "F.SECURITY.POSITION"
    F.SECURITY.POSITION = ""
    CALL OPF(YF.SECURITY.POSITION,F.SECURITY.POSITION)
*
    F.SECURITY.MASTER = ""
    CALL OPF("F.SECURITY.MASTER",F.SECURITY.MASTER)
*
    YF.LOCKING = "F.LOCKING"
    FP.LOCKING = ''
    CALL OPF(YF.LOCKING,FP.LOCKING)
*
* CPSGMIG-29137
	Y.LWORK.DAY = OCONV(DATE(),'D-') ;*MM-DD-YYYY
    Y.LWORK.DAY = Y.LWORK.DAY[7,4]:Y.LWORK.DAY[1,2]:Y.LWORK.DAY[4,2]
    CALL CDT("",Y.LWORK.DAY,"-1C")
    
	YLASTWRKDAY = Y.LWORK.DAY
* CPSGMIG-29137
    YTODAY = TODAY
    MNTH = YLASTWRKDAY[5,2]
    YR = YLASTWRKDAY[1,4]
    MNTH -= 1
    IF MNTH = 0 THEN
        MNTH = 12
        YR -= 1
    END
    MNTH = FMT(MNTH,"2'0'R")
    PREV.MNTH = YR:MNTH
*
    BASE.CCY = LCCY
*    
    YF.SCB.RB.SEC.POS.ACTIVITY = "F.SCB.RB.SEC.POS.ACTIVITY"
     F.SCB.RB.SEC.POS.ACTIVITY = ""
    CALL OPF(YF.SCB.RB.SEC.POS.ACTIVITY,F.SCB.RB.SEC.POS.ACTIVITY)
*
    YF.SEC.ACC.MASTER = "F.SEC.ACC.MASTER"
    F.SEC.ACC.MASTER = ""
    CALL OPF(YF.SEC.ACC.MASTER,F.SEC.ACC.MASTER)
*
    FN.SEC.POS.SAM.CONCAT = "F.SEC.POS.SAM.CONCAT"
    F.SEC.POS.SAM.CONCAT = ""
    CALL OPF(FN.SEC.POS.SAM.CONCAT,F.SEC.POS.SAM.CONCAT)
	
	Y.APP = 'CUSTOMER'
	Y.FIELD = 'L.O.B'
	Y.FIELD.POS = ''
	CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
	Y.CUST.LOB.POS = Y.FIELD.POS<1,1>
	Y.PARAM.ID    = 'SCB.CUST.SEG'
	Y.ALLOW.SEG   = 'RET'
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
	CONVERT @VM TO ' ' IN Y.ALLOWED.LOB
* S -- CPF Mode Exclusion	
	FN.AEB.SEC.PAR = 'F.AEB.SEC.PAR'
   F.AEB.SEC.PAR = ''
   CALL OPF(FN.AEB.SEC.PAR,F.AEB.SEC.PAR)
   
   FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
   F.SECURITY.MASTER = ''
   CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
* E -- CPF Mode Exclusion   
*   
RETURN
END
