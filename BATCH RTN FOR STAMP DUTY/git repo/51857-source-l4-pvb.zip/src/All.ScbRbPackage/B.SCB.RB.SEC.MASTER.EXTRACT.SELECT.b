$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.SEC.MASTER.EXTRACT.SELECT
*** ----------------------------------------------------------------------------------------
*
* This SELECT routine is done as part of the multiple elimination project for Security Master extract
* Select all the records from security master and send the data to springwatch team 
* ----------------------------------------------------------------------------------------
*
* Modification History :
*
* 15/06/2022 - Shreekantha. G - CPSGMIG-3789 - Copy of the existing routine B.SCB.SEC.MASTER.EXTRACT.SELECT
* ----------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.RB.SEC.MAS.EXT.COMMON
*
*HKOE_CR244 - S
*    SEL.CMD = 'SELECT ':FN.SECURITY.MASTER
    SEL.CMD = 'SELECT ':FN.SECURITY.MASTER:' WITH PRICE.UPDATE.CODE NE 35' 

*HKOE_CR244 - E

    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END

*
RETURN
* ----------------------------------------------------------------------------------------
END
