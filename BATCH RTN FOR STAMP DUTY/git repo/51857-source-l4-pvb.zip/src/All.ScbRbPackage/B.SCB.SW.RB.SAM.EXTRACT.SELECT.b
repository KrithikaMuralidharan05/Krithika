$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.SW.RB.SAM.EXTRACT.SELECT
*-----------------------------------------------------------------------------  *
* Desc   - This routine will generate the SAM Dump in AMEX.FILES.
*Modification History:
************************
* 06-Apr-2022 - CPSGMIG-1871 - Lavanya L - Copy of B.SCB.SW.SAM.EXTRACT.SELECT to generate the report only for Retail customers.
* 21-Apr-2022 - Removed the check for L.O.B and included in .SELECT
*
* 21-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
*-----------------------------------------------------------------------------  *

*******************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.SW.RB.SAM.EXTRACT.COMMON
*
    GOSUB SEL.PROCESS
RETURN
*******************************************************************************
SEL.PROCESS:
************
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.SAM:" WITH L.O.B EQ ":Y.ALLOWED.LOB		;*CPSGMIG-1871 - S/E
*CPSGMIG-13878(S)
*    SEL.CMD := " AND CUST.SECTOR EQ 23"
*CPSGMIG-13878(E)
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
RETURN
*******************************************************************************
END
