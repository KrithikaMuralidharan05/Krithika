$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.WKND.STMT.PROC(Y.PF.ID)
*
* This is BATCH routine which is attached to the SNG/SCB.RB.WKND.STMT.PROC. This routine
* loads the requested files and to process the EBBS incoming file.
*-------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-------------------------------------------------------------------------------
*
* 05-Sep-2022 - kalaikumaranp - CPSGMIG-798 - Statement file generation
*
* 12-Sep-2022 - kalaikumaranp - CPSGMIG-798 - To Avoid duplicate lined generated
* 13-Sep-2022 - kalaikumaranp - CPSGMIG-798 - APPEND added while Writing Extract.
*
* 22-Sep-2022 - kalaikumaranp - CPF Payment mode exclusion for MF.
*
* 26-Sep-2022 - kalaikumaranp - CPSGMIG-798 - Differentiate SN and SNPR based Security Master Capital Production Field.
*
* 11-Oct-2022 - 1657186 - CPSGMIG-798 - UAT Defect Fix.
* 01-Mar-2023 - CPSGMIG-19513 - kalaikumaranp - Decoupling Statement Requirement from historical.
* 07-Jul-2023 - CPSGMIG-31058 - 1657186 - Rate is mapped to Txn Price for Cash and Coupon events.
* 12-Sep-2024 - ADO-5369364 - Praveen Sundar (1543890) - Statement should show only the details of asset transfers that are settled.
* 17-Oct-2024 - BUG-4600774 - 1657186 - RBSG-Statement Cutoff logic Changes to avoid Backdated Transactions to be Missed.
* 21-Nov-2024 - ADO-6543049 - Praveen Sundar (1543890) - Only settled MF cash transactions to be shown in the statements
* 13-MAR-2026 - ADO-11084258- Pawan kr -RBSG_CAPE initiative_ Statement related changes interface files
*-------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
	$INSERT I_SCB.RBSTMT.PROCESS.COMMON
	$INSERT I_DAS.COMMON 
	$INSERT I_DAS.SECURITY.POSITION
	$INSERT I_F.SECURITY.MASTER
	$INSERT I_F.SC.POS.ASSET
	$INSERT I_F.DATES
	$INSERT I_F.SCB.EBBS.FILE.PARAM
	$INSERT I_F.SECURITY.MASTER
	$INSERT I_F.SECURITY.TRANS
	$INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_F.SCB.UTS.HIST.EBBS.REL.ID
    $INSERT I_F.SCB.UTS.HIST.PROD.ACNO
	$INSERT I_F.SCB.UTS.HIST.TXN.DETS
    $INSERT I_F.DIARY
    $INSERT I_F.ENTITLEMENT
    $INSERT I_F.SEC.ACC.MASTER
	$INSERT I_F.SCB.AT.SETT.DETAILS
	$INSERT I_F.SEC.TRADE
    $INSERT I_F.POSITION.TRANSFER
    $INSERT I_F.SCB.RB.STMT.TXN.OUT.DETS 
   $INSERT I_F.FUNDS.TRANSFER   ;*11084258_s
    $INSERT I_F.SCB.L.CAPE.CA.REF   ;*11084258_E
	
	GOSUB INIT
	GOSUB GET.EBBS.DATA
	R.SC.VAL.POSITIONS = '' ; Y.R.SC.VAL.POSITIONS.ERR = ''; Y.SAM.SM.ARR = '' 
	CALL F.READ(FN.SC.VAL.POSITIONS,Y.PF.ID,R.SC.VAL.POSITIONS,F.SC.VAL.POSITIONS,Y.SC.VAL.POSITIONS.ERR)
	CALL OCOMO('SC.VAL.POSITIONS records. Selected ':R.SC.VAL.POSITIONS)
	IF R.SC.VAL.POSITIONS THEN
	
	
        LOOP
            REMOVE Y.SC.POS.ID FROM R.SC.VAL.POSITIONS SETTING Y.SC.POS.ASSET.KEYS
            Y.ASSET.TYPE = '' ; Y.ASSET.TYPE = FIELD(Y.SC.POS.ID,'.',3)
            Y.SAT = '' ; Y.SAT = FIELD(Y.SC.POS.ID,'.',2)
            Y.TXN.ENABLE.FLAG = ''
            Y.PROD.CODE = ''
            GOSUB SET.PRODUCT.FLAG
		WHILE Y.SC.POS.ASSET.KEYS
	
        REPEAT
		Y.TXN.ENABLE.FLAG = ''
        Y.PROD.CODE = ''
        GOSUB GET.ZERO.POS.HOLDINGS
*Read the SCB.AT.SETT.DETAILS to get Settled and Unsettled transactions	
        Y.SAM.ID = Y.PF.ID; Y.SM.ID = ''; Y.AT.SETT.ARR = ''
	    GOSUB GET.SETT.AT.DATA		
* 
        
		GOSUB GET.TXN.DATA
        
        GOSUB GET.CASH.DIV.CA.TXNS
	
	END ELSE
    	Y.TXN.ENABLE.FLAG = ''
        Y.PROD.CODE = ''
    	GOSUB GET.ZERO.POS.HOLDINGS
*Read the SCB.AT.SETT.DETAILS to get Settled and Unsettled transactions	
        Y.SAM.ID = Y.PF.ID; Y.SM.ID = ''; Y.AT.SETT.ARR = ''
	    GOSUB GET.SETT.AT.DATA	
*        
        GOSUB GET.TXN.DATA
        
        GOSUB GET.CASH.DIV.CA.TXNS
    END
    
    GOSUB FINAL.OUTPUT.ARRAY
    
    CLOSESEQ F.OUT.FILE
*
RETURN
*
*----------------------------------------------------------------------------*
INIT:
*---
    Y.OUTPUT.ARR = '' ; Y.MF.HOL.OUTPUT.ARR = '' ; Y.SN.HOL.OUTPUT.ARR = '' ; Y.FI.HOL.OUTPUT.ARR = '' ; Y.SNPR.HOL.OUTPUT.ARR = '' ;Y.SNPR.SAT.FLAG = ''
	Y.MF.TXN.OUTPUT.ARR = '' ; Y.SN.TXN.OUTPUT.ARR = '' ; Y.SNPR.TXN.OUTPUT.ARR = '' ; Y.FI.TXN.OUTPUT.ARR = ''
	Y.MF.HOL.TOTAL = '' ; Y.SN.HOL.TOTAL = '' ; Y.SNPR.HOL.TOTAL = '' ; Y.FI.HOL.TOTAL = ''
	Y.EBBS.REL.ID = '' ; Y.LAST.STMT.DATE = '' ; Y.STMT.DATE = '' ; Y.SC.POS.ID = '' ; Y.SC.POS.ASSET.KEYS = ''
    Y.TXN.ENABLE.FLAG = '';Y.SM.ZERO.HOL = ''
    Y.MF.HOL.TOT.OUTPUT.ARR='';Y.SN.HOL.TOT.OUTPUT.ARR='';Y.SNPR.HOL.TOT.OUTPUT.ARR='';Y.FI.HOL.TOT.OUTPUT.ARR=''
	OPENSEQ AMEX.FILES.PATH,Y.MM.STMT.FILE.ID TO F.OUT.FILE ELSE
		CREATE F.OUT.FILE
	END
*	WEOFSEQ F.OUT.FILE
*
RETURN
*
*----------------------------------------------------------------------------*
GET.EBBS.DATA:
*-------------
	R.SCB.EBBS.FILE.PARAM = '' ; Y.SCB.EBBS.FILE.PARAM.ERR = ''
	CALL F.READ(FN.SCB.EBBS.FILE.PARAM,Y.PF.ID,R.SCB.EBBS.FILE.PARAM,F.SCB.EBBS.FILE.PARAM,Y.SCB.EBBS.FILE.PARAM.ERR)
	IF R.SCB.EBBS.FILE.PARAM THEN
		Y.EBBS.REL.ID = R.SCB.EBBS.FILE.PARAM<SCB.EBBS.RELATIONSHIP.NO>
		Y.LAST.STMT.DATE = R.SCB.EBBS.FILE.PARAM<SCB.EBBS.LAST.STMT.DATE>
		Y.STMT.DATE = R.SCB.EBBS.FILE.PARAM<SCB.EBBS.NEXT.STMT.DATE>
	END
*
RETURN
*----------------------------------------------------------------------------*
SET.PRODUCT.FLAG:
*----------------
    Y.FI.POS = '' ; Y.MF.POS = '' ; Y.SN.POS = '' ; Y.TMP.SN.SAT.FLAG = ''
    Y.FI.SAT.FLAG = '' ; Y.MF.SAT.FLAG = '' ; Y.SN.SAT.FLAG = '' ; Y.SNPR.SAT.FLAG = ''
    LOCATE Y.SAT IN Y.FI.PARAM.FLD.VALUE<1,1> SETTING Y.FI.POS THEN
        Y.FI.SAT.FLAG = 'Y'
        Y.PROD.CODE = 'ISA-I3'
        IF Y.TXN.ENABLE.FLAG EQ 'Y' THEN
            Y.FI.TRANS.POS = ''
            LOCATE Y.TXN.TYPE IN Y.FI.TRANS.FLD.NAME<1,1> SETTING Y.FI.TRANS.POS THEN
                Y.TRANS.NAME = Y.FI.TRANS.FLD.VALUE<1,Y.FI.TRANS.POS>
            END
        END
        GOSUB GET.SC.POS.ASSET
    END
    LOCATE Y.SAT IN Y.MF.PARAM.FLD.VALUE<1,1,1> SETTING Y.MF.POS THEN
        Y.MF.SAT.FLAG = 'Y'
        Y.PROD.CODE = 'ISA-IS'
        IF Y.TXN.ENABLE.FLAG EQ 'Y' THEN
            Y.MF.TRANS.POS = ''
            LOCATE Y.TXN.TYPE IN Y.MF.TRANS.FLD.NAME<1,1> SETTING Y.MF.TRANS.POS THEN
                Y.TRANS.NAME = Y.MF.TRANS.FLD.VALUE<1,Y.MF.TRANS.POS>
            END
        END
        GOSUB GET.SC.POS.ASSET
    END
    LOCATE Y.SAT IN Y.SN.PARAM.FLD.VALUE<1,1,1> SETTING Y.SN.POS THEN
        Y.SN.SAT.FLAG = 'Y'
        Y.PROD.CODE = 'ISA-I1'
        IF Y.TXN.ENABLE.FLAG EQ 'Y' THEN
            Y.SN.TRANS.POS = ''
            LOCATE Y.TXN.TYPE IN Y.SN.TRANS.FLD.NAME<1,1> SETTING Y.SN.TRANS.POS THEN
                Y.TRANS.NAME = Y.SN.TRANS.FLD.VALUE<1,Y.SN.TRANS.POS>
            END
        END
        GOSUB GET.SC.POS.ASSET
    END
RETURN
*
*----------------------------------------------------------------------------*
GET.SC.POS.ASSET:
*---------------
	
	IF Y.TXN.ENABLE.FLAG EQ 'Y' THEN
        RETURN
    END
    
    R.SC.POS.ASSET = '' ; Y.SC.POS.ASSET.ERR = ''
	CALL F.READ(FN.SC.POS.ASSET,Y.SC.POS.ID,R.SC.POS.ASSET,F.SC.POS.ASSET,Y.SC.POS.ASSET.ERR)
	CALL OCOMO('Processing SC.POS.ASSET ':Y.SC.POS.ID) 
	IF R.SC.POS.ASSET THEN
		Y.SEC.NO.CNT = 0 ; Y.SEC.NO.CNT = DCOUNT(R.SC.POS.ASSET<SC.PAS.SECURITY.NO>,@VM)
		Y.SEC.NO.CTR = 1
        LOOP
		WHILE Y.SEC.NO.CTR LE Y.SEC.NO.CNT
			Y.SM.ID = '' ; Y.SM.ID = R.SC.POS.ASSET<SC.PAS.SECURITY.NO,Y.SEC.NO.CTR>
			GOSUB GET.SM.NAME
			Y.SEC.CCY = '' ; Y.SEC.CCY = R.SC.POS.ASSET<SC.PAS.SECURITY.CCY,Y.SEC.NO.CTR>
			Y.NOMINAL = '' ; Y.NOMINAL = R.SC.POS.ASSET<SC.PAS.NO.NOMINAL,Y.SEC.NO.CTR>
			Y.ESTIMATION = '' ; Y.ESTIMATION = R.SC.POS.ASSET<SC.PAS.ESTIMATION,Y.SEC.NO.CTR>
            Y.UNREAL.PL = '' ; Y.UNREAL.PL = R.SC.POS.ASSET<SC.PAS.TOT.UNRL.MKT,Y.SEC.NO.CTR> ;*Update Unrealised PL
            Y.MKT.PRC = '' ; Y.MKT.PRC = R.SC.POS.ASSET<SC.PAS.MARKET.PRICE,Y.SEC.NO.CTR>
            Y.NOMINEE.CODE = '' ; Y.NOMINEE.CODE = R.SC.POS.ASSET<SC.PAS.NOMINEE,Y.SEC.NO.CTR>
			Y.SAM.ID = ''; Y.SAM.ID = FIELD(Y.SC.POS.ID,'.',1) 			
			Y.LWORK.DAY = '' ; Y.LWORK.DAY = R.SM<SC.SCM.DATE.LAST.PRICE>
            Y.TMP.PAS.NOMINAL = '0'; Y.TMP.PAS.NOMINAL = Y.NOMINAL
    		Y.TMP.PAS.UNRL = '0'; Y.TMP.PAS.UNRL = Y.UNREAL.PL
    		Y.TMP.PAS.ESTIMATION = '0' ; Y.TMP.PAS.ESTIMATION = Y.ESTIMATION
            IF Y.NOMINAL THEN
            	IF Y.NOMINEE.CODE EQ 1 THEN
                	GOSUB SEPARATE.PLEDGE.POSITION
            	END ELSE
                	GOSUB PROCESS.DATA
            	END
        	END
			Y.SEC.NO.CTR += 1
        REPEAT
	END
*
RETURN
* -----------------------
SEPARATE.PLEDGE.POSITION:
* -----------------------    
    Y.BAL.NOM.IND = '0'
    Y.BAL.NOM.NOIND = '0'
    UNPLEDGE.FLAG = ''
    SEC.POS.LIST = ''
    NO.OF.REC = ''
    ERR.SEL = ''
    Y.SP.UNRL = '0'
    SEL.CMD = 'SELECT ':FN.SECURITY.POSITION:' WITH SECURITY.ACCOUNT EQ ':Y.PF.ID:' AND SECURITY.NUMBER EQ ':Y.SM.ID
    CALL EB.READLIST (SEL.CMD,SEC.POS.LIST,'',NO.OF.REC,ERR.SEL)
                
    LOOP
        REMOVE Y.SP.ID FROM SEC.POS.LIST SETTING Y.SP.POS
    WHILE Y.SP.ID:Y.SP.POS
        Y.IND = FIELD(Y.SP.ID,'.',4)
        Y.DEPOSITORY = '' ; Y.DEPOSITORY = FIELD(Y.SP.ID,'.',3,1)
        IF Y.MF.SAT.FLAG EQ 'Y' THEN
        	IF Y.DEPOSITORY THEN
        		GOSUB CHECK.DEPO
        	END ELSE
        		Y.PAY.MODE = 'CASH'
        	END
        END ELSE
        	Y.PAY.MODE = 'CASH'
        END
        IF Y.PAY.MODE EQ 'CASH' THEN 	
        	R.SEC.POSITION = '' ; ERR.SEC.POS = ''
        	CALL F.READ (FN.SECURITY.POSITION,Y.SP.ID,R.SEC.POSITION,F.SECURITY.POSITION,ERR.SEC.POS)
        	IF Y.IND EQ 1 THEN
            	Y.BAL.NOM.IND += R.SEC.POSITION<SC.SCP.CLOSING.BAL.NO.NOM>
        	END ELSE
        		UNPLEDGE.FLAG = '1'
            	Y.BAL.NOM.NOIND += R.SEC.POSITION<SC.SCP.CLOSING.BAL.NO.NOM>
        	END
    	END
    REPEAT
    Y.EST.IND = ''
    FOR NOM.IND = 1 TO 2
        BEGIN CASE
            CASE NOM.IND EQ "1" AND Y.BAL.NOM.IND
                Y.TOT.BAL.NOM = Y.BAL.NOM.IND
                IF Y.TOT.BAL.NOM EQ Y.TMP.PAS.NOMINAL THEN
                    Y.SP.ESTIMATION = Y.TMP.PAS.ESTIMATION
                    Y.SP.UNRL = Y.TMP.PAS.UNRL
            	END ELSE
                	Y.SP.ESTIMATION = (Y.TOT.BAL.NOM/Y.TMP.PAS.NOMINAL) * Y.TMP.PAS.ESTIMATION
                    CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.SP.ESTIMATION,1,"")
                    Y.SP.UNRL = (Y.TOT.BAL.NOM/Y.TMP.PAS.NOMINAL) * Y.TMP.PAS.UNRL
                    CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.SP.UNRL,1,"")
                END
                Y.ESTIMATION =  Y.SP.ESTIMATION
                Y.NOMINAL = Y.TOT.BAL.NOM
                Y.UNREAL.PL = Y.SP.UNRL
                GOSUB PROCESS.DATA
            CASE NOM.IND EQ "2" AND UNPLEDGE.FLAG EQ '1' AND Y.BAL.NOM.NOIND
                Y.NOMINEE.CODE = ''
                Y.TOT.BAL.NOM = Y.BAL.NOM.NOIND
                IF Y.TOT.BAL.NOM EQ Y.TMP.PAS.NOMINAL THEN
                    Y.SP.ESTIMATION = Y.TMP.PAS.ESTIMATION
                    Y.SP.UNRL = Y.TMP.PAS.UNRL
            	END ELSE
                	Y.SP.ESTIMATION = (Y.TOT.BAL.NOM/Y.TMP.PAS.NOMINAL) * Y.TMP.PAS.ESTIMATION
                    CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.SP.ESTIMATION,1,"")
                    Y.SP.UNRL = (Y.TOT.BAL.NOM/Y.TMP.PAS.NOMINAL) * Y.TMP.PAS.UNRL
                    CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.SP.UNRL,1,"")
                END
                Y.ESTIMATION =  Y.SP.ESTIMATION
                Y.NOMINAL = Y.TOT.BAL.NOM
                Y.UNREAL.PL = Y.SP.UNRL
                GOSUB PROCESS.DATA
            
        END CASE
    NEXT NOM.IND
RETURN
*----------------------------------------------------------------------------*
PROCESS.DATA:
*-------------
* S -- CPF Mode Exclusion for MF
    IF Y.MF.SAT.FLAG EQ 'Y' AND Y.NOMINEE.CODE NE 1 THEN
        GOSUB CHECK.CASH.PAYMENT.INCLUDE
    END
    * Return if Zero Nominal after CPF Exclusion    
    IF NOT(Y.NOMINAL) THEN
        RETURN
    END
    Y.SGD.ESTIMATION = Y.ESTIMATION
* E -- CPF Mode Exclusion for MF
* SNPR Sat Flag Enable
    IF Y.SN.SAT.FLAG EQ 'Y' AND R.SM<SC.SCM.CAPITAL.PROTECTION> NE '100' THEN
        Y.TMP.SN.SAT.FLAG = Y.SN.SAT.FLAG
        Y.SN.SAT.FLAG = ''
        Y.SNPR.SAT.FLAG = 'Y'
        Y.PROD.CODE = 'ISA-I2'
    END
* SNPR Sat Flag Enable
    IF Y.SEC.CCY NE 'SGD' THEN
        CCY.MKT='1' ; EXT.RATE = '' ; EXT.CCY = 'SGD' ; EXT.AMT = "" ; LCY.AMT = "" ; BAS.CCY = "" ; RET.COD = "" ; DIFFER = 0 ;
        CALL EXCHRATE(CCY.MKT,EXT.CCY,EXT.AMT,Y.SEC.CCY,Y.ESTIMATION,BAS.CCY,EXT.RATE,DIFFER,LCY.AMT,RET.COD)
        Y.SGD.ESTIMATION = EXT.AMT
    END
    Y.PRICE = '' ; Y.PRICE = R.SC.POS.ASSET<SC.PAS.MARKET.PRICE,Y.SEC.NO.CTR>
    GOSUB GROUP.HOLDING.DATA
            
    Y.SNPR.SAT.FLAG = ''
    IF Y.TMP.SN.SAT.FLAG EQ 'Y' THEN
        Y.SN.SAT.FLAG = Y.TMP.SN.SAT.FLAG
        Y.TMP.SN.SAT.FLAG = ''
        Y.PROD.CODE = 'ISA-I1'
    END
*
RETURN
*
*----------------------------------------------------------------------------*
GET.SM.NAME:
*-----------
	R.SM = '' ; Y.SM.ERR = ''
	CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SM,F.SECURITY.MASTER,Y.SECURITY.MASTER.ERR)
	IF R.SM THEN
		Y.LR.UTS.INS.DESC = '' ; Y.LR.UTS.INS.DESC = R.SM<SC.SCM.LOCAL.REF,Y.LR.UTS.INS.DESC.POS>
		Y.SM.NAME = '' ; Y.SM.NAME = R.SM<SC.SCM.DESCRIPT>
* LR.UTS.INS.DESC is taken if it is available else Short Name.
        IF Y.LR.UTS.INS.DESC THEN
            Y.SM.NAME = Y.LR.UTS.INS.DESC
        END
    	CONVERT @SM TO @VM IN Y.SM.NAME
        CONVERT @VM TO @FM IN Y.SM.NAME
        CONVERT @FM TO '' IN Y.SM.NAME
*
		Y.SAT = '' ; Y.SAT = R.SM<SC.SCM.SUB.ASSET.TYPE>
	END
*
RETURN
*
*----------------------------------------------------------------------------*
GROUP.HOLDING.DATA:
*-----------------

    Y.EXCLUDE.HOLDING = ''
    GOSUB CHECK.UNSETTLED.POSITIONS 
	IF Y.EXCLUDE.HOLDING THEN RETURN
	BEGIN CASE
        CASE Y.MF.SAT.FLAG
            Y.MF.HOL.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'MF_HOLDING':'~':Y.PF.ID:'~':Y.SM.NAME:'~':Y.SEC.CCY:'~':Y.NOMINAL:'~':Y.PRICE:'~':Y.LWORK.DAY:'~':Y.ESTIMATION
            Y.MF.HOL.OUTPUT.ARR := '~':Y.SGD.ESTIMATION:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
            Y.MF.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
            Y.MF.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
            Y.MF.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
            Y.MF.HOL.TOTAL += Y.SGD.ESTIMATION
        CASE Y.SN.SAT.FLAG
            Y.SN.HOL.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'SN_HOLDING':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
            Y.SN.HOL.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.SM.NAME:'~':Y.SEC.CCY:'~':Y.NOMINAL:'~':Y.PRICE:'~'
            Y.SN.HOL.OUTPUT.ARR := Y.UNREAL.PL:'~':Y.LWORK.DAY:'~':Y.ESTIMATION:'~':Y.SGD.ESTIMATION:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
            Y.SN.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
            Y.SN.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
            Y.SN.HOL.TOTAL += Y.SGD.ESTIMATION
        CASE Y.SNPR.SAT.FLAG
            Y.SNPR.HOL.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'SNPR_HOLDING':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
            Y.SNPR.HOL.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
            Y.SNPR.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.SM.NAME:'~':Y.SEC.CCY:'~':Y.NOMINAL:'~':Y.PRICE:'~':
            Y.SNPR.HOL.OUTPUT.ARR := Y.UNREAL.PL:'~':Y.LWORK.DAY:'~':Y.ESTIMATION:'~':Y.SGD.ESTIMATION:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
            Y.SNPR.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
            Y.SNPR.HOL.TOTAL += Y.SGD.ESTIMATION
        CASE Y.FI.SAT.FLAG
            Y.FI.HOL.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'FI_HOLDING':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
            Y.FI.HOL.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
            Y.FI.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
            Y.FI.HOL.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.SM.NAME:'~':Y.SEC.CCY:'~':Y.NOMINAL:'~':Y.PRICE:'~':
            Y.FI.HOL.OUTPUT.ARR := Y.LWORK.DAY:'~':Y.ESTIMATION:'~':Y.SGD.ESTIMATION:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
            Y.FI.HOL.TOTAL += Y.SGD.ESTIMATION
	END CASE

RETURN
*----------------------------------------------------------------------------*
GET.TXN.DATA:
*-----------
	CALL OCOMO("Already processed transfers ids ":Y.AT.SETT.ARR)
	CHANGE @FM TO @VM IN Y.AT.SETT.ARR
    R.POS.CON.SCAC = dasSecurityPositionSecurityAccount
    THE.ARGS = Y.PF.ID
    TABLE.SUFFIX = ''
    CALL DAS('SECURITY.POSITION', R.POS.CON.SCAC, THE.ARGS, TABLE.SUFFIX)
    REC.COUNT = 0 ; REC.COUNT = DCOUNT(R.POS.CON.SCAC,FM)
    FOR POS.CON.SCAC.REC.COUNT = 1 TO REC.COUNT
        R.TRN.CON.DATE = '' ; Y.TRN.CON.DATE.ERR = '' ; DMUSER.FLAG = '' ; Y.PAY.MODE = '' 
        CALL F.READ(FN.TRN.CON.DATE, R.POS.CON.SCAC<POS.CON.SCAC.REC.COUNT>,R.TRN.CON.DATE,F.TRN.CON.DATE,TRN.CON.DATE.ERR)
        IF R.TRN.CON.DATE THEN
            TRANS.REC.COUNT = 0 ; TRANS.REC.COUNT = DCOUNT(R.TRN.CON.DATE,FM)
            FOR TRN.CON.DATE.REC.COUNT = 1 TO TRANS.REC.COUNT
                DMUSER.FLAG = ''
                CALL OCOMO('Processing TRN.CON.DATE ':R.TRN.CON.DATE<TRN.CON.DATE.REC.COUNT>) 
                Y.SM.ID = '' ; Y.SM.ID = FIELD(R.TRN.CON.DATE<TRN.CON.DATE.REC.COUNT>,'.',2)
                Y.SAM.ID = ''; Y.SAM.ID = FIELD(R.TRN.CON.DATE<TRN.CON.DATE.REC.COUNT>,'.',1) 
                GOSUB GET.SM.NAME
                SEC.NO = '' ; SEC.NO = FIELD(R.TRN.CON.DATE<TRN.CON.DATE.REC.COUNT>,'.',11)
                TRANS.NO = '' ; TRANS.NO = FIELD(R.TRN.CON.DATE<TRN.CON.DATE.REC.COUNT>,'.',12)
                SEC.TRANS.ID = SEC.NO:".":TRANS.NO
                R.SECURITY.TRANS = '' ; Y.SECURITY.TRANS.ERR = ''
                CALL F.READ(FN.SECURITY.TRANS,SEC.TRANS.ID,R.SECURITY.TRANS,F.SECURITY.TRANS,Y.SECURITY.TRANS.ERR)
                ST.DATE.UPDATED = ''; ST.DATE.UPDATED = R.SECURITY.TRANS<SC.SCT.DATE.UPDATED>
                ST.REV.DATE = ''; ST.REV.DATE = R.SECURITY.TRANS<SC.SCT.REVERSAL.DATE>
                IF R.SECURITY.TRANS AND ST.DATE.UPDATED NE '' AND ST.REV.DATE EQ '' THEN
                
                    REF.NO.SEQ = '' ; REF.NO.SEQ = R.SECURITY.TRANS<SC.SCT.REF.NO.SEQUENCE>
                                        Y.TXN.TRADE.DATE = '' ; Y.TXN.TRADE.DATE = R.SECURITY.TRANS<SC.SCT.TRADE.DATE>
* Authorisation Date to be taken for Transactions selection for RBSG Statement.                    
                    Y.TXN.AUTH.DATE = ''
                    BEGIN CASE
                        CASE REF.NO.SEQ[1,6] EQ 'SCTRSC'
                            R.SEC.TRD = '' ; ERR.ST = ''
                            CALL F.READ (FN.SEC.TRADE,REF.NO.SEQ,R.SEC.TRD,F.SEC.TRADE,ERR.ST)
                            Y.TXN.AUTH.DATE = R.SEC.TRD<SC.SBS.DATE.TIME,1>
                            Y.CURR.NO = R.SEC.TRD<SC.SBS.CURR.NO>
                        	IF Y.CURR.NO GT '1' THEN
                            	R.SEC.TRD.HIS = '' ; ERR.ST.HIS = ''
                            	CALL F.READ (FN.SEC.TRADE.HIS,REF.NO.SEQ:';1',R.SEC.TRD.HIS,F.SEC.TRADE.HIS,ERR.ST.HIS)
                            	Y.TXN.AUTH.DATE = R.SEC.TRD.HIS<SC.SBS.DATE.TIME,1>
                            END
                            Y.TXN.AUTH.DATE = OCONV(ICONV(Y.TXN.AUTH.DATE[1,6],"D"),"D4/G")
                    	CASE REF.NO.SEQ[1,6] EQ 'POSTSC'
                        	R.POST.TRANS = '' ; ERR.PT = ''
                            CALL F.READ (FN.POSITION.TRANSFER,REF.NO.SEQ,R.POST.TRANS,F.POSITION.TRANSFER,ERR.PT)
                            Y.TXN.AUTH.DATE = R.POST.TRANS<SC.PST.DATE.TIME,1>
                            Y.CURR.NO = R.POST.TRANS<SC.PST.CURR.NO>
                        	IF Y.CURR.NO GT '1' THEN
                            	R.POST.TRANS.HIS = '' ; ERR.PT.HIS = ''
                            	CALL F.READ (FN.POSITION.TRANSFER.HIS,REF.NO.SEQ:';1',R.POST.TRANS.HIS,F.POSITION.TRANSFER.HIS,ERR.PT.HIS)
                            	Y.TXN.AUTH.DATE = R.POST.TRANS.HIS<SC.PST.DATE.TIME,1>
                            END
                            Y.TXN.AUTH.DATE = OCONV(ICONV(Y.TXN.AUTH.DATE[1,6],"D"),"D4/G")
                    	CASE REF.NO.SEQ[1,6] EQ 'DIARSC'
                        	R.ENTITLEMENT = '' ; ERR.ENT = ''
                            CALL F.READ (FN.ENTITLEMENT,REF.NO.SEQ,R.ENTITLEMENT,F.ENTITLEMENT,ERR.ENT)
                            Y.TXN.AUTH.DATE = R.ENTITLEMENT<SC.ENT.DATE.TIME,1>
                            Y.CURR.NO = R.ENTITLEMENT<SC.ENT.CURR.NO>
                        	IF Y.CURR.NO GT '1' THEN
                            	R.ENTITLEMENT.HIS = '' ; ERR.ENT.HIS = ''
                            	CALL F.READ (FN.ENTITLEMENT.HIS,REF.NO.SEQ:';1',R.ENTITLEMENT.HIS,F.ENTITLEMENT.HIS,ERR.ENT.HIS)
                            	Y.TXN.AUTH.DATE = R.ENTITLEMENT.HIS<SC.ENT.DATE.TIME,1>
                        	END
                            Y.TXN.AUTH.DATE = OCONV(ICONV(Y.TXN.AUTH.DATE[1,6],"D"),"D4/G")
* For CA Events, Entitlement Value Date is taken for selection
							Y.TXN.TRADE.DATE = R.SECURITY.TRANS<SC.SCT.VALUE.DATE>                            
                    END CASE
* S --Exclude if INPUTTER is DMUSER for SECURITY.TRANSFER 
* 11084258_S --Excude if it is CAPE event for security transfer  
                    IF REF.NO.SEQ[1,6] EQ 'SECTSC' THEN
                        SEC.TRANSF.ERR = '' ; R.SECURITY.TRANSFER = ''; Y.TXN.DATA.REF = '' ; Y.TRANS.POS = ''			            
                        CALL F.READ(FN.SECURITY.TRANSFER,REF.NO.SEQ,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,SEC.TRANSF.ERR)
                        INPUTTER.NAME = R.SECURITY.TRANSFER<SC.STR.INPUTTER>
                        Y.CAPE.DESC = R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,ST.EVENT.DESC.POS>  ;*11084258_S/E
                        Y.TXN.AUTH.DATE = R.SECURITY.TRANSFER<SC.STR.DATE.TIME,1>
                        Y.CURR.NO = R.SECURITY.TRANSFER<SC.STR.CURR.NO>
                        IF Y.CURR.NO GT '1' THEN
                            SEC.TRANSF.ERR.HIS = '' ; R.SECURITY.TRANSFER.HIS = ''
                        	CALL F.READ(FN.SECURITY.TRANSFER.HIS,REF.NO.SEQ:';1',R.SECURITY.TRANSFER.HIS,F.SECURITY.TRANSFER.HIS,SEC.TRANSF.ERR.HIS)
                            Y.TXN.AUTH.DATE = R.SECURITY.TRANSFER.HIS<SC.STR.DATE.TIME,1>
                        END
                        Y.TXN.AUTH.DATE = OCONV(ICONV(Y.TXN.AUTH.DATE[1,6],"D"),"D4/G")
                     *11084258_S
                     *   IF INDEX(INPUTTER.NAME,'DMUSER',1) THEN
                    IF INDEX(INPUTTER.NAME,'DMUSER',1) OR Y.CAPE.DESC THEN
*11084258_E
                        CALL OCOMO("Txn is migrated or belong to Cape posting so skipping it here")
                            DMUSER.FLAG = 1
                        END
						Y.TXN.DATA.REF = REF.NO.SEQ 						
						CALL OCOMO("Processing Transfer ID ":Y.TXN.DATA.REF)
*Check if the transfer is already processed in GET.SETT.AT.DATA block then continue 						
						LOCATE Y.TXN.DATA.REF IN Y.AT.SETT.ARR<1,1> SETTING Y.TRANS.POS THEN
						  CALL OCOMO("Transfer already processed GET.SETT.AT.DATA block. Ignoring ":Y.TXN.DATA.REF)
						  CONTINUE
						END
                    END
* E --Exclude if INPUTTER is DMUSER for SECURITY.TRANSFER
                    IF Y.TXN.AUTH.DATE GT Y.LAST.STMT.DATE AND Y.TXN.AUTH.DATE LE Y.STMT.DATE AND DMUSER.FLAG EQ '' THEN
					    CALL OCOMO('Inside-GET.TXN.DATA block. Processing the record ':Y.TXN.DATA.REF) 
                        * Once the Txn is Sent out for the Statement , make an entry to SCB.RB.STMT.TXN.OUT.DETS                         
                        R.STMT.TXNS = '' ; ERR.STMT = ''
                        CALL F.READ (FN.SCB.STMT.TXN.OUT.DETS,SEC.TRANS.ID,R.STMT.TXNS,F.SCB.STMT.TXN.OUT.DETS,ERR.STMT)
                        IF R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> EQ '' THEN
	                    	R.STMT.TXNS<SCB.STMT.TXN.AUTH.DATE> = Y.TXN.AUTH.DATE
	                        R.STMT.TXNS<SCB.STMT.TXN.STMT.DATE> = Y.STMT.DATE
	                        R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> = 'Y'
	                        CALL F.WRITE (FN.SCB.STMT.TXN.OUT.DETS,SEC.TRANS.ID,R.STMT.TXNS)
                        Y.TXN.VALUE.DATE = '' ; Y.TXN.VALUE.DATE = R.SECURITY.TRANS<SC.SCT.VALUE.DATE>
                        Y.PEND.SETTLE = ''
                        IF Y.TXN.VALUE.DATE GT Y.STMT.DATE THEN Y.PEND.SETTLE = 'Y'
	    				Y.TXN.CCY = '' ; Y.TXN.CCY = R.SECURITY.TRANS<SC.SCT.TRADE.CURRENCY>
                        Y.TXN.TYPE = '' ; Y.TXN.TYPE = R.SECURITY.TRANS<SC.SCT.TRANS.TYPE>
	    				Y.NOMINEE.CODE = '' ; Y.NOMINEE.CODE = R.SECURITY.TRANS<SC.SCT.NOMINEE.CODE>
	    				R.SC.TRANS.NAME = '' ; Y.SC.TRANS.NAME.ERR = ''
	    				CALL F.READ(FN.SC.TRANS.NAME,R.SECURITY.TRANS<SC.SCT.TRANS.TYPE>,R.SC.TRANS.NAME,F.SC.TRANS.NAME,Y.SC.TRANS.NAME.ERR)
                        IF R.SC.TRANS.NAME THEN
                            Y.TRANS.NAME = '' ; Y.TRANS.NAME = R.SC.TRANS.NAME<SC.TNM.SHORT.NAME,1>
                        END
		      			
                        Y.TXN.NOMINAL = 0 ; Y.TXN.NOMINAL = R.SECURITY.TRANS<SC.SCT.NO.NOMINAL>
                        Y.TXN.PRICE = '' ; Y.TXN.PRICE = R.SECURITY.TRANS<SC.SCT.PRICE>
                        Y.TXN.AMT = 0 ; Y.TXN.AMT = R.SECURITY.TRANS<SC.SCT.NET.AMT.TRADE>
                        Y.TXN.ENABLE.FLAG = 'Y'
                        Y.PROD.CODE = ''
                        GOSUB SET.PRODUCT.FLAG
                        Y.TXN.ENABLE.FLAG = ''
                        IF Y.MF.SAT.FLAG EQ 'Y' THEN
                            Y.DEPOSITORY = '' ; Y.DEPOSITORY = R.SECURITY.TRANS<SC.SCT.DEPOSITORY>
               				GOSUB CHECK.DEPO
                            IF Y.PAY.MODE NE 'CASH' THEN
                                CONTINUE
                            END
                        END
* SNPR Sat Flag Enable
						IF Y.SN.SAT.FLAG EQ 'Y' AND R.SM<SC.SCM.CAPITAL.PROTECTION> NE '100' THEN
			                Y.SN.SAT.FLAG = ''
			                Y.SNPR.SAT.FLAG = 'Y'
                            Y.PROD.CODE = 'ISA-I2'
			            END
* SNPR Sat Flag Enable
                        GOSUB GROUP.TXN.DATA
                    END
                END
            END
            NEXT TRN.CON.DATE.REC.COUNT
        END
    NEXT POS.CON.SCAC.REC.COUNT
*
RETURN
*----------------------------------------------------------------------------*
GROUP.TXN.DATA:
*-------------
*
	BEGIN CASE
		CASE Y.MF.SAT.FLAG
			Y.MF.TXN.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'MF_TXN':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
			Y.MF.TXN.OUTPUT.ARR := '~':'':'~':'':'~':Y.SM.NAME:'~':Y.TRANS.NAME:'~':Y.TXN.NOMINAL:'~':Y.TXN.PRICE:'~':Y.TXN.TRADE.DATE:'~':Y.TXN.VALUE.DATE:'~':Y.PEND.SETTLE:'~':Y.TXN.CCY:'~':Y.TXN.AMT:'~':'':'~':'':'~':'':'~':'':'~':
			Y.MF.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.MF.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.MF.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
		CASE Y.SN.SAT.FLAG
			Y.SN.TXN.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'SN_TXN':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
			Y.SN.TXN.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
			Y.SN.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':Y.SM.NAME:'~':Y.TRANS.NAME:'~':Y.TXN.NOMINAL:'~':Y.TXN.PRICE:'~':Y.TXN.TRADE.DATE:'~':Y.TXN.VALUE.DATE:'~':Y.PEND.SETTLE:'~':Y.TXN.CCY:'~':Y.TXN.AMT:'~':'':'~':'':'~':'':'~':'':'~':
			Y.SN.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.SN.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
		CASE Y.SNPR.SAT.FLAG
			Y.SNPR.TXN.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'SNPR_TXN':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
			Y.SNPR.TXN.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
			Y.SNPR.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.SNPR.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':Y.SM.NAME:'~':Y.TRANS.NAME:'~':Y.TXN.NOMINAL:'~':Y.TXN.PRICE:'~':Y.TXN.TRADE.DATE:'~':Y.TXN.VALUE.DATE:'~':Y.PEND.SETTLE:'~':Y.TXN.CCY:'~':Y.TXN.AMT:'~':'':'~':'':'~':'':'~':'':'~':
			Y.SNPR.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
		CASE Y.FI.SAT.FLAG
			Y.FI.TXN.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'FI_TXN':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
			Y.FI.TXN.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
			Y.FI.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.FI.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.FI.TXN.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':Y.SM.NAME:'~':Y.TRANS.NAME:'~':Y.TXN.NOMINAL:'~':Y.TXN.PRICE:'~':Y.TXN.TRADE.DATE:'~':Y.TXN.VALUE.DATE:'~':Y.PEND.SETTLE:'~':Y.TXN.CCY:'~':Y.TXN.AMT:'~':Y.PROD.CODE:'~':Y.NOMINEE.CODE
	END CASE
*
RETURN
*
*----------------------------------------------------------------------------*
FINAL.OUTPUT.ARRAY:
*------------------

	IF Y.MF.HOL.OUTPUT.ARR THEN
        IF Y.OUTPUT.ARR THEN
			Y.OUTPUT.ARR<-1> = Y.MF.HOL.OUTPUT.ARR
    	END ELSE
    		Y.OUTPUT.ARR = Y.MF.HOL.OUTPUT.ARR
        END
	END
	IF Y.MF.HOL.TOT.OUTPUT.ARR THEN
        IF Y.OUTPUT.ARR THEN
			Y.OUTPUT.ARR<-1> = Y.MF.HOL.TOT.OUTPUT.ARR
    	END ELSE
    		Y.OUTPUT.ARR = Y.MF.HOL.TOT.OUTPUT.ARR
        END
    END
*
	IF Y.MF.TXN.OUTPUT.ARR THEN
		Y.OUTPUT.ARR<-1> = Y.MF.TXN.OUTPUT.ARR
	END
*
	IF Y.SN.HOL.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.SN.HOL.OUTPUT.ARR
    END
    
    IF Y.SN.HOL.TOT.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.SN.HOL.TOT.OUTPUT.ARR
    END
*
	IF Y.SN.TXN.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.SN.TXN.OUTPUT.ARR
	END
*
	IF Y.SNPR.HOL.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.SNPR.HOL.OUTPUT.ARR
	END
*
	IF Y.SNPR.HOL.TOT.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.SNPR.HOL.TOT.OUTPUT.ARR
	END
	
	IF Y.SNPR.TXN.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.SNPR.TXN.OUTPUT.ARR
	END
*
	IF Y.FI.HOL.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.FI.HOL.OUTPUT.ARR
    END
*
	IF Y.FI.HOL.TOT.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.FI.HOL.TOT.OUTPUT.ARR
    END
    
	IF Y.FI.TXN.OUTPUT.ARR THEN
        Y.OUTPUT.ARR<-1> = Y.FI.TXN.OUTPUT.ARR
	END
*
	IF Y.OUTPUT.ARR THEN
		CONVERT @FM TO CHAR(10) IN Y.OUTPUT.ARR
		WRITESEQ Y.OUTPUT.ARR APPEND TO F.OUT.FILE ELSE
			CALL OCOMO('Unable to write Statement details')
	    END
    END
*
*
RETURN
*
*----------------------------------------------------------------------------*
* =========================
CHECK.CASH.PAYMENT.INCLUDE:
* =========================
	SEC.POS.LIST = ''
    NO.OF.REC = ''
    ERR.SEL = ''
	SEL.CMD = "SELECT ":FN.SECURITY.POSITION:" WITH SECURITY.ACCOUNT EQ ":Y.PF.ID:" AND SECURITY.NUMBER EQ ":Y.SM.ID
    CALL EB.READLIST (SEL.CMD,SEC.POS.LIST,'',NO.OF.REC,ERR.SEL)
    NO.SEC.POS = 0 ; NO.SEC.POS = DCOUNT(SEC.POS.LIST,@FM)
    
    FOR SEC.POS.CNT = 1 TO NO.SEC.POS
        Y.DEPOSITORY = '' ; Y.DEPOSITORY = FIELD(SEC.POS.LIST<SEC.POS.CNT>,'.',3,1)
        IF Y.DEPOSITORY THEN
            GOSUB CHECK.DEPO
            IF Y.PAY.MODE EQ 'CASH' THEN
        	END ELSE
            	Y.MKT.PRC = R.SC.POS.ASSET<SC.PAS.MARKET.PRICE,Y.SEC.NO.CTR>
                R.SEC.POSITION = '' ; ERR.SEC.POS = ''
        		CALL F.READ (FN.SECURITY.POSITION,SEC.POS.LIST<SEC.POS.CNT>,R.SEC.POSITION,F.SECURITY.POSITION,ERR.SEC.POS)
        		Y.CLOSE.BAL.NOM = R.SEC.POSITION<SC.SCP.CLOSING.BAL.NO.NOM>
        		BEGIN CASE
                 CASE Y.CLOSE.BAL.NOM GT '0'
                    BEGIN CASE
                        CASE Y.NOMINAL GT '0'
                            IF Y.NOMINAL GE Y.CLOSE.BAL.NOM THEN
                              Y.NOMINAL = Y.NOMINAL - Y.CLOSE.BAL.NOM
                        	END ELSE
                              Y.NOMINAL = Y.CLOSE.BAL.NOM - Y.NOMINAL
                        	END
                    	CASE Y.NOMINAL LE '0'
                            Y.NOMINAL = Y.CLOSE.BAL.NOM - Y.NOMINAL
                    END CASE                                   
                 CASE Y.CLOSE.BAL.NOM LT '0'
                	BEGIN CASE
                		CASE Y.NOMINAL GT '0'
                            Y.NOMINAL = Y.NOMINAL + Y.CLOSE.BAL.NOM
                		CASE Y.NOMINAL LE '0'
                            Y.NOMINAL = Y.NOMINAL - Y.CLOSE.BAL.NOM
                    END CASE	
               END CASE
            END
        END
    NEXT SEC.POS.CNT
	IF Y.NOMINAL EQ Y.TMP.PAS.NOMINAL THEN
         Y.SP.ESTIMATION = Y.TMP.PAS.ESTIMATION
         Y.SP.UNRL = Y.UNREAL.PL
    END ELSE
         Y.SP.ESTIMATION = (Y.NOMINAL/Y.TMP.PAS.NOMINAL) * Y.TMP.PAS.ESTIMATION
	     CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.SP.ESTIMATION,1,"")
         Y.SP.UNRL = (Y.NOMINAL/Y.TMP.PAS.NOMINAL) * Y.TMP.PAS.UNRL
         CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.SP.UNRL,1,"")
    END
      	Y.ESTIMATION = Y.SP.ESTIMATION
        Y.UNREAL.PL = Y.SP.UNRL
RETURN
*----------------------------------------------------------------------------*
* =========
CHECK.DEPO:
* =========
	SEL.LIST = ''
	SEL.LIST = ''
	NO.OF.REC = ''
	ERR.SEL = ''
	CPF.POS = ''
	VAL.POS = ''
    Y.PAY.MODE = ''
	SEL.CMD = 'SELECT ':FN.AEB.SEC.PAR:' WITH DEPOSITORY EQ ':Y.DEPOSITORY
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,ERR.SEL)
	
	Y.CPF.ARR = 'CPF-15':@VM:'CPF-OA':@VM:'CPF-SA':@VM:'SRS'
	
	Y.CPF.VAL = FIELD(SEL.LIST,'.',4)
	LOCATE Y.CPF.VAL IN Y.CPF.ARR<1,1> SETTING VAL.POS THEN
		Y.PAY.MODE = Y.CPF.VAL
	END
	ELSE
		Y.PAY.MODE = 'CASH'
	END
RETURN
*----------------------------------------------------------------------
GET.CASH.DIV.CA.TXNS:
*====================
	SEC.ENT.LIST = ''
    NO.OF.REC = ''
    ERR.SEL = ''
	SEL.CMD = "SELECT ":FN.ENTITLEMENT:" WITH @ID LIKE ...":Y.PF.ID:"..."
    CALL EB.READLIST (SEL.CMD,SEC.ENT.LIST,'',NO.OF.REC,ERR.SEL)
    
    LOOP
        REMOVE Y.SC.ENT.ID FROM SEC.ENT.LIST SETTING Y.ENT.POS
    WHILE Y.SC.ENT.ID:Y.ENT.POS
    	Y.DIA.ID = FIELD(Y.SC.ENT.ID,'.',1)
        R.DIARY = '' ; ERR.DIA = '' ; Y.PAY.MODE = ''
        CALL F.READ (FN.DIARY,Y.DIA.ID,R.DIARY,F.DIARY,ERR.DIA)
	        Y.DIA.TYPE = '';Y.DIA.TYPE = R.DIARY<SC.DIA.EVENT.TYPE>
	        IF Y.DIA.TYPE EQ 'COUPON' OR Y.DIA.TYPE EQ 'DIVIDENDS' THEN
		    	R.ENT = '';ERR.ENT = ''
		        CALL F.READ (FN.ENTITLEMENT,Y.SC.ENT.ID,R.ENT,F.ENTITLEMENT,ERR.ENT)
* For CA, Entitlement Value Date is taken for selection                
                Y.TXN.TRADE.DATE = '' ; Y.TXN.TRADE.DATE = R.ENT<SC.ENT.VALUE.DATE>
        	    Y.TXN.AUT.DATE = ''; Y.TXN.AUT.DATE = R.ENT<SC.ENT.DATE.TIME,1> ;* Authorisation date
                Y.CURR.NO = R.ENT<SC.ENT.CURR.NO>
                IF Y.CURR.NO GT '1' THEN
                    R.ENT.HIS = '';ERR.ENT.HIS = ''
		        	CALL F.READ (FN.ENTITLEMENT.HIS,Y.SC.ENT.ID:';1',R.ENT.HIS,F.ENTITLEMENT.HIS,ERR.ENT.HIS)
                    Y.TXN.AUT.DATE = ''; Y.TXN.AUT.DATE = R.ENT.HIS<SC.ENT.DATE.TIME,1> ;* Authorisation date
                END
* Authorisation Date to be taken for RBSG Statement Selection                
                Y.TXN.AUT.DATE = OCONV(ICONV(Y.TXN.AUT.DATE[1,6],"D"),"D4/G")
        	IF Y.TXN.AUT.DATE GT Y.LAST.STMT.DATE AND Y.TXN.AUT.DATE LE Y.STMT.DATE THEN
* Once the Txn is Sent out for the Statement , make an entry to SCB.RB.STMT.TXN.OUT.DETS                         
                R.STMT.TXNS = '' ; ERR.STMT = ''
                CALL F.READ (FN.SCB.STMT.TXN.OUT.DETS,Y.SC.ENT.ID,R.STMT.TXNS,F.SCB.STMT.TXN.OUT.DETS,ERR.STMT)
                IF R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> EQ '' THEN
	               R.STMT.TXNS<SCB.STMT.TXN.AUTH.DATE> = Y.TXN.AUTH.DATE
	               R.STMT.TXNS<SCB.STMT.TXN.STMT.DATE> = Y.STMT.DATE
	               R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> = 'Y'
	               CALL F.WRITE (FN.SCB.STMT.TXN.OUT.DETS,Y.SC.ENT.ID,R.STMT.TXNS)
*				
				Y.TXN.VALUE.DATE = '' ; Y.TXN.VALUE.DATE = R.ENT<SC.ENT.VALUE.DATE>
                Y.PEND.SETTLE = ''
                IF Y.TXN.VALUE.DATE GT Y.STMT.DATE THEN Y.PEND.SETTLE = 'Y'
                Y.TRANS.NAME = '' ; 
                IF Y.DIA.TYPE EQ 'COUPON' THEN
                   Y.TRANS.NAME = 'COUPON PAYMENT'
            	END ELSE
                	Y.TRANS.NAME = 'CASH DIVIDEND'	
                END
            	Y.TXN.NOMINAL = 0 ; Y.TXN.NOMINAL = R.ENT<SC.ENT.QUALIFY.HOLDING>
                Y.SM.ID = '' ; Y.SM.ID = R.ENT<SC.ENT.SECURITY.NO>
                GOSUB GET.SM.NAME
                Y.TXN.PRICE = '' ; Y.TXN.PRICE = R.DIARY<SC.DIA.RATE> ;*CPSGMIG-31058
                Y.TXN.CCY = '' ; Y.TXN.CCY = R.ENT<SC.ENT.CURRENCY>
                Y.TXN.AMT = 0 ; Y.TXN.AMT = R.ENT<SC.ENT.NET.AMOUNT>
                Y.NOMINEE.CODE = '' ; Y.NOMINEE.CODE = R.ENT<SC.ENT.NOMINEE>
                Y.TXN.ENABLE.FLAG = 'Y'
                Y.PROD.CODE = '' ; Y.TXN.TYPE = ''
                GOSUB SET.PRODUCT.FLAG
                Y.TXN.ENABLE.FLAG = ''
                IF Y.MF.SAT.FLAG EQ 'Y' THEN
                      Y.DEPOSITORY = '' ; Y.DEPOSITORY = R.ENT<SC.ENT.DEPOSITORY>
               		  GOSUB CHECK.DEPO
                      IF Y.PAY.MODE NE 'CASH' THEN
                               CONTINUE
                      END
                END
* SNPR Sat Flag Enable
						IF Y.SN.SAT.FLAG EQ 'Y' AND R.SM<SC.SCM.CAPITAL.PROTECTION> NE '100' THEN
			                Y.SN.SAT.FLAG = ''
			                Y.SNPR.SAT.FLAG = 'Y'
                            Y.PROD.CODE = 'ISA-I2'
			            END
* SNPR Sat Flag Enable
                        GOSUB GROUP.TXN.DATA
                	END
	        END
    	END
    REPEAT
**********************************************************
SEC.CA.LIST = ''   ;*11084258_s
NO.OF.REC = ''
    ERR.SEL = ''
    Y.CA.ID.TYPES = 'MERGER':@VM:'SECURITY.SWITCH':@VM:'STOCK.SPLIT':@VM:'OPTIONAL.DIV':@VM:'STOCK.DIV':@VM:'REINVEST'
    Y.CA.FT.ID.TYPES = 'COUPON':@VM:'DIVIDENDS':@VM:'E.REDEMPTION'
	SEL.CMD = "SELECT ":FN.SCB.L.CAPE:" WITH @ID LIKE ...*":Y.PF.ID
    CALL EB.READLIST (SEL.CMD,SEC.CA.LIST,'',NO.OF.REC,ERR.SEL)
IF SEC.CA.LIST THEN 
***************
  LOOP
        REMOVE Y.SC.CA.ID FROM SEC.CA.LIST SETTING Y.CA.POS
    WHILE Y.SC.CA.ID:Y.CA.POS
    	        CALL F.READ (FN.SCB.L.CAPE,Y.SC.CA.ID,R.CAPE.REF,F.SCB.L.CAPE,ERR.CA)
	        Y.CA.EVENT.TYPE = '';Y.CA.EVENT.TYPE = FIELD(R.CAPE.REF<SCBCA.CAPE.EVENT.DETS>,'*',2)
                Y.PROD.TYPE = '' ; Y.PROD.TYPE = FIELD(R.CAPE.REF<SCBCA.CAPE.EVENT.DETS>,'*',1)
                 Y.CA.EVENT.DESC = '' ;Y.CA.EVENT.DESC = FIELD(R.CAPE.REF<SCBCA.CAPE.EVENT.DETS>,'*',3)
                Y.APPLICATION = R.CAPE.REF<SCBCA.APPLICATION>
          LOCATE 'FUNDS.TRANSFER' IN Y.APPLICATION<1,1> SETTING S.POS THEN 
   yFtTransId = R.CAPE.REF<SCBCA.TXN.REF,S.POS,1>
   ftFlag = 1 
  END

 LOCATE 'SECURITY.TRANSFER' IN Y.APPLICATION<1,1> SETTING V.POS THEN 
 yCapeEventTypesArr = 'SECURITY.SWITCH':@VM:"STOCK.SPLIT":@VM:'MERGER'
TRNTYPE = ""
   yStTransId = R.CAPE.REF<SCBCA.TXN.REF,V.POS,1>
 IF Y.CA.EVENT.TYPE MATCHES yCapeEventTypesArr THEN
yStTransId = ""
 Y.TRO.TRI =  CHANGE(R.CAPE.REF<SCBCA.TYPE,V.POS>,@SM,@FM)
  FINDSTR 'TRI' IN Y.TRO.TRI SETTING TRI.POS THEN
    yStTransIdIn = R.CAPE.REF<SCBCA.TXN.REF,V.POS,TRI.POS>
yStTransId<-1> = yStTransIdIn 
   TRNTYPE<-1> = 'TRI'
   END
 FINDSTR 'TRO' IN Y.TRO.TRI SETTING TRO.POS THEN
   yStTransIdOut = R.CAPE.REF<SCBCA.TXN.REF,V.POS,TRO.POS>
  TRNTYPE<-1> = 'TRO'
yStTransId<-1> = yStTransIdOut 
   END
 END
yStIdCount = DCOUNT(yStTransId,@FM)
Y.EVENT.TYPE.DESCRP = "EXCHANGE.OFFER":@VM:"CONVERSION":@VM:"SECURITIES.WRITE.DOWN"

 stFlag = 1 
  END

R.ENT = '';ERR.ENT = ''
   
		         CALL EB.READ.HISTORY.REC(F.FUNDS.TRANSFER.HIS,yFtTransId,R.FUNDS.TRANSFER.HIS,ERR.ENT)
                        IF R.FUNDS.TRANSFER.HIS EQ "" THEN
                       CALL F.READ (FN.FUNDS.TRANSFER,yFtTransId,R.FUNDS.TRANSFER.HIS,F.FUNDS.TRANSFER,ERR.ENT)
                       END


IF Y.CA.EVENT.TYPE NE 'SECURITY.SWITCH' THEN
    CALL F.READ (FN.SECURITY.TRANSFER,yStTransId,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,ERR.ENT)
END
Y.FT.PROD = "MF":@VM:"FI"

BEGIN CASE

 CASE ((Y.CA.EVENT.TYPE MATCHES Y.CA.FT.ID.TYPES) OR (Y.CA.EVENT.TYPE EQ 'REDEMPTION' AND Y.PROD.TYPE MATCHES Y.FT.PROD) OR (Y.CA.EVENT.TYPE EQ 'REDEMPTION' AND Y.CA.EVENT.DESC EQ 'MATURITY.IN.CASH'))

* For CA, Entitlement Value Date is taken for selection                
                Y.TXN.TRADE.DATE = '' ; Y.TXN.TRADE.DATE = R.FUNDS.TRANSFER.HIS<FT.DEBIT.VALUE.DATE>
                Y.TXN.AUT.DATE = ''; Y.TXN.AUT.DATE = R.FUNDS.TRANSFER.HIS<FT.DATE.TIME,1> ;* Authorisation date
                Y.CURR.NO = R.FUNDS.TRANSFER.HIS<FT.CURR.NO>
              * Authorisation Date to be taken for RBSG Statement Selection                
                Y.TXN.AUT.DATE = OCONV(ICONV(Y.TXN.AUT.DATE[1,6],"D"),"D4/G")
        	IF Y.TXN.AUT.DATE GT Y.LAST.STMT.DATE AND Y.TXN.AUT.DATE LE Y.STMT.DATE THEN
* Once the Txn is Sent out for the Statement , make an entry to SCB.RB.STMT.TXN.OUT.DETS                         
                R.STMT.TXNS = '' ; ERR.STMT = ''
                CALL F.READ (FN.SCB.STMT.TXN.OUT.DETS,yFtTransId,R.STMT.TXNS,F.SCB.STMT.TXN.OUT.DETS,ERR.STMT)
                IF R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> EQ '' THEN
	               R.STMT.TXNS<SCB.STMT.TXN.AUTH.DATE> = Y.TXN.AUTH.DATE
	               R.STMT.TXNS<SCB.STMT.TXN.STMT.DATE> = Y.STMT.DATE
	               R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> = 'Y'
	               CALL F.WRITE (FN.SCB.STMT.TXN.OUT.DETS,yFtTransId,R.STMT.TXNS)
*	               
	               Y.TXN.VALUE.DATE = '' ; Y.TXN.VALUE.DATE = R.FUNDS.TRANSFER.HIS<FT.DEBIT.VALUE.DATE>
	                Y.PEND.SETTLE = ''
	                IF Y.TXN.VALUE.DATE GT Y.STMT.DATE THEN Y.PEND.SETTLE = 'Y'
                       Y.TXN.PRICE = '' ; Y.TXN.PRICE = R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,L.RATE.POS> 	       
                        Y.TXN.CCY = '' ; Y.TXN.CCY = R.FUNDS.TRANSFER.HIS<FT.CREDIT.CURRENCY>
	                Y.TXN.AMT = 0 ; Y.TXN.AMT = R.FUNDS.TRANSFER.HIS<FT.AMOUNT.CREDITED>[4,99]
	                Y.NOMINEE.CODE = '' ; Y.NOMINEE.CODE = R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,NOMINEE.CODE.POS>
                         Y.TXN.NOMINAL = 0 ; Y.TXN.NOMINAL =R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,QUALIFY.HOLDING.POS>
	                Y.TRANS.NAME = '' ; 
                        BEGIN CASE 
	                CASE Y.CA.EVENT.TYPE EQ 'COUPON' 
	                   Y.TRANS.NAME = 'COUPON PAYMENT'
	            	CASE Y.CA.EVENT.TYPE EQ 'DIVIDENDS' 
	                	Y.TRANS.NAME = 'CASH DIVIDEND'	
	                CASE (Y.CA.EVENT.TYPE EQ 'REDEMPTION' OR Y.CA.EVENT.TYPE EQ 'E.REDEMPTION') AND Y.CA.EVENT.DESC EQ 'REPURCHASE.OFFER'
                        Y.TRANS.NAME = 'EARLY CALLBACK / BOND MATURITY'
                      CASE Y.CA.EVENT.TYPE EQ 'REDEMPTION' AND Y.CA.EVENT.DESC EQ 'REDEMPTION'
                        Y.TRANS.NAME = 'REDEMPTION'

                      CASE Y.CA.EVENT.TYPE EQ 'REDEMPTION' AND (Y.CA.EVENT.DESC EQ 'TERMINATION' OR Y.CA.EVENT.DESC EQ 'PARTIAL.TERMINATION')
                      Y.TRANS.NAME = 'FUND MATURITY / FUND CLOSURE'
                      Y.TXN.PRICE = ''
                       

                      CASE Y.CA.EVENT.TYPE EQ 'REDEMPTION' AND Y.CA.EVENT.DESC EQ 'MATURITY.IN.CASH'
                      Y.TRANS.NAME = 'MATURITY-CASH'
                     
                  CASE Y.CA.EVENT.TYPE EQ 'E.REDEMPTION' AND Y.CA.EVENT.DESC EQ 'PUT.REDEMPTION'
                   Y.TRANS.NAME = 'EARLY CALLBACK / BOND MATURITY'
                   CASE Y.CA.EVENT.TYPE EQ 'E.REDEMPTION' AND (Y.CA.EVENT.DESC EQ 'TERMINATION' OR Y.CA.EVENT.DESC EQ 'PARTIAL.TERMINATION')
                      Y.TRANS.NAME = 'FUND MATURITY / FUND CLOSURE'
         

                     END CASE
	            	Y.TXN.NOMINAL = 0 ; Y.TXN.NOMINAL =R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,QUALIFY.HOLDING.POS>
	                Y.SM.ID = '' ; Y.SM.ID = R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,L.SECURITY.NO.POS>
	                GOSUB GET.SM.NAME
	                
	                Y.TXN.ENABLE.FLAG = 'Y'
	                Y.PROD.CODE = '' ; Y.TXN.TYPE = ''
	                GOSUB SET.PRODUCT.FLAG
	                Y.TXN.ENABLE.FLAG = ''
	                IF Y.MF.SAT.FLAG EQ 'Y' THEN
	                      Y.DEPOSITORY = '' ; Y.DEPOSITORY = R.FUNDS.TRANSFER.HIS<FT.LOCAL.REF,DEPO.POS>
	               		  GOSUB CHECK.DEPO
	                      IF Y.PAY.MODE NE 'CASH' THEN
	                               CONTINUE
	                      END
	                END
	* SNPR Sat Flag Enable
					IF Y.SN.SAT.FLAG EQ 'Y' AND R.SM<SC.SCM.CAPITAL.PROTECTION> NE '100' THEN
				        Y.SN.SAT.FLAG = ''
				        Y.SNPR.SAT.FLAG = 'Y'
	                    Y.PROD.CODE = 'ISA-I2'
				    END
	* SNPR Sat Flag Enable
	                GOSUB GROUP.TXN.DATA
                 END
	        END
    	

       CASE (Y.CA.EVENT.TYPE MATCHES Y.CA.ID.TYPES) OR (Y.CA.EVENT.TYPE EQ 'REDEMPTION' AND (Y.CA.EVENT.DESC EQ 'MATURITY.IN.SHARES' AND Y.PROD.TYPE EQ 'SN'))
FOR I = 1 TO yStIdCount 
CALL F.READ (FN.SECURITY.TRANSFER,yStTransId<I>,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,ERR.ENT)
yStmtId = yStTransId<I>
* For CA, Entitlement Value Date is taken for selection     
                 Y.TRANSACTION.TYPE = R.SECURITY.TRANSFER<SC.STR.TRANSACTION.TYPE>      
                Y.TXN.TRADE.DATE = '' ; Y.TXN.TRADE.DATE = R.SECURITY.TRANSFER<SC.STR.VALUE.DATE>
                Y.TXN.AUT.DATE = ''; Y.TXN.AUT.DATE = R.SECURITY.TRANSFER<SC.STR.DATE.TIME,1> ;* Authorisation date
                Y.CURR.NO = R.SECURITY.TRANSFER<SC.STR.CURR.NO>
              * Authorisation Date to be taken for RBSG Statement Selection                
                Y.TXN.AUT.DATE = OCONV(ICONV(Y.TXN.AUT.DATE[1,6],"D"),"D4/G")
        	IF Y.TXN.AUT.DATE GT Y.LAST.STMT.DATE AND Y.TXN.AUT.DATE LE Y.STMT.DATE THEN
* Once the Txn is Sent out for the Statement , make an entry to SCB.RB.STMT.TXN.OUT.DETS                         
                R.STMT.TXNS = '' ; ERR.STMT = ''
                CALL F.READ (FN.SCB.STMT.TXN.OUT.DETS,yStmtId,R.STMT.TXNS,F.SCB.STMT.TXN.OUT.DETS,ERR.STMT)
                IF R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> EQ '' THEN
	               R.STMT.TXNS<SCB.STMT.TXN.AUTH.DATE> = Y.TXN.AUTH.DATE
	               R.STMT.TXNS<SCB.STMT.TXN.STMT.DATE> = Y.STMT.DATE
	               R.STMT.TXNS<SCB.STMT.TXN.STMT.INCL> = 'Y'
	               CALL F.WRITE (FN.SCB.STMT.TXN.OUT.DETS,yStmtId,R.STMT.TXNS)
*	               
	               Y.TXN.VALUE.DATE = '' ; Y.TXN.VALUE.DATE = R.SECURITY.TRANSFER<SC.STR.VALUE.DATE>
	                Y.PEND.SETTLE = ''
	                IF Y.TXN.VALUE.DATE GT Y.STMT.DATE THEN Y.PEND.SETTLE = 'Y'
	               
	            	
	                Y.SM.ID = '' ; Y.SM.ID = R.SECURITY.TRANSFER<SC.STR.SECURITY.NO>
	                GOSUB GET.SM.NAME
                     Y.TXN.NOMINAL = 0 ;  Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.OPTION.NOM.POS>
	                Y.TXN.PRICE = '' ; Y.TXN.PRICE = R.SM<SC.SCM.LAST.PRICE> 	       
                        Y.TXN.CCY = '' ; Y.TXN.CCY =  R.SM<SC.SCM.SECURITY.CURRENCY>
                              Y.TXN.AMT = 0 ; Y.TXN.AMT = R.FUNDS.TRANSFER.HIS<FT.AMOUNT.CREDITED>[4,99]
 Y.TRANS.NAME = '' ; 
	                BEGIN CASE
               CASE Y.CA.EVENT.TYPE EQ 'REINVEST' 
	                   Y.TRANS.NAME = 'REINVEST DIVIDEND'
 IF Y.TRANSACTION.TYPE EQ 'TRO' THEN
	            	   Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.QUAL.HOLDING.POS>
                   END ELSE
                  Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
                   END

	                CASE Y.CA.EVENT.TYPE EQ 'STOCK.DIV' 
 IF Y.TRANSACTION.TYPE EQ 'TRO' THEN
                         Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.QUAL.HOLDING.POS>
                   END ELSE
                  Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
                   END

                  	Y.TRANS.NAME = 'REINVEST DIVIDEND'	
                          
	                CASE Y.CA.EVENT.TYPE EQ 'OPTIONAL.DIV'
                   Y.TRANS.NAME = 'OPTIONAL DIV'
                  IF Y.TRANSACTION.TYPE EQ 'TRO' THEN
                    Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.QUAL.HOLDING.POS>
                   END ELSE
                  Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
                   END

                      CASE Y.CA.EVENT.TYPE EQ 'MERGER'
                    Y.TRANS.NAME = 'FUND MERGE'
                   IF Y.TRANSACTION.TYPE EQ 'TRO' THEN
                    Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.QUAL.HOLDING.POS>
                   END ELSE
                  Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
                   END
                    Y.TXN.AMT =  Y.TXN.NOMINAL*Y.TXN.PRICE
                    CASE Y.CA.EVENT.TYPE EQ 'STOCK.SPLIT'
                    IF Y.TRANSACTION.TYPE EQ 'TRO' THEN
                    Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.QUAL.HOLDING.POS>
                   END ELSE
                  Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
                   END
 Y.TRANS.NAME = 'FUND SPLIT'
Y.TXN.PRICE = ''

CASE Y.CA.EVENT.TYPE EQ 'SECURITY.SWITCH'

IF (Y.CA.EVENT.DESC MATCHES Y.EVENT.TYPE.DESCRP AND TRNTYPE<I> EQ 'TRO') THEN
Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.QUAL.HOLDING.POS>
Y.TRANS.NAME = 'EXTERNAL TRANSFER OUT'
END ELSE
Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
Y.TRANS.NAME = 'EXTERNAL TRANSFER IN'
END

CASE Y.CA.EVENT.TYPE EQ 'REDEMPTION' AND yStTransId 
Y.TRANS.NAME = 'MATURITY IN SHARES'
 Y.TXN.NOMINAL =  R.SECURITY.TRANSFER<SC.STR.LOCAL.REF,L.QUAL.HOLDING.POS>
END CASE
	       
	                Y.NOMINEE.CODE = '' ; Y.NOMINEE.CODE =  R.SECURITY.TRANSFER<SC.STR.NOMINEE.CODE>
	                Y.TXN.ENABLE.FLAG = 'Y'
	                Y.PROD.CODE = '' ; Y.TXN.TYPE = ''
	                GOSUB SET.PRODUCT.FLAG
	                Y.TXN.ENABLE.FLAG = ''
	                IF Y.MF.SAT.FLAG EQ 'Y' THEN
	                      Y.DEPOSITORY = '' ; Y.DEPOSITORY =  R.SECURITY.TRANSFER<SC.STR.DEPOSITORY>
	               		  GOSUB CHECK.DEPO
	                      IF Y.PAY.MODE NE 'CASH' THEN
	                               CONTINUE
	                      END
	                END
	* SNPR Sat Flag Enable
					IF Y.SN.SAT.FLAG EQ 'Y' AND R.SM<SC.SCM.CAPITAL.PROTECTION> NE '100' THEN
				        Y.SN.SAT.FLAG = ''
				        Y.SNPR.SAT.FLAG = 'Y'
	                    Y.PROD.CODE = 'ISA-I2'
				    END
	* SNPR Sat Flag Enable
	                GOSUB GROUP.TXN.DATA
                 END
	        END
   NEXT I 	
END CASE
    REPEAT  ;*11084258_E
END



*******************************
RETURN
*--------------------------------------------------------------------------------
GET.ZERO.POS.HOLDINGS:
*=====================
		Y.FI.SAT.FLAG = '' ; Y.MF.SAT.FLAG = '' ; Y.SN.SAT.FLAG = '' ;Y.SNPR.SAT.FLAG = ''

            IF Y.MF.HOL.OUTPUT.ARR NE '' THEN
                Y.MF.SAT.FLAG = 'Y'
                GOSUB GROUP.TOTAL.HOLDINGS.DATA
            END
        	IF Y.FI.HOL.OUTPUT.ARR NE '' THEN
                Y.FI.SAT.FLAG = 'Y'
                GOSUB GROUP.TOTAL.HOLDINGS.DATA
            END
        	IF Y.SN.HOL.OUTPUT.ARR NE '' THEN
                Y.SN.SAT.FLAG = 'Y'
                GOSUB GROUP.TOTAL.HOLDINGS.DATA
            END
        	IF Y.SNPR.HOL.OUTPUT.ARR NE '' THEN
                Y.SNPR.SAT.FLAG = 'Y'
                GOSUB GROUP.TOTAL.HOLDINGS.DATA
            END

        IF Y.MF.HOL.OUTPUT.ARR NE '' AND Y.SN.HOL.OUTPUT.ARR NE '' AND Y.FI.HOL.OUTPUT.ARR NE '' AND Y.SNPR.HOL.OUTPUT.ARR NE '' THEN
    	END ELSE
	        R.SAM = '' ; ERR.SAM = ''
	        CALL F.READ (FN.SEC.ACC.MASTER,Y.PF.ID,R.SAM,F.SEC.ACC.MASTER,ERR.SAM)
	        IF R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS> NE '' THEN
	            Y.LR.TP.ACCT.NO = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS>
	            Y.LR.TP.SYSTEM = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.SYSTEM.POS>
	            Y.LR.TP.AC.STATUS = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.AC.STATUS.POS>
	            
	            CONVERT @SM TO @VM IN Y.LR.TP.ACCT.NO
	            CONVERT @VM TO @FM IN Y.LR.TP.ACCT.NO
	            CONVERT @SM TO @VM IN Y.LR.TP.SYSTEM
	            CONVERT @VM TO @FM IN Y.LR.TP.SYSTEM
	            CONVERT @SM TO @VM IN Y.LR.TP.AC.STATUS
	            CONVERT @VM TO @FM IN Y.LR.TP.AC.STATUS
	            LOOP
	                REMOVE Y.TP.ACCT.NO FROM Y.LR.TP.ACCT.NO SETTING TP.AC.POS
	                REMOVE Y.TP.SYSTEM FROM Y.LR.TP.SYSTEM SETTING TP.SYS.POS
	                REMOVE Y.TP.AC.STAT FROM Y.LR.TP.AC.STATUS SETTING TP.STAT.POS
	            WHILE Y.TP.ACCT.NO:TP.AC.POS
	            	Y.FI.SAT.FLAG = '' ; Y.MF.SAT.FLAG = '' ; Y.SN.SAT.FLAG = '' ;Y.SNPR.SAT.FLAG = ''
	            	IF Y.TP.SYSTEM EQ 'UTS' AND Y.TP.AC.STAT NE 'CLOSED' THEN
	                    BEGIN CASE
						 	CASE Y.TP.ACCT.NO[9,2] EQ '11' AND Y.FI.HOL.OUTPUT.ARR EQ ''
							 Y.FI.SAT.FLAG = 'Y'
					         Y.PROD.CODE = 'ISA-I3'
                             IF Y.FI.HOL.TOTAL EQ '' THEN
                                Y.FI.HOL.TOTAL = '0'
                             END
					        CASE Y.TP.ACCT.NO[9,2] EQ '05' AND Y.FI.HOL.OUTPUT.ARR EQ ''
							 Y.FI.SAT.FLAG = 'Y'
					         Y.PROD.CODE = 'ISA-I3'
                             IF Y.FI.HOL.TOTAL EQ '' THEN
                                Y.FI.HOL.TOTAL = '0'
                             END
						 	CASE Y.TP.ACCT.NO[9,2] EQ '01' AND Y.MF.HOL.OUTPUT.ARR EQ ''
							 Y.MF.SAT.FLAG = 'Y'
					         Y.PROD.CODE = 'ISA-IS'
                             IF Y.MF.HOL.TOTAL EQ '' THEN
                                Y.MF.HOL.TOTAL = '0'
                             END
						 	CASE Y.TP.ACCT.NO[9,2] EQ '04' AND Y.SN.HOL.OUTPUT.ARR EQ ''
							 Y.SN.SAT.FLAG = 'Y'
					         Y.PROD.CODE = 'ISA-I1'
                             IF Y.SN.HOL.TOTAL EQ '' THEN
                                Y.SN.HOL.TOTAL = '0'
                             END
							CASE Y.TP.ACCT.NO[9,2] EQ '06' AND Y.SNPR.HOL.OUTPUT.ARR EQ ''
					    	 Y.SNPR.SAT.FLAG = 'Y'
					          Y.PROD.CODE = 'ISA-I2'
                              IF Y.SNPR.HOL.TOTAL EQ '' THEN
                                 Y.SNPR.HOL.TOTAL = '0'
                              END
	  					END CASE
	  						GOSUB GROUP.TOTAL.HOLDINGS.DATA 
	                END  	
	            REPEAT
	        END
        END
		
        IF Y.MF.HOL.TOT.OUTPUT.ARR EQ '' OR Y.FI.HOL.TOT.OUTPUT.ARR EQ '' OR Y.SN.HOL.TOT.OUTPUT.ARR EQ '' OR Y.SNPR.HOL.TOT.OUTPUT.ARR EQ '' THEN
			NO.OF.REC = '' ; R.POS.CON.SCAC = '' ;ERR.SEL = ''
            Y.MF.HOL.TOTAL = '0' ; Y.FI.HOL.TOTAL ='0';Y.SN.HOL.TOTAL='0'; Y.SNPR.HOL.TOTAL = '0'
			SEL.CMD = "SELECT ":FN.SECURITY.POSITION:" WITH SECURITY.ACCOUNT EQ ":Y.PF.ID:" AND CLOSING.BAL.NO.NOM EQ '0'"
	    	CALL EB.READLIST (SEL.CMD,R.POS.CON.SCAC,'',NO.OF.REC,ERR.SEL)
	        LOOP
	            REMOVE Y.SEC.POS.ID FROM R.POS.CON.SCAC SETTING Y.SEC.POS
	        WHILE Y.SEC.POS.ID:Y.SEC.POS
	        		Y.SM.ID = FIELD(Y.SEC.POS.ID,'.',2,1)
	                GOSUB GET.SM.NAME
	        		Y.TXN.ENABLE.FLAG = 'Y'
	        		Y.PROD.CODE = ''
	                Y.TXN.TYPE = ''
	        		GOSUB SET.PRODUCT.FLAG
	                Y.TXN.ENABLE.FLAG = ''
	                IF Y.SN.SAT.FLAG EQ 'Y' AND R.SM<SC.SCM.CAPITAL.PROTECTION> NE '100' THEN
				       Y.SN.SAT.FLAG = ''
				       Y.SNPR.SAT.FLAG = 'Y'
	                   Y.PROD.CODE = 'ISA-I2'
	            	END
	                GOSUB GROUP.TOTAL.HOLDINGS.DATA
	        REPEAT
    	END
RETURN
*-------------------------------------------------------------------------------
GROUP.TOTAL.HOLDINGS.DATA:
*-------------------------
	BEGIN CASE
        CASE Y.MF.SAT.FLAG AND Y.MF.HOL.TOT.OUTPUT.ARR EQ ''
            Y.MF.HOL.TOT.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'MF_Holding_Total':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
			Y.MF.HOL.TOT.OUTPUT.ARR := '~':'':'~':Y.MF.HOL.TOTAL:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.MF.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.MF.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
			Y.MF.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'ISA-IS':'~':''
        CASE Y.FI.SAT.FLAG AND Y.FI.HOL.TOT.OUTPUT.ARR EQ ''
        	Y.FI.HOL.TOT.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'FI_Holding_Total':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
        	Y.FI.HOL.TOT.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
        	Y.FI.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
        	Y.FI.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
        	Y.FI.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':Y.FI.HOL.TOTAL:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'ISA-I3':'~':''    
    	CASE Y.SN.SAT.FLAG AND Y.SN.HOL.TOT.OUTPUT.ARR EQ ''
        	Y.SN.HOL.TOT.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'SN_Holding_Total':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
        	Y.SN.HOL.TOT.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
        	Y.SN.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':Y.SN.HOL.TOTAL:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
        	Y.SN.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
        	Y.SN.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'ISA-I1':'~':''
    	CASE Y.SNPR.SAT.FLAG AND Y.SNPR.HOL.TOT.OUTPUT.ARR EQ ''
        	Y.SNPR.HOL.TOT.OUTPUT.ARR<-1> = 'D':'~':Y.EBBS.REL.ID:'~':'SNPR_Holding_Total':'~':Y.PF.ID:'~':'':'~':'':'~':'':'~':'':'~':'':'~':''
        	Y.SNPR.HOL.TOT.OUTPUT.ARR := '~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~'
        	Y.SNPR.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
        	Y.SNPR.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':Y.SNPR.HOL.TOTAL:'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':
        	Y.SNPR.HOL.TOT.OUTPUT.ARR := '':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'':'~':'ISA-I2':'~':''
    END CASE    
RETURN
*--------------------------------------------------------------------------------*	  
CHECK.UNSETTLED.POSITIONS:
*-------------------------

    Y.SETT.DETS.NOMINAL = 0; Y.SETT.DETS.PRICE = 0; Y.SETT.DETS.EST = 0; Y.SETT.DETS.SGD.EST = 0; Y.SETT.DETAILS.ID = ''
	Y.ACTU.NOMINAL = ''; Y.ACTU.PRICE = ''; Y.ACTU.EST = ''; Y.ACTU.SGD.EST = ''; Y.AT.SETT.DATE = ''; Y.AT.TRANS.ID = ''
	Y.SEL.CMD = ''; Y.SEL.LIST = ''; NO.OF.REC = ''; RET.CODE = ''; Y.MON = ''; Y.CURR.MON = ''; Y.SETT.POS = ''; Y.DATE.ARR = ''
*
    GOSUB FORM.SELECT.STMT
*	
	CALL OCOMO('Unsettled Positions Sel List ':Y.SEL.LIST.ARR)
	
	  Y.AT.TRANS.ID = ''; R.SCB.AT.SETT.DETAILS = ''; Y.SCB.AT.SETT.DETAILS.ERR = ''
	  Y.SEC.TRANS.ID = ''; Y.ID.POS = ''; Y.AT.SETT.DATE = ''; Y.DATE = ''; Y.STMT.INCL = ''

      LOOP
	  REMOVE Y.SCB.AT.SETT.DETAILS.ID FROM Y.SEL.LIST.ARR SETTING Y.ID.POS
	  WHILE Y.SCB.AT.SETT.DETAILS.ID:Y.ID.POS
	     R.SCB.AT.SETT.DETAILS = ''; Y.AT.TRANS.ID = ''; Y.CNT = ''; Y.ID.POS1 = ''; Y.SETT.DETS.NOMINAL = ''; Y.ACTU.NOMINAL = '' 
*6543049-S		 
         *IF Y.MF.SAT.FLAG EQ 'Y' THEN
		 *   Y.DEPOSITORY = ''; Y.DEPOSITORY = FIELD(Y.SCB.AT.SETT.DETAILS.ID,'.',3)
		 *   GOSUB CHECK.DEPO
		 *   IF Y.PAY.MODE EQ 'CASH' THEN
		 *      CONTINUE
		 *   END
		 *END		 
*6543049-E		 
	     CALL F.READ(FN.SCB.AT.SETT.DETAILS,Y.SCB.AT.SETT.DETAILS.ID,R.SCB.AT.SETT.DETAILS,F.SCB.AT.SETT.DETAILS,Y.SCB.AT.SETT.DETAILS.ERR)
	     IF R.SCB.AT.SETT.DETAILS THEN
		 CALL OCOMO('Processing Positions-SCB.AT.SETT.DETAILS ':Y.SCB.AT.SETT.DETAILS.ID)
	 
	        Y.AT.TRANS.ID = R.SCB.AT.SETT.DETAILS<AT.SETT.AT.ID>
			Y.CNT = DCOUNT(Y.AT.TRANS.ID,@VM)
	        Y.IDX = 0
	        LOOP
	        REMOVE Y.SEC.TRANS.ID FROM Y.AT.TRANS.ID SETTING Y.ID.POS1
	        WHILE Y.SEC.TRANS.ID:Y.ID.POS1			
			  Y.STMT.INCL = ''; Y.AT.SETT.DATE = ''; Y.TRN.TYPE = ''
			  Y.IDX++
			  Y.STMT.INCL = R.SCB.AT.SETT.DETAILS<AT.SETT.STMT.INCLUDED,Y.IDX>			  		  
			  GOSUB CHECK.NOMINEE.CODE 
			  
			  BEGIN CASE			  
		        CASE Y.NOMINEE.CODE AND Y.AT.NOMINEE.CODE
			         GOSUB CALCULATE.NOMINAL
			    CASE NOT(Y.NOMINEE.CODE) AND NOT(Y.AT.NOMINEE.CODE)
			         GOSUB CALCULATE.NOMINAL
			  END CASE			  

	     	   IF Y.IDX EQ Y.CNT THEN
			      Y.SPA.NOMINAL = ''; Y.SPA.NOMINAL = Y.NOMINAL
			      Y.ACTU.NOMINAL = Y.NOMINAL - Y.SETT.DETS.NOMINAL
				  IF Y.ACTU.NOMINAL EQ 0 THEN 
				     Y.EXCLUDE.HOLDING = 1
					 CALL OCOMO('Exclude from Holding section ':Y.SEC.TRANS.ID)
					 RETURN
				  END
				  CALL OCOMO('SC.POS.ASSET Nominal ':Y.NOMINAL)
				  CALL OCOMO('Unsettled Nominal ':Y.SETT.DETS.NOMINAL)
			      Y.NOMINAL = Y.ACTU.NOMINAL				  
				  CALL OCOMO('Updated Nominal ':Y.NOMINAL)

				  Y.ACTU.ESTIMATION = (Y.NOMINAL/Y.SPA.NOMINAL) * Y.ESTIMATION
                  CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.ACTU.ESTIMATION,1,"")
				  Y.ESTIMATION = Y.ACTU.ESTIMATION
				  
				  IF (Y.SN.SAT.FLAG EQ "Y" OR Y.SNPR.SAT.FLAG EQ "Y") AND Y.UNREAL.PL NE 0 THEN
				     Y.ACTU.UNREAL.PL = (Y.NOMINAL/Y.SPA.NOMINAL) * Y.UNREAL.PL
                     CALL EB.ROUND.AMOUNT(Y.SEC.CCY,Y.ACTU.UNREAL.PL,1,"")
				     Y.UNREAL.PL = Y.ACTU.UNREAL.PL
				  END
			      Y.SGD.ESTIMATION = Y.ESTIMATION
                  IF Y.SEC.CCY NE 'SGD' THEN
                     CCY.MKT='1' ; EXT.RATE = '' ; EXT.CCY = 'SGD' ; EXT.AMT = "" ; LCY.AMT = "" ; BAS.CCY = "" ; RET.COD = "" ; DIFFER = 0 ;
                     CALL EXCHRATE(CCY.MKT,EXT.CCY,EXT.AMT,Y.SEC.CCY,Y.ESTIMATION,BAS.CCY,EXT.RATE,DIFFER,LCY.AMT,RET.COD)
                     Y.SGD.ESTIMATION = EXT.AMT
                  END							  
			   END
	        REPEAT
	     END
       REPEAT
  
RETURN
*-------------------------------------------------------------------------------*
GET.SETT.AT.DATA:
*----------------

    Y.SETT.TXN.NOMINAL = 0; Y.SETT.TXN.PRICE = 0; Y.SETT.TXN.NET.AMT.TRADE = 0; Y.ACTU.TXN.NOM = ''; Y.ACTU.TXN.PRICE = ''; Y.SETT.DETAILS.ID = ''
	Y.SCB.AT.SETT.DETAILS.ID = ''; R.SCB.AT.SETT.DETAILS = ''; Y.SCB.AT.SETT.DETAILS.ERR = '';Y.SEC.TRANS.ARR = ''; Y.SEC.TRANS.POS = ''; Y.SETT.POS = ''
	Y.ACTU.TXN.NET.AMT.TRADE = '' ; Y.STMT.INCL = ''
*	
    GOSUB FORM.SELECT.STMT
*	
	CALL OCOMO('Processing Txns Sel Lists ':Y.SEL.LIST.ARR)

	LOOP
	REMOVE Y.SCB.AT.SETT.DETAILS.ID FROM Y.SEL.LIST.ARR SETTING Y.SETT.POS
	WHILE Y.SCB.AT.SETT.DETAILS.ID:Y.SETT.POS
	Y.STMT.INCL = ''; Y.SEC.TRANS.ARR = ''; Y.TRANS.AT.SETT.DT = ''; R.SCB.AT.SETT.DETAILS = ''
	  	  
	    CALL F.READ(FN.SCB.AT.SETT.DETAILS,Y.SCB.AT.SETT.DETAILS.ID,R.SCB.AT.SETT.DETAILS,F.SCB.AT.SETT.DETAILS,Y.SCB.AT.SETT.DETAILS.ERR)

               Y.SM.ID = ''; Y.SM.ID = FIELD(Y.SCB.AT.SETT.DETAILS.ID,'.',2)		
		       GOSUB GET.SM.NAME
*6543049-S			   
		       *Y.TXN.ENABLE.FLAG = 'Y'
		       *GOSUB SET.PRODUCT.FLAG
               *IF Y.MF.SAT.FLAG EQ 'Y' THEN		
	           *   Y.DEPOSITORY = ''; Y.DEPOSITORY = FIELD(Y.SCB.AT.SETT.DETAILS.ID,'.',3)
		       *   GOSUB CHECK.DEPO
		       *   IF Y.PAY.MODE EQ 'CASH' THEN
		       *      CALL OCOMO('Pay Mode is Cash, Ignoring ':Y.SCB.AT.SETT.DETAILS.ID)
		       *      CONTINUE
		       *   END
		       *END
*6543049-E			   
		IF R.SCB.AT.SETT.DETAILS THEN	   
         CALL OCOMO('Processing Txns SCB.AT.SETT.DETAILS ':Y.SCB.AT.SETT.DETAILS.ID)		
	     Y.SEC.TRANS.ARR = R.SCB.AT.SETT.DETAILS<AT.SETT.AT.ID>
*To store all the transfer ids processed from SCB.AT.SETT.DETAILS and ignore it from GET.TXN.DATA block		 		 
             Y.AT.SETT.ARR<-1> = Y.SEC.TRANS.ARR 			 
	           Y.SEC.TRANS.IDX = 0			   			   
         LOOP
		 REMOVE Y.SEC.TRANS.REF FROM Y.SEC.TRANS.ARR SETTING  Y.AT.POS 
		 WHILE Y.SEC.TRANS.REF : Y.AT.POS
		 Y.SEC.TRANS.IDX++
		 	  
	       Y.TRANS.AT.SETT.DT = R.SCB.AT.SETT.DETAILS<AT.SETT.SETT.DATE,Y.SEC.TRANS.IDX>
		   Y.STMT.INCL = R.SCB.AT.SETT.DETAILS<AT.SETT.STMT.INCLUDED,Y.SEC.TRANS.IDX>
*Exclude the transaction if it is not Settled or if already included in Statement	   
		   IF Y.STMT.INCL EQ "" THEN		   
		       IF NOT(Y.TRANS.AT.SETT.DT) THEN		
                   CALL OCOMO('Not Settled, Ignoring ':Y.SEC.TRANS.REF)				   
		       END ELSE
		          Y.TXN.VALUE.DATE = Y.TRANS.AT.SETT.DT
			      R.SCB.AT.SETT.DETAILS<AT.SETT.STMT.INCLUDED,Y.SEC.TRANS.IDX> = "Y"
			      CALL F.WRITE(FN.SCB.AT.SETT.DETAILS,Y.SCB.AT.SETT.DETAILS.ID,R.SCB.AT.SETT.DETAILS)			      
				  GOSUB GET.SEC.TRANS.DETAILS				  
		       END
		   END ELSE
		       IF Y.STMT.INCL EQ "Y" THEN
				  CALL OCOMO('Already Settled, Ignoring ':Y.SEC.TRANS.REF)
		       END
		   END
        REPEAT
*		 
	    END  
     REPEAT
   
RETURN
*--------------------------------------------------------------------------------*
FORM.SELECT.STMT:
*----------------
    Y.SEL.CMD = ''; Y.SEL.LIST = ''; NO.OF.REC = ''; RET.CODE = ''; Y.CURR.MON = ''; Y.CURR.YEAR = ''
	Y.CUR.DATE = ''; Y.PREV.MON = ''; Y.PREV.MON.DATE = ''; Y.DATE.ARR = ''; Y.SEL.LIST.ARR = ''
*	
    Y.TODAY = TODAY
    Y.CURR.MON = Y.TODAY[5,2]
	Y.CURR.YEAR = Y.TODAY[1,4]
	Y.CUR.DATE = Y.CURR.MON:Y.CURR.YEAR
*	
	IF Y.CURR.MON EQ "01" THEN 
	   Y.PREV.MON = "12"
	   Y.CURR.YEAR = Y.CURR.YEAR - 1
	END ELSE
*Append 0 for months from JAN to SEP	
	   Y.PREV.MON = Y.CURR.MON-1
	   IF Y.PREV.MON LT 10 THEN
	      Y.PREV.MON = '0':Y.PREV.MON
	   END
	END
*	
	Y.PREV.MON.DATE = Y.PREV.MON:Y.CURR.YEAR
*	
	Y.DATE.ARR<1> = Y.CUR.DATE
	Y.DATE.ARR<2> = Y.PREV.MON.DATE	
    
	     LOOP
	     REMOVE Y.DT FROM Y.DATE.ARR SETTING Y.SETT.POS
	     WHILE Y.DT:Y.SETT.POS
*	     
	        Y.SEL.CMD = 'SELECT ':FN.SCB.AT.SETT.DETAILS:' WITH @ID LIKE ':Y.SAM.ID:'.':Y.SM.ID:'....':Y.DT
	        CALL EB.READLIST(Y.SEL.CMD,Y.SEL.LIST,'',NO.OF.REC,RET.CODE)
	        Y.SEL.LIST.ARR<-1> = Y.SEL.LIST
*			
	     REPEAT
	
RETURN

*--------------------------------------------------------------------------------*
GET.SEC.TRANS.DETAILS:
*----------------------
   CALL OCOMO('Processing Transfer ':Y.SEC.TRANS.REF)
   R.SECURITY.TRANSFER = ''; SEC.TRANSF.ERR = ''; Y.TXN.TRADE.DATE = ''; Y.TXN.NOMINAL = ''; Y.NOMINEE.CODE = ''; Y.TXN.TYPE = ''
   Y.TXN.PRICE = ''; Y.PEND.SETTLE = ''; Y.TXN.CCY = ''; Y.TXN.AMT = ''; Y.TRANS.NAME = ''
   CALL F.READ(FN.SECURITY.TRANSFER,Y.SEC.TRANS.REF,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,SEC.TRANSF.ERR)
   IF R.SECURITY.TRANSFER THEN
      Y.SM.ID = R.SECURITY.TRANSFER<SC.STR.SECURITY.NO>
	  
	     Y.TXN.TRADE.DATE = R.SECURITY.TRANSFER<SC.STR.TRADE.DATE>    
         Y.TXN.TYPE = R.SECURITY.TRANSFER<SC.STR.TRANSACTION.TYPE>		
	     R.SC.TRANS.NAME = '' ; Y.SC.TRANS.NAME.ERR = ''
	     CALL F.READ(FN.SC.TRANS.NAME,Y.TXN.TYPE,R.SC.TRANS.NAME,F.SC.TRANS.NAME,Y.SC.TRANS.NAME.ERR)
         IF R.SC.TRANS.NAME THEN
            Y.TRANS.NAME = '' ; Y.TRANS.NAME = R.SC.TRANS.NAME<SC.TNM.SHORT.NAME,1>
         END		 
		 Y.TXN.NOMINAL = R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
		 Y.TXN.PRICE = R.SECURITY.TRANSFER<SC.STR.PRICE>
		 IF NOT(Y.TRANS.AT.SETT.DT) THEN
		    Y.TXN.VALUE.DATE = R.SECURITY.TRANSFER<SC.STR.VALUE.DATE>
		 END
		 Y.TXN.CCY = R.SECURITY.TRANSFER<SC.STR.SECURITY.CCY> 
		 Y.TXN.AMT = R.SECURITY.TRANSFER<SC.STR.NET.AMT.SEC.CCY>
		 Y.NOMINEE.CODE = R.SECURITY.TRANSFER<SC.STR.NOMINEE.CODE>
		 Y.TXN.ENABLE.FLAG = 'Y'
		 GOSUB SET.PRODUCT.FLAG
		 IF Y.SN.SAT.FLAG EQ 'Y' AND R.SM<SC.SCM.CAPITAL.PROTECTION> NE '100' THEN
		    Y.SN.SAT.FLAG = ''
		    Y.SNPR.SAT.FLAG = 'Y'
            Y.PROD.CODE = 'ISA-I2'
		 END		 		 
		 GOSUB GROUP.TXN.DATA		  
   END
   
RETURN
*-----------------------------------------------------------------*

CHECK.NOMINEE.CODE:
*------------------

 R.SEC.TRANS = ''; Y.SEC.TRANS.ERR = ''; Y.AT.NOMINEE.CODE = ''; Y.NOMINEE.FLAG = ''
 CALL F.READ(FN.SECURITY.TRANSFER,Y.SEC.TRANS.ID,R.SEC.TRANS,F.SECURITY.TRANSFER,Y.SEC.TRANS.ERR)
 IF R.SEC.TRANS THEN
    Y.AT.NOMINEE.CODE = R.SEC.TRANS<SC.STR.NOMINEE.CODE>
 END

RETURN
*-----------------------------------------------------------------*
CALCULATE.NOMINAL:
*------------------
  IF Y.STMT.INCL EQ "" THEN
     Y.AT.SETT.DATE = R.SCB.AT.SETT.DETAILS<AT.SETT.SETT.DATE,Y.IDX> 
     Y.TRN.TYPE = R.SCB.AT.SETT.DETAILS<AT.SETT.AT.TYPE,Y.IDX> 			 
     IF NOT(Y.AT.SETT.DATE) THEN	
        IF Y.TRN.TYPE EQ "CR" THEN 
           Y.SETT.DETS.NOMINAL += R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,Y.IDX> 	 
		END 
		IF Y.TRN.TYPE EQ "DR" THEN
		   Y.SETT.DETS.NOMINAL -= R.SCB.AT.SETT.DETAILS<AT.SETT.NOMINAL,Y.IDX>
		END			    
	  END
  END
RETURN
*-----------------------------------------------------------------*
END