$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-50</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.ASSET.PRICE.PDW.EXT.POST
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 04/08/2022 - kalaikuamran p - New requirement for RBSG - Batch file from T24 -> PDW/ATHENA
*								T24_SG_AssetPrice_YYYYMMDD.txt
* 10/08/2022 - kalaikuamran p - Underscore in the file naming changed to hypen
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.ASSET.PRICE.PDW.EXT.COMMON
    $INSERT I_F.DATES
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)

    Y.FINAL.FILE.NAME = ''
    R.ASSETPRICE.RPT.FINAL.ARR = ''
    Y.FINAL.FILE.NAME = 'T24-SG-AssetPrice-':TODAY:'.csv'
*
RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.FILES = ''
*
    Y.UDFILE	= 'AMEX.FILES'
    SEL.CMD     = ID.COMPANY[1,2]:'*-AssetPrice-FILE-*':TODAY:'.csv-*'
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, NO.OF.FILES)
*
    IF SEL.LIST THEN
        LOOP
            REMOVE SEL.FILE FROM SEL.LIST SETTING SEL.POS
        WHILE SEL.FILE:SEL.POS
            R.AMEX.FILE = '' ; AMEX.ERR = ''
            CALL F.READ(FN.AMEX.FILES,SEL.FILE,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            IF R.ASSETPRICE.RPT.FINAL.ARR EQ '' THEN
                R.ASSETPRICE.RPT.FINAL.ARR = R.AMEX.FILE
            END ELSE
                R.ASSETPRICE.RPT.FINAL.ARR :=@FM:R.AMEX.FILE
            END
            CALL F.DELETE(FN.AMEX.FILES,SEL.FILE)
        REPEAT
    END
    DL = CHAR(01)
	NO.OF.RECORDS = DCOUNT(R.ASSETPRICE.RPT.FINAL.ARR,@FM)
    Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
	Y.PRICE.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
	Y.PRICE.HEADER<-1> = 'C-RECORD-IND':DL:'C-FUND':DL:'C-FUND-HSE':DL:'X-FUND-HSE':DL:'X-FUND':DL:'C-FUND-CCY':DL:'T-CUT-OFF':DL:'A-BID-PRICE':DL:'A-OFFER-PRICE':DL:'C-FUND-PRICE':DL:'F-EXCL-DIV':DL:'D-EFF':DL:'F-PVB':DL:'F-PROF-INV':DL:'P-FEL':DL:'C-ASSET-TYPE':DL:'C-FUND-CLASS':DL:'D-LST-MAINT'
	Y.PRICE.FOOTER = 'T':DL:NO.OF.RECORDS
	R.ASSETPRICE.RPT.FINAL = Y.PRICE.HEADER:@FM:R.ASSETPRICE.RPT.FINAL.ARR:@FM:Y.PRICE.FOOTER
    R.ASSETPRICE.RPT.FINAL = UTF8(R.ASSETPRICE.RPT.FINAL)
*
    WRITE R.ASSETPRICE.RPT.FINAL TO F.AMEX.FILES,Y.FINAL.FILE.NAME
*
RETURN
*-----------------------------------------------------------------------------
END
