$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.AM.EXTRACT.SELECT
*---------------------------------------------------------------------------------------------------------------
* 
* 
*-----------------------------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-----------------------------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864
*
** 21-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
*-----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.EBBS.AM.EXT.COMMON
    $INSERT I_F.SEC.ACC.MASTER
*
    SEL.CMD = 'SELECT ':FN.SEC.ACC.MAST
*CPSGMIG-13878(S)
    SEL.CMD := " WITH CUST.SECTOR EQ 23"
*CPSGMIG-13878(E)

	IF BATCH.DETAILS<3> THEN 
	Y.FROM.DATE = BATCH.DETAILS<3,1,1>[3,6]:'0000'				;* 20 221202 0000
	Y.TO.DATE = BATCH.DETAILS<3,1,2>[3,6]:'2359'
		SEL.CMD := " AND DATE.TIME GE ":Y.FROM.DATE:" AND DATE.TIME LE ":Y.TO.DATE
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
		CALL BATCH.BUILD.LIST('',SEL.LIST)
    END	
*
    RETURN
*
*-----------------------------------------------------------------------------------------------------------------
END
*-----------------------------------------------------------------------------------------------------------------