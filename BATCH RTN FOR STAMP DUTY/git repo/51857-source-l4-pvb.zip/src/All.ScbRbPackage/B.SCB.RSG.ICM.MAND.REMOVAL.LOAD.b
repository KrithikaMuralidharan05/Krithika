$PACKAGE All.ScbRbPackage
*
* Implementation of All.ScbRbPackage.bScbRsgIcmMandRemovalLoad
* Load routine to initialise the variables, for removing the ord id and corr id from SCB.RSG.ICM.T24.MAND.LIST
* whose record doesnot exist or got removed after 30 days.
* Developed by :- Pawan kr(1668106)
*Jira ref:- CPSGMIG-5191
*-------------------------------------
SUBROUTINE B.SCB.RSG.ICM.MAND.REMOVAL.LOAD
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RSG.ICM.MAND.REMOVAL.COMMON
    GOSUB INIT ; *
RETURN

*-----------------------------------------------------------------------------

*** <region name= INIT>
INIT:
*** <desc> TO initialise the variables used accross the .select as well main record rouitne </desc>
*

*
    CALL LOAD.COMPANY("SG1090400")

    FN.SRIT.MAND.LIST = "F.SCB.RSG.ICM.T24.MAND.LIST"
    F.SRIT.MAND.LIST =""
    CALL OPF(FN.SRIT.MAND.LIST,F.SRIT.MAND.LIST)

    FN.ORD.DET = "F.OFS.REQUEST.DETAIL"
    F.ORD.DET =""
    CALL OPF(FN.ORD.DET,F.ORD.DET)

RETURN
*** </region>
END