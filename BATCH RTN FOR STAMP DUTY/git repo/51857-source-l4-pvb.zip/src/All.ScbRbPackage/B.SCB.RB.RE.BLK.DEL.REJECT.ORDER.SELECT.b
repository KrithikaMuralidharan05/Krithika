$PACKAGE All.ScbRbPackage
* @ValidationCode : MjotMTY3ODU3NDI5MzpDcDEyNTI6MTYwMTM4NTIwNjgwOToxNjAxMjc0Oi0xOi0xOjA6MDpmYWxzZTpOL0E6REVWXzIwMTgwOS4xOi0xOi0x
* @ValidationInfo : Timestamp         : 29 Sep 2020 18:43:26
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1601274
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201809.1
SUBROUTINE B.SCB.RB.RE.BLK.DEL.REJECT.ORDER.SELECT
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*  Bharathiraja P    17-May-2022         CPSGMIG-565 Settle MF Trade: Cash Debit / Credit in Client's Account
*                                        CPSGMIG-3157 T24 Dev - EBBS Block creation / deletion
*-----------------------------------------------------------------------------
     $INSERT I_COMMON
     $INSERT I_EQUATE
     $INSERT I_F.BATCH
     $INSERT I_F.SCB.CASH.BLK.SETT
     $INSERT I_B.SCB.RB.RE.BLK.DEL.REJECT.ORDER.COMMON 

*Perform Select
    SelList = ''; ListName = ''; Selected = ''; SystemReturnCode = ''
    Sel.Cmd = "SELECT ":FnBlkRej:" WITH TYPE EQ 'SOO' AND WITH BLOCK.STATUS EQ 'TO_BE_BLOCKED' 'BLOCKED'"
    CALL EB.READLIST(Sel.Cmd, SelList, ListName, Selected, SystemReturnCode)
    IF (SelList) THEN
         CALL BATCH.BUILD.LIST("", SelList)
    END
    
RETURN
END
