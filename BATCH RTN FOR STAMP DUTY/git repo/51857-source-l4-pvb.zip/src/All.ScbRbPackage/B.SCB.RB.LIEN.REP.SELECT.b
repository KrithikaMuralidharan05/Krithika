* @ValidationCode : MjotMTQ4MzU3Mzc3NTpJU08tODg1OS0xOjE2NzgzNDgzMjcxMDM6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 09 Mar 2023 13:22:07
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.LIEN.REP.SELECT
*-----------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14081 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       7 Mar 2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* This is the multi-threaded routine which generates the Lien Report
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_B.SCB.RB.LIEN.REP.COMMON
*-----------------------------------------------------------------------------
    
    GOSUB SELECT.RECORDS

RETURN
*-------------*
SELECT.RECORDS:
*-------------*
    
    SEL.CMD = "SSELECT ":FN.SEC.ACC.MASTER
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
    
RETURN
END