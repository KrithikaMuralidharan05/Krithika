$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-12</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.CONSOL.XML.ADV.RB.LOAD
*-----------------------------------------------------------------------------
* Created by    : Sasikumar Kannan
* Creation Date : 28/06/2012
*-----------*
*DESCRIPTION:
*-----------*
* This is a BATCH routine is used for consolidating all the XML advices generated.
* This is a requirement for DE-PERSONALISATION Project.
* Routine attached to the BATCH Application
* XXX/B.SCB.CONSOL.XML.ADV(Online Generation with Interval of 30 mins in Business days.
*------------------------------------------------------------------------------------------
* PVB-60661 - 9-10-2020 - Kapil K - SMS Post Trade Notification
*------------------------------------------------------------------------------------------
* PVB-60661 - 6-11-2020 - Kapil K - SMS Post Trade Notification Post-Live changes -cross compile
* TAFJUPG - Code conversion for TAFJ upgrade - TAFJ VOC/DIR changes.
*
* 23-Jul-2021 - 1389710 Changes done in WRITESEQ usage for R20 multi server environment(TAFJUPG-MS) 
*
* 25-04-2022  - CPSGMIG-1081    Avinash        This Routine copied from B.SCB.CONSOL.XML.ADV.LOAD to 
*                                              B.SCB.CONSOL.XML.ADV.RB.LOAD to consolidate only retail advices.
*------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_TSA.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.CONSOL.XML.ADV.RB.COMMON
*---------------------------------------------------------------------------------
PROCESS:
*-------

    FN.SCB.DP.XML.ADV.STATUS = 'F.SCB.DP.XML.ADV.STATUS'
    F.SCB.DP.XML.ADV.STATUS  = ''
    CALL OPF(FN.SCB.DP.XML.ADV.STATUS,F.SCB.DP.XML.ADV.STATUS)
*
    FN.DE.O.HISTORY = 'F.DE.O.HISTORY'
    F.DE.O.HISTORY = ''
    CALL OPF(FN.DE.O.HISTORY,F.DE.O.HISTORY)
*	TAFJUPG - /S
    FN.SCB.RB.DP.XML.FILES = 'F.SCB.RB.DP.XML.FILES'
    ORCLFILENAME=''
    F.SCB.RB.DP.XML.FILES = ''
*   CALL OPF(FN.SCB.DP.XML.FILES,F.SCB.DP.XML.FILES)
	CALL SCB.GET.ORACLE.FILENAME(FN.SCB.RB.DP.XML.FILES,"",ORCLFILENAME)
	FN.SCB.RB.DP.XML.FILES=ORCLFILENAME
*	TAFJUPG - /E

    FN.DE.O.HEADER ='F.DE.O.HEADER'
    F.DE.O.HEADER  =''
    CALL OPF(FN.DE.O.HEADER,F.DE.O.HEADER)
*
    Y.DPFILE.ID = AGENT.NUMBER:'-':TODAY:'-':PROCESS.NAME[1,3]
*
RETURN
*---------------------------------------------------------------------------------------------------*
END
