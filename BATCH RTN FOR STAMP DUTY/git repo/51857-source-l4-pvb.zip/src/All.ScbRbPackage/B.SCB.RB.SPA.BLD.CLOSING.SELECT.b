$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-24</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.SPA.BLD.CLOSING.SELECT
*-----------------------------------------------------------------------------------------------*
* Description:
*-------------------------------------------------------------------------------------------------------------
* Daily job to update closing bal no nom in SCB.RB.SEC.POS.ACTIVITY.
*-------------------------------------------------------------------------------------------------------------
* Modification History:
*-------------------------------------------------------------------------------------------------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- Daily job to update closing bal no nom in SCB.RB.SEC.POS.ACTIVITY.
*-------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SCB.RB.SEC.POS.ACTIVITY
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.POSITION
    $INSERT I_SCB.RB.SPA.BLD.CLOSING.COMMON
    $INSERT I_F.COMPANY
*

   SEL.CMD= "SELECT " :YF.SEC.ACC.MASTER:" WITH L.O.B EQ ":Y.ALLOWED.LOB

    SEC.ACC.MASTER.LIST = ""

    NO.SEC.ACC.CUST = ""

    SEL.ERR = ""

    CALL EB.READLIST(SEL.CMD,SEC.ACC.MASTER.LIST,'',NO.SEC.ACC.CUST,SEL.ERR)

   
	CALL BATCH.BUILD.LIST('',SEC.ACC.MASTER.LIST)


RETURN
END
