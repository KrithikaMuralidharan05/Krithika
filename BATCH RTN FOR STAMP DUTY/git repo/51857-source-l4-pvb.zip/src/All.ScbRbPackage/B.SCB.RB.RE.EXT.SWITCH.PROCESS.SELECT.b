$PACKAGE All.ScbRbPackage
* @ValidationCode : MjotMzk2NzU4NzYwOkNwMTI1MjoxNTgzOTA3Njk5NDc3OjE2MDEyNzQ6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxODA5LjE6LTE6LTE=
* @ValidationInfo : Timestamp         : 11 Mar 2020 11:51:39
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1601274
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201809.1

SUBROUTINE B.SCB.RB.RE.EXT.SWITCH.PROCESS.SELECT
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* Author		      Date 	         Reference	    Description
*-------------------------------------------------------------------------------------------------------------------------------------------
* Bharathiraja Ponmudi        24-May-2022        CPSGMIG-565        Settle MF Trade: Cash Debit / Credit in Client's Account
* Loganathan G		      28-Aug-2023        CPSGMIG-23267	    Block and Settlement process for Ext Switch (FSO-FSI)
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.RE.EXT.SWITCH.PROCESS.COMMON
*-----------------------------------------------------------------------------
    
    SEL.CMD = ''; SEL.LIST = ''; NO.OF.RECS = ''; ERR.LIST = ''; 
    
    SEL.CMD = "SELECT ":FN.CASH.BLK.SETT: " WITH BLOCK.STATUS EQ 'SWITCH_BLOCK' "
    CALL EB.READLIST(SEL.CMD, SEL.LIST, "", NO.OF.RECS, ERR.LIST)

    CALL BATCH.BUILD.LIST('',SEL.LIST)

RETURN
*-----------------------------------------------------------------------------
END
