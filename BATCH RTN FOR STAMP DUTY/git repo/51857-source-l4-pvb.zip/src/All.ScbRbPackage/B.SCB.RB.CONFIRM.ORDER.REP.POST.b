* @ValidationCode : MjotMTM0MTcxMjkxOklTTy04ODU5LTE6MTY5MzI5NzkzMTY0NDoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 29 Aug 2023 14:02:11
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*-----------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CONFIRM.ORDER.REP.POST
*-----------------------------------------------------------------------------
* Project Name                   :      CPSGMIG-34072
* Developed By                   :      1670271
* Developed On                   :      07-Sep-2023
*-----------------------------------------------------------------------------
* Description:
*-------------
* Batch report to generate the confirmed order from SEC.TRADE & SECURITY.TRANSFER
*-------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
* 20-9-2023  1670271  CPSGMIG-34031 - Month to date Transaction report similar to Daily Transaction Confirmed R2W report MTD reports
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.DATES
    $INSERT I_B.SCB.RB.CONFIRM.ORDER.REP.COMMON
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
	GOSUB PROCESS
	 
RETURN
*---------*
INITIALISE:
*---------*

    FN.AMEX.FILES = 'AMEX.FILES' ;  F.AMEX.FILES = '' ; CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)

	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
	
    Y.TXN.FINAL.FILE = BATCH.DETAILS<3,1>
	Y.FINAL.FILE.NAME = FIELD(Y.TXN.FINAL.FILE,'*', 2)
	
    Y.LWD = '' ; Y.LWD = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.TXN.FINAL.FILE = EREPLACE(Y.FINAL.FILE.NAME,"<LWD>",Y.LWD,-1)
    
    YDL = ','

RETURN
*------*
PROCESS:
*------*
    
    SEL.CMD = '' ; SEL.LIST = '' ; SEL.CNT = '' ; SEL.POS = '' ; R.TXN.ARR = '' ; Y.FINAL.TXN.ARR = '' ; Y.SEL.FILE = ''
*
    Y.UDFILE  = 'AMEX.FILES'
   		
    BEGIN CASE
        CASE MTH.DAILY.FLAG EQ 'D'
            SEL.CMD = "CONFIRMORDERDLY-":TODAY:"-*.csv*"
        CASE MTH.DAILY.FLAG EQ 'M'
            SEL.CMD = "CONFIRMORDERMTH-":TODAY:"-*.csv*"
        CASE MTH.DAILY.FLAG EQ 'MTD'
            SEL.CMD = "CONFIRMORDERMTD-":TODAY:"-*.csv*"
    END CASE
	
    CALL SCB.UDLIST(Y.UDFILE, SEL.CMD, SEL.LIST, SEL.CNT)
*
    LOOP
        REMOVE Y.SEL.ID FROM SEL.LIST SETTING SEL.POS
    WHILE Y.SEL.ID : SEL.POS
        
        R.AMEX.FILE = '' ; AMEX.ERR = ''
        CALL F.READ(FN.AMEX.FILES,Y.SEL.ID,R.AMEX.FILE,F.AMEX.FILES,AMEX.ERR)
            
        IF NOT(R.TXN.ARR) THEN
            R.TXN.ARR = R.AMEX.FILE
        END ELSE
            R.TXN.ARR<-1> = R.AMEX.FILE
        END
        CALL F.DELETE(FN.AMEX.FILES,Y.SEL.ID)
            
    REPEAT

* Frame Header part
    Y.TXN.HDR = "Transaction Reference,ISOC Operator,Order Closing Id,Country Code,Sales Staff Name,"
    Y.TXN.HDR:= "Account Type,Account Number,Account Open Date,Lien Reason Code,Lien Reason Code Desc,"
    Y.TXN.HDR:= "Order No.,Order Date,Account Holder DOB,Transaction Type,Detail On Order Type,Order Type,"
    Y.TXN.HDR:= "Transaction Status,Product Provider Name,Asset Code,Asset Name,Asset Currency,"
    Y.TXN.HDR:= "Transaction Amount,Remarks,Account Holder 1,ID Number 1,EBBS Rel ID 1,Account Holder 2,ID Number 2," ;*CPSGMIG-14085
    Y.TXN.HDR:= "EBBS Rel ID 2,Account Holder 3,ID Number 3,EBBS Rel ID 3,Account Holder 4,ID Number 4,EBBS Rel ID 4,RSP Plan ID,ISIN,PRR [Risk]," ;*CPSGMIG-14085
    Y.TXN.HDR:= "Channel info,ClientIdentifier,PrimaryAcctHolder,Account Holder DOB 2,Account Holder DOB 3,Account Holder DOB 4,"
    Y.TXN.HDR:= "Transaction Date,Referral ID,Transaction CCY,Rel 1,Rel 2,Rel 3,Rel 4"

    IF MTH.DAILY.FLAG EQ "MTD" THEN
        Y.TXN.HDR:=",Charge Amount"
    END

    Y.FINAL.TXN.ARR     = Y.TXN.HDR
    Y.FINAL.TXN.ARR<-1> = R.TXN.ARR
        
    WRITE Y.FINAL.TXN.ARR TO F.AMEX.FILES,Y.TXN.FINAL.FILE
	
RETURN
END
