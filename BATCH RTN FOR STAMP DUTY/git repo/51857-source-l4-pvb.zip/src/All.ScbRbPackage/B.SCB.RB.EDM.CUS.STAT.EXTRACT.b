$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-54</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.CUS.STAT.EXTRACT
*******************************************************************************
* 21 Apr 2016 - New CAP Functionality - Subramanian M.
*             - This routine will generate the Customer Status Dump in AMEX.FILES.
*******************************************************************************
*******************************************************************************
*Modification History:
************************
* 27-May-2022 - CPSGMIG-3321 - Lavanya L - Copy of the existing routine B.SCB.EDM.CUS.STAT.EXTRACT
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CUSTOMER.STATUS
    $INSERT I_F.DATES
*

    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*******************************************************************************
INIT:
****
    FN.CUSTOMER.STATUS = 'F.CUSTOMER.STATUS'
    F.CUSTOMER.STATUS = ''
    CALL OPF(FN.CUSTOMER.STATUS,F.CUSTOMER.STATUS)
*
*R20 UPG -S
    ARG1 = 'AMEX.FILES'
    ARG2= ''
    ARG3 =''
    CALL SCB.GET.ORACLE.FILENAME(ARG1, ARG2, ARG3)
    FN.AMEX.FILES = ARG3
*R20 UPG -E
*
   Y.HEADER = ''							;*CPSGMIG-3321-S/E
    Y.FINAL.FILE.NAME = '' ; Y.COMP.NAME = ''
    R.CUS.STAT.RPT.ARR = ''
    DL = CHAR(01)
**Headers**
	Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
	Y.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
   Y.HEADER<-1> = 'D':DL:'ID':DL:'CUSTOMER_STATUS':DL:'DESCRIPTION':DL:'SHORT_NAME'	;*CPSGMIG-3321 - S/E
**Headers**
*
    Y.COMP.NAME = ID.COMPANY[1,2]
    IF Y.COMP.NAME EQ 'GB' THEN
        Y.COMP.NAME = 'UK'
    END
    Y.FINAL.FILE.NAME = Y.COMP.NAME:"-RB-CUS.STATUS-":TODAY:".CSV"			;*CPSGMIG-3321-S/E
RETURN
*******************************************************************************
PROCESS:
********
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.CUSTOMER.STATUS
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    Y.COUNT = 0
    IF SEL.LIST THEN
        LOOP
            REMOVE CUS.STAT.ID FROM SEL.LIST SETTING SEL.POS
        WHILE CUS.STAT.ID:SEL.POS
            R.CUS.STATUS = '' ; CUS.STAT.ERR = ''
            CALL F.READ(FN.CUSTOMER.STATUS,CUS.STAT.ID,R.CUS.STATUS,F.CUSTOMER.STATUS,CUS.STAT.ERR)
            IF R.CUS.STATUS THEN
                GOSUB ADD.ARRAY
            END
        Y.COUNT++
        REPEAT
    END
    Y.FINAL.ARR = ''
*CPSGMIG-3321-S
   Y.FINAL.ARR = Y.HEADER:FM:R.CUS.STAT.RPT.ARR
   Y.FINAL.ARR<-1> ='T':DL:Y.COUNT
*    Y.FINAL.ARR = R.CUS.STAT.RPT.ARR
*CPSGMIG-3321-E
    GOSUB WRITE.AMEX.FILE
*
RETURN
*******************************************************************************
ADD.ARRAY:
*********
	Y.DESC = R.CUS.STATUS<EB.CST.DESCRIPTION>
    CONVERT ',' TO '|' IN Y.DESC
    IF R.CUS.STAT.RPT.ARR EQ '' THEN
        R.CUS.STAT.RPT.ARR = 'D':DL:CUS.STAT.ID:DL:CUS.STAT.ID:DL:Y.DESC:DL:R.CUS.STATUS<EB.CST.SHORT.NAME>
    END ELSE
        R.CUS.STAT.RPT.ARR<-1> = 'D':DL:CUS.STAT.ID:DL:CUS.STAT.ID:DL:Y.DESC:DL:R.CUS.STATUS<EB.CST.SHORT.NAME>
    END
RETURN
*******************************************************************************
WRITE.AMEX.FILE:
****************
	Y.FINAL.ARR = UTF8(Y.FINAL.ARR)
    CALL F.WRITE(FN.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FINAL.ARR)
RETURN
*******************************************************************************
END
