* @ValidationCode : MjotMTIwMjUwNzU5OklTTy04ODU5LTE6MTcwNDkwMzI4MTg2MDo4MTg5OTg3Oi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 10 Jan 2024 21:44:41
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 8189987
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
		$PACKAGE All.ScbRbPackage
		SUBROUTINE B.SCB.RB.SP.EXTRACT(SP.ID)
		*-----------------------------------------------------------------------------
		* Project Name                   :       CPSGMIG-12700 - JEWEL_T24_PROJECT
		* Developed By                   :       Sathish
		* Developed On                   :       14 October 2022
		*-----------------------------------------------------------------------------
		* Description:
		*-------------
		* This is the multi-threaded routine which generates the spoke monthly
		* report to get the SECURITY.POSITION transaction data every month.
		*-----------------------------------------------------------------------------
		* Modification History :
		* 1663000     26-Oct-2022    CPSGMIG-14917   To update FileOpen command for Temp Sequential file.
		* 1404392     09-Nov-2022 - CPSGMIG-15298 - Vestima check changed to SCB.RB.VEST.FLAG api
		* 1404392     16-Nov-2022 - CPSGMIG-14651 - ADVICE.INDEX field addition & junk value removal in product provider, Name, Ebbs Rel column
		*                                           Product type will be updated for all columns
		* 1667095     03-Jan-2023    CPSGMIG-17593   Updating mapping for Divident Type CASH OR REINVEST
		* 1667095     23-Jan-2023    CPSGMIG-17723 - Update mapping for product provider name
		* 1663000     27-Feb-2023    CPSGMIG-19026 - Daily Spoke Monthly Report
		* 1663000     11-Apr-2023    CPSGMIG-22845 & 22846 - Include Position Migration flag column
		* 1648769     13-Apr-2023    CPSGMIG-22845 & 22846 - Map SAM>START.DATE in Account Open Date column.
		* 1648769     28-Apr-2023    CPSGMIG-14070   To includ customer type, Portfolio valuation and the RM details.
		* 1648769     10-May-2023    CPSGMIG-26790   Existing mapping changes in AUM column.
		* 1670271     06-Jun-2023    CPSGMIG-29138   If Settlement group doesn't fall under AEB.SEC.PAR>CPF-OACPF-15CPF-SASRS then update it as CASH for MF product type.
		* 1671073     05-Jun-2023    CPSGMIG-24900   Adding 2 new fields viz Average Unit Cost & Unrealized P/L
		* 1671073     12-Jun-2023    CPSGMIG-24900   Removing SC.POS.ASSET table read as per code review comment
		* 1671073     12-Jul-2023    CPSGMIG-31097   removed SC.VALUE1 and removed Y.UNREAL.PL from CASE and made as common, This issue is an observation in UAT             
		* 8189987     10-Jan-2024     ADO-2360270   - Inaccurate Infor reflected under Account Holders, instead of EBBS rel ID the PfolioKey field is mapped
		*-----------------------------------------------------------------------------------------
			$INSERT I_COMMON
			$INSERT I_EQUATE
			$INSERT I_F.CUSTOMER
			$INSERT I_F.SECURITY.MASTER
			$INSERT I_F.SEC.ACC.MASTER
			$INSERT I_F.SECURITY.POSITION
			$INSERT I_F.SUB.ASSET.TYPE
			$INSERT I_B.SCB.RB.SP.EXTRACT.COMMON
			$INSERT I_BATCH.FILES ;*CPSGMIG-14917
			$INSERT I_F.AEB.SEC.PAR ;*CPSGMIG-19026
		*CPSGMIG-14070-S
			$INSERT I_F.DEPT.ACCT.OFFICER
			$INSERT I_F.SCB.WM.H.SEGMENT
		*CPSGMIG-14070-E
			$INSERT I_F.PRICE.TYPE
            
		*-----------------------------------------------------------------------------
			GOSUB INITIALISE
			GOSUB CHECK.RET.CUS
		RETURN
		*-------------------------------------------------------------------------------
		INITIALISE:
		*----------
			SP.TXN.ARRAY= ''
			DELIMITER = ','
			CTRY = ''
			AC.HLDR1 = ''; AC.HLDR2 = ''
			AC.HLDR3 = ''; AC.HLDR4 = ''
			ID.NUM1 = ''; ID.NUM2 = ''
			ID.NUM3 = ''; ID.NUM4 = ''
			HOME.PH = '' ; WORK.PH = ''; DOB = ''
			ADDRESS1 = ''; ADDRESS2 = ''; ADDRESS3= ''; ADDRESS4 = ''
			DISTRICT = ''; STATE ='' ; COUNTRY = ''
			POSTAL.CD = ''; CNTRY.FULL.NAME = ''
			BRANCH = ''; BRANCH.DESC = ''
			ISLAMIC.FLAG = ''; CITY = ''
				 
		RETURN
		*-------------------------------------------------------------------------------
		CHECK.RET.CUS:
		*-------------
			R.CUS= ""; CUS.ERR= ""
			Y.CUS.ID = FIELD(SP.ID,'-',1)
			CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUS,F.CUSTOMER,CUS.ERR)
			Y.CUS.LOB =R.CUS<EB.CUS.LOCAL.REF,Y.L.O.B>
			Y.EBBS.REL =R.CUS<EB.CUS.LOCAL.REF,Y.LR.EBBS.REL>
			*CHANGE @SM TO ' ' IN Y.EBBS.REL
			Y.STAFF.IND=R.CUS<EB.CUS.LOCAL.REF,Y.LR.STAFF.IND>
			Y.PFOLIO.KEY=R.CUS<EB.CUS.LOCAL.REF,Y.LR.PFOLIO.KEY>
***
	Y.EBBS.PFOLIO.KEY = Y.PFOLIO.KEY
    CHANGE ':' TO ' ' IN Y.EBBS.PFOLIO.KEY
    
***
            
		*CPSGMIG-14070-S
			Y.CUST.TYPE = R.CUS<EB.CUS.LOCAL.REF,Y.LWM.PVB.IND.POS>
			R.CUS.TYPE = ''
			CUS.TYP.ERR = ''
			Y.CUS.DESC = ''
			CALL F.READ(FN.SCB.LWM.PVB,Y.CUST.TYPE,R.CUS.TYPE,F.SCB.LWM.PVB,CUS.TYP.ERR)
			Y.CUS.DESC = R.CUS.TYPE<SCBWM.SEG.DESCRIPTION>
			Y.DAO = R.CUS<EB.CUS.ACCOUNT.OFFICER>
			R.DAO = ''
			ERR.DAO = ''
			Y.RM.NAME = ''
			CALL F.READ(FN.DAO,Y.DAO,R.DAO,F.DAO,ERR.DAO)
			Y.RM.NAME = R.DAO<EB.DAO.NAME>
			CHANGE ',' TO '' IN Y.RM.NAME
		*CPSGMIG-14070-E
			BEGIN CASE
				CASE R.CUS<EB.CUS.SECTOR> EQ "21"
					Y.CLIENT.IDENTIFIER = "SG.RETAIL"
				CASE R.CUS<EB.CUS.SECTOR> EQ "51" AND Y.STAFF.IND EQ "Y"
					Y.CLIENT.IDENTIFIER = "SG.RETAIL"
				CASE R.CUS<EB.CUS.SECTOR> EQ "23"
					Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
			END CASE
			IF Y.CUS.LOB MATCHES Y.ALLOWED.LOB THEN
				GOSUB PROCESS
			END ELSE
				RETURN
			END
		RETURN
		*-------------------------------------------------------------------------------
		PROCESS:
		*-------
		*Extract SP details
			GOSUB MAPPING.DETAILS
		   
		* Appending the SP Data
			GOSUB BUILD.SP.DATA
		   
		* Write SP data in Temporary File delimited with Agent No.
			IF SP.TXN.ARRAY THEN
				OPENSEQ AMEX.FILES,Y.RPT.AGENT.FILE TO F.SP.RPT ELSE CREATE F.SP.RPT ELSE ;*CPSGMIG-14917 -s
					CALL OCOMO("Error opening ":Y.RPT.AGENT.FILE)
				END
			
				WRITESEQ SP.TXN.ARRAY APPEND TO F.SP.RPT ELSE
					CALL FATAL.ERROR('Unable to write ':F.SP.RPT)
				END
				CLOSESEQ F.SP.RPT
			END
			
		RETURN
		*---------------------------------------------------------------------------------
		MAPPING.DETAILS:
		*---------------
		   
			R.SP = ""; SP.ERR = ""
			R.SM = ""; SM.ERR = ""
			R.SAM = ""; SAM.ERR = ""
			R.SUB.ASSET.TYPE = "" ; AT.ERR = ""
		   
		* SP data Extraction-start
		*--------------------------------------------------------------
			CALL F.READ(FN.SP,SP.ID,R.SP,F.SP,SP.ERR)
			Y.SM.ID = R.SP<SC.SCP.SECURITY.NUMBER>
			Y.SEC.AC = R.SP<SC.SCP.SECURITY.ACCOUNT>
			Y.ASSET = Y.SM.ID
			Y.UNIT.BAL = R.SP<SC.SCP.CLOSING.BAL.NO.NOM>
			Y.DEPOSITORY = R.SP<SC.SCP.DEPOSITORY>
			Y.COST.INVST = R.SP<SC.SCP.COST.INVST.SEC.CCY>
			Y.NOMINAL = R.SP<SC.SCP.CLOSING.BAL.NO.NOM>
		

		* SP data Extraction-end
		*--------------------------------------------------------------
		   
		* SM data Extraction-start
		*--------------------------------------------------------------
			CALL F.READ(FN.SM,Y.SM.ID,R.SM,F.SM,SM.ERR)
			Y.RETAIL.DEPO = R.SM<SC.SCM.LOCAL.REF,Y.LR.RETAIL.DEPO>
			Y.SM.DESC = R.SM<SC.SCM.DESCRIPT>

			Y.PRICE.TYPE.ID = R.SM<SC.SCM.PRICE.TYPE> 
			R.PT='' ; ERR.PT='' ; Y.PERC.FACTOR=''
			CALL F.READ(FN.PT,Y.PRICE.TYPE.ID,R.PT,F.PT,ERR.PT)
			Y.PT.PERC = R.PT<SC.PRT.PERCENTAGE>
			
			IF (Y.PT.PERC EQ "Y") OR (Y.PT.PERC EQ "YES") THEN
			Y.PERC.FACTOR = "100"
			END ELSE
			Y.PERC.FACTOR = "1"
			END	
			Y.PT.MFACT = R.PT<SC.PRT.MULTIPLY.FACTOR>
			
		* Calculation
			IF (Y.NOMINAL GT "0") AND (Y.PT.MFACT NE "0") THEN
			Y.COST.PRICE = DROUND((Y.COST.INVST * Y.PERC.FACTOR) / (Y.NOMINAL * Y.PT.MFACT),2)
			END ELSE
			Y.COST.PRICE = "0"
			END

		*CPSGMIG-15298 Start
		*DEPO.VALUES = '6708':@VM:'6709'
		   
		*IF Y.RETAIL.DEPO MATCHES DEPO.VALUES THEN
		*VESTIMA.FLAG = "Y"
		*END ELSE
		*VESTIMA.FLAG = "N"
		*END
			VESTIMA.FLAG = ''
			CALL SCB.RB.VEST.FLAG(Y.DEPOSITORY,VESTIMA.FLAG)
			IF VESTIMA.FLAG EQ '' THEN
				VESTIMA.FLAG = 'N'
			END
		*CPSGMIG-15298 End
			Y.PRD.TYPE=''
			CALL SCB.WM.GET.PRODUCT.TYPE(Y.SM.ID,Y.PRODUCT.TYPE)   ;*To update product type
			Y.PRD.TYPE = Y.PRODUCT.TYPE

		*CPSGMIG-17723(S)
			Y.PRVDR.NAME = '' ; Y.TR.ISSUER = ''
			Y.TR.ISSUER = R.SM<SC.SCM.TR.ISSUER>
			IF Y.TR.ISSUER AND (Y.PRODUCT.TYPE EQ 'MF') THEN
				R.ISSUER.CUST = '' ; ISS.CUST.ERR = ''
				CALL F.READ(FN.CUSTOMER,Y.TR.ISSUER,R.ISSUER.CUST,F.CUSTOMER,ISS.CUST.ERR)
				Y.NAME.1 = '' ; Y.NAME.2 = ''; NAME.DL = ''
				IF R.ISSUER.CUST THEN
					Y.NAME.1 = R.ISSUER.CUST<EB.CUS.NAME.1>
					Y.NAME.2 = R.ISSUER.CUST<EB.CUS.NAME.2>
					NAME.DL = ' '
					Y.PRVDR.NAME = Y.NAME.1:NAME.DL:Y.NAME.2
					CONVERT @VM TO '' IN Y.PRVDR.NAME
				END
			END
		*CPSGMIG-17723(E)
		   
			Y.NAME = R.SM<SC.SCM.LOCAL.REF,Y.LR.UTS.INS.DESC>
			IF NOT(Y.NAME) THEN
				Y.NAME = Y.SM.DESC
				CHANGE @VM TO '' IN Y.NAME
				CHANGE @SM TO ' ' IN Y.NAME
			END ELSE
				CHANGE @SM TO '' IN Y.NAME
			END
		   
			Y.CCY = R.SM<SC.SCM.SECURITY.CURRENCY>
			Y.PRICE = R.SM<SC.SCM.LAST.PRICE>
			Y.PRICE.DATE = R.SM<SC.SCM.DATE.LAST.PRICE>
			Y.INST = R.SM<SC.SCM.LOCAL.REF,Y.CASH.OR.REINV>
			Y.ISIN.CD = R.SM<SC.SCM.I.S.I.N.>
			Y.SAT = R.SM<SC.SCM.SUB.ASSET.TYPE>
		*CPSGMIG-17593(S)
			Y.RET.DEPO.INV	= R.SM<SC.SCM.LOCAL.REF,LM.RET.DEPO.INV.POS>
			Y.FACTOR = R.SM<SC.SCM.FACTOR>   ; *CPSGMIG-26790-S/E
			BEGIN CASE
				CASE Y.INST EQ 'C'
					Y.INST = "CASH"
				CASE Y.INST EQ 'R'
					Y.INST = "REINVEST"
				CASE Y.INST EQ ''
					IF Y.RETAIL.DEPO AND (Y.DEPOSITORY EQ Y.RETAIL.DEPO) THEN
						Y.INST = "CASH"
					END ELSE
						IF Y.RET.DEPO.INV AND (Y.DEPOSITORY EQ Y.RET.DEPO.INV) THEN
							Y.INST = "REINVEST"
						END
					END
			END CASE
		*CPSGMIG-17593(E)
			CALL F.READ(FN.SUB.ASSET.TYPE,Y.SAT,R.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE,AT.ERR)
			IF R.SUB.ASSET.TYPE THEN
				Y.ASSET.TYPE = R.SUB.ASSET.TYPE<SC.CSG.ASSET.TYPE.CODE>
			END
			Y.SC.POS.ASSET.ID = Y.SEC.AC:".":Y.SAT:".":Y.ASSET.TYPE

		   
		*SC.POS.ASSET Extraction-start
		*----------------------------------
		*CPSGMIG-26790-S
			*Y.AMU.AMT= ''
			
		** Get the price accroding to method from SECURITY.MASTER
		** Also get the MARGIN.RATE, PERCENTAGE, MULT.FACTOR
		*
			CALC.METHOD = ""
			CALL DBR("PRICE.TYPE":FM:SC.PRT.CALCULATION.METHOD, Y.PRICE.TYPE.ID, CALC.METHOD)
			PERC.IND = ""
			CALL DBR("PRICE.TYPE":FM:SC.PRT.PERCENTAGE, Y.PRICE.TYPE.ID, PERC.IND)
			IF CALC.METHOD MATCHES "DISCOUNT":VM:"YIELD":VM:"TYIELD" THEN     ;* Percentage
				MARKET.PRICE = R.SM<SC.SCM.DISC.YLD.PERC>
			END ELSE
				MARKET.PRICE = R.SM<SC.SCM.LAST.PRICE>
			END
			**CALC.CONSID:
		*
			SC.VALUE = "" ; VALUE.DATE = TODAY
			CAP.RATE = "" ; CAP.AMT = ""
			SC.VALUE1 = ""
			CALL SC.CALC.CONSID(Y.SM.ID, Y.NOMINAL, MARKET.PRICE, VALUE.DATE, SC.VALUE,CAP.RATE,CAP.AMT,FACTOR)
			  
		    Y.BOND.OR.SHARE = R.SM<SC.SCM.BOND.OR.SHARE>
		    Y.UNREAL.PL = DROUND((SC.VALUE - Y.COST.INVST),2)
			BEGIN CASE
				CASE Y.BOND.OR.SHARE EQ "B"
					IF Y.FACTOR GT '0' THEN
						Y.AMU.AMT = ((Y.UNIT.BAL * Y.PRICE * Y.FACTOR) / 100)
					END ELSE
						Y.AMU.AMT = ((Y.UNIT.BAL * Y.PRICE) / 100)
					END
					
				CASE Y.BOND.OR.SHARE EQ "S"
					Y.AMU.AMT = (Y.UNIT.BAL * Y.PRICE)
					
			END CASE
		*SC.POS.ASSET Extraction-end
		*----------------------------------
			
		* SM data Extraction-end
		*--------------------------------------------------------------

		* SAM data Extraction-start
		*--------------------------------------------------------------
			CALL F.READ(FN.SAM,Y.SEC.AC,R.SAM,F.SAM,SAM.ERR)
			AC.OPEN.DATE= R.SAM<SC.SAM.START.DATE>                       ;*CPSGMIG-22845 & 22846 -S/E
			Y.ADVICE.INDEX = R.SAM<SC.SAM.ADVICE.INDEX>
			
			Y.POSMIG.DATE  = R.SAM<SC.SAM.LOCAL.REF,Y.SAM.POSMIG.POS>    ;*CPSGMIG-22845 & 22846 -S
			IF Y.POSMIG.DATE THEN
				Y.POSMIG.FLAG = 'Y'
			END ELSE
				Y.POSMIG.FLAG = 'N'
			END                                                                     ;*CPSGMIG-22845 & 22846 -E
		* SAM data Extraction-end
		*--------------------------------------------------------------
			GOSUB GET.SETTLEMENT.GRP ;*CPSGMIG-19026
			
		RETURN
		*--------------------------------------------------------------------------------
		GET.SETTLEMENT.GRP:
		*-----------------*

			Y.SETT.GROUP = '' ; Y.GRP.VALUE = ''       ;*CPSGMIG-19026   -s
			IF (Y.PRODUCT.TYPE EQ 'MF') AND (MTH.DAILY.FLAG EQ 'D') AND (Y.DEPOSITORY NE "") THEN
				GRP.CMD = 'SELECT ':FN.AEB.SEC.PAR:' WITH @ID LIKE "':ID.COMPANY[1,2]:'...2.MF..." AND DEPOSITORY EQ "':Y.DEPOSITORY:'"'
				CALL EB.READLIST(GRP.CMD,GRP.LIST,'',GRP.CNT,GRP.ERR)

			IF GRP.LIST EQ '' OR ((Y.DEPOSITORY EQ Y.RETAIL.DEPO) OR (Y.DEPOSITORY EQ Y.RET.DEPO.INV))THEN ;* CPSGMIG-29138
                Y.SETT.GROUP = 'CASH'
            END ELSE
                Y.GRP.VALUE = FIELD(GRP.LIST,'.',4)
					IF Y.GRP.VALUE EQ "ALL" THEN
						Y.SETT.GROUP = 'CASH'
					END ELSE
						Y.SETT.GROUP = Y.GRP.VALUE
					END
			END
			END

		RETURN                       ;*CPSGMIG-19026   -e

		BUILD.SP.DATA:
		*-------------
			
			IF MTH.DAILY.FLAG EQ 'M' THEN                       ;* CPSGMIG-19026
				SP.TXN.ARRAY = VESTIMA.FLAG:DELIMITER:CTRY:DELIMITER:Y.SEC.AC:DELIMITER:AC.HLDR1:DELIMITER:AC.HLDR2:DELIMITER:
				SP.TXN.ARRAY := AC.HLDR3:DELIMITER:AC.HLDR4:DELIMITER:ID.NUM1:DELIMITER:ID.NUM2:DELIMITER:ID.NUM3:DELIMITER:
				SP.TXN.ARRAY := ID.NUM4:DELIMITER:HOME.PH:DELIMITER:WORK.PH:DELIMITER:DOB:DELIMITER:AC.OPEN.DATE:DELIMITER:
				SP.TXN.ARRAY := DQUOTE(Y.PRVDR.NAME):DELIMITER:Y.ASSET:DELIMITER:DQUOTE(Y.NAME):DELIMITER:Y.CCY:DELIMITER:
				SP.TXN.ARRAY := Y.PRICE:DELIMITER:Y.PRICE.DATE:DELIMITER:Y.UNIT.BAL:DELIMITER:Y.AMU.AMT:DELIMITER:
				SP.TXN.ARRAY := ADDRESS1:DELIMITER:ADDRESS2:DELIMITER:ADDRESS3:DELIMITER:ADDRESS4:DELIMITER:
				SP.TXN.ARRAY := DISTRICT:DELIMITER:STATE:DELIMITER:COUNTRY:DELIMITER:POSTAL.CD:DELIMITER:
				SP.TXN.ARRAY := CNTRY.FULL.NAME:DELIMITER:BRANCH:DELIMITER:BRANCH.DESC:DELIMITER:Y.PRD.TYPE :DELIMITER:
				SP.TXN.ARRAY := Y.INST:DELIMITER:Y.ISIN.CD:DELIMITER:ISLAMIC.FLAG:DELIMITER:CITY:DELIMITER:Y.EBBS.PFOLIO.KEY:DELIMITER:
				SP.TXN.ARRAY := Y.CLIENT.IDENTIFIER:DELIMITER:DQUOTE(Y.PFOLIO.KEY):DELIMITER:Y.ADVICE.INDEX
				SP.TXN.ARRAY := DELIMITER:Y.POSMIG.FLAG:DELIMITER:Y.CUS.DESC:DELIMITER:Y.RM.NAME            ;*CPSGMIG-22845 & 22846 -S/E  *CPSGMIG-14070-S/E
				SP.TXN.ARRAY := DELIMITER:Y.COST.PRICE:DELIMITER:Y.UNREAL.PL   
			END ELSE                                             ;* CPSGMIG-19026 -S
				SP.TXN.ARRAY = VESTIMA.FLAG:DELIMITER:CTRY:DELIMITER:Y.SEC.AC:DELIMITER:AC.HLDR1:DELIMITER:AC.HLDR2:DELIMITER:
				SP.TXN.ARRAY := AC.HLDR3:DELIMITER:AC.HLDR4:DELIMITER:ID.NUM1:DELIMITER:ID.NUM2:DELIMITER:ID.NUM3:DELIMITER:
				SP.TXN.ARRAY := ID.NUM4:DELIMITER:HOME.PH:DELIMITER:WORK.PH:DELIMITER:DOB:DELIMITER:AC.OPEN.DATE:DELIMITER:
				SP.TXN.ARRAY := DQUOTE(Y.PRVDR.NAME):DELIMITER:Y.ASSET:DELIMITER:DQUOTE(Y.NAME):DELIMITER:Y.CCY:DELIMITER:
				SP.TXN.ARRAY := Y.PRICE:DELIMITER:Y.PRICE.DATE:DELIMITER:Y.UNIT.BAL:DELIMITER:Y.AMU.AMT:DELIMITER:
				SP.TXN.ARRAY := ADDRESS1:DELIMITER:ADDRESS2:DELIMITER:ADDRESS3:DELIMITER:ADDRESS4:DELIMITER:
				SP.TXN.ARRAY := DISTRICT:DELIMITER:STATE:DELIMITER:COUNTRY:DELIMITER:POSTAL.CD:DELIMITER:
				SP.TXN.ARRAY := CNTRY.FULL.NAME:DELIMITER:BRANCH:DELIMITER:BRANCH.DESC:DELIMITER:Y.PRD.TYPE :DELIMITER:
				SP.TXN.ARRAY := Y.INST:DELIMITER:Y.ISIN.CD:DELIMITER:ISLAMIC.FLAG:DELIMITER:CITY:DELIMITER:Y.EBBS.PFOLIO.KEY:DELIMITER:
				SP.TXN.ARRAY := Y.CLIENT.IDENTIFIER:DELIMITER:DQUOTE(Y.PFOLIO.KEY):DELIMITER:Y.ADVICE.INDEX:DELIMITER:Y.SETT.GROUP     ;* CPSGMIG-19026 -E
				SP.TXN.ARRAY := DELIMITER:Y.POSMIG.FLAG:DELIMITER:Y.CUS.DESC:DELIMITER:Y.RM.NAME             ;*CPSGMIG-22845 & 22846 -S/E  *CPSGMIG-14070-S/E
			END
			
			
		RETURN
		END