$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-176</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.CCMS.RESP.EXTRACT.POST
*-----------------------------------------------------------------------------
* Description:
*-------------------------------------------------------------------------------------------------------------
* Month end job to send the response file to CCMS.
*
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- CCMS - Month end job to send the response file to CCMS.
* 10-Apr-2023 - CPSGMIG-312 - kalaikumaranp - CCMS - Response File name changed.
*-------------------------------------------------------------------------------------------------------------
    	$INSERT I_COMMON
    	$INSERT I_EQUATE
        $INSERT I_F.DATES
        
    FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
    L.WORK.DATE=TODAY
    
    Y.FINAL.ID = 'PCCS.IE52010.T24RE.FILE'
    Y.BKP.FINAL.ID = 'PCCS.IE52010.T24RE.FILE.':TODAY:'.PROCESSED.txt'
	    
Y.UDFILE       = 'AMEX.FILES'
Y.ST.CRITERIA  = ID.COMPANY[1,2]:'-SCCT.SP.IE52010.T24RE.FILE.':TODAY:'-*'
Y.FILE.ARRAY = ''
Y.FILE.ARRAY = 'H':L.WORK.DATE:'T24'

    SEL.FILE.ID    = ''
    Y.ST.CNT       = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.ST.CRITERIA, SEL.FILE.ID, Y.ST.CNT)

    Y.DEL.FILE.ID = SEL.FILE.ID
    LOOP
        REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
    WHILE Y.FILE.ID:POS
        CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.CCMS.REC,F.APPEND.FILES,APP.ERR)
        IF R.CCMS.REC NE  '' THEN
            Y.FILE.ARRAY<-1> = R.CCMS.REC
            LINE.COUNT = DCOUNT(R.CCMS.REC, @FM)
            TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
        END
        CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
        LINE.COUNT = ''
    REPEAT
Y.FILE.ARRAY<-1> = 'T':FMT(TOTAL.LINE.COUNT,"7'0'R")

WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.ID

WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.BKP.FINAL.ID

RETURN
END


