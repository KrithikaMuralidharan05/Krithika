
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PEN.TRANS.CLEANUP(PendingId)

*-------------------------------------------------------------------------------------------
* Developed By                   :   Mohammed Haris
* Developed On                   :   07-MAR-2024
* ADO Reference	                 :   7428259,7428290
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Main routine to remove to false portfolio and update the rejected transaction.
*--------------------------------------------------------------------------------------------
* Called From:  TSA.SERVICE>SNG/B.SCB.RB.PEN.TRANS.CLEANUP.ONETIME
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*--------------------------------------------------------------------------------------------
*

*****************************Insert Files******************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SCB.RB.PENDING.TRANSACTION
    $INSERT I_F.SCB.RB.PENDING.TRANSACTION.ARC
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SC.EXE.SEC.ORDERS
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.COMPANY
    $INSERT I_B.SCB.RB.PEN.TRANS.CLEANUP.COMMON

***********************************************************************

    GOSUB CHECK.FOR.EXIST.ORDER
RETURN

************************************************************************
*This GOSUB will check if the pending transaction is available in the SOO/SESO
CHECK.FOR.EXIST.ORDER:


    CALL F.READ(FnPendingTransaction,PendingId,RPendingTransaction,FPendingTransaction,PendingTransactionErr)

    IF PendingTransactionErr THEN
        CALL OCOMO("Records ":PendingId:" Not able to read from Pending Transaction Table")
        RETURN
    END
    ELSE
        OrderIds=RPendingTransaction<SCB.PEND.TRANS.ORDER.ID>
    END

    IF NOT(OrderIds) THEN
        CALL OCOMO("Order Ids not found in the Pending Transaction Table for id ":PendingId)
        RETURN
    END


    OrderIdCount=DCOUNT(OrderIds,@VM)
	WriteFlag=0

    FOR CntOne=1 TO OrderIdCount
    OpenId=OrderIds<1,CntOne>
	SesoFlag=0
    SooFlag=0
	FalseFlag=0
    IF NOT(OpenId) THEN CONTINUE
        GOSUB GETFLAG
        IF NOT(SesoFlag) AND NOT(SooFlag) THEN
            CALL OCOMO("Open Id ":OpenId:" does not exist in either SOO/SESO so we delete that multi value set For Pending ID ":PendingId)
            GOSUB DEL.ORDER.SET
            CONTINUE
        END
        GOSUB FALSE.PORTFOLIO.CHECK
        IF FalseFlag THEN CONTINUE
        GOSUB REJECTED.PORTFOLIO.CHECKSUM
    NEXT CntOne
    IF WriteFlag THEN 
	GOSUB UPD.DELETE.PEND.TRANS.REC
	END
	ELSE
	CALL OCOMO("Pending Portfolio ":PendingId:" does not require correction")
	END
RETURN
************************************************************************
*Return flag based on existance of record in SOO/SESO
GETFLAG:
**********************************************************************
	OrderSecurityNumber=''
	OrderStatus=''
    CALL F.READ(FnScExeSecOrders,OpenId,RScExeSecOrders,FScExeSecOrders,ScExeSecOrdersErr)
    IF NOT(RScExeSecOrders) THEN
        HisOpenId=OpenId
        CALL EB.READ.HISTORY.REC(FScExeSecOrdersHis,HisOpenId,RScExeSecOrdersHis,ScExeSecOrdersHisErr)
        IF RScExeSecOrdersHis THEN
            OrderSecurityNumber=RScExeSecOrdersHis<SC.ESO.SECURITY.ACCT>
            OrderStatus=RScExeSecOrdersHis<SC.ESO.ORDER.STATUS>
            SesoFlag=1
        END
    END
    ELSE
        OrderSecurityNumber=RScExeSecOrders<SC.ESO.SECURITY.ACCT>
        OrderStatus=RScExeSecOrders<SC.ESO.ORDER.STATUS>
        SesoFlag=1
    END
    IF SesoFlag THEN
	CHANGE "]" TO @VM IN OrderSecurityNumber
	RETURN
    END
	CALL F.READ(FnSecOpenOrder,OpenId,RSecOpenOrder,FSecOpenOrder,SecOpenOrderErr)
    IF NOT(RSecOpenOrder) THEN
        HisOpenId=OpenId
        CALL EB.READ.HISTORY.REC(FSecOpenOrderHis,HisOpenId,RSecOpenOrderHis,SecOpenOrderHisErr)
        IF RSecOpenOrderHis THEN
            OrderSecurityNumber=RSecOpenOrderHis<SC.SOO.SECURITY.ACCNT>
            OrderStatus=RSecOpenOrderHis<SC.SOO.DEAL.STATUS>
            SooFlag=1
        END
    END
    ELSE
        OrderSecurityNumber=RSecOpenOrder<SC.SOO.SECURITY.ACCNT>
        OrderStatus=RSecOpenOrder<SC.SOO.DEAL.STATUS>
        SooFlag=1
    END
	CHANGE "]" TO @VM IN OrderSecurityNumber
RETURN
****************************************************************************************
*This will find the OpenId and delete that multi value set.
DEL.ORDER.SET:
****************************************************************************************
	FmPos='';VmPos='';SmPos=''
    FINDSTR OpenId IN RPendingTransaction<SCB.PEND.TRANS.ORDER.ID> SETTING FmPos,VmPos,SmPos THEN
        DEL RPendingTransaction<SCB.PEND.TRANS.ORDER.ID,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.SECURITY.CODE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.PAYMENT.TYPE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.BUY.SELL,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.NOMINEE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.SAT.CODE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.ORDER.DATE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.VALUE.DATE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.DEPOSITORY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.ORDER.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.ORDER.NOMINALS,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.NET.AMT.TRADE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.GROSS.AMT.TRADE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.NET.AMT.BASE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.GROSS.AMT.BASE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.PRICE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.DEAL.STATUS,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.ORDER.STATUS,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TRADE.ID,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.SECURITY.CODE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.PAYMENT.TYPE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.BUY.SELL,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.NOMINEE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.SAT.CODE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TRADE.DATE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.VALUE.DATE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.DEPOSITORY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.ORDER.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.ORDER.NOMINALS,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.NET.AMT.TRADE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.GROSS.AMT.TRADE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.NET.AMT.BASE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.GROSS.AMT.BASE.CCY,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.PRICE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TRADE.STATUS,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.TXN.CODE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.COM.REF,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.OR.TRADE.VAL.DATE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.TXN.CODE,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.COM.REF,VmPos>
        DEL RPendingTransaction<SCB.PEND.TRANS.TR.TRADE.VAL.DATE,VmPos>
		WriteFlag=1
    END
RETURN
****************************************************************************************
*This is to Check of the potfolio number matches the security account number
FALSE.PORTFOLIO.CHECK:
****************************************************************************************
*    IF OrderSecurityNumber NE PendingId THEN
    IF PendingId MATCHES OrderSecurityNumber ELSE
        CALL OCOMO("Portfolio Mismatch between SESO/SOO and Pending Tranasction table, SESO/SOO = ":OrderSecurityNumber:" Pending Id ":PendingId)
        CALL OCOMO("Removing the False Portfilio order ":OrderIds<1,CntOne>:" FROM Pending Id ":PendingId)
        GOSUB DEL.ORDER.SET
        FalseFlag=1
    END
RETURN
***************************************************************************************
*This is to check if the DEAL.STATUS/ORDER.STATUS IS REJECTED OR CANCELLED
REJECTED.PORTFOLIO.CHECKSUM:
***************************************************************************************
	FmPos='';VmPos='';SmPos=''
    FINDSTR OpenId IN RPendingTransaction<SCB.PEND.TRANS.ORDER.ID> SETTING FmPos,VmPos,SmPos THEN
    IF SesoFlag AND (OrderStatus EQ 'REJECTED' OR OrderStatus EQ 'CANCELLED') AND (RPendingTransaction<SCB.PEND.TRANS.ORDER.STATUS,VmPos> NE 'REJECTED' OR RPendingTransaction<SCB.PEND.TRANS.ORDER.STATUS,VmPos> NE 'CANCELLED') THEN  
            RPendingTransaction<SCB.PEND.TRANS.ORDER.STATUS,VmPos> = OrderStatus
			WriteFlag=1
            CALL OCOMO("OrderId ":OpenId:" will be updated as ":OrderStatus:" as SESO ":OpenId:" is ":OrderStatus)
        END
    
    IF SooFlag AND (OrderStatus EQ 'REJECTED' OR OrderStatus EQ 'CANCELLED') AND (RPendingTransaction<SCB.PEND.TRANS.DEAL.STATUS,VmPos> NE 'REJECTED' OR RPendingTransaction<SCB.PEND.TRANS.DEAL.STATUS,VmPos> NE 'CANCELLED') THEN       
            RPendingTransaction<SCB.PEND.TRANS.DEAL.STATUS,VmPos> = OrderStatus
            WriteFlag=1
            CALL OCOMO("OrderId ":OpenId:" will be updated as ":OrderStatus:" as SOO ":OpenId:" is ":OrderStatus)
        END
    END

RETURN
***************************************************************************************
*This will either update the Pending Transaction record or Delete the record
UPD.DELETE.PEND.TRANS.REC:
***************************************************************************************

    IF RPendingTransaction<SCB.PEND.TRANS.ORDER.ID,1> NE '' OR RPendingTransaction<SCB.PEND.TRANS.TRADE.ID,1> NE '' THEN
        CALL OCOMO("Updating the Pending Record ":PendingId)
        CALL F.WRITE(FnPendingTransaction,PendingId,RPendingTransaction)
    END
    ELSE
        CALL OCOMO("Deleting the Pending Record ":PendingId)
        CALL F.DELETE(FnPendingTransaction,PendingId)
    END

RETURN
END