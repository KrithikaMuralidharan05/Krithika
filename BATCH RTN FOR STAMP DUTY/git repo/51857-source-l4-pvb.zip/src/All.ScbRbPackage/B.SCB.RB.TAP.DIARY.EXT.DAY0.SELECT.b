$PACKAGE All.ScbRbPackage
*----------------------------------------------------------------------------------------------------------
* <Rating>-18</Rating>
*----------------------------------------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.TAP.DIARY.EXT.DAY0.SELECT
*----------------------------------------------------------------------------------------------------------
* Modification History:
*---------------------*
* 05-Aug-2022 - CPSGMIG-5347 - Shreekantha. G - Copy of the existing routine SCB.B.EDM.DIARY.EXTRACT.SELECT
*----------------------------------------------------------------------------------------------------------
*
    $INSERT  I_COMMON
    $INSERT  I_EQUATE
    $INSERT  I_F.DIARY
    $INSERT  I_F.SECURITY.MASTER
    $INSERT  I_F.STOCK.EXCHANGE
    $INSERT  I_BATCH.FILES
    $INSERT  I_TSA.COMMON
    $INSERT  I_B.SCB.RB.TAP.DIARY.EXT.COMMON
*
    SEL.CMD = ''
	Y.PILOT.DATE = '20221205'
    SEL.CMD = "SSELECT ":FN.DIARY:" WITH VALUE.DATE GE ":Y.PILOT.DATE
*
    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
*
    IF SEL.LIST THEN
*        CALL SCB.SORT(SORT.CMD, Y.DIARY.ID.LIST, FINAL.LIST)
        CALL BATCH.BUILD.LIST('',SEL.LIST)
*
    END
*
    RETURN
*
*----------------------------------------------------------------------------------------------------------
END
*----------------------------------------------------------------------------------------------------------
