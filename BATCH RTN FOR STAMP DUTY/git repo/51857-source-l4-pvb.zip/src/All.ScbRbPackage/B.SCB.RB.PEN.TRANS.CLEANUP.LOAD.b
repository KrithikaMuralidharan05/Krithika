$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.PEN.TRANS.CLEANUP.LOAD

*-------------------------------------------------------------------------------------------
* Developed By                   :   Mohammed Haris
* Developed On                   :   07-MAR-2024
* ADO Reference	                 :   7428259,7428290
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Load routine to remove to false portfolio and update the rejected transaction.
*--------------------------------------------------------------------------------------------
* Called From:  TSA.SERVICE>SNG/B.SCB.RB.PEN.TRANS.CLEANUP.ONETIME 
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*--------------------------------------------------------------------------------------------
*

******INSERT FILES**************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SCB.RB.PENDING.TRANSACTION
    $INSERT I_F.SCB.RB.PENDING.TRANSACTION.ARC
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.SC.EXE.SEC.ORDERS
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.COMPANY
    $INSERT I_B.SCB.RB.PEN.TRANS.CLEANUP.COMMON
********************************
*******OPENING TABLES************

    FnPendingTransaction = 'F.SCB.RB.PENDING.TRANSACTION'
    FPendingTransaction = ''
    CALL OPF(FnPendingTransaction,FPendingTransaction)

    FnPendingTransactionArc = 'F.SCB.RB.PENDING.TRANSACTION.ARC'
    FPendingTransactionArc = ''
    CALL OPF(FnPendingTransactionArc,FPendingTransactionArc)

    FnSecOpenOrder = 'F.SEC.OPEN.ORDER'
    FSecOpenOrder = ''
    CALL OPF(FnSecOpenOrder,FSecOpenOrder)

    FnSecOpenOrderHis = 'F.SEC.OPEN.ORDER$HIS'
    FSecOpenOrderHis = ''
    CALL OPF(FnSecOpenOrderHis,FSecOpenOrderHis)

    FnSecTrade = 'F.SEC.TRADE'
    FSecTrade = ''
    CALL OPF(FnSecTrade,FSecTrade)

    FnSecTradeHis = 'F.SEC.TRADE$HIS'
    FSecTradeHis = ''
    CALL OPF(FnSecTradeHis,FSecTradeHis)

    FnScExeSecOrders= 'F.SC.EXE.SEC.ORDERS'
    FScExeSecOrders = ''
    CALL OPF(FnScExeSecOrders,FScExeSecOrders)

    FnScExeSecOrdersHis = 'F.SC.EXE.SEC.ORDERS$HIS'
    FScExeSecOrdersHis = ''
    CALL OPF(FnScExeSecOrdersHis,FScExeSecOrdersHis)

***********************************************************************************
RETURN
END