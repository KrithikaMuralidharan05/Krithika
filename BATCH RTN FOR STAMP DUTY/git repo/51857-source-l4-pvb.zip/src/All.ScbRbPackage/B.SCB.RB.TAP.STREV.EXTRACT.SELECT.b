$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.STREV.EXTRACT.SELECT
**--------------------------------------------------------------------------------------------------------------------
    ! CREATED DT  : 
    ! AUTHOR      : 
    ! CC NO       :
    ! DESCRIPTION : THIS IS A SELECT FILE WHICH  WILL SELECT ALL THE TRADE TRASACTION HAPPENED ON A DAY TO DAY BASIS
    !               SEND TO PBDW FOR MANTAS PROJECT.
**--------------------------------------------------------------------------------------------------------------------
*
* 16/08/2022 - Shreekantha. G - CPSGMIG-5346
*
*--------------------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.TAP.STREV.EXTRACT.COMMON
*
    IF ID.COMPANY EQ "SG1090400" THEN   
        SEL.CMD = "SSELECT ":FN.SEC.TRD.REV :" WITH @ID LIKE ":COUNTRY.NAME:"...*SCTRSC..."
    END ELSE        
        SEL.CMD = "SSELECT ":FN.SEC.TRD.REV :" WITH @ID LIKE ":ID.COMPANY:"...*SCTRSC..." 
    END
*
    CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
*
    Y.ARRAY.RET = ''
    CALL SCB.ST.REV.APPEND(Y.ARRAY.RET)
    IF Y.ARRAY.RET THEN
        IF SEC.ID THEN
            SEC.ID<-1> = Y.ARRAY.RET
        END ELSE
            SEC.ID     = Y.ARRAY.RET
        END
    END
*
    CALL BATCH.BUILD.LIST('ST.LIST',SEC.ID)
*
    RETURN
*
*--------------------------------------------------------------------------------------------------------------------
END
*--------------------------------------------------------------------------------------------------------------------
