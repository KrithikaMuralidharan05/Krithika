$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.PRICE.SPEED.EXT.LOAD
*-----------------------------------------------------------------------------
*Modification History:
*---------------------
* 27/04/2022 - Sasi V - New requirement for RBSG - Batch file from T24 -> eSpeed
*						RBSG_ESPEED_PRICE_YYYYMMDD.txt
* 29-May-2023 - 1657186	- CPSGMIG-24977 - TDS Field additions.
* 10-Jul-2023 - 1657186 - CPSGMIG-31089 - Hedge Fund Indicator mapping change.
* 19-Feb-2024 - Vidya A - ADO-7377127	- Updating PRICE value to improve security value that have a valid factor
* 12-Jan-2026 - 1526956 - ADO-11753802  - Inclusion of Tranche ID as part of Price feed to SPEED from T24 for RBSG
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.PRICE.SPEED.EXT.COMMON
    $INSERT I_F.PRICE.TYPE	;* ADO-7377127 {S/E}
	$INSERT I_F.SCB.WM.H.LOCAL.PARAM	;* ADO-11753802(S/E)
*
    GOSUB INIT
*
RETURN
*-----------------------------------------------------------------------------
INIT:
*----
    FN.SECURITY.MASTER = 'F.SECURITY.MASTER'
    F.SECURITY.MASTER = ''
    CALL OPF(FN.SECURITY.MASTER, F.SECURITY.MASTER)
*
    FN.CUSTOMER = 'F.CUSTOMER'
    F.CUSTOMER = ''
    CALL OPF(FN.CUSTOMER, F.CUSTOMER)
*
	Y.APP = 'SECURITY.MASTER':@FM:'CUSTOMER'
***ADO-11753802 -S
    *Y.FIELD = 'LR.UTS.INS.DESC':@VM:'COUNTRY.RISK':@VM:'LR.RETAIL.DEPO':@VM:'LM.RET.DEPO.INV':@VM:'CASH.OR.REINV':@VM:'TDS.GLOBAL.ID':@VM:'LR.PERMAL.IND':@FM:'LR.PP.CODE'
	Y.FIELD = 'LR.UTS.INS.DESC':@VM:'COUNTRY.RISK':@VM:'LR.RETAIL.DEPO':@VM:'LM.RET.DEPO.INV':@VM:'CASH.OR.REINV':@VM:'TDS.GLOBAL.ID':@VM:'LR.PERMAL.IND':@VM:'ORD.MGMT.REF.NO':@FM:'LR.PP.CODE'
***ADO-11753802 -E
    Y.FIELD.POS = ''
    CALL MULTI.GET.LOC.REF(Y.APP,Y.FIELD,Y.FIELD.POS)
    LR.UTS.INS.DESC.POS = Y.FIELD.POS<1,1>
    COUNTRY.RISK.POS = Y.FIELD.POS<1,2>
	LR.RETAIL.DEPO.POS = Y.FIELD.POS<1,3>
    LM.RET.DEPO.INV.POS = Y.FIELD.POS<1,4>
    LR.CASH.OR.REINV.POS = Y.FIELD.POS<1,5> ;* CPSGMIG-24977
    LR.TDS.GLOBAL.ID.POS = Y.FIELD.POS<1,6>
    Y.LR.PERMAL.IND.POS = Y.FIELD.POS<1,7>
	Y.LR.ORD.MGMT.REF.NO.POS = Y.FIELD.POS<1,8> ;*ADO-11753802(S/E)
	LR.PP.CODE.POS = Y.FIELD.POS<2,1>
    
* ADO-7377127 {S}
    FN.PRICE.TYPE = 'F.PRICE.TYPE'
	F.PRICE.TYPE = ''
	CALL OPF(FN.PRICE.TYPE,F.PRICE.TYPE)
* ADO-7377127 {E}
***ADO-11753802 -S
	FN.SCB.WM.H.LOCAL.PARAM   = 'F.SCB.WM.H.LOCAL.PARAM'  
	F.SCB.WM.H.LOCAL.PARAM 	= ''
	CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
*
	R.LOC.PARAM = '' ; LOC.PARAM.ERR = '' ; Y.FIELD.NAME = '' ; Y.FIELD.VALUE = ''
	Y.SAT.POS = '' ; Y.SAT.ARRAY = '' ; PARAM.ID = 'SCB.SAT.DEF'
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,PARAM.ID,R.LOC.PARAM,F.SCB.WM.H.LOCAL.PARAM,LOC.PARAM.ERR)
	IF R.LOC.PARAM THEN
		Y.FIELD.NAME = R.LOC.PARAM<SCBWM.PRM.FIELD.NAME>
		Y.FIELD.VALUE = R.LOC.PARAM<SCBWM.PRM.FIELD.VALUE>
		LOCATE 'SN.SAT.CODES' IN Y.FIELD.NAME<1,1> SETTING Y.SAT.POS THEN
			Y.SAT.ARRAY = Y.FIELD.VALUE<1,Y.SAT.POS>
			CHANGE @SM TO @VM IN Y.SAT.ARRAY
		END
	END
***ADO-11753802 -E
*
RETURN
*-----------------------------------------------------------------------------
END
