
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.TRADE.DOMICILE(YTRANSID)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14086 - JEWEL_T24_PROJECT
* Developed By                   :       1667095
* Developed On                   :       13 April 2023
*---------------------------------------------------------------------------------------------
* Description:
*-------------
* Multi thread routine to extract the trade domicile details
*---------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG/SCB.B.TRADE.DOMICILE
*---------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*28/04/2023		1667095			Update mapping for asset name and order type
*04/05/2023		1667095			CPSGMIG-26751 Updated mapping for rel id
*15/06/2023             1670271         UT Trade domicile report-additional fields
*23/06/2023             1648769                 CPSGMIG-29355 - Changes;
*                                                 1. If SP>NOMINEE.CODE is 1 then default ESPD esle check SAM>LR.LIEN.CODE is value exist update else Check the
*                                                 table SC.SCB.RB.BLOCK>selected portfolio record with SM and Depo combination.If record exist then pick the
*                                                 value from SC.SCB.RB.BLOCK>LR.LIEN.CODE else LR.LIEN.CODE and LIEN remarks values should be left Blank.
*                                                 2. Lien Remarks, replace ',' to '' to not exceed to next columns.
*13/07/2023             1670271                   Update LR.CLOSING.ID & LR.REFERRAL.ID from SOO instaed of SEC.TRADE.
*                                                  Based on transaction code Settlement order ID and Settlement account number should be taken.
*10-Aug-2023            1648769         CPSGMIG-32375 - Rel ID Delimiters needs to be fixed from '-' to ':' for Joint Accounts.
*29-Sep-2023   1670271          CPSGMIG-34479 - Reports - Mapping Change
*25-Oct-2023   1663000          1790769       - For MF Channel Info , Send TAP Ref if exists , else send OMF Ref
*16-Jul-2025   8212847          ADO-8729382   - Converting the Comma in the fieldsLr Referral Id, Lr Sourcing Id, Lr Closing Id of the file into null,so system should not move the data to next column.
*---------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_TSA.COMMON
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SC.TRANS.NAME
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SECURITY.TRANSFER
    $INSERT I_F.SC.SCB.LIEN.CODE
    $INSERT I_F.SEC.OPEN.ORDER
    $INSERT I_F.CUSTOMER
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SC.TRANS.TYPE
	$INSERT I_B.SCB.TRADE.DOMICILE.COMMON
    $INSERT I_F.SC.SCB.RB.BLOCK
    $INSERT I_F.SECURITY.POSITION

    GOSUB INIT
    GOSUB DO.PROCESS
    
RETURN
*---------------------------------------------------------------------------------------------
INIT:
*--------
    Y.CO.CODE 	= '' ;	Y.PAYMENT.TYPE 	= ''
    Y.ACCT.NUM 	= '' ;	Y.TRADE.DATE 	= ''
    Y.LEV.IND 	= '' ; 	Y.ORD.SETT.CCY 	= ''
    Y.ORDER.NO 	= '' ; 	Y.SETT.ACC.NUM 	= ''
    Y.ORD.DATE  = '' ;  Y.REFERRAL.ID 	= ''
    Y.ORD.TYPE 	= '' ; 	Y.LR.CLOSING.ID = ''
    Y.SM.ID 	= '' ;	Y.ACR.INT.AMT 	= ''
    Y.BR.PRICE 	= '' ; 	Y.VALUE.DATE 	= ''
    Y.TRANS.AMT = '' ;  Y.CUST.PRICE 	= ''
    Y.REMARKS 	= '' ;  Y.CUST.NONOM 	= ''
    Y.ORD.CCY 	= '' ;  Y.LR.NET.SAL.PERC =  ''
    Y.ARRAY 	= '';  Y.CONFIRMATION.DATE = ''
    Y.CLIENT.IDENTIFIER = ''   ; Y.RECORD.STATUS = ''
    Y.CUST.PFOLIO.KEY = ''     ; Y.LR.OMF.REF.NO = ''
    Y.LWM.EDP.REF.NUM  = ''    ; Y.TAP.REF.NO = ''
    Y.DEPO = ''                ; Y.TRANS.CODE = ''

	
*Initialise field to be fetched from ICM or EBBS
    Y.ID.REF = '' ; Y.ACC.HOLDER.NAME = ''
    Y.ACCT.HOLDER = '' ; Y.ACC.HOLD.DOB = ''
    Y.MOBILE.PH.NO = '' ; Y.ACCT.OPEN.BR.CD = ''
    
RETURN
*---------------------------------------------------------------------------------------------
DO.PROCESS:
*-----------------
  
    Y.TXN.ID = FIELD(YTRANSID,'*',2)
    
    
    BEGIN CASE
        CASE Y.TXN.ID[1,6] EQ 'SCTRSC'        ;* Process Sec Trade
            GOSUB SEC.TRADE.DET
                    
        CASE Y.TXN.ID[1,6] EQ 'SECTSC'        ;* Process Security Transfer
            GOSUB SECURITY.TRANSFER.DET
    END CASE
RETURN
*---------------------------------------------------------------------------------------------
SEC.TRADE.DET:
*--------------------
    R.SEC.TRADE = '' ;  Y.ST.ERR = ''
    CALL F.READ(FN.SEC.TRADE,Y.TXN.ID,R.SEC.TRADE,F.SEC.TRADE,Y.ST.ERR)
    IF R.SEC.TRADE EQ "" THEN
        Y.HISTRADE.ID = '' ; Y.HISTRADE.ID = Y.TXN.ID ; SECTRHIS.ERR = ''
        CALL EB.READ.HISTORY.REC(F.SEC.TRADE.HIS,Y.HISTRADE.ID,R.SEC.TRADE,SECTRHIS.ERR)
    END
*Fetch Customer Id to check for retail customer
    Y.CUS.ID      = R.SEC.TRADE<SC.SBS.CUSTOMER.NO>
    GOSUB GET.CUS.LOB
    IF Y.L.O.B MATCHES Y.ALLOWED.LOB THEN
        Y.CO.CODE  = R.SEC.TRADE<SC.SBS.CO.CODE>
        Y.SM.ID    = R.SEC.TRADE<SC.SBS.SECURITY.CODE>
        Y.ACCT.NUM = R.SEC.TRADE<SC.SBS.CUST.SEC.ACC>
        Y.TRANS.CODE = R.SEC.TRADE<SC.SBS.CUST.TRANS.CODE>
        Y.ORDER.NO = R.SEC.TRADE<SC.SBS.CU.ORDER.NOS>
        Y.ORD.CCY  = R.SEC.TRADE<SC.SBS.TRADE.CCY>
        Y.BR.PRICE = R.SEC.TRADE<SC.SBS.BR.PRICE>
        Y.REMARKS = R.SEC.TRADE<SC.SBS.CU.NARRATIVE>
        CONVERT @SM TO " " IN Y.REMARKS
        Y.ACCT.NO = R.SEC.TRADE<SC.SBS.CUST.SEC.ACC>
        Y.TRADE.DATE = R.SEC.TRADE<SC.SBS.TRADE.DATE>
		Y.CUST.NONOM = R.SEC.TRADE<SC.SBS.CUST.NO.NOM>
        Y.LR.NET.SAL.PERC = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.NET.SAL.PERC.POS>
        
        Y.LR.CLOSING.ID = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.CLOSING.ID.POS>
*8729382 - S
        Y.LR.CLOSING.ID = EREPLACE(Y.LR.CLOSING.ID, ",", "")
*8729382 - E
        Y.TRANS.AMT  = R.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>
        Y.LEV.IND 		= R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.LEVERAGE.IND.POS>
        Y.VALUE.DATE    = R.SEC.TRADE<SC.SBS.VALUE.DATE>
        Y.PAYMENT.TYPE = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.SCT.LR.PYMT.TYPE.POS>
        Y.CUST.PRICE 	= R.SEC.TRADE<SC.SBS.CUST.PRICE>
        Y.RECORD.STATUS    = R.SEC.TRADE<SC.SBS.RECORD.STATUS>
        Y.CONF.ASST.PRICE = Y.CUST.PRICE
        Y.CONFIRMATION.DATE    = R.SEC.TRADE<SC.SBS.DATE.TIME,1>[1,6]
        Y.LR.OMF.REF.NO    = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.OMF.REF.NO.POS>
        Y.LWM.EDP.REF.NUM  = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LWM.EDP.REF.NUM.POS>
        Y.TAP.REF.NO       = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.TAP.REF.NO.POS>
        Y.DEPO             = R.SEC.TRADE<SC.SBS.DEPOSITORY>

        GOSUB BUY.SELL
        IF Y.BUY.SELL EQ 'BUY' THEN
            Y.SETT.ACC.NUM = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.PAY.CASA.ACC.POS>
            Y.ORD.SETT.CCY = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.PAY.CASA.CCY.POS>
        END ELSE
            Y.SETT.ACC.NUM = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.REC.CASA.ACC.POS>
            Y.ORD.SETT.CCY = R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.LR.REC.CASA.CCY.POS>
        END
        
        Y.REFERRAL.ID 	= R.SEC.TRADE<SC.SBS.LOCAL.REF,Y.REFERAL.RM.POS>
*8729382 - S
        Y.REFERRAL.ID = EREPLACE(Y.REFERRAL.ID, ",", "")
*8729382 - E


* Fetch COMMISSION details
        Y.COMM.AMT.ARR = '' ; Y.COMM.AMT = ''
        Y.COMM.AMT.ARR = R.SEC.TRADE<SC.SBS.CU.CHARGE.TAX.AMT>
        Y.COMM.AMT     = FMT(SUM(Y.COMM.AMT.ARR),'R2')
        Y.SCB.CHARGE = Y.COMM.AMT

*Get Asset and customer details
        GOSUB GET.MAPPING.DTLS
       
        IF Y.FI.SAT.FLAG EQ 'Y' THEN
            Y.ACR.INT.AMT  = R.SEC.TRADE<SC.SBS.CUST.INTR.AMT>
            IF NOT(Y.ACR.INT.AMT) THEN
                Y.ACR.INT.AMT = '0'
            END
        END
    
*Fetch SOO details
        R.SEC.OPEN.ORDER = '' ; Y.SOO.ERR = '' ; Y.SOO.ID = Y.ORDER.NO
        CALL F.READ(FN.SEC.OPEN.ORDER,Y.SOO.ID,R.SEC.OPEN.ORDER,F.SEC.OPEN.ORDER,Y.SOO.ERR)
        IF NOT(R.SEC.OPEN.ORDER) THEN
            Y.SOO.HIS.ID = Y.SOO.ID
            CALL EB.READ.HISTORY.REC(F.SEC.OPEN.ORDER.HIS,Y.SOO.HIS.ID,R.SEC.OPEN.ORDER,Y.SOO.ERR)
        END
        IF R.SEC.OPEN.ORDER THEN
            Y.LR.RSP.REF 	= R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.LR.RSP.REF.POS>
            Y.LR.RM.DISC.PERC = '' ; Y.LR.RM.DISC.PERC = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.LR.RM.DISC.PERC.POS>
            IF Y.ACCT.TYPE EQ 'MF' THEN
                Y.ORD.DATE   = R.SEC.OPEN.ORDER<SC.SOO.ORDER.DATE>
                Y.LR.CLOSING.ID = '' ; Y.LR.CLOSING.ID = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.LR.CLOSING.ID.POS.SO>
                Y.REFERRAL.ID = '' ; Y.REFERRAL.ID = R.SEC.OPEN.ORDER<SC.SOO.LOCAL.REF,Y.REFERRAL.ID.POS>
            END
        END
* Fetch ORDER Transaction TYPE details
        Y.ORDTRANS.TYPE = ''
        BEGIN CASE
            CASE Y.LR.RSP.REF NE ''
                Y.ORDTRANS.TYPE = "Savings Plan"
            
            CASE Y.LR.RSP.REF EQ ''
                IF Y.TRANS.CODE THEN
                    GOSUB GET.SCTRANS.NAME
                END
        END CASE
        Y.ORD.TYPE = Y.ORDTRANS.TYPE
		
        GOSUB GET.TXN.STATUS
        GOSUB WRITE.TO.TEMP.FILE
    END
RETURN
*---------------------------------------------------------------------------------------------
SECURITY.TRANSFER.DET:
*---------------------------
    R.SECURITY.TRANSFER = '' ; SECURITY.TRANSFER.ERR = ''
    CALL F.READ(FN.SECURITY.TRANSFER,Y.TXN.ID,R.SECURITY.TRANSFER,F.SECURITY.TRANSFER,SECURITY.TRANSFER.ERR)
    IF R.SECURITY.TRANSFER EQ "" THEN
        Y.SECHIS.ID = '' ; SECHIS.ERR = '' ; Y.SECHIS.ID = Y.TXN.ID
        CALL EB.READ.HISTORY.REC(F.SECURITY.TRANSFER.HIS,Y.SECHIS.ID,R.SECURITY.TRANSFER,SECHIS.ERR)
    END
*Fetch Customer Id to check for retail customer
    Y.CUS.ID      = R.SECURITY.TRANSFER<SC.STR.CUSTOMER.NO>
    GOSUB GET.CUS.LOB

    IF (Y.L.O.B MATCHES Y.ALLOWED.LOB) THEN
        Y.CO.CODE		= R.SECURITY.TRANSFER<SC.STR.CO.CODE>
        Y.SM.ID			= R.SECURITY.TRANSFER<SC.STR.SECURITY.NO>
        Y.ACCT.NUM 		= R.SECURITY.TRANSFER<SC.STR.SECURITY.ACC>
        Y.TRADE.DATE  	= R.SECURITY.TRANSFER<SC.STR.TRADE.DATE>
        Y.TRANS.CODE 	= R.SECURITY.TRANSFER<SC.STR.TRANSACTION.TYPE>
        Y.TRANS.AMT     = R.SECURITY.TRANSFER<SC.STR.NET.AMT.SEC.CCY>
        Y.VALUE.DATE    = R.SECURITY.TRANSFER<SC.STR.VALUE.DATE>
        Y.CUST.PRICE 	= R.SECURITY.TRANSFER<SC.STR.PRICE>
        Y.ACCT.NO 		= R.SECURITY.TRANSFER<SC.STR.SECURITY.ACC>
        Y.COMM.AMT		= R.SECURITY.TRANSFER<SC.STR.CU.COMMISSION>
        IF NOT(Y.COMM.AMT) THEN
            Y.COMM.AMT = '0'
        END
        Y.CONF.ASST.PRICE = Y.CUST.PRICE
        Y.CUST.NONOM 	= R.SECURITY.TRANSFER<SC.STR.NO.NOMINAL>
        Y.REMARKS       = R.SECURITY.TRANSFER<SC.STR.CUST.REMARKS>
        CHANGE @SM TO ' ' IN Y.REMARKS
        Y.RECORD.STATUS	    = R.SECURITY.TRANSFER<SC.STR.RECORD.STATUS>
        Y.PAYMENT.TYPE = R.SECURITY.TRANSFER<SC.SBS.LOCAL.REF,Y.ST.LR.PYMT.TYPE.POS>
        Y.CONFIRMATION.DATE = R.SECURITY.TRANSFER<SC.STR.DATE.TIME,1>[1,6]
        Y.DEPO   = R.SECURITY.TRANSFER<SC.STR.DEPOSITORY>
        IF Y.TRANS.CODE THEN
            GOSUB GET.SCTRANS.NAME
        END
        Y.ORD.TYPE = Y.ORDTRANS.TYPE
        GOSUB GET.MAPPING.DTLS ;*Get Asset and customer details
        GOSUB GET.TXN.STATUS
        GOSUB WRITE.TO.TEMP.FILE
    END
RETURN

*---------------------------------------------------------------------------------------------
GET.CUS.LOB:
*----------*
    Y.LR.PFOLIO.POS1 = '' ;  Y.LR.PFOLIO.POS2 = ''
    R.CUSTOMER = ''  ;   Y.CUS.ERR = ''
    CALL F.READ(FN.CUSTOMER,Y.CUS.ID,R.CUSTOMER,F.CUSTOMER,Y.CUS.ERR)
    Y.L.O.B = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LOB.POS>
       
RETURN

*---------------------------------------------------------------------------------------------
GET.MAPPING.DTLS:
*-----------------*
*Get Asset Details
    Y.COMP.DOM = '' ; Y.ASSET.NAME = '' ; Y.ACCT.TYPE = ''
    Y.ORDER.CURRENCY = '' ; Y.ISIN = ''
    
    R.SECURITY.MASTER = '' ; SECURITY.MASTER.ERR = ''
    CALL F.READ(FN.SECURITY.MASTER,Y.SM.ID,R.SECURITY.MASTER,FP.SECURITY.MASTER,SECURITY.MASTER.ERR)
    Y.ORDER.CURRENCY = R.SECURITY.MASTER<SC.SCM.SECURITY.CURRENCY>
    Y.ISIN           = R.SECURITY.MASTER<SC.SCM.I.S.I.N.>
    Y.COMP.DOM = R.SECURITY.MASTER<SC.SCM.COMPANY.DOMICILE>
    Y.SUB.ASSET.TYPE = R.SECURITY.MASTER<SC.SCM.SUB.ASSET.TYPE>
    Y.LR.UTS.INS.DESC = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,Y.LR.UTS.INS.DESC.POS>
    Y.ASSET.NAME = Y.LR.UTS.INS.DESC
    CHANGE @VM TO "" IN Y.ASSET.NAME
    CHANGE @SM TO "" IN Y.ASSET.NAME
    IF Y.ASSET.NAME EQ '' THEN
        Y.ASSET.NAME = R.SECURITY.MASTER<SC.SCM.DESCRIPT>
        CHANGE @VM TO " " IN Y.ASSET.NAME
        CHANGE @SM TO " " IN Y.ASSET.NAME
    END

    GOSUB GET.SM.PRODUCT.TYPE
    IF (Y.ACCT.TYPE EQ 'MF') THEN
        Y.PYMT.TYPE = Y.PAYMENT.TYPE
        IF (Y.PYMT.TYPE EQ '') THEN
            Y.PYMT.TYPE = 'CASH'
        END
    END
*Get ProductProvider Name
    Y.PRODUCT.NAME = '' ; Y.TR.ISSUER = ''
    Y.TR.ISSUER = R.SECURITY.MASTER<SC.SCM.TR.ISSUER>
    IF Y.TR.ISSUER AND (Y.ACCT.TYPE EQ 'MF') THEN
        R.ISSUER.CUST = '' ; ISS.CUST.ERR = ''
        CALL F.READ(FN.CUSTOMER,Y.TR.ISSUER,R.ISSUER.CUST,F.CUSTOMER,ISS.CUST.ERR)
        Y.NAME.1 = '' ; Y.NAME.2 = '' ; NAME.DL = ''
        IF R.ISSUER.CUST THEN
            Y.NAME.1 = R.ISSUER.CUST<EB.CUS.NAME.1>
            Y.NAME.2 = R.ISSUER.CUST<EB.CUS.NAME.2>
            NAME.DL = ' '
            Y.PRODUCT.NAME = Y.NAME.1:NAME.DL:Y.NAME.2
            CONVERT @VM TO '' IN Y.PRODUCT.NAME
        END
    END
      
    R.SEC.ACC.MASTER = ''    ;  Y.SAM.ERR = '' ; Y.LR.LIEN.CODE = '' ; Y.ACC.OPEN.DATE = ''
    Y.CHANNEL.REF = ''
	
    CALL F.READ(FN.SEC.ACC.MASTER,Y.ACCT.NO,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,Y.SAM.ERR)
    Y.ACC.OPEN.DATE = R.SEC.ACC.MASTER<SC.SAM.START.DATE>
    GOSUB GET.LIEN.CODE.VAL
			
    BEGIN CASE
        CASE Y.LWM.EDP.REF.NUM NE ""
            Y.CHANNEL.REF = Y.LWM.EDP.REF.NUM
            
        CASE Y.LR.OMF.REF.NO NE ""
            Y.CHANNEL.REF = Y.LR.OMF.REF.NO
            
        CASE Y.TAP.REF.NO NE ""
            Y.CHANNEL.REF = Y.TAP.REF.NO
    END CASE
    
*Fetch Customer Details
    Y.LR.PP.CODE 	= '' ; Y.LR.PP.CODE 	= R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.PP.CODE.POS>
    Y.LR.EBBS.REL     	= '' ; Y.LR.EBBS.REL    = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.EBBS.REL.POS>
    Y.LR.PFOLIO.ARR 	= '' ; Y.LR.PFOLIO.ARR  = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
    Y.LR.STAFF.IND 	= '' ; Y.LR.STAFF.IND 	= R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.STAFF.IND.POS>
    BEGIN CASE
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ '21'
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ '51' AND Y.LR.STAFF.IND EQ "Y"
            Y.CLIENT.IDENTIFIER = "SG.RETAIL"
        CASE R.CUSTOMER<EB.CUS.SECTOR> EQ '23'
            Y.CLIENT.IDENTIFIER = "SG.RET.CB.BB"
    END CASE
    Y.CUST.PFOLIO.KEY = Y.LR.PFOLIO.ARR
    CHANGE ':' TO @FM IN Y.LR.PFOLIO.ARR
    Y.SIGN.MANDATE = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.SIGN.MANDATE.POS>
    CHANGE @VM TO @FM IN Y.SIGN.MANDATE
    CHANGE @SM TO @FM IN Y.SIGN.MANDATE
    CHANGE @VM TO @FM IN Y.LR.EBBS.REL
    CHANGE @SM TO @FM IN Y.LR.EBBS.REL
*Fetch EBBS rel Id based pn Pfolio Key field
    Y.LR.PFOLIO.POS1 = ''
    LOOP
        REMOVE Y.PFOLIO.ID FROM Y.LR.PFOLIO.ARR SETTING Y.LR.PFOLIO.POS1
    WHILE Y.PFOLIO.ID : Y.LR.PFOLIO.POS1
        IF PFOLIO.IDX LE 4 THEN
            Y.LR.PFOLIO.POS2 = ''
            LOCATE Y.PFOLIO.ID IN Y.LR.EBBS.REL SETTING Y.LR.PFOLIO.POS2 THEN
                PFOLIO.IDX += 1
                IF NOT(Y.REL.ID.ARR) THEN
                    Y.REL.ID.ARR = Y.SIGN.MANDATE<Y.LR.PFOLIO.POS2>
                END ELSE
                    Y.REL.ID.ARR := @FM: Y.SIGN.MANDATE<Y.LR.PFOLIO.POS2>
                END
            END
        END
    REPEAT
	
    IF Y.TXN.ID[1,6] EQ 'SCTRSC' THEN
        LOCATE Y.SUB.ASSET.TYPE IN Y.FI.SAT.CODES<1,1> SETTING FI.POS THEN ;* BONDS - FI
            Y.ORDER.NO = ''; Y.ORDER.NO = Y.LWM.EDP.REF.NUM
            Y.CHANNEL.REF = '' ; Y.CHANNEL.REF = Y.TAP.REF.NO
        END ELSE
            IF Y.ACCT.TYPE EQ 'MF' THEN
                Y.CHANNEL.REF = '' ; Y.CHANNEL.REF = Y.TAP.REF.NO
                IF Y.CHANNEL.REF EQ '' THEN
                    Y.CHANNEL.REF = Y.LR.OMF.REF.NO
                END
                
            END
        END
    END
      	
RETURN
*--------------------------------------------------------------------------------
BUY.SELL:
*------------
    R.SC.TRANS 		= '' ; ERR.SC.TRANS 	= '' ;    TXN.POS = ''
    R.SC.TRA.CODE 	= '' ; SC.TRA.CODE.ERR	= '' ; Y.BUY.SELL = ''
    CALL F.READ(FN.SC.TRA.CODE,Y.TRANS.CODE,R.SC.TRA.CODE,F.SC.TRA.CODE,SC.TRA.CODE.ERR)
    Y.TXN.CODE = R.SC.TRA.CODE<1>
    
    CALL F.READ(FN.SC.TRANS.TYPE,Y.TXN.CODE,R.SC.TRANS,F.SC.TRANS.TYPE,ERR.SC.TRANS)
    LOCATE Y.TRANS.CODE IN R.SC.TRANS<SC.TRN.SECURITY.CR.CODE> SETTING TXN.POS THEN
        Y.BUY.SELL = 'BUY'
    END
    ELSE
        Y.BUY.SELL = 'SELL'
    END
	
RETURN
*--------------------------------------------------------------------------------
GET.SCTRANS.NAME:
*---------------*
    R.SCTRANS.NAME = '' ; SCTRANS.NAME.ERR = '' ; Y.ORDTRANS.TYPE = ''
    CALL F.READ(FN.SC.TRANS.NAME,Y.TRANS.CODE,R.SCTRANS.NAME,F.SC.TRANS.NAME,SCTRANS.NAME.ERR)
    IF R.SCTRANS.NAME THEN
        Y.ORDTRANS.TYPE = R.SCTRANS.NAME<SC.TNM.SHORT.NAME,1>
    END
                
RETURN
*-----------------------------------------------------------------------------
GET.TXN.STATUS:
*--------------
    Y.TXN.STATUS = ''
    IF ( Y.RECORD.STATUS EQ "REVE" ) THEN
        Y.TXN.STATUS = "Reversed"
    END ELSE
        Y.SECMAST.VAL = Y.ACCT.TYPE

        IF Y.SECMAST.VAL NE "" THEN
            BEGIN CASE
                CASE Y.SECMAST.VAL EQ "MF"
                    Y.TXN.STATUS = "Settled"
                CASE 1
                    IF Y.VALUE.DATE GT Y.LAST.WORKING.DATE THEN
                        Y.TXN.STATUS = "Pending Settlement"
                    END ELSE
                        Y.TXN.STATUS = "Settled"
                    END
            END CASE
        END
    END

RETURN
*-----------------------------------------------------------------------------
GET.SM.PRODUCT.TYPE:
*----------------------
    Y.ACCOUNT.TYPE = ''
    LOCATE Y.SUB.ASSET.TYPE IN Y.MF.SAT.CODES<1,1> SETTING MF.POS THEN
        Y.ACCT.TYPE = 'MF'
    END ELSE
        LOCATE Y.SUB.ASSET.TYPE IN Y.SN.SAT.CODES<1,1> SETTING SN.POS THEN
            Y.CAPITAL.PROTECTION = ''
            Y.CAPITAL.PROTECTION = R.SECURITY.MASTER<SC.SCM.CAPITAL.PROTECTION>
            BEGIN CASE
                CASE Y.CAPITAL.PROTECTION = '99'
                    Y.ACCT.TYPE = 'Non Capital SN'
                CASE Y.CAPITAL.PROTECTION = '100'
                    Y.ACCT.TYPE = 'Capital SN'
				CASE 1
					Y.ACCT.TYPE = 'SN'
            END CASE
        END ELSE
            LOCATE Y.SUB.ASSET.TYPE IN Y.FI.SAT.CODES<1,1> SETTING FI.POS THEN
				R.SUB.ASSET.TYPE = '' ; SUB.ASSET.TYPE.ERR = ''
			    CALL F.READ(FN.SUB.ASSET.TYPE,Y.SUB.ASSET.TYPE,R.SUB.ASSET.TYPE,F.SUB.ASSET.TYPE,SUB.ASSET.TYPE.ERR)
                Y.ACCT.TYPE = R.SUB.ASSET.TYPE<SC.CSG.DESCRIPTION>
                Y.FI.SAT.FLAG = 'Y'
            END
        END
    END
RETURN
*------------------*
GET.LIEN.CODE.VAL:
*------------------*
* Get Security Position based on Portfolio
    SEL.CMD    = "SELECT RECID FROM ":Y.VIEW.NAME:" WHERE SECURITY_ACCOUNT = '":Y.ACCT.NO:"' AND SECURITY_NUMBER = '":Y.SM.ID:"'"
    SEL.CMD    := "AND DEPOSITORY = '":Y.DEPO:"' ORDER BY SECURITY_NUMBER"
    SEL.CMD    = TRIM(SEL.CMD)

    TRANSLATE.QUERY = '' ; RESULT.SET = "" ; ERR.CODE   = "" ; ERR.MSG    = "" ; UNIQUE.ID = OPERATOR:"-":TNO:"-LIENREP-":TIME()
    CALL SCB.CALL.ORACLE.SQL(TRANSLATE.QUERY, UNIQUE.ID, SEL.CMD, RESULT.SET, ERR.CODE, ERR.MSG)
    LOOP
        REMOVE Y.SP.ID FROM RESULT.SET SETTING SP.POS
    WHILE Y.SP.ID : SP.POS
        R.SECURITY.POSITION = '' ; SECURITY.POSITION.ERR = '' ; Y.NOM.CODE = ''
        CALL F.READ(FN.SECURITY.POSITION,Y.SP.ID,R.SECURITY.POSITION,F.SECURITY.POSITION,SECURITY.POSITION.ERR)
        Y.NOM.CODE     = R.SECURITY.POSITION<SC.SCP.NOMINEE.CODE>
        IF Y.NOM.CODE EQ '1' THEN
            Y.LR.LIEN.CODE = 'ESPD'
        END
        GOSUB GET.LIEN.CODE.VAL1
    REPEAT
    IF Y.LR.LIEN.CODE EQ '' THEN
        GOSUB GET.LIEN.CODE.VAL1
    END

RETURN
*------------------*
GET.LIEN.CODE.VAL1:
*------------------*

    IF Y.LR.LIEN.CODE EQ '' THEN
        Y.LR.LIEN.CODE = R.SEC.ACC.MASTER<SC.SAM.LOCAL.REF,Y.LR.LIEN.CODE.POS>
        IF Y.LR.LIEN.CODE EQ '' THEN
            R.SC.SCB.RB.BLOCK = ''   ; Y.SC.SCB.RB.BLOCK.ERR = ''
            CALL F.READ(FN.SC.SCB.RB.BLOCK,Y.SP.ID,R.SC.SCB.RB.BLOCK,FN.SC.SCB.RB.BLOCK,Y.SC.SCB.RB.BLOCK.ERR)
            Y.LR.LIEN.CODE = R.SC.SCB.RB.BLOCK<RB.BLK.LR.LIEN.CODE>
        END
    END

    IF Y.LR.LIEN.CODE THEN
        R.SC.SCB.LIEN.CODE = ''  ;  Y.SC.SCB.LIEN.CODE.ERR = ''
        CALL F.READ(FN.SC.SCB.LIEN.CODE,Y.LR.LIEN.CODE,R.SC.SCB.LIEN.CODE,F.SC.SCB.LIEN.CODE,Y.SC.SCB.LIEN.CODE.ERR)
        Y.LR.REMARKS = R.SC.SCB.LIEN.CODE<SC.SCBL.DESC>
        Y.LR.REMARKS  = EREPLACE(Y.LR.REMARKS, ",", " ")
    END

RETURN
*-----------------------------------------------------------------------------
WRITE.TO.TEMP.FILE:
*-----------------*
    Y.DELIM = ','
    Y.TRADE.DATE     	= OCONV(ICONV(Y.TRADE.DATE,'D4'),'D4')
    Y.VALUE.DATE      	= OCONV(ICONV(Y.VALUE.DATE,'D4'),'D4')
    Y.ORD.DATE      	= OCONV(ICONV(Y.ORD.DATE,'D4'),'D4')
    Y.CONFIRMATION.DATE = OCONV(ICONV(Y.CONFIRMATION.DATE,'D4'),'D4')
    
    Y.ARRAY  = Y.CO.CODE[1,2]
    Y.ARRAY := Y.DELIM:Y.ACCT.TYPE
    Y.ARRAY := Y.DELIM:Y.ACCT.NUM
    Y.ARRAY := Y.DELIM:Y.SETT.ACC.NUM
    Y.ARRAY := Y.DELIM:Y.ID.REF
    Y.ARRAY := Y.DELIM:Y.ACC.HOLDER.NAME
    Y.ARRAY := Y.DELIM:Y.ORDER.NO
    Y.ARRAY := Y.DELIM:Y.TXN.ID
    Y.ARRAY := Y.DELIM:Y.TRADE.DATE
    Y.ARRAY := Y.DELIM:Y.ORD.DATE
    Y.ARRAY := Y.DELIM:Y.CONFIRMATION.DATE
    Y.ARRAY := Y.DELIM:Y.ACC.HOLD.DOB
    Y.ARRAY := Y.DELIM:Y.ORDTRANS.TYPE
    Y.ARRAY := Y.DELIM:Y.ORD.TYPE
    Y.ARRAY := Y.DELIM:Y.TXN.STATUS
    Y.ARRAY := Y.DELIM:Y.LR.PP.CODE
    Y.ARRAY := Y.DELIM:DQUOTE(Y.PRODUCT.NAME)
    Y.ARRAY := Y.DELIM:Y.SM.ID
    Y.ARRAY := Y.DELIM:DQUOTE(Y.ASSET.NAME)
    Y.ARRAY := Y.DELIM:Y.ORDER.CURRENCY
    Y.ARRAY := Y.DELIM:Y.ORD.SETT.CCY
    Y.ARRAY := Y.DELIM:Y.ORD.CCY
    Y.ARRAY := Y.DELIM:Y.ISIN
    Y.ARRAY := Y.DELIM:Y.LEV.IND
    Y.ARRAY := Y.DELIM:Y.TRANS.AMT
    Y.ARRAY := Y.DELIM:DQUOTE(Y.REFERRAL.ID)
    Y.ARRAY := Y.DELIM:Y.LR.CLOSING.ID
    Y.ARRAY := Y.DELIM:Y.VALUE.DATE
    Y.ARRAY := Y.DELIM:Y.CUST.PRICE
    Y.ARRAY := Y.DELIM:Y.BR.PRICE
    Y.ARRAY := Y.DELIM:Y.COMM.AMT
    Y.ARRAY := Y.DELIM:Y.ACR.INT.AMT
    Y.ARRAY := Y.DELIM:Y.CUST.NONOM
    Y.ARRAY := Y.DELIM:Y.LR.RM.DISC.PERC
    Y.ARRAY := Y.DELIM:Y.SCB.CHARGE
    Y.ARRAY := Y.DELIM:Y.CONF.ASST.PRICE
    Y.ARRAY := Y.DELIM:Y.ACCT.OPEN.BR.CD
    Y.ARRAY := Y.DELIM:Y.LR.NET.SAL.PERC
    Y.ARRAY := Y.DELIM:DQUOTE(Y.REMARKS)
    Y.ARRAY := Y.DELIM:Y.PYMT.TYPE
    Y.ARRAY := Y.DELIM:Y.LR.LIEN.CODE
    Y.ARRAY := Y.DELIM:Y.LR.REMARKS
    Y.ARRAY := Y.DELIM:Y.COMP.DOM
    Y.ARRAY := Y.DELIM:Y.ACCT.HOLDER
    Y.ARRAY := Y.DELIM:Y.REL.ID.ARR<1>
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<1>
    Y.ARRAY := Y.DELIM:Y.MOBILE.PH.NO
    Y.ARRAY := Y.DELIM:Y.ACCT.HOLDER
    Y.ARRAY := Y.DELIM:Y.REL.ID.ARR<2>
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<2>
    Y.ARRAY := Y.DELIM:Y.MOBILE.PH.NO
    Y.ARRAY := Y.DELIM:Y.ACCT.HOLDER
    Y.ARRAY := Y.DELIM:Y.REL.ID.ARR<3>
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<3>
    Y.ARRAY := Y.DELIM:Y.MOBILE.PH.NO
    Y.ARRAY := Y.DELIM:Y.ACCT.HOLDER
    Y.ARRAY := Y.DELIM:Y.REL.ID.ARR<4>
    Y.ARRAY := Y.DELIM:Y.LR.PFOLIO.ARR<4>
    Y.ARRAY := Y.DELIM:Y.MOBILE.PH.NO
    Y.ARRAY := Y.DELIM:Y.CLIENT.IDENTIFIER
    Y.ARRAY := Y.DELIM:Y.CUST.PFOLIO.KEY
    Y.ARRAY := Y.DELIM:Y.ACC.OPEN.DATE
    Y.ARRAY := Y.DELIM:Y.CHANNEL.REF
* Write to Temp File
    IF Y.ARRAY THEN
        OPENSEQ AMEX.FILES,Y.TEMP.FILE.NAME TO FP.AMEX.FILES ELSE
        END
        WRITESEQ Y.ARRAY APPEND TO FP.AMEX.FILES ELSE
            CALL OCOMO("Unable to Write UT Trade Domicile report")
        END
        CLOSESEQ FP.AMEX.FILES
    END


RETURN
*--------------------------------------------------------------------------------

END
