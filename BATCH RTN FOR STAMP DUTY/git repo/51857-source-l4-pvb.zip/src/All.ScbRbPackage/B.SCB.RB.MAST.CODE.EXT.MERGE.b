$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.MAST.CODE.EXT.MERGE
*---------------------------------------------------------------------------
* Modification History :- 
* 10-Jan-2023 - Lavanya L  - NEW - CPSGMIG-17799
* Description 	:	The routine is used to send the daily dump of Fees & Charges 
*					configured for MF Instrument to Springwatch.
*--------------------------------------------------------------------------------

	$INSERT I_COMMON
	$INSERT I_EQUATE
	
	FN.APPEND.FILES = 'AMEX.FILES'
    F.APPEND.FILES = ''
    CALL OPF(FN.APPEND.FILES,F.APPEND.FILES)
	
	DL = '|'
	
	Y.FINAL.FILE.NAME = "MASTER-":TODAY:".txt"
	
	GOSUB GET.HEADER
	
	GOSUB WRITE.DETS
	
	RETURN
*------------------------------------------------------------------------
GET.HEADER:
*----------
	Y.HEADER = 'H':DL:'T24':DL:'SG':DL:TODAY
	
	RETURN
*------------------------------------------------------------------------------	
WRITE.DETS:	
*-----------
	Y.UDFILE    = 'AMEX.FILES'
    Y.CRITERIA  = 'MASTER-CODE-VALUE-*'
    SEL.FILE.ID = ''
    NO.OF.IDS   = ''
    CALL SCB.UDLIST(Y.UDFILE, Y.CRITERIA, SEL.FILE.ID, NO.OF.IDSD)

    IF SEL.FILE.ID THEN
         
        Y.DEL.FILE.ID = SEL.FILE.ID
        LOOP
            REMOVE Y.FILE.ID FROM SEL.FILE.ID SETTING POS
        WHILE Y.FILE.ID:POS
        	
            CALL F.READ(FN.APPEND.FILES,Y.FILE.ID,R.AMEX.FILES,F.APPEND.FILES,APP.ERR)
            ! Checking whether the file contains any record
            IF R.AMEX.FILES NE '' THEN
                Y.FILE.ARRAY<-1> = R.AMEX.FILES
* Count the number of records in the file to get the total count of CUSTOMER
*                LINE.COUNT = 0
*                LINE.COUNT = DCOUNT(R.AMEX.FILES, @FM)
*                TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + LINE.COUNT
            END
* Delete the file after forming the array
            CALL F.DELETE(FN.APPEND.FILES,Y.FILE.ID)
            LINE.COUNT = ''
        REPEAT
    END
    
    Y.FILE.ARRAY = SORT(Y.FILE.ARRAY)
    
    WRITE Y.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME
    GOSUB REMOVE.DUP.LINE									;*CPSGMIG-20152 - S/E
    CALL F.READ(FN.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FILE.ARRAY,F.APPEND.FILES,READ.ERR1)
    TOTAL.LINE.COUNT = DCOUNT(Y.FILE.ARRAY,@FM)

   Y.STAMP = OCONV(TIME(),"MTS")

* Footer should be in the following format

*
    Y.FINAL.FILE.ARRAY := Y.HEADER:@FM:Y.FILE.ARRAY:@FM:'T':DL:TOTAL.LINE.COUNT

*
* Finally write the single file to the AMEX.FILES path
*    
	WRITE Y.FINAL.FILE.ARRAY TO F.APPEND.FILES,Y.FINAL.FILE.NAME

RETURN
*----------------------------------------------------------------------------------
REMOVE.DUP.LINE:
*===============
	AMEXPATH=""
    CALL SCB.GET.ORACLE.FILENAME("AMEX.FILES","",AMEXPATH)
    FILE.PATH.ORG = AMEXPATH				

    CALL SCB.REMOVE.DUPLICATE.LINE(FILE.PATH.ORG,Y.FINAL.FILE.NAME)
RETURN
END
