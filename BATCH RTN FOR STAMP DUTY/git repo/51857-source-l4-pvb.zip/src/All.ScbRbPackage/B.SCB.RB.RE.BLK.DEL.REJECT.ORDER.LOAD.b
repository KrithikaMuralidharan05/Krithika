$PACKAGE All.ScbRbPackage
* @ValidationCode : MjoxMjMyMTk3NzMwOkNwMTI1MjoxNjAxMDM1MDQxNDUzOjE2MDEyNzQ6LTE6LTE6MDowOmZhbHNlOk4vQTpERVZfMjAxODA5LjE6LTE6LTE=
* @ValidationInfo : Timestamp         : 25 Sep 2020 17:27:21
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : 1601274
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : DEV_201809.1
SUBROUTINE B.SCB.RB.RE.BLK.DEL.REJECT.ORDER.LOAD
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*  Bharathiraja P    17-May-2022         CPSGMIG-565 Settle MF Trade: Cash Debit / Credit in Client's Account
*                                        CPSGMIG-3157 T24 Dev - EBBS Block creation / deletion
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE 
    $INSERT I_B.SCB.RB.RE.BLK.DEL.REJECT.ORDER.COMMON

    FnBlkRej = "F.SCB.CASH.BLK.SETT"
    FBlkRej = ""
    CALL OPF(FnBlkRej, FBlkRej)
    
    FnSooBlkRej = 'F.SEC.OPEN.ORDER'
    FSooBlkRej  = ''
    CALL OPF(FnSooBlkRej, FSooBlkRej)
   
    FnSooBlkRejHis = 'F.SEC.OPEN.ORDER$HIS'
    FSooBlkRejHis  = ''
    CALL OPF(FnSooBlkRejHis, FSooBlkRejHis)
    
RETURN

END
