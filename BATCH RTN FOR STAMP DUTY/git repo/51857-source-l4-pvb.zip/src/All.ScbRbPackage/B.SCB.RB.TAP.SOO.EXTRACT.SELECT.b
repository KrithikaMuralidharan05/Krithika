$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.TAP.SOO.EXTRACT.SELECT
*** ----------------------------------------------------------------------------------------
*
* This SELECT routine is  used for the file generation of T24_SG_RB_TAP_SOO_<yymmddhhmmss> to TAP
*
***---------------------------------------------------------------------------------------------------------------------------------------------------
*
* Modification History : 
*
* 14/07/2022 - Lavanya L - CPSGMIG-4869
* -----------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.RB.TAP.SEC.OPEN.COMMON
    $INSERT I_BATCH.FILES
*
	IF NOT(CONTROL.LIST) THEN
        GOSUB BUILD.CONTROL.LIST
    END
    BEGIN CASE
        CASE CONTROL.LIST<1,1> = "SCB.SEC.OPEN.ORD.TRD.STATUS"
            GOSUB UPDATE.SOO
        CASE CONTROL.LIST<1,1> = "SCB.SEC.OPEN.ORD.TRD.STATUS.HIS"
            GOSUB UPDATE.SOO.HIS
    END CASE
RETURN
*----------------------------------------------------------------------
UPDATE.SOO:
*----------
    SEL.CMD = "SELECT ":FN.SCB.SEC.OPEN.ORD.TRD.STAT:" WITH (TAP.REP.STATUS EQ '') AND DEAL.STATUS NE ''"
    
    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END

RETURN
* ----------------------------------------------------------------------------------------
UPDATE.SOO.HIS:
*--------------
	SEL.CMD.HIS = "SELECT ":FN.SCB.SEC.OPEN.ORD.TRD.STAT.HIS:" WITH (TAP.REP.STATUS EQ '') AND DEAL.STATUS NE ''"
   
    SEL.LIST.HIS = '' ; RET.CODE.HIS = '' ; NO.OF.REC.HIS = ''
    CALL EB.READLIST(SEL.CMD.HIS,SEL.LIST.HIS,'',NO.OF.REC.HIS,RET.CODE.HIS)
    IF SEL.LIST.HIS THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST.HIS)
    END

RETURN
* ----------------------------------------------------------------------------------------
BUILD.CONTROL.LIST:
*------------------

	CONTROL.LIST<-1> = "SCB.SEC.OPEN.ORD.TRD.STATUS"
    CONTROL.LIST<-1> = "SCB.SEC.OPEN.ORD.TRD.STATUS.HIS"
	RETURN
END
