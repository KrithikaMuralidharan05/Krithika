$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>65</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.BLD.SAM.POSN.CONCAT
*-----------------------------------------------------------------------------
*
* This routine builds the concat file SCB.RB.SAM.POSN which specifies security postion movements for a
* SAM
*-------------------------------------------------------------------------------------------------------------
*Modification History:
*---------------------
*
* 23-Feb-2023 - CPSGMIG-312 - kalaikumaranp- CCMS - Builds the concat file SCB.RB.SAM.POSN which specifies security postion movements.
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.DATES
*
    GOSUB OPEN.FILES
    GOSUB SELECT.LIMIT
    GOSUB BLD.CONCAT.FILE
*
*
OPEN.FILES:
*==========
*
    CUST.ID = ''
* CPSGMIG-29137    
    Y.LWORK.DAY = OCONV(DATE(),'D-') ;*MM-DD-YYYY
    Y.LWORK.DAY = Y.LWORK.DAY[7,4]:Y.LWORK.DAY[1,2]:Y.LWORK.DAY[4,2]
    CALL CDT("",Y.LWORK.DAY,"-1C")
* CPSGMIG-29137    
    LT.WRK.DAY = Y.LWORK.DAY
    DATE.REC = LT.WRK.DAY[1,6]
*
    FN.SCB.RB.SEC.POS.ACTIVITY = 'F.SCB.RB.SEC.POS.ACTIVITY'
    FV.SCB.RB.SEC.POS.ACTIVITY = ''
    CALL OPF(FN.SCB.RB.SEC.POS.ACTIVITY,FV.SCB.RB.SEC.POS.ACTIVITY)
*
    FN.SCB.RB.SAM.POSN = 'F.SCB.RB.SAM.POSN'
    FV.SCB.RB.SAM.POSN = ''
    CALL OPF(FN.SCB.RB.SAM.POSN,FV.SCB.RB.SAM.POSN)
*
RETURN
*==========
SELECT.LIMIT:
*============
    SEL.CMD = "SELECT ":FN.SCB.RB.SEC.POS.ACTIVITY:" WITH @ID LIKE ...":DATE.REC

    SEL.IDS = '' ; NO.SEL.IDS = '' ; SYS.RET.ERR = ''
    CALL EB.READLIST(SEL.CMD, SEL.IDS, '', NO.SEL.IDS, SYS.RET.ERR)

    SAM.IDS = SORT(SEL.IDS)

	RETURN
*
*============
BLD.CONCAT.FILE:
*===============
*

    PREV.SAM = ''
    SAM.LIST = ''
    LOOP  ;* Loop and remove IDs to put into concat file
        REMOVE ID.SAM FROM SAM.IDS SETTING POS
    WHILE ID.SAM NE ''
        CURR.SAM = FIELD(ID.SAM,'.',1)
        IF PREV.SAM EQ '' THEN PREV.SAM = CURR.SAM
        IF PREV.SAM EQ CURR.SAM THEN
            SAM.LIST<-1> = ID.SAM
        END ELSE
            R.AEB.SAM.POSN = ''
            R.AEB.SAM.POSN = SAM.LIST
            CALL F.WRITE(FN.SCB.RB.SAM.POSN,PREV.SAM,R.SCB.RB.SAM.POSN)
            SAM.LIST = ''
            SAM.LIST<-1> = ID.SAM
        END
        PREV.SAM = CURR.SAM
    REPEAT
*
    IF SAM.LIST AND PREV.SAM THEN
        R.SCB.RB.SAM.POSN = ''
        R.SCB.RB.SAM.POSN = SAM.LIST
        CALL F.WRITE(FN.SCB.RB.SAM.POSN,PREV.SAM,R.SCB.RB.SAM.POSN)
    END
*
RETURN
*
*===============
*
END
