* @ValidationCode : MjotMTMwMzQyODE0NzpJU08tODg1OS0xOjE2ODA1MTI2NzE3NzE6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 03 Apr 2023 14:34:31
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.MTM.BOOKBUILD.LOAD
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14087 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       16 Feb 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .LOAD Routine to extract Unsettled Trades
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
* 13-Mar-2023   1663000          CPSGMIG-21143 - Include ClientIdentifier & PrimaryAccountHolder columns
* 03-Mar-2023   1663000          CPSGMIG-14087 - Selection Changed to SEC.TRADE
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM
    $INSERT I_B.SCB.MTM.BOOKBUILD.COMMON
*--------------------------------------------------------------------------------------------
    
    GOSUB OPEN.FILES
    GOSUB GET.VALUES

RETURN
*---------*
OPEN.FILES:
*---------*

    FN.CUSTOMER              = 'F.CUSTOMER'              ; F.CUSTOMER              = ''  ; CALL OPF(FN.CUSTOMER,F.CUSTOMER)
    FN.SEC.TRADE             = 'F.SEC.TRADE'             ; F.SEC.TRADE             = ''  ; CALL OPF(FN.SEC.TRADE,F.SEC.TRADE)
    FN.SECURITY.MASTER       = 'F.SECURITY.MASTER'       ; F.SECURITY.MASTER       = ''  ; CALL OPF(FN.SECURITY.MASTER,F.SECURITY.MASTER)
    FN.SCB.WM.H.LOCAL.PARAM  = 'F.SCB.WM.H.LOCAL.PARAM'  ; F.SCB.WM.H.LOCAL.PARAM  = ''  ; CALL OPF(FN.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM)
  
    AMEX.FILES.PATH = 'AMEX.FILES'
    ARG2 = ''
    CALL SCB.GET.ORACLE.FILENAME(AMEX.FILES.PATH, ARG2, AMEX.FILES)
    Y.TEMP.FILE = "SCBMTMBOOKBUILD-":TODAY:"-":SESSION.NO:".csv"

RETURN
*---------*
GET.VALUES:
*---------*
    
* PVB/RB Customer Demarkation
    Y.PARAM.ID		= 'SCB.CUST.SEG'
    Y.ALLOW.SEG 	= 'RET'
    Y.ALLOWED.LOB	= ''
	CALL SCB.GET.ALLOWED.CUST.SEG(Y.PARAM.ID,Y.ALLOW.SEG,Y.ALLOWED.LOB)
 
* Get LRF values
    APP.NAME    = 'CUSTOMER'
    FIELD.NAME := 'L.O.B' :@VM: 'LR.PFOLIO.KEY' :@VM: 'LR.STAFF.IND'        ;* CPSGMIG-21143
    FIELD.POS   = ''
    CALL MULTI.GET.LOC.REF(APP.NAME, FIELD.NAME, FIELD.POS)
    Y.LOB.POS   = FIELD.POS<1,1> ;   Y.CUS.LRPFOLIO.POS= FIELD.POS<1,2> ; Y.CU.STAFFIND.POS = FIELD.POS<1,3>  ;*CPSGMIG-21143
  
* Get Param Values
    Y.SAT.PARAM = 'SCB.SN.ASSET.TYPES' ; R.SCB.WM.H.LOCAL.PARAM = '' ; Y.SCB.WM.H.LOCAL.PARAM.ERR = ''
    CALL F.READ(FN.SCB.WM.H.LOCAL.PARAM,Y.SAT.PARAM,R.SCB.WM.H.LOCAL.PARAM,F.SCB.WM.H.LOCAL.PARAM,Y.SCB.WM.H.LOCAL.PARAM.ERR)
    IF R.SCB.WM.H.LOCAL.PARAM THEN
        Y.SN.PARAM.FLD.VALUE = R.SCB.WM.H.LOCAL.PARAM<SCBWM.PRM.FIELD.VALUE>
        CHANGE @SM TO @VM IN Y.SN.PARAM.FLD.VALUE
    END
    
RETURN
END
