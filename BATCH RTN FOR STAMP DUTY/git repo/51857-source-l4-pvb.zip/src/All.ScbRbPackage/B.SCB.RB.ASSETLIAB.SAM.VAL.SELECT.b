$PACKAGE All.ScbRbPackage
	SUBROUTINE B.SCB.RB.ASSETLIAB.SAM.VAL.SELECT
* -------------------------------------------------------------------------------------
* Multithread routine for the file generation of SG-RB-ASSET-LIAB-<date>.csv to EDMP
*
**---------------------------------------------------------------------------------------------------------------------------------------------------
*
* Modification History : 
*
* 31/10/2022 - Lavanya L - CPSGMIG-291 - DAY 0 file generation
*--------------------------------------------------------------------
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_BATCH.FILES
	$INSERT I_B.SCB.RB.ASSETLIAB.SAM.VAL.COMMON
	
	SEL.CMD = 'SELECT ':FN.SAM:' WITH L.O.B EQ 8'
	CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
	RETURN
	END