$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-10</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.CUS.SEC.EXTRACT.SELECT
**************************************************************************
* 25 Feb 2016 - FCC EDMP - Subramanian M
*             - This routine will generate the Customer Security Dump in AMEX.FILES.
**************************************************************************
*******************************************************************************
*Modification History:
************************
* 27-May-2022 - CPSGMIG-3321 - Lavanya L - Copy of the existing routine B.SCB.EDM.CUS.STAT.EXTRACT.SELECT
*
* 21-Oct-2022 - CPSGMIG-13878 - Ananthy.S - For pilot launch filtering customer using sector 23 and parameterised customer.
*--------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.EDM.CUS.SEC.EXTRACT.COMMON

*
    GOSUB SEL.PROCESS
RETURN
*******************************************************************************
SEL.PROCESS:
************
*CPSGMIG-2796-S

    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
  *  SEL.CMD = "SELECT ":FN.CUSTOMER.SECURITY
    IF ID.COMPANY[1,2] EQ 'SG' THEN
    		SEL.CMD = 'SELECT ':FN.CUSTOMER.SECURITY:' WITH L.O.B EQ ':Y.ALLOWED.LOB
*CPSGMIG-13878(S)
*                SEL.CMD := " AND SECTOR EQ 23"
*CPSGMIG-13878(E)
	END ELSE
		SEL.CMD = 'SELECT ':FN.CUSTOMER.SECURITY
	END
*CPSGMIG-2796-E
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
RETURN
*******************************************************************************
END
