* @ValidationCode : MjotMTg5MjI0NDE1OTpJU08tODg1OS0xOjE2NjYwODgxNTE2OTU6MTY2MzAwMDotMTotMTowOjA6ZmFsc2U6Ti9BOlIyMF9TUDEwLjA6LTE6LTE=
* @ValidationInfo : Timestamp         : 18 Oct 2022 15:45:51
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.SETT.UNSETT.TRADES.SELECT
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-14422 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       18 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* .SELECT Routine to extract Daily Trasaction details for the current month.
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SNG.EOD.REPORT.GEN
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.SETT.UNSETT.TRADES.COMMON
*--------------------------------------------------------------------------------------------

    GOSUB SELECT.RECORDS

RETURN
*-------------*
SELECT.RECORDS:
*-------------*
    
* Select Transaction details for the Current Month
    SEL.CMD = "SELECT ":FN.SEC.TRADES.MDAY:" WITH @ID LIKE ":ID.COMPANY[1,2]:"..."
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',SEL.CNT,SEL.ERR)

    CALL BATCH.BUILD.LIST('',SEL.LIST)

RETURN
END
