$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CSE.SAM.DET(Y.SAM.ID)
*----------------------------------------
* Routine to extract the SM and SAM and its equivalent UTS and ISA Account details that were loaded
*Created by :- 1657186 

* 02 Mar 2023 - CPSGMIG-19983 - kalaikumaranp - To send BB and Individual Client Feed to CSE.
* 23-Mar- 2023 - CPSGMIG-18238 - Lakshmi PR- Parameterised the customer tranche records.
* 11-May-2023 - CPSGMIG-26865 - 1657816 - Individula client not reported in the SAM.ISA.
* 30-May-2023  - CPSGMIG-27389 - 1657186 - Rel Id's having delimiter as "-" in case of Joint Accounts.
* 08-Aug-2023 - CPSGMIG-32489 - 1657186 - Updating Surviving id for Cuco process.
* 08-Aug-2023- CPSGMIG-32375 - 1670271 - Rel ID Delimiters needs to be fixed for Joint Accounts
*------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.CUSTOMER
    $INSERT I_B.SCB.RB.CSE.SAM.DET.COMMON
	
* PF.SKIP - S
	LOCATE Y.SAM.ID IN Y.PF.LIST<1> SETTING PF.SKIP.POS THEN
		RETURN
	END
* PF.SKIP - E

    GOSUB INIT    ;*To initialise the variables AND open files
    GOSUB SAM.PROCESS    ;*To get the details of sec acc master and exract field values
    CLOSESEQ F.OUT.FILE
RETURN
******
INIT:
******	
	OPENSEQ AMEX.FILES.PATH,Y.FILE.ID TO F.OUT.FILE ELSE
		CREATE F.OUT.FILE
	END
	
RETURN
*****************
SAM.PROCESS:
*****************
 		R.SAM = ''
        CALL F.READ(FN.SEC.ACC.MASTER,Y.SAM.ID,R.SAM,F.SEC.ACC.MASTER,Y.SAM.POS)

        IF R.SAM THEN

            Y.PFOLIO.KEY = R.SAM<SC.SAM.LOCAL.REF,Y.LR.PFOLIO.KEY.POS>
            Y.SURV.PORT.KEY = R.SAM<SC.SAM.LOCAL.REF,Y.SURV.PORT.POS> ;*CPSGMIG-32489
            IF Y.SURV.PORT.KEY NE '' THEN
                Y.PFOLIO.KEY = Y.SURV.PORT.KEY
            END
			PFOLIO.KEY.COUNT =DCOUNT(Y.PFOLIO.KEY,":")
            SAM.POS = ''
            LOCATE Y.SAM.ID IN Y.SAM.HYPEN.LIST<1,1> SETTING SAM.POS THEN ;*CPSGMIG-27389
                PFOLIO.KEY.PRIMARY = Y.SAM.HYPEN.VAL<1,SAM.POS>
            END ELSE
				PFOLIO.KEY.PRIMARY =FIELD(Y.PFOLIO.KEY,":",1)
				PFOLIO.SECONDARY1 = FIELD(Y.PFOLIO.KEY,":",2)
				PFOLIO.SECONDARY2 = FIELD(Y.PFOLIO.KEY,":",3)
				PFOLIO.SECONDARY3 = FIELD(Y.PFOLIO.KEY,":",4)
				PFOLIO.SECONDARY4 = FIELD(Y.PFOLIO.KEY,":",5)
			END
			
			ISA.STATUS = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.AC.STATUS.POS>
			CHANGE @SM TO @FM IN ISA.STATUS
            Y.TP.ACCT.NO = R.SAM<SC.SAM.LOCAL.REF,Y.LR.TP.ACCT.NO.POS>
            CHANGE @SM TO @FM IN Y.TP.ACCT.NO
            TP.ACCT.CNT = DCOUNT(Y.TP.ACCT.NO,@FM)
			CUS.NO = R.SAM<SC.SAM.CUSTOMER.NUMBER>
			CUS.ID = CUS.NO
            GOSUB CUSTOMER.PROCESS    ;*read customer to get sector detail if business or individual
			*CPSGMIG-18238- Start
			 Y.MIG.DAT = R.SAM<SC.SAM.LOCAL.REF,Y.MIG.DAT.POS>
            IF Y.FILE.FLAG EQ "TRANCHE" AND (Y.MIG.DAT NE '' OR Y.SECTOR EQ '23') THEN
             IF Y.SECTOR EQ "23" THEN
                Y.SEGMENT.CODE = "Business Banking"
				GOSUB CORP.ISA
             END
             ELSE
                Y.SEGMENT.CODE ="Individual"
                GOSUB CORP.ISA ;*CPSGMIG-26865
             END   
            END ELSE
			  IF Y.FILE.FLAG EQ "FULL" THEN
			   IF Y.SECTOR EQ "23" THEN
                Y.SEGMENT.CODE = "Business Banking"
				GOSUB CORP.ISA
               END
               ELSE
                Y.SEGMENT.CODE ="Individual"
                GOSUB CORP.ISA ;* ;*CPSGMIG-26865
             	END
            END
            END			 
			
			*CPSGMIG-18238- End
        END   ;*end FOR first IF

RETURN
*********************
CUSTOMER.PROCESS:
********************

    CALL F.READ(FN.CUSTOMER,CUS.ID,R.CUSTOMER,F.CUSTOMER,CUS.ERR)
    Y.SECTOR =R.CUSTOMER<EB.CUS.SECTOR>
    Y.PP.CODE = R.CUSTOMER<EB.CUS.LOCAL.REF,Y.LR.PP.CODE.POS>		;*Used to get PP CODE FOR SM
    
RETURN
**************************
CORP.ISA:
*************************

    IF TP.ACCT.CNT LE 1 THEN
			
        Y.SAM.ARRAY = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS
                        Y.ARRAY = Y.SAM.ARRAY
    			GOSUB FILE.WRITE.PROCESS
    END
    ELSE
        I = 1
        LOOP
        WHILE I LE TP.ACCT.CNT
		
		Y.SAM.ARRAY = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO<I>:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS<I>
                Y.ARRAY = Y.SAM.ARRAY
    			GOSUB FILE.WRITE.PROCESS
            I+=1
        REPEAT
    END
RETURN
**************
INDIV.ISA:
*************
    IF TP.ACCT.CNT LE 1 THEN
        FINDSTR Y.TP.ACCT.NO IN ISA.LISTS SETTING TP.POS THEN   ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed
			
            Y.SAM.ARRAY = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS
        	Y.ARRAY = Y.SAM.ARRAY
        	GOSUB FILE.WRITE.PROCESS
        END
    END
    ELSE
        I = 1
        LOOP
        WHILE I LE TP.ACCT.CNT
            FINDSTR Y.TP.ACCT.NO<I> IN ISA.LISTS SETTING TP.POS THEN   ;*if the LR.TP.ACCT.NO matches with ISA lists of individual from SCB.WM.H.LOCAL.PARAM table then proceed

		
                Y.SAM.ARRAY = Y.SAM.ID:',':CUS.NO:',':Y.TP.ACCT.NO<I>:',':PFOLIO.KEY.PRIMARY:',':PFOLIO.SECONDARY1:',':PFOLIO.SECONDARY2:',':PFOLIO.SECONDARY3:',':PFOLIO.SECONDARY4:',':Y.SEGMENT.CODE:',':ISA.STATUS<I>
            	Y.ARRAY = Y.SAM.ARRAY
            	GOSUB FILE.WRITE.PROCESS
            END
            I+=1
        REPEAT
    END
RETURN
********************
FILE.WRITE.PROCESS:
********************
    WRITESEQ Y.ARRAY APPEND TO F.OUT.FILE ELSE
            PRINT 'UNABLE TO WRITE'
        END

RETURN
************************************************************
END