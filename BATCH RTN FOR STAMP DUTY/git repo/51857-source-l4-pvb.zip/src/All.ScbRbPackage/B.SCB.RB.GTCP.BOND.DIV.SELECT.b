$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>122</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.GTCP.BOND.DIV.SELECT
*-----------------------------------------------------------------------------
* Modification History:
*-----------------------------------------------------------------------------
* 01-Nov-2022 - CPSGMIG-14150 - Sasi V - GTCP extract MFU-T24-BOND.DIVIDENDS-<start.date>-<end.date>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RB.GTCP.BOND.DIV.COMMON

	IF Y.START.DATE AND Y.END.DATE THEN
		GOSUB PROCESS
	END

RETURN
*-----------------------------------------------------------------------------
PROCESS:
*-------
    SEL.CMD = "SELECT ":FN.ENTITLEMENT:" WITH L.O.B EQ ":Y.ALLOWED.LOB
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    CALL BATCH.BUILD.LIST('',SEL.LIST)
*
RETURN
*-----------------------------------------------------------------------------
END
