$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CS.TR.FEE.UPD(Y.SEC.ID)
*--------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-12313
* Routine Type                 Batch Job
* Attached To                  BATCH>SNG/B.SCB.RB.CS.TR.FEE.UPD
* Workflow                     This routine will select the customer security table and look for the L.O.B
*                              value of that particular customer. If the customer LOB other than RET L.O.B
*                              list available in Common Parameter then system will update EXCL.TRAIL.FEE
*                              field value as 'YES'
*
**************************
* EXTRA CARE MUST BE TAKEN
**************************
* This Service has to be run only when it is really required as it will affect the majority of the 
* customer security records.
*--------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      		Description
*--------------------------------------------------------------------------------------------------------
*  Tejomurthy M        22/Dec/2022     CPSGMIG-12313        Initial Draft
*--------------------------------------------------------------------------------------------------------
*
	$INSERT I_COMMON
	$INSERT I_EQUATE
	$INSERT I_BATCH.FILES
	$INSERT I_F.CUSTOMER
	$INSERT I_F.CUSTOMER.SECURITY
	$INSERT I_B.SCB.RB.CS.TR.FEE.UPD.COMMON

	GOSUB INIT
	GOSUB PROCESS
	GOSUB WRITE.DATA
	
	RETURN
*--------------------------------------------------------------------------------------------------------
INIT:
*****

	R.CUS = '' 			; CUS.READ.ERR = ''
	R.CUS.SEC = ''		; CUS.SEC.READ.ERR = ''
	CUS.TYPE.LIST = ''  ; Y.CO.CODE = ''
	Y.ARRAY = ''		; Y.ARR.INFO = ''
	TEMP.CU.TYPE = ''
	
	RETURN
*--------------------------------------------------------------------------------------------------------
PROCESS:
********

	CALL F.READ(FN.CUS,Y.SEC.ID,R.CUS,FV.CUS,CUS.READ.ERR)
	IF NOT(CUS.READ.ERR) THEN
		Y.LOB.STATUS = R.CUS<EB.CUS.LOCAL.REF,Y.LOB.POS>
		IF Y.LOB.STATUS MATCHES Y.ALLOWED.LOB THEN
			Y.ARRAY = Y.SEC.ID:",":Y.LOB.STATUS:",,SKIPPED,RETAIL.CUSTOMER"
		END ELSE	
			CALL F.READ(FN.CUS.SEC,Y.SEC.ID,R.CUS.SEC,FV.CUS.SEC,CUS.SEC.READ.ERR)
			IF NOT(CUS.SEC.READ.ERR) THEN
				CUS.TYPE.LIST = R.CUS.SEC<SC.CSC.CUSTOMER.TYPE>
				TEMP.CU.TYPE = CUS.TYPE.LIST
				CONVERT VM TO "_" IN TEMP.CU.TYPE
				LOCATE 'CUSTOMER' IN CUS.TYPE.LIST<1,1> SETTING CUS.POS THEN
					Y.CO.CODE = R.CUS.SEC<SC.CSC.CO.CODE>
**					R.CUS.SEC<SC.CSC.EXCL.TRAIL.FEE> = 'YES'
**					CALL F.WRITE(FN.CUS.SEC,Y.SEC.ID,R.CUS.SEC)
					IF R.CUS.SEC<SC.CSC.EXCL.TRAIL.FEE> NE 'YES' THEN
						GOSUB DO.OFS.PROCESSING
					END ELSE
						Y.ARRAY = Y.SEC.ID:",":Y.LOB.STATUS:",":TEMP.CU.TYPE:",SKIPPED,EXCL.TR.FEE.ALREADY.WITH.YES"
					END
				END ELSE
					Y.ARRAY = Y.SEC.ID:",":Y.LOB.STATUS:",":TEMP.CU.TYPE:",SKIPPED,CUS.TYPE.NOT.CUSTOMER"
				END
			END ELSE
				Y.ARRAY = Y.SEC.ID:",":Y.LOB.STATUS:",,SKIPPED,CUS.SEC.REC.NOT.FOUND"
			END
		END
	END ELSE
		Y.ARRAY = Y.SEC.ID:",,,SKIPPED,CUST.REC.NOT.FOUND"
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
DO.OFS.PROCESSING:
******************

	Y.OFS.HEAD = "CUSTOMER.SECURITY,/I/PROCESS//0/,//":Y.CO.CODE:"/3,":Y.SEC.ID:","
	Y.OFS.MSG  = Y.OFS.HEAD:"EXCL.TRAIL.FEE::=YES"
	
	Y.OFS.SOURCE = "SCB.UPD.THRU.OFS"
	CALL OFS.GLOBUS.MANAGER(Y.OFS.SOURCE,Y.OFS.MSG)
	
	Y.RESP.FLAG = '' ; Y.FIRST.MSG = ''
	Y.FIRST.MSG = FIELDS(Y.OFS.MSG,',',1,1)
	Y.RESP.FLAG = FIELDS(Y.FIRST.MSG,'/',3,1)
	
	IF Y.RESP.FLAG EQ '1' THEN
		Y.ARRAY = Y.SEC.ID:",":Y.LOB.STATUS:",":TEMP.CU.TYPE:",SUCCESS,RECORD.UPDATED.SUCCESSFULLY"
	END ELSE
		Y.ERR.MSG = ''
		Y.ERR.MSG = FIELD(Y.OFS.MSG,",",2)
		Y.ARRAY = Y.SEC.ID:",":Y.LOB.STATUS:",":TEMP.CU.TYPE:",FAILED,":Y.ERR.MSG
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
WRITE.DATA:
***********

	Y.FINAL.FILE.NAME = 'SCB.CS.EX.TR.FEE.DET.':TODAY:'.':SESSION.NO
	READLIST Y.ARR.INFO FROM Y.FINAL.FILE.NAME THEN
		Y.ARR.INFO<-1> = Y.ARRAY
		WRITELIST Y.ARR.INFO TO Y.FINAL.FILE.NAME
	END ELSE
		WRITELIST Y.ARRAY TO Y.FINAL.FILE.NAME
	END
	
	RETURN
*--------------------------------------------------------------------------------------------------------
END