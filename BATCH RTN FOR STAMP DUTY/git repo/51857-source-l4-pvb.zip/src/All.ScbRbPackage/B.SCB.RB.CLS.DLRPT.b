$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>3244</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.CLS.DLRPT(SC.POS.ASSET.ONE.ID)
*-----------------------------------------------------------------------------
*Desc : Copy of the existing routine AEB.CLS.DLRPT
*Modification History:
************************
* 24-May-2022 - CPSGMIG-3320 - Lavanya L 
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SC.POS.ASSET
    $INSERT I_F.CUSTOMER
    $INSERT I_F.DATES
    $INSERT I_F.SECURITY.MASTER
    $INSERT I_F.SUB.ASSET.TYPE
    $INSERT I_F.DEPT.ACCT.OFFICER
    $INSERT I_F.MD.DEAL
    $INSERT I_F.ACCOUNT
    $INSERT I_F.MM.MONEY.MARKET
    $INSERT I_F.LD.LOANS.AND.DEPOSITS   ;* CM0000000578880
    $INSERT I_F.CATEGORY
    $INSERT I_F.FD.FID.ORDER
    $INSERT I_F.FOREX
    $INSERT I_F.CL.SUIT.PARAM
    $INSERT I_F.AEB.LOCATION
    $INSERT I_B.SCB.RB.CLS.DLRPT.COMMON
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER          ;* RMWB_Client_Portfolio_S/E
*Enable 1.2 CR_Start
    $INSERT I_F.CUSTOMER.STATUS
*Enable 1.2 CR_End

*
*

*---TAFJUPGR20---START--
*---TAFJUPGR20---END
***Recon_report*** - Strat
    ASSET.SAT.POS = ''
    LIAB.SAT.POS = ''
    ASSET.SAT.FLAG = ''
    LIAB.SAT.FLAG = ''
    ASSET.SUM = ''
    LIAB.SUM = ''
    Y.TEMP.NUM = ''
    CIF.CNT = ''
***Recon_report*** - End
*TAP Enable CR - Start
    Y.ACCRUED.AMT = ''
*TAP Enable CR - End
*Enable 1.2 CR_Start
    Y.MARKET.PRICE = ''
    Y.EXCHANGE.RATE = ''
    INVERSE.EXCH.RATE = ''
    MVAL.PFOLIO.CCY = ''
    Y.ACCRUED.INT.PFOLIO.CCY = ''
    Y.CUSTOMER.STATUS.DESC = ''
*Enable 1.2 CR_End

    CALL F.READ(FN.SC.POS.ASSET,SC.POS.ASSET.ONE.ID,R.SC.POS.ASSET,FP.SC.POS.ASSET,ER1)
*** CHANGES FOR ASSET EXTRACT -- START
    SP.CNT = SP.CNT + 1
*        PRINT SP.CNT
***CHANGES FOR ASSET -- END
    CIF.NO = FIELD(SC.POS.ASSET.ONE.ID,"-",1)
    CALL F.READ(FN.CUSTOMER,CIF.NO,R.CUSTOMER,FP.CUSTOMER,ERR1)
    APPLICAT = R.SC.POS.ASSET<SC.PAS.APPLICATION>
    CIF.RISK = R.CUSTOMER<EB.CUS.LOCAL.REF,LOCAL.REF.CLIENT.RISK>
    IF CIF.RISK EQ '' THEN
        CIF.RISK = "NULL"
    END
    A.OFF = R.CUSTOMER<EB.CUS.ACCOUNT.OFFICER>

    CUS.STAT = R.CUSTOMER<EB.CUS.CUSTOMER.STATUS>
*CPSGMIG-3320 - S
	Y.CUST.LOB = R.CUSTOMER<EB.CUS.LOCAL.REF,LOB.POS>
	LOBPOS = ''

	LOCATE Y.CUST.LOB IN Y.ALLOWED.LOB<1,1> SETTING LOBPOS THEN
		GOSUB PROCESS
	END
*CPSGMIG-3320 - E
	RETURN
PROCESS:
*--------
        READ R.DEPT.ACCT.OFFICER FROM FP.DEPT.ACCT.OFFICER,A.OFF ELSE NULL
        A.O.NAME = R.DEPT.ACCT.OFFICER<EB.DAO.NAME>
        CONVERT ',' TO '|' IN A.O.NAME
        A.O.LOCATION = R.DEPT.ACCT.OFFICER<EB.DAO.LOCAL.REF,LOCAL.REF.LOCATION>
        CALL F.READ(FN.AEB.LOCATION,A.O.LOCATION,R.AEB.LOCATION,FV.AEB.LOCATION,R.AEB.LOCATION.ERR)
        IF R.AEB.LOCATION.ERR = '' THEN
            RM.LOCATION = R.AEB.LOCATION<AEB.LOC.NAME>
        END
        SA.ID = FIELD(SC.POS.ASSET.ONE.ID,".",2)
        READ R.SAT FROM FP.SAT,SA.ID ELSE NULL
        SEC.CAT = R.SAT<SC.CSG.DESCRIPTION,1>
*
*
        TOT.MULTI.VAL = DCOUNT(APPLICAT,@VM)

**** CHANGES FOR CREDIT MIS PHASE II - START
*        BOOKING.CENTRE = BRANCH.CODE      ;* CM0000000578880
        AS.CIF.NO = FIELD(SC.POS.ASSET.ONE.ID,'.',1)
        AS.CIF.NO = FIELD(AS.CIF.NO,'-',1)
        SAT.CODE = FIELD(SC.POS.ASSET.ONE.ID,'.',2)
*            CALL DBR("SUB.ASSET.TYPE":FM:SC.CSG.DESCRIPTION,SAT.CODE,SAT.DESC)
        R.SAT = ''
        CALL F.READ(FN.SAT,SAT.CODE,R.SAT,FP.SAT,SAT.ERR)
*        SAT.DESC = R.SAT<SC.CSG.DESCRIPTION,1>     ;* CM0000000578880
        MATURITY.DATE = ''
        EXCEPTION.FLAG = ''
        EXCEP.EXPIRY.DATE = ''
        BORROWER.CIF = ''
        PLEDGE.CIF = AS.CIF.NO
        PERCENTAGE.ALLOC = ''
* Spring watch Issue/S
        SAM.ID = '' ;* Spring Watch Issue
        SAM.ID = FIELD(SC.POS.ASSET.ONE.ID,'.',1)
* Spring watch Issue/E
**** CHANGES FOR CREDIT MIS PHASE II - END
        R.SEC.ACC.MASTER = ''; SECM.ERR = ''; SAM.REF.CCY  = ''       ;*RMWB_Client_Portfolio_S
        CALL F.READ(FN.SEC.ACC.MASTER,SAM.ID,R.SEC.ACC.MASTER,F.SEC.ACC.MASTER,SECM.ERR)
        SAM.REF.CCY  = R.SEC.ACC.MASTER<SC.SAM.REFERENCE.CURRENCY>    ;*RMWB_Client_Portfolio_E

***Recon_report*** - Strat
        LOCATE SAT.CODE IN ASSET.SAT.ARRAY<1,1> SETTING ASSET.SAT.POS THEN
            ASSET.SAT.FLAG = "YES"
        END ELSE
            ASSET.SAT.FLAG = "NO"
            ASSET.SAT.POS = ''
        END
        LOCATE SAT.CODE IN LIAB.SAT.ARRAY<1,1> SETTING LIAB.SAT.POS THEN
            LIAB.SAT.FLAG = "YES"
        END ELSE
            LIAB.SAT.FLAG = "NO"
            LIAB.SAT.POS = ''
        END
***Recon_report*** - End

        FOR ONE.MULTI.VAL = 1 TO TOT.MULTI.VAL
**** CHANGES FOR CREDIT MIS PHASE II - START
            APPLICAT.ID = R.SC.POS.ASSET<SC.PAS.APPLICATION,ONE.MULTI.VAL>
            SECURITY.CODE = R.SC.POS.ASSET<SC.PAS.SECURITY.NO,ONE.MULTI.VAL>
            MARKET.VALUE = R.SC.POS.ASSET<SC.PAS.ESTIMATION,ONE.MULTI.VAL>
            LENDING.VALUE = R.SC.POS.ASSET<SC.PAS.MARGIN.VALUE,ONE.MULTI.VAL>
*OPICSDECOMM S
            Y.FX.TYPE.OF.FX = ''
            R.FX = ''
            SEC.NO = R.SC.POS.ASSET<SC.PAS.SECURITY.NO,ONE.MULTI.VAL>
            READ R.FX FROM FP.FOREX,SEC.NO ELSE NULL
            Y.FX.TYPE.OF.FX = R.FX<FX.LOCAL.REF,TYPE.OF.FOREX.POS>

            IF APPLICAT.ID[1,2] EQ 'FX' AND Y.FX.TYPE.OF.FX EQ 'UNFUNDED.FX' THEN

                IF LENDING.VALUE THEN
                    LENDING.RATE = '100'
                END ELSE
                    LENDING.RATE = ''
                END
            END ELSE
*OPICSDECOMM E
                IF MARKET.VALUE AND LENDING.VALUE THEN
                    LENDING.RATE = (LENDING.VALUE / MARKET.VALUE) * 100
                END ELSE
                    LENDING.RATE = ''
                END

            END
***Recon_report*** - Strat
            ASSET.SUM = 0
            LIAB.SUM = 0
            BEGIN CASE
                CASE ASSET.SAT.FLAG EQ "YES"
                    ASSET.SUM  = MARKET.VALUE
                CASE LIAB.SAT.FLAG EQ "YES"
                    LIAB.SUM = MARKET.VALUE
                CASE 1
            END CASE
            Y.TEMP.NUM = ASSET.SUM:"|":LIAB.SUM:"|":"SAT.CODE :":SAT.CODE:"~":"ASSET.SAT.FLAG :":ASSET.SAT.FLAG:"~":"LIAB.SAT.FLAG :":LIAB.SAT.FLAG:"~":"MARKET.VALUE :":MARKET.VALUE
***Recon_report*** - End

CLR.EXT:
**** CHANGES FOR CREDIT MIS PHASE II - END
            P.ASS.CLASS = ''
            CATEG = ''
            SEC.NAME = ''
            Y.COST.PRICE = '' ;* CAP rolling release phase2 requirement S/E
*usd change -s
            SEC.CCY = ''
            GROSS.TRD = ''
            SELL.CCY = ''
            VALUE.HOLD.USD = ''
            TM = '' ;* CM0000000578880
*usd change -e
            APPLN = R.SC.POS.ASSET<SC.PAS.APPLICATION,ONE.MULTI.VAL>
            APPLN1 = APPLN[1,2]
*            IF APPLN1 NE "LD" THEN          ;* CM0000000578880
            TOT.HOLD = R.SC.POS.ASSET<SC.PAS.NO.NOMINAL,ONE.MULTI.VAL>
            VALUE.HOLD = R.SC.POS.ASSET<SC.PAS.ESTIMATION,ONE.MULTI.VAL>
            VAL.DATE = TODAY
            SEC.NO = R.SC.POS.ASSET<SC.PAS.SECURITY.NO,ONE.MULTI.VAL>

* CAP rolling release phase2 requirement - S
            Y.COST.PRICE = R.SC.POS.ASSET<SC.PAS.COST.PRICE,ONE.MULTI.VAL>
            IF Y.COST.PRICE EQ '' THEN
                Y.COST.PRICE = 0
            END
* CAP rolling release phase2 requirement - E

*New Requirement-s
            SEC.CCY = R.SC.POS.ASSET<SC.PAS.SECURITY.CCY,ONE.MULTI.VAL>
*New Requirement-e
*usd change -s
            IF VALUE.HOLD THEN
                SELL.CCY = "USD"
                HOLD.REF.CCY = ''       ;* RMWB_Client_Portfolio_S
*CALL EXCHRATE('1',SEC.CCY,VALUE.HOLD,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RETURN.CODE)
                GOSUB CCY.CONV          ;* RMWB_Client_Portfolio_E
                VALUE.HOLD.USD = SELL.AMT
                BEGIN CASE
                    CASE SAM.REF.CCY EQ SEC.CCY       ;* RMWB_Client_Portfolio_S
                        HOLD.REF.CCY = VALUE.HOLD
                    CASE SAM.REF.CCY EQ 'USD'
                        HOLD.REF.CCY = VALUE.HOLD.USD
                    CASE SAM.REF.CCY NE SEC.CCY AND SAM.REF.CCY NE 'USD'

                        SELL.CCY = ''
                        SELL.CCY = SAM.REF.CCY
                        GOSUB CCY.CONV
                        HOLD.REF.CCY = SELL.AMT
                END CASE      ;* RMWB_Client_Portfolio_S
            END ELSE
                VALUE.HOLD.USD = 0
                HOLD.REF.CCY = 0        ;* RMWB_Client_Portfolio_S/E
            END
*usd change -s
           IF APPLN1 EQ "SC" THEN
                    READ R.SECURITY.MASTER FROM FP.SECURITY.MASTER, SEC.NO ELSE NULL
                    SECURITY.ID = SEC.NO
                    SECURITY.RATING = R.SECURITY.MASTER<SC.SCM.RATING>
                    SEC.NAME = R.SECURITY.MASTER<SC.SCM.SHORT.NAME,1>
                    P.ASS.CLASS = R.SECURITY.MASTER<SC.SCM.LOCAL.REF,LOCAL.REF.AS.CLASS>
                    IF P.ASS.CLASS EQ '' THEN
                        P.ASS.CLASS = R.CL.SUIT.PARAM<SUT.DEF.ASS.CODE>
                    END
                
            
*New change for MM -e
*
* 15002404 - S
            Y.DEPOSITORY = R.SC.POS.ASSET<SC.PAS.DEPOSITORY,ONE.MULTI.VAL>
* 15002404 - E
*TAP Enable CR - Start
            Y.ACCRUED.AMT = ''
            Y.ACCRUED.AMT = R.SC.POS.ASSET<SC.PAS.ACCRUED.INT,ONE.MULTI.VAL>
*TAP Enable CR - End
*Enable 1.2 CR_Start
            Y.MARKET.PRICE = ''
            Y.MARKET.PRICE = R.SC.POS.ASSET<SC.PAS.MARKET.PRICE,ONE.MULTI.VAL>
*
            Y.EXCHANGE.RATE = '' ; Y.ACCRUED.INT.PFOLIO.CCY = '0'
            GOSUB GET.PORTFOLIO.CCY
*
            MVAL.PFOLIO.CCY = ''
*            MVAL.PFOLIO.CCY = HOLD.REF.CCY - Y.ACCRUED.INT.PFOLIO.CCY  ;*Enable 1.2 CR_Fix
            MVAL.PFOLIO.CCY = HOLD.REF.CCY        ;*Enable 1.2 CR_Fix
*
*Enable 1.2 CR_End
			IF VALUE.HOLD.USD NE 0 AND VALUE.HOLD.USD NE '' THEN 
            ASST.HOLD.DATA = 'D':DL:BK.CENT:DL:CIF.NO:DL:CIF.RISK:DL:A.OFF:DL:A.O.NAME:DL:RM.LOCATION:DL
            ASST.HOLD.DATA := SECURITY.ID:DL:SEC.NAME:DL:SEC.CAT:DL:P.ASS.CLASS:DL:SEC.CCY:DL
            ASST.HOLD.DATA := SECURITY.RATING:DL:TOT.HOLD:DL:VALUE.HOLD.USD:DL:VAL.DATE:DL
*
            ASST.HOLD.DATA := SAT.CODE:DL:MATURITY.DATE:DL:MARKET.VALUE:DL:LENDING.VALUE:DL:
            ASST.HOLD.DATA := LENDING.RATE:DL:EXCEPTION.FLAG:DL:EXCEP.EXPIRY.DATE:DL:BORROWER.CIF:DL:
            ASST.HOLD.DATA := PLEDGE.CIF:DL:PERCENTAGE.ALLOC:DL:SAM.ID:DL:APPLN:DL:CATEG
            ASST.HOLD.DATA := DL:Y.COST.PRICE        ;* CAP rolling release phase2 requirement S/E
            ASST.HOLD.DATA:= DL:SAM.REF.CCY:DL:HOLD.REF.CCY       ;* RMWB_Client_Portfolio_S/E
            ASST.HOLD.DATA := DL:Y.DEPOSITORY        ;* 15002404
*TAP Enable CR - Start
            ASST.HOLD.DATA :=DL:Y.ACCRUED.AMT
*TAP Enable CR - End
*ENABLE CR - Start
            ASST.HOLD.DATA :=DL:CUS.STAT
*ENABLE CR - End
*Enable 1.2 CR_Start
            GOSUB CUST.STATUS.DESC
            ASST.HOLD.DATA :=DL:Y.MARKET.PRICE:DL:Y.EXCHANGE.RATE:DL:MVAL.PFOLIO.CCY:DL:Y.ACCRUED.INT.PFOLIO.CCY:DL:Y.CUSTOMER.STATUS.DESC
*Enable 1.2 CR_End
*            GOSUB FORMAT.EXTRACT
            GOSUB WRITE.ASST.LIAB
            END
			END
*            END           ;* CM0000000578880 E
*
SKIP.MD:
        NEXT ONE.MULTI.VAL
*


	RETURN
*----------------------------------------------------------------------	
GET.PORTFOLIO.CCY:
*---------------------
	BEGIN CASE
        CASE SAM.REF.CCY EQ SEC.CCY
            Y.EXCHANGE.RATE = '1'
            IF Y.ACCRUED.AMT THEN
                Y.ACCRUED.INT.PFOLIO.CCY = ''
                Y.ACCRUED.INT.PFOLIO.CCY = Y.ACCRUED.AMT
            END
        CASE SAM.REF.CCY NE SEC.CCY
            SELL.CCY = '' ; VALUE.HOLD = ''
            SELL.CCY = SAM.REF.CCY
            VALUE.HOLD = Y.ACCRUED.AMT
            GOSUB CCY.CONV
            Y.DIFF = ''
            Y.DIFF = DIFFERENCE
            Y.EXCHANGE.RATE = EXCHANGE.RATE
            GOSUB GET.ANYLD.EX.RATE
            IF INVERSE.EXCH.RATE EQ 'N' THEN
                Y.EXCHANGE.RATE = 1/Y.EXCHANGE.RATE
            END
            IF Y.ACCRUED.AMT THEN
                Y.ACCRUED.INT.PFOLIO.CCY = ''
                Y.ACCRUED.INT.PFOLIO.CCY = SELL.AMT
            END
    END CASE	
	RETURN
*-----------------------------------------------------------------------------
* RMWB_Client_Portfolio_S
CCY.CONV:
*--------

    SELL.AMT = ''
    BASE.CCY = ''
    EXCHANGE.RATE = ''
    DIFFERENCE = ''
    LCY.AMT = ''
    RETURN.CODE = ''
    CALL EXCHRATE('1',SEC.CCY,VALUE.HOLD,SELL.CCY,SELL.AMT,BASE.CCY,EXCHANGE.RATE,DIFFERENCE,LCY.AMT,RETURN.CODE)
RETURN
* RMWB_Client_Portfolio_E

*-----------------------------------------------------------------------------

*Enable 1.2 CR_Start
GET.ANYLD.EX.RATE:
******************
*
    INVERSE.EXCH.RATE = 'N'
    BUY.CCY = ''
    BUY.CCY = SEC.CCY
*
    IF Y.DIFF THEN
        IF BASE.CCY EQ BUY.CCY THEN
            Y.BASE.CCY.TMP = SELL.CCY
        END ELSE
            Y.BASE.CCY.TMP = BUY.CCY
        END
    END ELSE
        Y.BASE.CCY.TMP = BASE.CCY
    END
*
    IF BUY.CCY NE Y.BASE.CCY.TMP THEN
        INVERSE.EXCH.RATE = 'Y'
    END

RETURN

******
WRITE.ASST.LIAB:
****************
	
* TAFJUPG-MVM - sugumar start
    OPENSEQ AMEX.FILES,FILE.NAME TO FP.AMEX.FILES ELSE
*        CALL OCOMO("UNABLE TO OPEN AMEX FILES")
    END
    WRITESEQ ASST.HOLD.DATA APPEND TO FP.AMEX.FILES ELSE
        CALL OCOMO("UNABLE TO WRITE AL LIAB FILE EXTRACT")
    END
    CLOSESEQ FP.AMEX.FILES
***********
*    OPENSEQ AMEX.FILES,TEMP.FILE.NAME TO FV.AMEX.FILES ELSE
*        CALL OCOMO("UNABLE TO OPEN AMEX FILES-FV")
*    END

*    WRITESEQ Y.TEMP.NUM APPEND TO FV.AMEX.FILES ELSE
*        CALL OCOMO("UNABLE TO WRITE AL LIAB FILE EXTRACT-TEMP")
*    END
*    CLOSESEQ FV.AMEX.FILES
**************

****Recon_Reports**** - Start
    CIF.CNT += 1

RETURN
*-----------------------------------------------------------------------------
*Enable 1.2 CR_Start
*
CUST.STATUS.DESC:
****************
*
    R.CUSTOMER.STATUS = ''
    ERR.CUSTOMER.STATUS = ''
    Y.CUSTOMER.STATUS.DESC = ''
    CALL F.READ(FN.CUSTOMER.STATUS,CUS.STAT,R.CUSTOMER.STATUS,F.CUSTOMER.STATUS,ERR.CUSTOMER.STATUS)
    Y.CUSTOMER.STATUS.DESC = R.CUSTOMER.STATUS<EB.CST.DESCRIPTION,1>
    
  *  CONVERT @VM TO "|" IN Y.CUSTOMER.STATUS.DESC
  Y.CUSTOMER.STATUS.DESC = Y.CUSTOMER.STATUS.DESC[1,15]
*
RETURN
*Enable 1.2 CR_End
*------------------------------------------------------------------------------
END
