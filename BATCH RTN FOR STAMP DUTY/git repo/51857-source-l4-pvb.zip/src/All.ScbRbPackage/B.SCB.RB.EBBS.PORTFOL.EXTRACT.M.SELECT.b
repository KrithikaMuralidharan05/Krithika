$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EBBS.PORTFOL.EXTRACT.M.SELECT
*---------------------------------------------------------------------------------------------------------------
* 
* 
*-----------------------------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
*-----------------------------------------------------------------------------------------------------------------
*
* 25/08/2022 - Shreekantha. G - CPSGMIG-5864
*
* 20/10/2022 - Swaminathan.S.R - CPSGMIG-13848 - Report modification to send ISA details
*                                Copy of existing B.SCB.RB.EBBS.PORTFOL.EXTRACT routine + ISA Details added as per CPSGMIG-13848
** 24-Mar-2023 - Lavanya L - CPSGMIG-21169 - Tranche requirement
*-----------------------------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.EBBS.PORTFOL.EXT.M.COMMON
    $INSERT I_F.SEC.ACC.MASTER
*
    SEL.CMD = 'SELECT ':FN.SEC.ACC.MAST:' WITH L.O.B EQ 8'
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
		CALL BATCH.BUILD.LIST('',SEL.LIST)
    END	
*
    RETURN
*
*-----------------------------------------------------------------------------------------------------------------
END
*-----------------------------------------------------------------------------------------------------------------