$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.EDM.SOO.EXTRACT.SELECT
**-------------------------------------------------------------------------------------------------
*
* This SELECT routine is  used for the file generation of T24_SG_RB_EDM_SOO_<yymmddhhmmss> to EDMP 
*
**-------------------------------------------------------------------------------------------------
*
* Modification History : 
*
* 22/07/2022 - Shreekantha. G  - NEW - CPSGMIG-4971
*
*--------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.RB.EDM.SEC.OPEN.COMMON
*
    SEL.CMD = "SELECT ":FN.SEC.OPEN.ORDER:" WITH L.O.B EQ '8'"
   *
    SEL.LIST = '' ; RET.CODE = '' ; NO.OF.REC = ''
*
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.REC,RET.CODE)
    IF SEL.LIST THEN
        CALL BATCH.BUILD.LIST('',SEL.LIST)
    END
*
    RETURN
*
*--------------------------------------------------------------------------------------------------
END
*--------------------------------------------------------------------------------------------------
