$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.RE.UPD.SUSP.SETT.RECS(Y.ID)
*-----------------------------------------------------------------------------
* Routine Type                 Batch Pre process routine
* Attached To                  BATCH>SNG/SCB.RB.IN.SUSP.SETT.RES.EBBS
* Workflow                     To create record in SCB.CASH.BLK.SETT for
*                              Commission entries.
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*  Author            Date                Reference              Description
*  Bharathiraja P    23-Aug-2022         CPSGMIG-387            Automation of accounting entries for commission in EBBS
*-----------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.RE.UPD.SUSP.SETT.RECS.COMMON
    $INSERT I_F.SEC.TRADE
    $INSERT I_F.SCB.CASH.BLK.SETT
    $INSERT I_F.SCB.WM.H.LOCAL.PARAM

    Y.SUSP.ID = ''
    Y.SUSP.ID = Y.ID:'.S'
    REC.SCB.CASH.BLK.SET = '' ; ER.SCB.CASH.BLK.SET = ''
    CALL F.READ(FN.APP, Y.SUSP.ID, REC.SCB.CASH.BLK.SET, F.APP, ER.SCB.CASH.BLK.SET)
    IF (ER.SCB.CASH.BLK.SET) THEN ;*Proceed to process only if the suspense entry does not exist already
        GOSUB CREATE.SUSP.ENTRY
    END
    
RETURN
*-----------------------------------------------------------------------------
*** <region name= Create Suspense Entry>:
CREATE.SUSP.ENTRY:
*** <desc>Create a record in SCB.CASH.BLK.SETT for commission. </desc>
*-----------------------------------------------------------------------------

    REC.SCB.CASH.BLK.SET = '' ; ER.SCB.CASH.BLK.SET = ''; REC.SCB.CASH.BLK.SET.SUSP = ''
    CALL F.READ(FN.APP, Y.ID, REC.SCB.CASH.BLK.SET.SUSP, F.APP, ER.SCB.CASH.BLK.SET)
    Y.SEC.TRADE.ID = ''; REC.SEC.TRADE = '' ; ER.SEC.TRADE = ''
    
*For reversal records, Read Trade record from history
    IF FIELD(Y.ID,'.',2) EQ "R" THEN
        Y.SEC.TRADE.ID = FIELD(Y.ID,'.',1):";1"
        CALL F.READ(FN.SEC.TRADE.SUSP.HIS, Y.SEC.TRADE.ID, REC.SEC.TRADE, F.SEC.TRADE.SUSP.HIS, ER.SEC.TRADE)
        Y.TXN.CODE = "D"
    END ELSE
        Y.SEC.TRADE.ID = Y.ID
        CALL F.READ(FN.SEC.TRADE.SUSP, Y.SEC.TRADE.ID, REC.SEC.TRADE, F.SEC.TRADE.SUSP, ER.SEC.TRADE)
        Y.TXN.CODE = "C"
    END

*Calculate Commission amount by Trade type
    IF NOT(ER.SEC.TRADE) THEN
        GOSUB GET.COMM.AMT
    END
        
RETURN
*-----------------------------------------------------------------------------
*** <region name= Write Cash Block Sett Record>:
GET.COMM.AMT:
*** <desc>Write the suspense entry in SCB.CASH.BLK.SETT </desc>
*-----------------------------------------------------------------------------
    Y.TXN.TYPE = REC.SEC.TRADE<SC.SBS.CUST.TRANS.CODE>
    IF Y.TXN.TYPE = 'BUY' OR Y.TXN.TYPE = 'SEL' THEN ;*For FI/SN Trades
        Y.CU.NET.AMT = REC.SEC.TRADE<SC.SBS.CU.NET.AM.TRD>
        Y.BR.NET.AMT = REC.SEC.TRADE<SC.SBS.BR.NET.AM.TRD>
        Y.COMM.AMT = ABS(Y.CU.NET.AMT - Y.BR.NET.AMT)
    END ELSE ;*For MF
        Y.CU.CHG.TX.AMT = REC.SEC.TRADE<SC.SBS.CU.CHARGE.TAX.AMT>
        Y.COMM.AMT = SUM(Y.CU.CHG.TX.AMT)
        IF Y.COMM.AMT < 0 THEN ;*For cool-off trades, comm amt will be negative
            Y.TXN.CODE = "D"
            Y.COMM.AMT = ABS(Y.COMM.AMT)
        END
    END
    
    IF (Y.COMM.AMT) AND Y.COMM.AMT NE 0 THEN
        GOSUB WRITE.CASH.BLK.SETT
    END
    
RETURN
*-----------------------------------------------------------------------------
*** <region name= Write Cash Block Sett Record>:
WRITE.CASH.BLK.SETT:
*** <desc>Write the suspense entry in SCB.CASH.BLK.SETT </desc>
*-----------------------------------------------------------------------------

    REC.SCB.CASH.BLK.SET.SUSP<S.TYPE>               = "SUSPENSE"
    REC.SCB.CASH.BLK.SET.SUSP<S.TRANSACTION.CODE>   = Y.TXN.CODE
    REC.SCB.CASH.BLK.SET.SUSP<S.EBBS.BLK.REF>       = ''
    REC.SCB.CASH.BLK.SET.SUSP<S.BLOCK.AMOUNT>       = Y.COMM.AMT
    REC.SCB.CASH.BLK.SET.SUSP<S.CASA.ACCOUNT>       = Y.EBBS.SUSP.ACCT
    REC.SCB.CASH.BLK.SET.SUSP<S.BLOCK.STATUS>       = "BLK_NOT_REQD"
    REC.SCB.CASH.BLK.SET.SUSP<S.SETT.STATUS>        = "SUSP_TO_BE_SETTLED"
    REC.SCB.CASH.BLK.SET.SUSP<S.STATUS.DATE>        = TODAY
    REC.SCB.CASH.BLK.SET.SUSP<S.BLK.CREATE.DATE>    = ''
    REC.SCB.CASH.BLK.SET.SUSP<S.RES.CODE>           = ''
    REC.SCB.CASH.BLK.SET.SUSP<S.RES.DESC>           = ''


    CALL F.WRITE(FN.APP, Y.SUSP.ID, REC.SCB.CASH.BLK.SET.SUSP)
    
RETURN

END
