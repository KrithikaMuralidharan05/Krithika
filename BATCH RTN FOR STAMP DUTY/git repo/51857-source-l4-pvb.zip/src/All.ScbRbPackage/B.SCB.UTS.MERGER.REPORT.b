* @ValidationCode : MjoxOTg0OTc2MzA3OklTTy04ODU5LTE6MTY2NTcxOTgwOTUyMzoxNjYzMDAwOi0xOi0xOjA6MDpmYWxzZTpOL0E6UjIwX1NQMTAuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 14 Oct 2022 09:26:49
* @ValidationInfo : Encoding          : ISO-8859-1
* @ValidationInfo : User Name         : 1663000
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R20_SP10.0
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.UTS.MERGER.REPORT(YUTSTRADE)
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-5332 - JEWEL_T24_PROJECT
* Developed By                   :       1663000
* Developed On                   :       13 October 2022
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Process Routine to extract Trade details for Subscription, Redemption , SwitchIn & SwitchOut
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>SCB.UTS.MERGER.REPORT
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* Date          Author           Description
*
*--------------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.UTS.MERGER.REPORT.COMMON
*--------------------------------------------------------------------------------------------

    GOSUB DO.PROCESS

RETURN
*---------*
DO.PROCESS:
*---------*
    
    YUTSARG1 = ',|':YUTSTRADE
    YUTSARG2 = ''
        
    CALL SCB.C.GET.UTS.MERGER.TRADE.DETS(YUTSARG1,YUTSARG2)             ;* Called Routine to fetch Trade details
    
* Write into file
    IF YUTSARG2 THEN
        OPENSEQ AMEX.FILES,Y.UTS.TEMP.FILE TO FP.AMEX.FILES ELSE
        END
        WRITESEQ YUTSARG2 APPEND TO FP.AMEX.FILES ELSE
            CALL OCOMO("Unable to Write UTS Merger Report")
        END
        CLOSESEQ FP.AMEX.FILES
    END

RETURN
END
