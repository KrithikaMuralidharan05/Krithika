*--------------------------------------------------------------------------------------------
$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.IBANKING.PREPROCESS
*--------------------------------------------------------------------------------------------
* Project Name                   :       CPSGMIG-27441 - JEWEL_T24_PROJECT
* Developed By                   :       1648769
* Developed On                   :       03 June 2023
*--------------------------------------------------------------------------------------------
* Description:
*-------------
* Single thread routine to pre-process the ebk_t24_custidlist_YYYYMMDD.txt records to update the records in the IBANKING_RELIDS.txt 
*--------------------------------------------------------------------------------------------
* Called From:  BATCH>B.SCB.IBANKING.PREPROCESS
*--------------------------------------------------------------------------------------------
* Modification History:
*----------------------
* 03/07/2023             1670271                 Absolute file path is provided to rename file in "&SAVEDLISTS&".
*--------------------------------------------------------------------------------------------

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.SEC.ACC.MASTER
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT                             
*--------------------------------------------------------------------------------------------
 
    IF ID.COMPANY[1,2] EQ "SG" THEN
        GOSUB INITIALISE
        GOSUB DO.RENAME.FILE                         
        GOSUB DO.PROCESS
    END

RETURN
*---------*
INITIALISE:
*---------*
    
    FN.SL               = '&SAVEDLISTS&'                  ; F.SL              = '' ; CALL OPF(FN.SL,F.SL)
    FN.AMEX             = 'AMEX.FILES'                    ; F.AMEX            = '' ; CALL OPF(FN.AMEX,F.AMEX)
    FN.EBBS.REL.CONCAT  = 'F.ST.SCB.RSG.EBBS.REL.CONCAT'  ; F.EBBS.REL.CONCAT = '' ; CALL OPF(FN.EBBS.REL.CONCAT,F.EBBS.REL.CONCAT)
  
    ARG2 = ''
    SAVE.LIST.PATH = ''
    ARG3 = ''
    AMEX.LIST.PATH = ''
    CALL SCB.GET.ORACLE.FILENAME(FN.SL, ARG2, SAVE.LIST.PATH)
    CALL SCB.GET.ORACLE.FILENAME(FN.AMEX, ARG3, AMEX.LIST.PATH)    
    
    Y.FUND.REQ.FILE = FIELD(BATCH.DETAILS<3,1>,'*',1)
    Y.IBANKING.FILE = FIELD(BATCH.DETAILS<3,1>,'*',2)
    CALL B.SCB.C.CONV.FILE.NAME(Y.FUND.REQ.FILE)
    CALL B.SCB.C.CONV.FILE.NAME(Y.IBANKING.FILE)
    
RETURN
*--------------*
DO.RENAME.FILE:
*--------------*
    Y.IBANKING.RENAME.FILE = FIELD(Y.IBANKING.FILE,'.',1)
    Y.IBANKING.RENAME.FILE = Y.IBANKING.RENAME.FILE:"_":"<LSYSDATE>":".txt"
    CALL B.SCB.C.CONV.FILE.NAME(Y.IBANKING.RENAME.FILE)

    CHANGE '&SAVEDLISTS&' TO '"&SAVEDLISTS&"' IN SAVE.LIST.PATH

    EXE.CMD = "SH -c 'mv ":SAVE.LIST.PATH:"/":Y.IBANKING.FILE:" ":SAVE.LIST.PATH::"/":Y.IBANKING.RENAME.FILE:"'"
    EXECUTE EXE.CMD

RETURN
*---------*
DO.PROCESS:
*---------*
    
    OPEN AMEX.LIST.PATH TO AMEX.PATH THEN
        READ R.FILE.DATA FROM AMEX.PATH,Y.FUND.REQ.FILE THEN            
            LOOP
                REMOVE Y.REL.ID FROM R.FILE.DATA SETTING Y.REL.POS
            WHILE Y.REL.ID : Y.REL.POS
                IF Y.REL.ID[1,1] EQ 'D' THEN
                    Y.REL.ID.TMP = Y.REL.ID[2,99]
                    Y.REL.ID     = TRIM(Y.REL.ID.TMP, "", "D")
                
                    R.EBBS.REL.CONCAT = '' ; ERR.REL.CONCAT = ''                                            ;* Get CustomerNo from EBBS Concat file
                    CALL F.READ(FN.EBBS.REL.CONCAT,Y.REL.ID,R.EBBS.REL.CONCAT,F.EBBS.REL.CONCAT,ERR.REL.CONCAT)
    
                    IF R.EBBS.REL.CONCAT THEN
                        Y.MANDATE.KEY = R.EBBS.REL.CONCAT<ST.RSG.EBBS.MANDATE.KEY>
                        CHANGE @VM TO @FM IN Y.MANDATE.KEY
                        Y.CUST.ID.CNT = DCOUNT(Y.MANDATE.KEY,@FM)
                    
                        LOOP
                            REMOVE Y.CUS.ID FROM Y.MANDATE.KEY SETTING Y.CUS.POS
                        WHILE Y.CUS.ID : Y.CUS.POS
                            LOCATE Y.CUS.ID IN Y.HOLDING.CUS.ARR SETTING Y.HOLD.POS THEN
                                CALL OCOMO("Duplicate Customer - ":Y.CUS.ID: "Found in the File.Hence ignored")
                            END ELSE
                                Y.HOLDING.CUS.ARR<-1> = Y.CUS.ID
                            END
                        REPEAT
                    END ELSE
                        CALL OCOMO("Rel Id ":Y.REL.ID:" not found in ST.SCB.RSG.EBBS.REL.CONCAT file")
                    END
                END
            REPEAT
                
        END ELSE
            CALL OCOMO("Unable to read iBanking Request file from In-Directory")
        END
    END ELSE
        CALL OCOMO("Unable to open iBanking Request File")
    END
    
    IF Y.HOLDING.CUS.ARR THEN                                     
         WRITE Y.HOLDING.CUS.ARR TO F.SL,Y.IBANKING.FILE
    END                                                           

RETURN
END
