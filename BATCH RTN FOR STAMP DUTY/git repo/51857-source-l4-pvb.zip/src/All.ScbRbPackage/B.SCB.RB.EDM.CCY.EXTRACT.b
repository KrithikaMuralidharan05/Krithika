$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>240</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.EDM.CCY.EXTRACT
*******************************************************************************
* Modification History:
*----------------------
* 16-Jun-2022 - CPSGMIG-3789 - Shreekantha. G - Copy of the existing routine B.SCB.EDM.CCY.EXTRACT
*******************************************************************************
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_F.CURRENCY
    $INSERT I_F.DATES         ;* 15002404
*
    GOSUB INIT
    GOSUB PROCESS
*
RETURN
*******************************************************************************
INIT:
****
    FN.CURRENCY = 'F.CURRENCY'
    F.CURRENCY = ''
    CALL OPF(FN.CURRENCY,F.CURRENCY)
*
    FN.AMEX.FILES = 'AMEX.FILES'
    F.AMEX.FILES = ''
    CALL OPF(FN.AMEX.FILES,F.AMEX.FILES)
*
	DL = CHAR(01)					;* CTRL A 
    Y.HEADER = ''								;*CPSGMIG-3789-S-E
    Y.FINAL.FILE.NAME = '' ; Y.COMP.NAME = ''
    R.CCY.RPT.ARR = ''
*
**Headers** CPSGMIG-3789 - S	
	Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.HEADER = 'H':DL:'T24':DL:'SG':DL:Y.LAST.WRK.DAY
    Y.HEADER<-1> = 'D':DL:'ID':DL:'CURRENCY_CODE':DL:'RANK':DL:'NUMERIC_CCY_CODE':DL:'CCY_NAME':DL
    Y.HEADER:= 'NO_OF_DECIMALS':DL:'INTEREST_DAY_BASIS':DL:'CURRENCY_MARKET':DL:'MID_REVAL_RATE':DL:'DEFAULT_SPREAD':DL
    Y.HEADER:= 'BUY_RATE':DL:'SELL_RATE':DL:'MIN_ROUND_TYPE':DL:'PRECIOUS_METAL':DL:'COUNTRY_CODE'
*    Y.HEADER:= 'TRUST_D_M,EXCH_RATE,LAST_WRK_DAY,TODAY_DATE,NEXT_WRK_DAY'
**Headers** CPSGMIG-3789 - E

    Y.COMP.NAME = ID.COMPANY[1,2]
   
    Y.FINAL.FILE.NAME = Y.COMP.NAME:"-RB-CURRENCY-":TODAY:".CSV"		;*CPSGMIG-3789 - S/E
*WS-32716 - S
    Y.TODAY.DATE   = TODAY
    Y.LAST.WRK.DAY = R.DATES(EB.DAT.LAST.WORKING.DAY)
    Y.NEXT.WRK.DAY = R.DATES(EB.DAT.NEXT.WORKING.DAY)
*WS-32716 - E

RETURN
*******************************************************************************
PROCESS:
********
    SEL.CMD = '' ; SEL.LIST = '' ; NO.OF.RECS = '' ; SEL.ERR = ''
    SEL.CMD = "SELECT ":FN.CURRENCY
	TOTAL.LINE.COUNT = 0							;*CPSGMIG-3789 - Trailer
    CALL EB.READLIST(SEL.CMD,SEL.LIST,'',NO.OF.RECS,SEL.ERR)
    IF SEL.LIST THEN
        LOOP
            REMOVE CCY.ID FROM SEL.LIST SETTING SEL.POS
        WHILE CCY.ID:SEL.POS
            R.CCY.REC = '' ; CCY.ERR = ''
            CALL F.READ(FN.CURRENCY,CCY.ID,R.CCY.REC,F.CURRENCY,CCY.ERR)
            IF R.CCY.REC THEN
* 15002404 - S
                Y.AMT2 = ''
                Y.BASE.CCY = ''
                Y.EXCH.RATE = ''
                Y.DIFF = ''
                Y.LCYAMT = ''
                Y.TRUST.D.M = ''
                Y.USD.RATE = ''
                CALL EXCHRATE(1,'USD','1',CCY.ID,Y.AMT2,Y.BASE.CCY,Y.EXCH.RATE,Y.DIFF,Y.LCYAMT,'')
                IF Y.BASE.CCY EQ 'USD' THEN Y.TRUST.D.M = 'D' ELSE Y.TRUST.D.M = 'M'
* 15002404 - E
                GOSUB ADD.ARRAY
            END
			TOTAL.LINE.COUNT = TOTAL.LINE.COUNT + 1			;*CPSGMIG-3789 - Tailer
        REPEAT
    END
    Y.FINAL.ARR = ''
    Y.FINAL.ARR = Y.HEADER:FM:R.CCY.RPT.ARR
	Y.FINAL.ARR :=@FM:'T':DL:TOTAL.LINE.COUNT				;*CPSGMIG-3789-S-E-Trailer
	*Y.FINAL.ARR = R.CCY.RPT.ARR
    Y.FINAL.ARR = UTF8(Y.FINAL.ARR)							;* changing the file to UTF-8 format
    GOSUB WRITE.AMEX.FILE
*
RETURN
*******************************************************************************
ADD.ARRAY:
*********
    IF R.CCY.RPT.ARR EQ '' THEN
        R.CCY.RPT.ARR = 'D':DL:CCY.ID:DL:CCY.ID:DL:R.CCY.REC<EB.CUR.RANK>
        R.CCY.RPT.ARR := DL:R.CCY.REC<EB.CUR.NUMERIC.CCY.CODE>:DL:R.CCY.REC<EB.CUR.CCY.NAME>:DL:R.CCY.REC<EB.CUR.NO.OF.DECIMALS>
        R.CCY.RPT.ARR := DL:R.CCY.REC<EB.CUR.INTEREST.DAY.BASIS>:DL:R.CCY.REC<EB.CUR.CURRENCY.MARKET>:DL:R.CCY.REC<EB.CUR.MID.REVAL.RATE>
        R.CCY.RPT.ARR := DL:R.CCY.REC<EB.CUR.DEFAULT.SPREAD>:DL:R.CCY.REC<EB.CUR.BUY.RATE>:DL:R.CCY.REC<EB.CUR.SELL.RATE>
        R.CCY.RPT.ARR := DL:R.CCY.REC<EB.CUR.MIN.ROUND.TYPE>:DL:R.CCY.REC<EB.CUR.PRECIOUS.METAL>:DL:R.CCY.REC<EB.CUR.COUNTRY.CODE>
*        R.CCY.RPT.ARR := ',':Y.TRUST.D.M:',':Y.EXCH.RATE    ;* 15002404
*        R.CCY.RPT.ARR := ',':Y.LAST.WRK.DAY:',':Y.TODAY.DATE:',':Y.NEXT.WRK.DAY ;*WS-32716 S/ E
    END ELSE
        TEMP.ARR = ''
        TEMP.ARR = 'D':DL:CCY.ID:DL:CCY.ID:DL:R.CCY.REC<EB.CUR.RANK>
        TEMP.ARR := DL:R.CCY.REC<EB.CUR.NUMERIC.CCY.CODE>:DL:R.CCY.REC<EB.CUR.CCY.NAME>:DL:R.CCY.REC<EB.CUR.NO.OF.DECIMALS>
        TEMP.ARR := DL:R.CCY.REC<EB.CUR.INTEREST.DAY.BASIS>:DL:R.CCY.REC<EB.CUR.CURRENCY.MARKET>:DL:R.CCY.REC<EB.CUR.MID.REVAL.RATE>
        TEMP.ARR := DL:R.CCY.REC<EB.CUR.DEFAULT.SPREAD>:DL:R.CCY.REC<EB.CUR.BUY.RATE>:DL:R.CCY.REC<EB.CUR.SELL.RATE>
        TEMP.ARR := DL:R.CCY.REC<EB.CUR.MIN.ROUND.TYPE>:DL:R.CCY.REC<EB.CUR.PRECIOUS.METAL>:DL:R.CCY.REC<EB.CUR.COUNTRY.CODE>
*        TEMP.ARR := ',':Y.TRUST.D.M:',':Y.EXCH.RATE         ;* 15002404
*        TEMP.ARR := ',':Y.LAST.WRK.DAY:',':Y.TODAY.DATE:',':Y.NEXT.WRK.DAY      ;*WS-32716 S/ E
        R.CCY.RPT.ARR<-1> = TEMP.ARR
    END
RETURN
*******************************************************************************
WRITE.AMEX.FILE:
****************
    CALL F.WRITE(FN.AMEX.FILES,Y.FINAL.FILE.NAME,Y.FINAL.ARR)
RETURN
*******************************************************************************
END
