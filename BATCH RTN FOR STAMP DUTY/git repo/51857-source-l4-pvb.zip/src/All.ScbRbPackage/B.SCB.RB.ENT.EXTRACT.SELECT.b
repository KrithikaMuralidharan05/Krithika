$PACKAGE All.ScbRbPackage
*-----------------------------------------------------------------------------
* <Rating>-69</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE B.SCB.RB.ENT.EXTRACT.SELECT

    ! DESCRIPTION : THIS LOAD FILE WILL LOAD ALL THE ENTITLEMENT TRASACTION
* Copy of existing B.SCB.ENT.PBDW.EXTRACT.SELECT with change in select and include LOB logic for RB.
* Revision History:
*------------------
*   Date               who           Reference            Description
* 27-Jul-2022       Lavanya L       CPSGMIG-4231       Initial Creation
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_B.SCB.RB.ENT.EXTRACT.COMMON
    $INSERT I_BATCH.FILES     ;* 15002404



* 15002404 - S
    IF NOT(CONTROL.LIST) THEN
*        CONTROL.LIST = "ENT.LIVE":@FM:"ENT.REVE":@FM:"ENT.RIGHTS" 		;*TAFJUPG - S/E
		CONTROL.LIST = "ENT.LIVE":@FM:"ENT.REVE"
    END


    BEGIN CASE

        CASE CONTROL.LIST<1,1> = "ENT.LIVE"
* 15002404 - E

            IF ID.COMPANY EQ "SG1090400" THEN         ;* QC-574 S/E For SNG, ACU transactions should be included.
                SEL.CMD = "SELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":COUNTRY.NAME:"...*DIAR..."
*
* QC-574 Start
*
            END ELSE    ;* For HKB, since COUNTRY.NAME based selection includes HKW transactions also
                SEL.CMD = "SELECT ":FN.SEC.TRD.TODAY:" WITH @ID LIKE ":ID.COMPANY:"...*DIAR..."         ;* ID.COMPANY is used instead
            END
*
* QC-574 End
*
* 15002404 - S
            CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
*        CALL BATCH.BUILD.LIST('ST.LIST',SEC.ID)
            CALL BATCH.BUILD.LIST('',SEC.ID)

        CASE CONTROL.LIST<1,1> = "ENT.REVE"
            SEL.CMD = ''
            IF ID.COMPANY EQ "SG1090400" THEN
                SEL.CMD = "SELECT ":FN.SEC.TRD.REV:" WITH @ID LIKE ":COUNTRY.NAME:"...*DIAR..."
            END ELSE
                SEL.CMD = "SELECT ":FN.SEC.TRD.REV:" WITH @ID LIKE ":ID.COMPANY:"...*DIAR..."
            END
            CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
            CALL BATCH.BUILD.LIST('',SEC.ID)



    
*        CASE CONTROL.LIST<1,1> = "ENT.RIGHTS"
         
* TAFJUPG_S
 *           Y.DT.TIME = TODAY[3,6]:"0000"
 *           SEL.CMD = "SELECT ":FN.ENTITLEMENT:" WITH OPT.STATUS EQ 'PENDING' AND OPTION.DESC EQ 'RIGHTS' AND DATE.TIME GE ":Y.DT.TIME
 *            SEL.CMD = "SELECT ":FN.ENTITLEMENT:" WITH OPT.STATUS EQ 'PENDING'"
 *            SEL.CMD = "SELECT ":FN.ENTITLEMENT
* ;* TAFJUPG_E
  *          CALL EB.READLIST(SEL.CMD,SEC.ID,'',NO.OF.IDS,SEC.ERR)
  *          CALL BATCH.BUILD.LIST('',SEC.ID)

    END CASE
* 15002404 - E
RETURN
END
