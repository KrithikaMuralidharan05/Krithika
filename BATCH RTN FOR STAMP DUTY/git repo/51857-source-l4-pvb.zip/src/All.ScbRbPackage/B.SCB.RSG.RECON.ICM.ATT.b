$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RSG.RECON.ICM.ATT(R.DETS.ARR)
*-----------------------------------------------------------------------------
*
*--------------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
*Jira Reference:CPSGMIG-17414
*Developer : Raja Prabhu S
*Date : 14-APR-2023
*Description : Used to extract the details from ICM  for recon against the data from t24
*O/p : NA
*---------------------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_BATCH.FILES
    $INSERT I_B.SCB.RSG.RECON.ICM.ATT.COMMON
    $INSERT I_F.CUSTOMER
    $INSERT I_F.ST.SCB.RSG.EBBS.REL.CONCAT
       
    GOSUB INIT
    GOSUB PROCESS
   
RETURN

*----------
INIT:
*---------
    Y.REL.ID = FIELD(R.DETS.ARR,'|',2)
    Y.ADD.CODE = FIELD(R.DETS.ARR,'|',5)
    Y.W8.FLAG =""
    Y.W8.EXP.DTE =""
    Y.W9.FLAG =""
    Y.W9.EXP.DTE =""
    Y.NAT=FIELD(R.DETS.ARR,'|',4)
    Y.RES =FIELD(R.DETS.ARR,'|',3)
    Y.DOC.TYPE = FIELD(R.DETS.ARR,'|',6)
    Y.DOC.EXP.DTE = FIELD(R.DETS.ARR,'|',7)
    Y.US.PERSON =FIELD(R.DETS.ARR,'|',9)
    Y.EU.CHK.COUNTRIES = "AT":@VM:"BE":@VM:"BG":@VM:"HR":@VM:"CY":@VM:"CZ":@VM:"DK":@VM:"EE":@VM:"FI":@VM:"FR":@VM:"DE":@VM:"GR":@VM:"HU":@VM:"IS":@VM:"IE":@VM:"IT":@VM:"LV":@VM:"LI":@VM:"LT":@VM:"LU":@VM:"MT":@VM:"NL":@VM:"NO":@VM:"PL":@VM:"PT":@VM:"RO":@VM:"SK":@VM:"SI":@VM:"ES":@VM:"SE":@VM:"GB"
    CHANGE '-' TO ' ' IN Y.DOC.EXP.DTE
    
    IF Y.DOC.TYPE EQ 'W8N' THEN
        Y.W8.FLAG = 'Y'
        Y.W8.EXP.DTE=OCONV(ICONV(Y.DOC.EXP.DTE,'D2'),'D/E')
        Y.W8.CURR.DT = FIELD(Y.W8.EXP.DTE,'/',3):FIELD(Y.W8.EXP.DTE,'/',2):FIELD(Y.W8.EXP.DTE,'/',1)
    END

    IF Y.DOC.TYPE EQ 'W9N' THEN
        Y.W9.FLAG = 'Y'
        Y.W9.EXP.DTE=OCONV(ICONV(Y.DOC.EXP.DTE,'D2'),'D/E')
        Y.W9.CURR.DT = FIELD(Y.W9.EXP.DTE,'/',3):FIELD(Y.W9.EXP.DTE,'/',2):FIELD(Y.W9.EXP.DTE,'/',1)
    END
    
    IF Y.RES EQ 'AU' THEN
        Y.AU.PERSON = 'Y'
    END ELSE
        Y.AU.PERSON = 'N'
    END

    IF Y.RES EQ 'NZ' THEN
        Y.NZ.PERSON = 'Y'
    END ELSE
        Y.NZ.PERSON = 'N'
    END

	IF Y.RES MATCHES Y.EU.CHK.COUNTRIES THEN
        Y.EU.PERSON = 'Y'
    END ELSE
        Y.EU.PERSON = 'N'
    END
    

    
RETURN

*-----------
PROCESS:
*------------

    Y.DUB.POS = ''
    CALL F.READ(FN.EBBS.CONCAT,Y.REL.ID,R.EBBS.CONCAT,F.EBBS.CONCAT,EBBS.ERR)
    IF R.EBBS.CONCAT THEN
        Y.MAN.KEY=R.EBBS.CONCAT<ST.RSG.EBBS.MANDATE.KEY>
        CHANGE @VM TO '-' IN Y.MAN.KEY
        R.DETS.ARR =  Y.REL.ID:'|': Y.ADD.CODE:'|':Y.W8.FLAG:'|':Y.W8.CURR.DT:'|':Y.W9.FLAG:'|':Y.W9.CURR.DT:'|':Y.NAT:'|':Y.US.PERSON:'|':Y.AU.PERSON:'|':Y.NZ.PERSON:'|':Y.EU.PERSON:'|':Y.MAN.KEY
        GOSUB WRITE.FILE
    END ELSE
        R.EXP.ARR1 = Y.REL.ID:" - Missing in EBBS.REL.CONCAT table"
        WRITESEQ R.EXP.ARR1 APPEND TO Y.EXP.FILEPATH ELSE
            CALL OCOMO("Exception can't write")
        END
    END
RETURN

*--------------
WRITE.FILE:
*----------------

    WRITESEQ R.DETS.ARR APPEND TO Y.NS.FILEPATH ELSE
        CALL OCOMO("WRITE  EXTRACT FOR RECON.ICM.ATT")
    END
    
RETURN
*-----------------------------------------------------------------------
END