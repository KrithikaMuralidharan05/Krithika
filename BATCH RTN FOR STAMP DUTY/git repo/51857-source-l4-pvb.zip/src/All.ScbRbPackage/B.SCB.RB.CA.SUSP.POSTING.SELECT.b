$PACKAGE All.ScbRbPackage
SUBROUTINE B.SCB.RB.CA.SUSP.POSTING.SELECT
*-------------------------------------------------------------------------------------------------------
* Author                       Tejomurthy M
* EPACC/Story/Sub task Ref     CPSGMIG-662
* Routine Type                 Batch process routine
* Attached To                  BATCH>SNG/B.SCB.RB.CA.SUSP.PROCESS
* Workflow                     This routine will read ACCT Entry table to identify Suspense Entry
*                              raised under PVB Category for RB Client on DIARY Transaction and
*                              arrange contra posting for PVB and actual posting for RB Susp Category.
*-------------------------------------------------------------------------------------------------------
* Modification History :
************************
*     Author              Date          Reference      Description
*-------------------------------------------------------------------------------------------------------
*  Tejomurthy M        02/Sep/2022     CPSGMIG-662    Initial Draft
*-------------------------------------------------------------------------------------------------------
*
    $INSERT I_COMMON
    $INSERT I_EQUATE
  	$INSERT I_B.SCB.RB.CA.SUSP.POSTING.COMMON
	
	GOSUB INIT
    GOSUB PROCESS
	
    RETURN
*-------------------------------------------------------------------------------------------------------
INIT:
*****
     
	Y.ARRAY = ''
	
    RETURN
*-------------------------------------------------------------------------------------------------------
PROCESS:
********
    
    LOOP
        REMOVE Y.CATEG.ID FROM Y.PVB.SUSP.AC.CAT SETTING POS1
    WHILE Y.CATEG.ID:POS1
        CALL F.READ(FN.CATEG.INT.ACCT,Y.CATEG.ID,R.CATEG.INT.ACCT,FP.CATEG.INT.ACCT,ERR.CATEG.INT.ACCT)
        R.PVB.SUSP.ACCT = R.CATEG.INT.ACCT
        LOOP
            REMOVE ACC.ID FROM R.PVB.SUSP.ACCT SETTING ACC.POS
        WHILE ACC.ID:ACC.POS
            R.ENTRIES = ''
            CALL F.READ(FN.ACCT.ENT.LWD,ACC.ID,R.ENTRIES,FP.ACCT.ENT.LWD,AC.ENT.ERR)
            IF R.ENTRIES THEN
                CONVERT @VM TO @FM IN R.ENTRIES
                IF Y.ARRAY THEN
                    Y.ARRAY<-1> = R.ENTRIES
                END ELSE
                    Y.ARRAY = R.ENTRIES
                END
            END
        REPEAT	
    REPEAT	
    IF (Y.ARRAY) THEN
         CALL BATCH.BUILD.LIST("", Y.ARRAY)
    END    

    RETURN
*-------------------------------------------------------------------------------------------------------
END