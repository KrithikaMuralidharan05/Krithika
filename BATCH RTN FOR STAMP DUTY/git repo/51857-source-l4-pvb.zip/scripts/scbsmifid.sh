#!/bin/sh
echo "OK, starting now..."
sftp -oPort=$1 $2@$3 <<EOF
lcd $4
cd $7
$5 $6
