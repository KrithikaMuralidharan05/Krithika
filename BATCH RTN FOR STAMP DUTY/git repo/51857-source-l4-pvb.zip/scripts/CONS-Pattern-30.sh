#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<R08_EXTRACT>> <<R20_EXTRACT>> <<CONSOLIDATED_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

echo "--R08 FILE Before--"
cat $1
wc -l $1

echo "--R20 FILE Before--"
cat $2
wc -l $2

#Remove empty lines from file
sed -i '/^\s*$/d' $1
sed -i '/^\s*$/d' $2

echo "--R08 FILE After--"
cat $1
wc -l $1

echo "--R20 FILE After--"
cat $2
wc -l $2

#Get 1st field from trailer, which is required to create new trailer
trailer=$(tail -1 $1)
field_1_trailer=$(echo ${trailer} | cut -d"|" -f1)

#Remove trailer from first and second file


result=$(sed -i'' -e '$d' $1)

sed -i'' -e '$d' $2

echo "--R08 FILE After tail last line --"
cat $1
wc -l $1

echo "--R20 FILE After tail last line --"
cat $2
wc -l $2


#Consolidate transactions from both file
cat $1 $2 > temp.csv

echo "--R08 FILE--"
cat $1
wc -l $1

echo "--R20 FILE--"
cat $2
wc -l $2

echo "--temp.csv FILE--"
cat temp.csv

#Get new record count from new file
line=$(wc -l temp.csv)
count=$(echo ${line} | cut -d" " -f1)

#Create new trailer with new total count
newtrailer=$field_1_trailer"|"$count
echo $newtrailer > trailer.txt

#Create new file
cat temp.csv trailer.txt > $3

#Remove temporarily created files in this program
rm temp.csv trailer.txt

#Remove original files
rm $1 $2

if [ $? -ne 0 ]; then
  echo "Error: Failed to Consolidate file - " $result
  exit 1
fi