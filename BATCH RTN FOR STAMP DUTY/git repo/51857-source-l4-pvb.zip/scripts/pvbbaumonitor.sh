#!/bin/ksh
#!/bin/sh
#path="/t24/dev/Temenos/T24/bnk/bnk.interface/SCB.COB.REPORT/"
path="/t24/dev/Temenos/T24/bnk/bnk.interface/AMEX.FILES/"
#filename="COB.REPORT.20211010.csv"
filename="ITRS.SERVICE"
file=$path$filename
echo "S.NO","HEADER","OUTPUT_VALUE","INSTANCE","DATE_TIME"
while IFS="," read S_NO STAGE START_TIME END_TIME ELAP_TIME
do
echo $S_NO,$STAGE,$START_TIME,$END_TIME,$ELAP_TIME
done <"$file"
