#Script starts - ECARS Daily T24 Reports Archival for File transfer
#!/usr/bin/ksh 
echo " **********ECARS Daily T24 Reports Archival - zip Script*********"
echo "\n\n\n"
todate=`date '+%Y%m%d'`

CurDir=$PWD
echo "CurDir :" $CurDir
CmodIN=$1
CmodOUT=$2
CmodARC=$3
CmodLastwd=$4
DateTime=$5
ZipFileName=$6$DateTime
T24InDir=$CurDir'/'$CmodIN
echo "T24InDir :" $T24InDir
T24OutDir=$CurDir'/'$CmodOUT
echo "T24OutDir :" $T24OutDir
T24ArcDir=$CurDir'/'$CmodARC
echo "T24ArcDir :" $T24ArcDir
if [ -d $T24InDir ]
then
   cd $T24InDir
   echo "T24InDir :" $PWD
   ls -lr *.ASC *.csv *.xls *.txt | grep -v T24Recon.txt | awk -v CFileName="$ZipFileName" '{print "T24"","CFileName".zip"","$9","$5","d}' "d=$(date +"%Y-%m-%d %r")" >T24Recon.txt
   zip -m $ZipFileName.zip *
else
   echo "Directory Missing - $T24InDir"
fi
if [ -d $T24OutDir ]
then
   cp $ZipFileName.zip $T24OutDir
   echo "File Copied to middleware path & ready for ISIS transfer"
   mv $ZipFileName.zip $T24ArcDir/$ZipFileName.zip
   echo "File Backup taken in arc folder"
else
   echo "Directory Missing - $T24OutDir"
fi
echo "Todays Date :" $todate
echo "Reports Dated :" $CmodLastwd
echo " ****************************Thank You***************************"
exit
