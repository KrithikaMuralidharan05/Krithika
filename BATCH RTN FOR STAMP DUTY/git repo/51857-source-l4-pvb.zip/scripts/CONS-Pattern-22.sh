#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<R08_EXTRACT>> <<R20_EXTRACT>> <<CONSOLIDATED_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Remove empty lines from file
sed -i '/^\s*$/d' $1
sed -i '/^\s*$/d' $2

#Remove both header(1 and 2) from second file
sed -i'' -e '1d' $2
sed -i'' -e '1d' $2

#Consolidate transactions from both file
cat $1 $2 > $3

#Remove original files
rm $1 $2