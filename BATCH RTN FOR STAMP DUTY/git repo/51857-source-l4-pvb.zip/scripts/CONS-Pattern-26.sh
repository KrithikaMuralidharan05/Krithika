#!/bin/sh

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Remove empty lines from file
sed -i '/^\s*$/d' $1
sed -i '/^\s*$/d' $2

#Get trailer and two headers which is required to create new trailer
trailer=$(tail -1 $2)
head_1=$(head -1 $2)
head_2=$(sed -n '2p' $2)

#Remove trailer/header 1 and header 2 from first and second file
sed -i'' -e '1d' -e '$d' $1
sed -i'' -e '1d' -e '$d' $2
sed -i'' -e '1d' $1
sed -i'' -e '1d' $2

#Consolidate transactions from both file
cat $1 $2 > temp.csv

#create new temporary files
echo $trailer > trailer.txt
echo $head_1 > header_1.txt
echo $head_2 > header_2.txt

#Create new file
cat header_1.txt header_2.txt temp.csv trailer.txt > $3

#Remove temporarily created files in this program
rm header_1.txt header_2.txt temp.csv trailer.txt

#Remove original files
rm $1 $2