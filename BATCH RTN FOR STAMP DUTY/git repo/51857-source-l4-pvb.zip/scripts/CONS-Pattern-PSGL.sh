#!/bin/sh

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Get record count and amount details from r08 file
r08_header=$(head -1 $1)
r08_recordCount=${r08_header:3:5}
r08_amount=${r08_header:16:26}

#Get record count and amount details from r20 file
r20_header=$(head -1 $2)
r20_recordCount=${r20_header:3:5}
r20_amount=${r20_header:16:26}

#Add the record count and amount from both files
#subtract one record count from total as we removing an header from one file while merging
recordCountTotal=$(($(($(echo $r08_recordCount | awk '{print $1 + 0}' ))) + $(($(echo $r20_recordCount | awk '{print $1 + 0}' )))))
recordCountTotal=$(($recordCountTotal-1))
amountTotal=$(($(($(echo $r08_amount | awk '{print $1 + 0}' ))) + $(($(echo $r20_amount | awk '{print $1 + 0}' )))))

#format the record count and amount with leading zeros
formatted_record_count=$(printf "%05d\n" $recordCountTotal)
formatted_amount=$(printf "%026d\n" $amountTotal)

#prepare new header for merged file with total record count and total amount
tempHeader=${r08_header//${r08_recordCount}/${formatted_record_count}}
header=${tempHeader//${r08_amount}/${formatted_amount}}

#merge both files excluding first line
{ sed '1d' $2;sed '1d' $1; } > $3

#Add the new header at the first line of merged file	
sed -i "1i $header" $3

#Remove original files
rm $1 $2
