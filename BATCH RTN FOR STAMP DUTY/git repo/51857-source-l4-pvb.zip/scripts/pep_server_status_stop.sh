#!/bin/sh

#Check if the pep server executable file exists
if [ ! -f $TAFJ_HOME/scblib/protegrity/defiance_dps/bin/pepsrvctrl ]
then
	echo $TAFJ_HOME"/scblib/protegrity/defiance_dps/bin/pepsrvctrl file does not exists"
fi

#Get the current status of PEP server.
status=`$TAFJ_HOME/scblib/protegrity/defiance_dps/bin/pepsrvctrl status`

#Stop the server if it is running
if [[ $status != *'is not running!'* ]] ; then	
    $TAFJ_HOME/scblib/protegrity/defiance_dps/bin/pepsrvctrl stop
fi 

#Check if the log forwarder executable file exists
if [ ! -f $TAFJ_HOME/scblib/protegrity/fluent-bit/bin/logforwarderctrl ]
then
	echo $TAFJ_HOME"/scblib/protegrity/fluent-bit/bin/logforwarderctrl file does not exists"
	exit 1
fi

#Get the current status of log forwarder server.
status=`$TAFJ_HOME/scblib/protegrity/fluent-bit/bin/logforwarderctrl status`

#Stop the server if it is not running
if [[ $status != *'is not running'* ]] ; then	
    $TAFJ_HOME/scblib/protegrity/fluent-bit/bin/logforwarderctrl stop
fi 
