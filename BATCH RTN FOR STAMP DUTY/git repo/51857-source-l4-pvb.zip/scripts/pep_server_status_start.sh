#!/bin/sh

#Check if the Logforwarder executable file exists
if [ ! -f $TAFJ_HOME/scblib/protegrity/fluent-bit/bin/logforwarderctrl ]
then
	echo $TAFJ_HOME"/scblib/protegrity/fluent-bit/bin/logforwarderctrl file does not exists"
fi

#Get the current status of Logforwarder server.
logforwarder_status=`$TAFJ_HOME/scblib/protegrity/fluent-bit/bin/logforwarderctrl status`

#Start the server if it is not running
if [[ $logforwarder_status == *'is not running'* ]] ; then	
    $TAFJ_HOME/scblib/protegrity/fluent-bit/bin/logforwarderctrl start
fi

#Check if the Pepserver executable file exists
if [ ! -f $TAFJ_HOME/scblib/protegrity/defiance_dps/bin/pepsrvctrl ]
then
	echo $TAFJ_HOME"/scblib/protegrity/defiance_dps/bin/pepsrvctrl file does not exists"
	exit 1
fi

#Get the current status of PEP server.
pepsrv_status=`$TAFJ_HOME/scblib/protegrity/defiance_dps/bin/pepsrvctrl status`

#Start the server if it is not running
if [[ $pepsrv_status == *'is not running!'* ]] ; then	
    $TAFJ_HOME/scblib/protegrity/defiance_dps/bin/pepsrvctrl start
fi 
