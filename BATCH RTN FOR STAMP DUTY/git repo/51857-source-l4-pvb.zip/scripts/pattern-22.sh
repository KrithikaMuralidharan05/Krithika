#!/bin/sh

#Validate arguments.
if [ "$#" -ne 2 ]
then
  echo "Incorrect number of arguments, Program accepts 2 arguments. <<MIGRATED_DATA_FILE>> <<EXTRACT_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Take backup of original file.
base_name=$(basename $2)
outDir=$T24_HOME/bnk/bnk.interface/tranche.files
cp $2 $outDir/"ORG."$base_name

lines=""
#Create grep command with all the migrated customer/account/SAM.
while read line || [ -n "$line" ]; do
   data_migrated=$(echo ${line} | cut -d"|" -f1)
   lines=$lines"-e '"
   lines=$lines$data_migrated
   lines=$lines"' "
done < $1

grep_cmd="grep -a -w -v $lines $2 > $outDir/filtered_$base_name"

#Remove all migrated customer/accounts/trailer from original and create transactions.csv file.
eval $grep_cmd

sleep 20

#Create new file appending both transaction and trailer file.
cat $outDir/filtered_$base_name > $2

sleep 20

#Create copy of filtered file
cp $2 $outDir

#Remove temporary files created in this script.
rm $outDir/filtered_$base_name