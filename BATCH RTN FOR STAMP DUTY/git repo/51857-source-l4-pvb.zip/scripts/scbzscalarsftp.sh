#!/bin/sh
echo "OK, starting now..."
cmd="sftp -o ProxyCommand='/usr/bin/nc --proxy-type http --proxy 10.4.80.158:443 %h %p' -oPort=$1 $2@$3"
eval $cmd <<EOF
lcd $4
cd $5
$6 $7
ls -ltr
$8 $9
ls -ltr
exit
EOF
