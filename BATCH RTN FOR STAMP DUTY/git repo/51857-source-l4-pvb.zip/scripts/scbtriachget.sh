#!/bin/sh
cd /t24/prod/Temenos/TAFJ/scblib/cortex/20240803/linux.gcc.release.x86_64/
./RunMu Strat.App.JerseyFXRates --host=uklpaptrp301a.gdc.standardchartered.com:14002 /t24/prod/Temenos/T24/bnk/bnk.interface/scg.interfaces/in/TRI/FXUSDRAT.prn 2>/dev/null
chmod 775 /t24/prod/Temenos/T24/bnk/bnk.interface/scg.interfaces/in/TRI/FXUSDRAT.prn