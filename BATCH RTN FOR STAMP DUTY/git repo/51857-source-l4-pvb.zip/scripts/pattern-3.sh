#!/bin/sh

#Validate arguments.
if [ "$#" -ne 2 ]
then
  echo "Incorrect number of arguments, Program accepts 2 arguments. <<MIGRATED_DATA_FILE>> <<EXTRACT_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Take backup of original file.
base_name=$(basename $2)
outDir=$T24_HOME/bnk/bnk.interface/tranche.files
cp $2 $outDir/"ORG."$base_name

lines=""
#Create grep command with all the migrated customer/account/SAM.
while read line || [ -n "$line" ]; do
   data_migrated=$(echo ${line} | cut -d"|" -f1)
   lines=$lines"-e '"
   lines=$lines$data_migrated
   lines=$lines"' "
done < $1

#Get 1st and 2nd field from trailer, which is required to create new trailer
trail=$(tail -1 $2)
field_1_trailer=$(echo ${trail} | cut -d"," -f1)
field_2_trailer=$(echo ${trail} | cut -d"," -f2)

#Add trailer to grep, it will also be removed from file.
lines=$lines"-e '"$trail"' "

grep_cmd="grep -a -w -v $lines $2 > $outDir/filtered_$base_name"

#Remove all migrated customer/accounts/trailer from original and create transactions.csv file
eval $grep_cmd

sleep 20

#Get new record count from new file.
line_1=$(wc -l $outDir/filtered_$base_name)
newCount=$(echo ${line_1} | cut -d" " -f1)

#Create new trailer and update same to final extract file.
newTrailer=$field_1_trailer","$field_2_trailer","$newCount

#Write new trailer to new file.
echo $newTrailer > $outDir/trailer_$base_name

#Create new file appending both transaction and trailer file.
cat $outDir/filtered_$base_name $outDir/trailer_$base_name > $2

sleep 20

#Create copy of filtered file.
cp $2 $outDir 

#Remove temporary files created in this script.
rm $outDir/trailer_$base_name $outDir/filtered_$base_name