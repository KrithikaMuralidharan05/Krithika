#!/bin/sh
v_file_name=$1; t24_today=$2; t24_file_path=$3; arc_file_path=$4; cap_file_path=$5;
cat "$t24_file_path/$v_file_name" | awk -F'|' '{ if(($2!="") && (index($19,"SGP")>0)) {print $2 }}' > "&SAVEDLISTS&/$v_file_name.SGP"
cat "$t24_file_path/$v_file_name" | awk -F'|' '{ if(($2!="") && (index($19,"HKG")>0)) {print $2 }}' > "&SAVEDLISTS&/$v_file_name.HKG"
cat "$t24_file_path/$v_file_name" | awk -F'|' '{if(index($19,"HKG")>0){print $0}}' > "$t24_file_path/HK1000215.$t24_today.$v_file_name"
cat "$t24_file_path/$v_file_name" | awk -F'|' '{if((index($2,"SGD")>0) && (index($19,"SGP")>0)){print $0}}' > "$t24_file_path/SG1090400.$t24_today.$v_file_name"
cat "$t24_file_path/$v_file_name" | awk -F'|' '{if((index($2,"SGD")==0) && (index($19,"SGP")>0)){print $0}}' > "$t24_file_path/SG1090401.$t24_today.$v_file_name"
mv "$t24_file_path/$v_file_name" "$arc_file_path/$v_file_name"
