#!/bin/sh

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Remove empty lines from file
sed -i '/^\s*$/d' $1
sed -i '/^\s*$/d' $2

#Get 1st and 2nd field from trailer, which is required to create new trailer
header=$(head -1 $1)
trailer=$(tail -1 $1)
field_1_trailer=$(echo ${trailer} | cut -d"," -f1)

#Remove trailer from first and second file
sed -i'' -e '1d' -e '$d' $1
sed -i'' -e '1d' -e '$d' $2

#Consolidate transactions from both file
cat $1 $2 > temp.csv

#Get new record count from new file
line=$(wc -l temp.csv)
count=$(echo ${line} | cut -d" " -f1)

#Create temp file to calculate amount
cp temp.csv tempAmount.csv

#Amount Calculation
calculatedTotalAmount=0
checkAmount=10000
while read line || [ -n "$line" ]; do
	limitProduct=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $17}')
	if [ $limitProduct == $checkAmount ]; then
		amount=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $5}') 
		if [ ! -z "$amount" -a "$amount" != " " ]; then
			newAmount=$(echo "$amount" | tr -d '""')
			calculatedTotalAmount=$(echo "$newAmount + $calculatedTotalAmount" | bc)
		fi	    
	fi
done < tempAmount.csv

#Create new trailer with new total count
newtrailer=$field_1_trailer","$count","$calculatedTotalAmount
echo $newtrailer > trailer.txt

echo $header > header.txt

#Create new file
cat header.txt temp.csv trailer.txt > $3

#Remove temporarily created files in this program
rm header.txt temp.csv trailer.txt tempAmount.csv

#Remove original files
rm $1 $2