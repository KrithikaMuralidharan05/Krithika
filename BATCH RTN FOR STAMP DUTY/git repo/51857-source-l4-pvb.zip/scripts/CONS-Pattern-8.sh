#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<R08_EXTRACT>> <<R20_EXTRACT>> <<CONSOLIDATED_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Remove empty lines from file
sed -i '/^\s*$/d' $1
sed -i '/^\s*$/d' $2

#Get 1st field from trailer, which is required to create new trailer
trail=$(tail -1 $2)
field_1_trailer=$(echo ${trail} | cut -d"," -f1)
field_2_trailer=$(echo ${trail} | cut -d"," -f2)

#Remove trailer from first file and header and trailer from second file
sed -i'' -e '$d' $1
sed -i'' -e '1d' -e '$d' $2

#Consolidate transactions from both file
cat $1 $2 > temp.csv

#Create file for checksum calculation and remove header from it.
cp temp.csv fileForCheckSumCal.csv
sed -i'' -e '1d' fileForCheckSumCal.csv

checkSumJarPath=''
if [ -e $T24_HOME/bnk.lib/scblib/CheckSumUtility.jar ]
then
    checkSumJarPath=$T24_HOME/bnk.lib/scblib/CheckSumUtility.jar
else
	checkSumJarPath=$T24_HOME/bnk/bnk.lib/scblib/CheckSumUtility.jar
fi

checkSumValue=$(java -jar /t24/dev/Temenos/T24/bnk/bnk.lib/scblib/CheckSumUtility.jar fileForCheckSumCal.csv)

#Get new record count from new file
line=$(wc -l temp.csv)

tempCount=$(echo ${line} | cut -d" " -f1)

#Remove a count which is header
newCount="$((tempCount-1))"

#Create new trailer with new total count
newTrailer=$field_1_trailer","$field_2_trailer","$newCount","$checkSumValue
echo $newTrailer > trailer.txt

#Create new file
cat temp.csv trailer.txt > $3

#Remove temporarily created files in this program
rm temp.csv trailer.txt fileForCheckSumCal.csv

#Remove original files
rm $1 $2