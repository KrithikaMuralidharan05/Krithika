#!/bin/sh

#Validate arguments.
if [ "$#" -ne 2 ]
then
  echo "Incorrect number of arguments, Program accepts 2 arguments. <<MIGRATED_DATA_FILE>> <<EXTRACT_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Take backup of original file.
base_name=$(basename $2)
outDir=$T24_HOME/bnk/bnk.interface/tranche.files
cp $2 $outDir/"ORG."$base_name

#Remove transactions based on column.
while read line || [ -n "$line" ]; do	
  data_migrated=$(echo ${line} | cut -d"|" -f1)
  awk -v var=$data_migrated '{FS = ","}{ if($1 != var) print }' $2 > $outDir/transactionsTmp_$base_name
  cp $outDir/transactionsTmp_$base_name $2
done < $1

#Get 1st,2nd and 4th field from trailer, which is required to create new trailer.
trail=$(tail -1 $2)
field_1_trailer=$(echo ${trail} | cut -d"," -f1)
field_2_trailer=$(echo ${trail} | cut -d"," -f2)
field_4_trailer=$(echo ${trail} | cut -d"," -f4)

sed '$d' $outDir/transactionsTmp_$base_name > $outDir/transactions_$base_name

#Get new record count from new file.
line=$(wc -l $outDir/transactions_$base_name)
tempCount=$(echo ${line-count} | cut -d" " -f1)

#Remove a count which is header, not required to remove same for trailer, as trailer itself will be removed.
newCount="$((tempCount-1))"

#Create new trailer and update same to final extract file.
newTrailer=$field_1_trailer","$field_2_trailer","$newCount","$field_4_trailer

#Write new trailer to new file.
echo $newTrailer > $outDir/trailer_$base_name

#Create new file appending both transaction and trailer file.
cat $outDir/transactions_$base_name $outDir/trailer_$base_name > $2

sleep 20

#Create copy of filtered file.
cp $2 $outDir 

#Remove temporary files created in this script.
rm $outDir/trailer_$base_name $outDir/transactions_$base_name $outDir/transactionsTmp_$base_name