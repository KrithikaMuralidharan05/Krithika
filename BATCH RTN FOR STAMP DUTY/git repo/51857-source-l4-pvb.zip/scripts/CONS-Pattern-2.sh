#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<R08_EXTRACT>> <<R20_EXTRACT>> <<CONSOLIDATED_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

mkdir tempDir
cd tempDir
mkdir R08
mkdir R20

cd ..
mkdir finalDir

tar xzf $1 -C tempDir/R08
tar xzf $2 -C tempDir/R20

cd tempDir/R08

r08_csv=$(ls *.csv)
mv $r08_csv R08_$r08_csv

cd ../R20

r20_csv=$(ls *.csv)
mv $r20_csv R20_$r20_csv

cd ../..

cp tempDir/R08/* finalDir/
cp tempDir/R20/* finalDir/

cd finalDir

#Remove empty lines from file
sed -i '/^\s*$/d' R08_$r08_csv
sed -i '/^\s*$/d' R20_$r20_csv

r08_trailer=$(tail -1 R08_$r08_csv)
r20_trailer=$(tail -1 R20_$r20_csv)

#Remove trailer from first and second file
sed -i'' -e '$d' R08_$r08_csv
sed -i'' -e '$d' R20_$r20_csv

r08_count=$(echo ${r08_trailer} | cut -d"|" -f2)
r20_count=$(echo ${r20_trailer} | cut -d"|" -f2)

totalCount=$(($r08_count + $r20_count))

newTrailer="NO.OF.XML|"$totalCount
echo $newTrailer > trailer.txt

cat R08_$r08_csv R20_$r20_csv trailer.txt > $r08_csv

rm R08_$r08_csv R20_$r20_csv trailer.txt

tar czf $3 *

cd ..

rm -rf tempDir
rm -rf finalDir

#Remove original files
rm $1 $2