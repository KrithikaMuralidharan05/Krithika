#!/bin/sh

echo "OK, starting now..."

# Download
sftp -o "ProxyCommand=/usr/bin/nc --proxy-type http --proxy 10.4.80.158:443 %h %p" \
-oPort="$1" "$2@$3" <<EOF
lcd "$4"
cd "$5"
$6 $7
ls -ltr
bye
EOF

# Check downloaded files
MATCH_COUNT=$(find "$4" -maxdepth 1 -type f -name "$7" 2>/dev/null | wc -l)

if [ "$MATCH_COUNT" -gt 0 ]
then
 echo "Download successful: $MATCH_COUNT file(s)"

 # Delete remote files
 if [ "$8" = "rm" ]
 then
 sftp -o "ProxyCommand=/usr/bin/nc --proxy-type http --proxy 10.4.80.158:443 %h %p" \
 -oPort="$1" "$2@$3" <<EOF
cd "$5"
rm $7
ls -ltr
bye
EOF
 fi
else
 echo "Download failed. Remote file will not be deleted."
 exit 1
fi
