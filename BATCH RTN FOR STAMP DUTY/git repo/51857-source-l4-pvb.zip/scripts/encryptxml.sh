#!/bin/ksh

###############################
# Encrypt the PV XML File     #
###############################

    echo "List all the xml files extracted"

    echo "Go to the directory where the xml file is stored"

# Enter the directory path where the xml file is going to reside in the this command
# cd <Please insert the directory where the xml file is stored>
    CURDIR=$PWD
#GLBDIR='/../bnk.data/eb/F.AEB.EST000'
    T24DIR='/../bnk.interface/F_AEB_ESTMT_CON'
#XMLDIR=$PWD$GLBDIR
    XMLDIR=$PWD$T24DIR
#XMLDIR='/opt/T24/SIT/T24SITEMWH/bnk/bnk.run/CTS.BP/xmls3'
   echo $CURDIR
#echo $GLBDIR
    echo $T24DIR
    echo $XMLDIR
    cd $XMLDIR
####Company ID passed as argument####
### Change - Sankar (28/11/2011)
company=$1
########
  #  for file in `ls -a *.xml`
for file in `ls -a ${company}*.xml`
####Company ID passed as argument####
    do
    echo "The file name is $file"
# /opt/freeware/bin/openssl des3 -e -in $file -out `ls $file | cut -b1-36`.enc -K 003a54b58c5f3845bcf2a34585d46363242ffce32d3d5f01 -iv 1234567812345678
/usr/bin/openssl des3 -e -in $file -out `ls $file | cut -b1-36`.enc -K 003a54b58c5f3845bcf2a34585d46363242ffce32d3d5f01 -iv 1234567812345678
#    /usr/local/openssh/bin/openssl des3 -e -in $file -out `ls $file | cut -b1-36`.enc -K 003a54b58c5f3845bcf2a34585d46363242ffce32d3d5f01 -iv 1234567812345678
    rm $file
#If you want to take a back up of the xml file then please let me know. I shall add the commands

    done

    echo `ls *.enc`
    cd $CURDIR
