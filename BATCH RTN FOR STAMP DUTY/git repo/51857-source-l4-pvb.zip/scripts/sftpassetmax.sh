#!/bin/sh
echo "OK, starting now..."
cd $4
if [ $9 == "enc" ]
then
/usr/bin/openssl enc -aes-256-cbc -pbkdf2 -in $7.xml -out $7.enc -k $8
fi
sftp -o ProxyCommand='/usr/bin/nc --proxy-type http --proxy 10.4.80.158:443 %h %p' -o StrictHostKeyChecking=no -o PubkeyAcceptedKeyTypes=ssh-rsa -oPort=$1 $2@$3 <<EOF
lcd $4
cd $5
$6 $7.$9
exit
