#!/bin/sh

#Take backup of original file
base_name=$(basename $2)
outDir=$T24_HOME/bnk/bnk.interface/tranche.files
cp $2 $outDir/"ORG."$base_name

mv $2 $outDir/org_$base_name
grep -a -w -v "DBCTR" $outDir/org_$base_name > $outDir/Exclude_org_$base_name
sort $outDir/Exclude_org_$base_name | uniq > $outDir/Exclude_Uniq_org_$base_name 
grep "DBCTR" $outDir/org_$base_name >> $outDir/Exclude_Uniq_org_$base_name

mv $outDir/Exclude_Uniq_org_$base_name $2
cp $2 $outDir
rm $outDir/Exclude_org_$base_name
rm $outDir/org_$base_name

file_date=$(echo $base_name | cut -d '_' -f3)
amex_dir_file_name=JSY.NFRDET.$file_date
mv $T24_HOME/bnk/bnk.interface/AMEX.FILES/$amex_dir_file_name $outDir/"ORG."$amex_dir_file_name
cp $2 $T24_HOME/bnk/bnk.interface/AMEX.FILES/
cd $T24_HOME/bnk/bnk.interface/AMEX.FILES/
mv $base_name $amex_dir_file_name
cp $T24_HOME/bnk/bnk.interface/AMEX.FILES/$amex_dir_file_name $outDir
