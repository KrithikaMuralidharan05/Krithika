#!/bin/sh

#Validate arguments.
if [ "$#" -ne 2 ]
then
  echo "Incorrect number of arguments, Program accepts 2 arguments. <<MIGRATED_DATA_FILE>> <<EXTRACT_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Take backup of original file.
base_name=$(basename $2)
outDir=$T24_HOME/bnk/bnk.interface/tranche.files
cp $2 $outDir/"ORG."$base_name

lines=""
#Create grep command with all the migrated customer/account/SAM.
while read line || [ -n "$line" ]; do
   data_migrated=$(echo ${line} | cut -d"|" -f1)
   lines=$lines"-e '"
   lines=$lines$data_migrated
   lines=$lines"' "
done < $1

#Get 1st field from trailer, which is required to create new trailer.
header=$(head -1 $2)
trail=$(tail -1 $2)
field_1_trailer=$(echo ${trail} | cut -d"," -f1)

#Add trailer to grep, it will also be removed from file.
lines=$lines"-e '"$trail"' -e '"$header"'"

grep_cmd="grep -a -w -v $lines $2 > $outDir/filtered_$base_name"

#Remove all migrated customer/accounts/trailer from original and create transactions.csv file.
eval $grep_cmd

sleep 20

#Get new record count from new file.
line_1=$(wc -l $outDir/filtered_$base_name)
newCount=$(echo ${line_1} | cut -d" " -f1)

#Create temp file to calculate amount.
cp $outDir/filtered_$base_name $outDir/transactionsAmount_1_$base_name

#Amount Calculation.
calculatedTotalAmount_1=0
while read line || [ -n "$line" ]; do
    amount=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $11}')  
	if [ ! -z "$amount" -a "$amount" != " " ]; then
			calculatedTotalAmount_1=$(echo "$amount + $calculatedTotalAmount_1" | bc)
	fi	    
done < $outDir/transactionsAmount_1_$base_name

calculatedTotalAmount_rounded_1=`printf "%.2f" $calculatedTotalAmount_1`

#Create temp file to calculate amount.
cp $outDir/filtered_$base_name $outDir/transactionsAmount_2_$base_name

#Amount Calculation.
calculatedTotalAmount_2=0
while read line || [ -n "$line" ]; do
    amount=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $14}') 
	if [ ! -z "$amount" -a "$amount" != " " ]; then
			calculatedTotalAmount_2=$(echo "$amount + $calculatedTotalAmount_2" | bc)
	fi	    
done < $outDir/transactionsAmount_2_$base_name

calculatedTotalAmount_rounded_2=`printf "%.2f" $calculatedTotalAmount_2`

#Create temp file to calculate amount.
cp $outDir/filtered_$base_name $outDir/transactionsAmount_3_$base_name

#Amount Calculation.
calculatedTotalAmount_3=0
while read line || [ -n "$line" ]; do
    amount=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $97}') 
	if [ ! -z "$amount" -a "$amount" != " " ]; then
			calculatedTotalAmount_3=$(echo "$amount + $calculatedTotalAmount_3" | bc)
	fi	    
done < $outDir/transactionsAmount_3_$base_name

calculatedTotalAmount_rounded_3=`printf "%.2f" $calculatedTotalAmount_3`

#Create new trailer and update same to final extract file.
newTrailer=$field_1_trailer","$newCount","$calculatedTotalAmount_rounded_1","$calculatedTotalAmount_rounded_2","$calculatedTotalAmount_rounded_3

#Write new trailer to new file.
echo $newTrailer > $outDir/trailer_$base_name
echo $header > $outDir/header_$base_name

#Create new file appending both transaction and trailer file.
cat $outDir/header_$base_name $outDir/filtered_$base_name $outDir/trailer_$base_name > $2

sleep 20

#Create copy of filtered file.
cp $2 $T24_HOME/bnk/bnk.interface/tranche.files 

#Remove temporary files created in this script.
rm $outDir/header_$base_name $outDir/trailer_$base_name $outDir/filtered_$base_name $outDir/transactionsAmount_1_$base_name $outDir/transactionsAmount_2_$base_name $outDir/transactionsAmount_3_$base_name