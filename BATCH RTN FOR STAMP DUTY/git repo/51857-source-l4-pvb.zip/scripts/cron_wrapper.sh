#!/bin/bash
source /home/t24user/.bash_profile 
# ──────────────────────────────────────────────────────────────────────────────
# Cron Wrapper – JSON Status Logger with Airflow-like Retry + Output Logging
# ──────────────────────────────────────────────────────────────────────────────
 
set -o pipefail
 
# ── Configuration ──
LOG_DIR="/t24/prod/Temenos/T24/bnk/bnk.log/CRON/logs"
OUTPUT_LOG_DIR="/t24/prod/Temenos/T24/bnk/bnk.log/CRON/logs/output"  # Separate directory for script outputs
METRICS_DIR="/t24/prod/Temenos/T24/bnk/bnk.log/CRON/metrics"    # Directory for JSON metrics
HOSTNAME=$(hostname)
MODULE="cron"
METRICS_NAME="airflow_cron_scheduler"
 
# Create log directories
mkdir -p "$LOG_DIR" "$OUTPUT_LOG_DIR" "$METRICS_DIR"
 
# ── Default Retry Settings (Airflow-equivalent) ──
MAX_RETRIES=3                # max number of retries (like airflow retries param)
RETRY_DELAY=60               # seconds between retries (like airflow retry_delay)
RETRY_EXPONENTIAL=false      # exponential backoff (like airflow retry_exponential_backoff)
LOG_RETENTION_DAYS=15        # Days to keep old logs
 
# ── Parse Options ──
usage() {
    cat <<EOF
Usage: $0 [OPTIONS] -- <command> [args...]
 
Options:
  -r, --max-retries N        Max retry attempts (default: 3)
  -d, --retry-delay N        Delay in seconds between retries (default: 30)
  -e, --exponential-backoff  Enable exponential backoff on retries
  -k, --keep-days N          Days to retain logs (default: 30)
  -h, --help                 Show this help
 
Environment Variables:
  LOG_DIR                    Base log directory (default: /apps/cron/logs)
  OUTPUT_LOG_DIR             Output log directory (default: /apps/cron/logs/output)
  METRICS_DIR                Metrics directory (default: /apps/cron/logs/metrics)
 
Example:
  $0 -r 3 -d 10 -e -- /apps/scripts/backup.sh --full
  $0 -- /apps/scripts/etl_job.sh arg1 arg2
 
Log Files Created:
  - Metrics: $METRICS_DIR/<scriptname>_<timestamp>.json
  - Output:  $OUTPUT_LOG_DIR/<scriptname>/<scriptname>_<timestamp>.log
  - STDOUT:  $OUTPUT_LOG_DIR/<scriptname>/<scriptname>_<timestamp>.out
  - STDERR:  $OUTPUT_LOG_DIR/<scriptname>/<scriptname>_<timestamp>.err
 
EOF
    exit 1
}
 
# Parse command-line arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -r|--max-retries)
            MAX_RETRIES="$2"; shift 2 ;;
        -d|--retry-delay)
            RETRY_DELAY="$2"; shift 2 ;;
        -e|--exponential-backoff)
            RETRY_EXPONENTIAL=true; shift ;;
        -k|--keep-days)
            LOG_RETENTION_DAYS="$2"; shift 2 ;;
        -h|--help)
            usage ;;
        --)
            shift; break ;;
        *)
            echo "Error: Unknown option: $1"
            usage ;;
    esac
done
 
# Validate command is provided
if [[ $# -eq 0 ]]; then
    echo "Error: No command specified"
    usage
fi
 
COMMAND=("$@")
COMMAND_STRING="${COMMAND[*]}"
 
# ── Extract Script Information ──
SCRIPT_PATH="${COMMAND[0]}"
SCRIPT_NAME=$(basename "$SCRIPT_PATH")
SCRIPT_NAME_NO_EXT="${SCRIPT_NAME%.*}"
 
# If script name is empty, use a default
if [[ -z "$SCRIPT_NAME_NO_EXT" ]]; then
    SCRIPT_NAME_NO_EXT="unnamed_script"
fi
 
# ── Generate Timestamps ──
START_EPOCH=$(date +%s)
START_DATETIME=$(date '+%Y-%m-%d %H:%M:%S')
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
DATE_ONLY=$(date '+%Y%m%d')
 
# ── Create Script-Specific Log Directory ──
SCRIPT_LOG_DIR="${OUTPUT_LOG_DIR}/${SCRIPT_NAME_NO_EXT}"
mkdir -p "$SCRIPT_LOG_DIR"
 
# ── Define Log File Paths ──
COMBINED_LOG="${SCRIPT_LOG_DIR}/${SCRIPT_NAME_NO_EXT}_${TIMESTAMP}.log"
STDOUT_LOG="${SCRIPT_LOG_DIR}/${SCRIPT_NAME_NO_EXT}_${TIMESTAMP}.out"
STDERR_LOG="${SCRIPT_LOG_DIR}/${SCRIPT_NAME_NO_EXT}_${TIMESTAMP}.err"
METRICS_FILE="${METRICS_DIR}/${SCRIPT_NAME_NO_EXT}_${TIMESTAMP}.json"
 
# ── Logging Functions ──
log_header() {
    cat <<EOF | tee -a "$COMBINED_LOG"
================================================================================
CRON JOB EXECUTION
================================================================================
Script Name        : $SCRIPT_NAME
Script Path        : $SCRIPT_PATH
Script Arguments   : ${COMMAND[*]:1}
Hostname           : $HOSTNAME
User               : $(whoami)
Working Directory  : $(pwd)
PID                : $$
PPID               : $PPID
Start Time         : $START_DATETIME
Start Epoch        : $START_EPOCH
================================================================================
Retry Configuration:
  Max Retries      : $MAX_RETRIES
  Retry Delay      : ${RETRY_DELAY}s
  Exponential      : $RETRY_EXPONENTIAL
================================================================================
Log Files:
  Combined Log     : $COMBINED_LOG
  STDOUT           : $STDOUT_LOG
  STDERR           : $STDERR_LOG
  Metrics JSON     : $METRICS_FILE
================================================================================
 
EOF
}
 
log_footer() {
    local exit_code=$1
    local status=$2
    local duration=$3
    local retry_count=$4
 
    cat <<EOF | tee -a "$COMBINED_LOG"
 
================================================================================
EXECUTION COMPLETE
================================================================================
End Time           : $(date '+%Y-%m-%d %H:%M:%S')
End Epoch          : $(date +%s)
Duration           : ${duration}s ($(format_duration "$duration"))
Exit Code          : $exit_code
Status             : $status
Retry Count        : $retry_count / $MAX_RETRIES
================================================================================
Output File Sizes:
  STDOUT           : $(get_file_size "$STDOUT_LOG")
  STDERR           : $(get_file_size "$STDERR_LOG")
  Combined         : $(get_file_size "$COMBINED_LOG")
================================================================================
 
EOF
}
 
# ── Helper Functions ──
format_duration() {
    local seconds=$1
    local hours=$((seconds / 3600))
    local minutes=$(((seconds % 3600) / 60))
    local secs=$((seconds % 60))
    printf "%02d:%02d:%02d" "$hours" "$minutes" "$secs"
}
 
get_file_size() {
    local file=$1
    if [[ -f "$file" ]]; then
        local size=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null || echo "0")
        if command -v numfmt &>/dev/null; then
            numfmt --to=iec-i --suffix=B "$size" 2>/dev/null || echo "${size} bytes"
        else
            echo "${size} bytes"
        fi
    else
        echo "0 bytes"
    fi
}
 
calculate_retry_delay() {
    local attempt=$1
    if [[ "$RETRY_EXPONENTIAL" == "true" ]]; then
        echo $((RETRY_DELAY * (2 ** (attempt - 1))))
    else
        echo "$RETRY_DELAY"
    fi
}
 
# ── Write JSON Metrics ──
write_json_metrics() {
    local exit_code=$1
    local status=$2
    local duration=$3
    local retry_count=$4
    local error_message=$5
 
    local end_epoch=$(date +%s)
    local end_datetime=$(date '+%Y-%m-%d %H:%M:%S')
 
    # Read last 20 lines of stderr for error context
    local stderr_excerpt=""
    if [[ -f "$STDERR_LOG" ]] && [[ -s "$STDERR_LOG" ]]; then
        # stderr_excerpt=$(tail -20 "$STDERR_LOG" | sed 's/"/\\"/g' | tr '\n' '\\n')
        stderr_excerpt=$(tail -20 "$STDERR_LOG" | sed 's/\\/\\\\/g; s/"/\\"/g; s/$/\\n/g' | tr -d '\n' | sed 's/\\n$//')
    fi
 
    # Calculate percentiles (simplified - just use duration for now)
    local p50=$duration
    local p95=$duration
    local p99=$duration
 
    cat > "$METRICS_FILE" <<EOF
{"timestamp": "$end_datetime", "epoch": $end_epoch, "hostname": "$HOSTNAME", "module": "$MODULE", "metrics_name": "$METRICS_NAME", "script.name": "$SCRIPT_NAME", "script.path": "$SCRIPT_PATH", "script.arguments": [$(printf '"%s",' "${COMMAND[@]:1}" | sed 's/,$//')], "script.command": "$COMMAND_STRING", "script.working_directory": "$(pwd)", "script.user": "$(whoami)", "execution.start_time": "$START_DATETIME", "execution.start_epoch": $START_EPOCH, "execution.end_time": "$end_datetime", "execution.end_epoch": $end_epoch, "execution.duration_seconds": $duration,  "execution.exit_code": $exit_code, "execution.status": "$status", "execution.retry_count": $retry_count, "execution.max_retries": $MAX_RETRIES, "retry_config": $MAX_RETRIES, "retry_delay": $RETRY_DELAY, "stdout_log": "$STDOUT_LOG", "stderr_log": "$STDERR_LOG", "error.message": "$error_message", "error.stderr_excerpt": "$stderr_excerpt"}
EOF
 
    # Create symlink to latest metrics
    ln -sf "$METRICS_FILE" "${METRICS_DIR}/${SCRIPT_NAME_NO_EXT}_latest.json"
}
 
# ── Cleanup Old Logs ──
cleanup_old_logs() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Cleaning up logs older than ${LOG_RETENTION_DAYS} days..." | tee -a "$COMBINED_LOG"
 
    # Cleanup output logs
    find "$SCRIPT_LOG_DIR" -type f \( -name "*.log" -o -name "*.out" -o -name "*.err" \) -mtime +$LOG_RETENTION_DAYS -delete 2>/dev/null || true
 
    # Cleanup metrics
    find "$METRICS_DIR" -type f -name "${SCRIPT_NAME_NO_EXT}_*.json" -mtime +$LOG_RETENTION_DAYS ! -name "*_latest.json" -delete 2>/dev/null || true
 
    # Cleanup empty directories
    find "$OUTPUT_LOG_DIR" -type d -empty -delete 2>/dev/null || true
 
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Cleanup completed" | tee -a "$COMBINED_LOG"
}
 
# ── Main Execution with Retry Logic ──
log_header
 
retry_count=0
exit_code=0
status="unknown"
error_message=""
 
while [[ $retry_count -le $MAX_RETRIES ]]; do
    if [[ $retry_count -gt 0 ]]; then
        delay=$(calculate_retry_delay "$retry_count")
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Retry attempt $retry_count/$MAX_RETRIES after ${delay}s delay..." | tee -a "$COMBINED_LOG"
        sleep "$delay"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Executing command: $COMMAND_STRING" | tee -a "$COMBINED_LOG"
        echo "" | tee -a "$COMBINED_LOG"
    fi
 
    # Execute command with output redirection
    set +e
    {
        # Run command and capture outputs
        "${COMMAND[@]}" > >(tee -a "$STDOUT_LOG") 2> >(tee -a "$STDERR_LOG" >&2)
        exit_code=$?
    }
    set -e
 
    # Combine stdout and stderr into combined log
    {
        echo ""
        echo "────────────────────────────────────────────────────────────────────────────"
        echo "STDOUT OUTPUT (Attempt $((retry_count + 1)))"
        echo "────────────────────────────────────────────────────────────────────────────"
        cat "$STDOUT_LOG" 2>/dev/null || echo "(no output)"
        echo ""
        echo "────────────────────────────────────────────────────────────────────────────"
        echo "STDERR OUTPUT (Attempt $((retry_count + 1)))"
        echo "────────────────────────────────────────────────────────────────────────────"
        cat "$STDERR_LOG" 2>/dev/null || echo "(no errors)"
        echo ""
    } >> "$COMBINED_LOG"
 
    if [[ $exit_code -eq 0 ]]; then
        status="success"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Command succeeded on attempt $((retry_count + 1))" | tee -a "$COMBINED_LOG"
        break
    else
        error_message="Command failed with exit code $exit_code"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Command failed with exit code $exit_code on attempt $((retry_count + 1))" | tee -a "$COMBINED_LOG"
 
        if [[ $retry_count -lt $MAX_RETRIES ]]; then
            retry_count=$((retry_count + 1))
            status="retrying"
        else
            status="failed"
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Max retries ($MAX_RETRIES) reached. Giving up." | tee -a "$COMBINED_LOG"
            break
        fi
    fi
done
 
# Calculate final duration
END_EPOCH=$(date +%s)
DURATION=$((END_EPOCH - START_EPOCH))
 
# Write footer
log_footer "$exit_code" "$status" "$DURATION" "$retry_count"
 
# Write JSON metrics
write_json_metrics "$exit_code" "$status" "$DURATION" "$retry_count" "$error_message"
 
# Create symlinks to latest logs
ln -sf "$COMBINED_LOG" "${SCRIPT_LOG_DIR}/${SCRIPT_NAME_NO_EXT}_latest.log"
ln -sf "$STDOUT_LOG" "${SCRIPT_LOG_DIR}/${SCRIPT_NAME_NO_EXT}_latest.out"
ln -sf "$STDERR_LOG" "${SCRIPT_LOG_DIR}/${SCRIPT_NAME_NO_EXT}_latest.err"
 
# Cleanup old logs
cleanup_old_logs
 
# Exit with the command's exit code
exit "$exit_code"
