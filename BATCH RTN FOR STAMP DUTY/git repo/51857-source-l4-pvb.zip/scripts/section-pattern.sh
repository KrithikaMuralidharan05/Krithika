#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<R08_EXTRACT>> <<R20_EXTRACT>> <<CONSOLIDATED_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Variables to identify which sections are present
section_1='no'
section_2='no'
section_3='no'
section_4='no'

#Directory to create R08 and R20 specific sections files(Segregated files)
mkdir R08
mkdir R20


declare -a section_array
i=0

#Check if Sections present in files, if present update array size and set variable as yes
if  grep -q "Section 1:" $1 ; then
         section_1='yes' 
		 section_array[i]='section_1' 
		 i=$((i+1))
fi

if  grep -q "Section 2:" $1 ; then
         section_2='yes' 
		 section_array[i]='section_2' 
		 i=$((i+1))
fi

if  grep -q "Section 3:" $1 ; then
         section_3='yes' 
		 section_array[i]='section_3' 
		 i=$((i+1))
fi

if  grep -q "Section 4:" $1 ; then
         section_4='yes' 
		 section_array[i]='section_4' 
		 i=$((i+1))
fi

#If array size is 1, then we have only one section in file, create corresponding file
if [[ ${#section_array[@]} = 1 ]] && [[ $section_1 = 'yes' ]] ; then
		awk '/Section 1:/,0' $1 > R08/section_1.txt
fi

if [[ ${#section_array[@]} = 1 ]] && [[ $section_2 = 'yes' ]] ; then
		awk '/Section 2:/,0' $1 > R08/section_2.txt
fi

if [[ ${#section_array[@]} = 1 ]] && [[ $section_3 = 'yes' ]] ; then
		awk '/Section 3:/,0' $1 > R08/section_3.txt
fi

if [[ ${#section_array[@]} = 1 ]] && [[ $section_4 = 'yes' ]] ; then
		awk '/Section 4:/,0' $1 > R08/section_4.txt
fi

#If array size is 2, then we have only two sections in file, create corresponding files
if [[ ${#section_array[@]} = 2 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2:/{ /Section 2:/!p }' $1 > R08/section_1.txt
		awk '/Section 2:/,0' $1 > R08/section_2.txt
fi

if [[ ${#section_array[@]} = 2 ]] && [[ $section_1 = 'yes' ]] && [[ $section_3 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 3:/{ /Section 3:/!p }' $1 > R08/section_1.txt
		awk '/Section 3:/,0' $1 > R08/section_3.txt 
fi

if [[ ${#section_array[@]} = 2 ]] && [[ $section_1 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 4:/{ /Section 4:/!p }' $1 > R08/section_1.txt
		awk '/Section 4:/,0' $1 > R08/section_4.txt 
fi

if [[ ${#section_array[@]} = 2 ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] ; then
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $1 > R08/section_2.txt
		awk '/Section 3:/,0' $1 > R08/section_3.txt
fi

if [[ ${#section_array[@]} = 2 ]] && [[ $section_2 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 2:/, /Section 4:/{ /Section 4:/!p }' $1 > R08/section_2.txt
		awk '/Section 4:/,0' $1 > R08/section_4.txt
fi

if [[ ${#section_array[@]} = 2 ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $1 > R08/section_3.txt
		awk '/Section 4:/,0' $1 > R08/section_4.txt
fi

#If array size is 3, then we have only three sections in file, create corresponding files
if [[ ${#section_array[@]} = 3 ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $1 > R08/section_2.txt
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $1 > R08/section_3.txt
		awk '/Section 4:/,0' $1 > R08/section_4.txt 
fi

if [[ ${#section_array[@]} = 3 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2:/{ /Section 2:/!p }' $1 > R08/section_1.txt
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $1 > R08/section_2.txt
		awk '/Section 3:/,0' $1 > R08/section_3.txt
fi

if [[ ${#section_array[@]} = 3 ]] && [[ $section_1 = 'yes' ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 3:/{ /Section 3:/!p }' $1 > R08/section_1.txt
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $1 > R08/section_3.txt
		awk '/Section 4:/,0' $1 > R08/section_4.txt 
fi

if [[ ${#section_array[@]} = 3 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2:/{ /Section 2:/!p }' $1 > R08/section_1.txt
		sed -n '/Section 2:/, /Section 4:/{ /Section 4:/!p }' $1 > R08/section_2.txt
		awk '/Section 4:/,0' $1 > R08/section_4.txt
fi

#If array size is 4, then we have all four sections in file, create corresponding files
if [[ ${#section_array[@]} = 4 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2:/{ /Section 2:/!p }' $1 > R08/section_1.txt
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $1 > R08/section_2.txt
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $1 > R08/section_3.txt
		awk '/Section 4:/,0' $1 > R08/section_4.txt	
fi

#logic for R20 files
#Variables to identify which sections are present
section_1='no'
section_2='no'
section_3='no'
section_4='no'

#Directory to create R08 and R20 specific sections files(Segregated files)
declare -a section_array_r20
i=0

#Check if Sections present in files, if present update array size and set variable as yes
if  grep -q "Section 1:" $2 ; then
         section_1='yes' 
		 section_array_r20[i]='section_1' 
		 i=$((i+1))
fi

if  grep -q "Section 2:" $2 ; then
         section_2='yes' 
		 section_array_r20[i]='section_2' 
		 i=$((i+1))
fi

if  grep -q "Section 3:" $2 ; then
         section_3='yes' 
		 section_array_r20[i]='section_3' 
		 i=$((i+1))
fi

if  grep -q "Section 4:" $2 ; then
         section_4='yes' 
		 section_array_r20[i]='section_4' 
		 i=$((i+1))
fi

#If array size is 1, then we have only one section in file, create corresponding file
if [[ ${#section_array_r20[@]} = 1 ]] && [[ $section_1 = 'yes' ]] ; then
		awk '/Section 1:/,0' $2 > R20/section_1.txt
		section_1_header=$(head -1 R20/section_1.txt)
fi

if [[ ${#section_array_r20[@]} = 1 ]] && [[ $section_2 = 'yes' ]] ; then
		awk '/Section 2:/,0' $2 > R20/section_2.txt
		section_2_header=$(head -1 R20/section_2.txt)
fi

if [[ ${#section_array_r20[@]} = 1 ]] && [[ $section_3 = 'yes' ]] ; then
		awk '/Section 3:/,0' $2 > R20/section_3.txt
		section_3_header=$(head -1 R20/section_3.txt)
fi

if [[ ${#section_array_r20[@]} = 1 ]] && [[ $section_4 = 'yes' ]] ; then
		awk '/Section 4:/,0' $2 > R20/section_4.txt
		section_4_header=$(head -1 R20/section_4.txt)
fi

#If array size is 2, then we have only two sections in file, create corresponding files
if [[ ${#section_array_r20[@]} = 2 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2/{ /Section 2:/!p }' $2 > R20/section_1.txt
		awk '/Section 2:/,0' $2 > R20/section_2.txt
		section_1_header=$(head -1 R20/section_1.txt)
		section_2_header=$(head -1 R20/section_2.txt)
fi

if [[ ${#section_array_r20[@]} = 2 ]] && [[ $section_1 = 'yes' ]] && [[ $section_3 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 3:/{ /Section 3:/!p }' $2 > R20/section_1.txt
		awk '/Section 3:/,0' $2 > R20/section_3.txt
		section_1_header=$(head -1 R20/section_1.txt)
		section_3_header=$(head -1 R20/section_3.txt)
fi

if [[ ${#section_array_r20[@]} = 2 ]] && [[ $section_1 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 4:/{ /Section 4:/!p }' $2 > R20/section_1.txt
		awk '/Section 4:/,0' $2 > R20/section_4.txt
		section_1_header=$(head -1 R20/section_1.txt)
		section_4_header=$(head -1 R20/section_4.txt)
fi

if [[ ${#section_array_r20[@]} = 2 ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] ; then
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $2 > R20/section_2.txt
		awk '/Section 3:/,0' $2 > R20/section_3.txt
		section_2_header=$(head -1 R20/section_2.txt)
		section_3_header=$(head -1 R20/section_3.txt)
fi

if [[ ${#section_array_r20[@]} = 2 ]] && [[ $section_2 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 2:/, /Section 4:/{ /Section 4:/!p }' $2 > R20/section_2.txt
		awk '/Section 4:/,0' $2 > R20/section_4.txt
		section_2_header=$(head -1 R20/section_2.txt)
		section_4_header=$(head -1 R20/section_4.txt)
fi

if [[ ${#section_array_r20[@]} = 2 ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $2 > R20/section_3.txt
		awk '/Section 4:/,0' $2 > R20/section_4.txt
		section_3_header=$(head -1 R20/section_3.txt)
		section_4_header=$(head -1 R20/section_4.txt)
fi

#If array size is 3, then we have only three sections in file, create corresponding files
if [[ ${#section_array_r20[@]} = 3 ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $2 > R20/section_2.txt
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $2 > R20/section_3.txt
		awk '/Section 4:/,0' $2 > R20/section_4.txt
		section_2_header=$(head -1 R20/section_2.txt)
		section_3_header=$(head -1 R20/section_3.txt)
		section_4_header=$(head -1 R20/section_4.txt)
fi

if [[ ${#section_array_r20[@]} = 3 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2:/{ /Section 2:/!p }' $2 > R20/section_1.txt
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $2 > R20/section_2.txt
		awk '/Section 3:/,0' $2 > R20/section_3.txt
		section_1_header=$(head -1 R20/section_1.txt)
		section_2_header=$(head -1 R20/section_2.txt)
		section_3_header=$(head -1 R20/section_3.txt)		
fi

if [[ ${#section_array_r20[@]} = 3 ]] && [[ $section_1 = 'yes' ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 3:/{ /Section 3:/!p }' $2 > R20/section_1.txt
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $2 > R20/section_3.txt
		awk '/Section 4:/,0' $2 > R20/section_4.txt
		section_1_header=$(head -1 R20/section_1.txt)
		section_3_header=$(head -1 R20/section_3.txt)
		section_4_header=$(head -1 R20/section_4.txt)
fi

if [[ ${#section_array_r20[@]} = 3 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2:/{ /Section 2:/!p }' $2 > R20/section_1.txt
		sed -n '/Section 2:/, /Section 4:/{ /Section 4:/!p }' $2 > R20/section_2.txt
		awk '/Section 4:/,0' $2 > R20/section_4.txt
		section_1_header=$(head -1 R20/section_1.txt)
		section_2_header=$(head -1 R20/section_2.txt)
		section_4_header=$(head -1 R20/section_4.txt)
fi

#If array size is 4, then we have all four sections in file, create corresponding files
if [[ ${#section_array_r20[@]} = 4 ]] && [[ $section_1 = 'yes' ]] && [[ $section_2 = 'yes' ]] && [[ $section_3 = 'yes' ]] && [[ $section_4 = 'yes' ]] ; then
		sed -n '/Section 1:/, /Section 2:/{ /Section 2:/!p }' $2 > R20/section_1.txt
		sed -n '/Section 2:/, /Section 3:/{ /Section 3:/!p }' $2 > R20/section_2.txt
		sed -n '/Section 3:/, /Section 4:/{ /Section 4:/!p }' $2 > R20/section_3.txt		
		awk '/Section 4:/,0' $2 > R20/section_4.txt	
		section_1_header=$(head -1 R20/section_1.txt)
		section_2_header=$(head -1 R20/section_2.txt)
		section_3_header=$(head -1 R20/section_3.txt)
		section_4_header=$(head -1 R20/section_4.txt)
fi

#Merge individual section files from R08 and R20 directory into 1 file
#Crete R08 section file if it is present
#If same section file present in both R08 and R20, then remove header and section header from R20 file
#If same section file is not present in R20, then Add header to R20 file
if [ -f ./R08/section_1.txt ]; then
	cat ./R08/section_1.txt > newSection_1.txt
fi

if [ -f ./R20/section_1.txt ]; then
  if [ ! -f ./R08/section_1.txt ]; then
	echo $section_1_header > section_1_header.txt
	cat section_1_header.txt >> newSection_1.txt
	sed -i '1d' ./R20/section_1.txt 
  else	
	sed -i'' -e '1,3d' ./R20/section_1.txt	
  fi	
  cat ./R20/section_1.txt >> newSection_1.txt
fi

if [ -f ./R08/section_2.txt ]; then
	cat ./R08/section_2.txt > newSection_2.txt    
fi

if [ -f ./R20/section_2.txt ]; then
    if [ ! -f ./R08/section_2.txt ]; then
	 echo $section_2_header > section_2_header.txt
	 cat section_2_header.txt >> newSection_2.txt
	 sed -i '1d' ./R20/section_2.txt
	else
     sed -i'' -e '1,3d' ./R20/section_2.txt	  
    fi
  cat ./R20/section_2.txt >> newSection_2.txt
fi

if [ -f ./R08/section_3.txt ]; then
	cat ./R08/section_3.txt > newSection_3.txt    
fi

if [ -f ./R20/section_3.txt ]; then
	if [ ! -f ./R08/section_3.txt ]; then
	 echo $section_3_header > section_3_header.txt
	 cat section_3_header.txt >> newSection_3.txt
	 sed -i '1d' ./R20/section_3.txt
	else
		sed -i'' -e '1,3d' ./R20/section_3.txt	
    fi
  cat ./R20/section_3.txt >> newSection_3.txt
fi

if [ -f ./R08/section_4.txt ]; then
	cat ./R08/section_4.txt > newSection_4.txt    
fi

if [ -f ./R20/section_4.txt ]; then	
	if [ ! -f ./R08/section_4.txt ]; then
	 echo $section_4_header > section_4_header.txt
	 cat section_4_header.txt >> newSection_4.txt
	 sed -i '1d' ./R20/section_4.txt
    else
		sed -i'' -e '1,3d' ./R20/section_4.txt	
	fi
  cat ./R20/section_4.txt >> newSection_4.txt
fi

#Add all sections to single file with blank line in between
if [ -f newSection_1.txt ]; then
	cat newSection_1.txt >> $3    
fi

if [ -f newSection_2.txt ]; then
	cat newSection_2.txt >> $3    
fi

if [ -f newSection_3.txt ]; then
	cat newSection_3.txt >> $3    
fi

if [ -f newSection_4.txt ]; then
	cat newSection_4.txt >> $3    
fi

#Remove all blank lines from file
sed -i '/^[[:space:]]*$/d' $3

#Add blank lines as required by sections file
if  grep -q "Section 1:" $3 ; then
	sed -i -r 's/(^.*)(Section 1:  Dealing Limits Status and Utilization)(.*$)/\2\n\3/' $3
fi

if grep -q "Section 1:" $3 && grep -q "Section 2:" $3 ; then
	sed -i -r 's/(^.*)(Section 2: Expired Dealing Limits)(.*$)/\1\n\2\n\3/' $3
fi

if grep -q "Section 2:" $3 && ! grep -q "Section 1:" $3 ; then
	sed -i -r 's/(^.*)(Section 2: Expired Dealing Limits)(.*$)/\2\n\3/' $3
fi

if grep -q "Section 3:" $3 && ( grep -q "Section 2:" $3 || grep -q "Section 1:" $3 ) ; then
	sed -i -r 's/(^.*)(Section 3: Exceeded Dealing Limits)(.*$)/\1\n\2\n\3/' $3
fi

if grep -q "Section 3:" $3 && (! grep -q "Section 2:" $3 && ! grep -q "Section 1:" $3 ) ; then
	sed -i -r 's/(^.*)(Section 3: Exceeded Dealing Limits)(.*$)/\2\n\3/' $3
fi

if grep -q "Section 4:" $3 && (! grep -q "Section 3:" $3 && ! grep -q "Section 2:" $3 && ! grep -q "Section 1:" $3) ; then
	sed -i -r 's/(^.*)(Section 4: Clients with \x27No\x27 Dealing Limits setup)(.*$)/\2\n\3/' $3
fi

if grep -q "Section 4:" $3 && ( grep -q "Section 3:" $3 || grep -q "Section 2:" $3 || grep -q "Section 1:" $3) ; then
	sed -i -r 's/(^.*)(Section 4: Clients with \x27No\x27 Dealing Limits setup)(.*$)/\1\n\2\n\3/' $3
fi

#Remove temporarily created directories and files
rm -rf R08
rm -rf R20
rm -f newSection*
rm -f section_*

#Remove original files
rm $1 $2