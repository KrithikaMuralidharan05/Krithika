#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<MIGRATED_DATA_FILE>> <<EXTRACT_FILE>> <<INCLUDE/EXCLUDE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Take backup of original file.
base_name=$(basename $2)

outDir=''
if [ -e $HOME/../bnk.interface/tranche.files ]
then
    outDir=$HOME/../bnk.interface/tranche.files
else
	outDir=$T24_HOME/bnk/bnk.interface
fi

cp $2 $outDir/"ORG."$base_name

lines=""
#Create grep command with all the migrated customer/account/SAM.
while read line || [ -n "$line" ]; do
   data_migrated=$(echo ${line} | cut -d"|" -f1)
   lines=$lines"-e '"
   lines=$lines$data_migrated
   lines=$lines"' "
done < $1

#Get the header
head=$(head -1 $2)

#Remove header and trailer.
sed '1d' $2 >> tmp.csv
mv tmp.csv $2

sed '$d' $2 >> tmp.csv
mv tmp.csv $2

if [ $3 = "INCLUDE" ]; then
    #Logic to create file including migrated transactions.(R20)
	grep_cmd="grep $lines $2 > transactions.csv"
    eval $grep_cmd
elif [ $3 = "EXCLUDE" ]; then
	#Logic to create file with excluding migrated transactions.(R08)	
	grep_cmd="grep -v $lines $2 > transactions.csv"
    eval $grep_cmd
fi

#Get new record count from new file.
line_1=$(wc -l transactions.csv)
newCount=$(echo ${line_1} | cut -d" " -f1)

#Write new trailer to new file.
echo $newCount > trailer.txt

#Write head to header file.
echo $head >  header.txt

#Create new file appending both transaction and trailer file.
cat header.txt transactions.csv trailer.txt > $2

#Create copy of filtered file.
cp $2 $outDir 

#Remove temporary files created in this script.
rm header.txt trailer.txt transactions.csv