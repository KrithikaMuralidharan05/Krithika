#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<R08_EXTRACT>> <<R20_EXTRACT>> <<CONSOLIDATED_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Remove empty lines from file
sed -i '/^\s*$/d' $1
sed -i '/^\s*$/d' $2

#Get 1st and 2nd field from trailer, which is required to create new trailer
trailer=$(tail -1 $1)
header=$(head -1 $1)
field_1_trailer=$(echo ${trailer} | cut -d"," -f1)

#Remove trailer from first and second file
sed -i'' -e '1d' -e '$d' $1
sed -i'' -e '1d' -e '$d' $2

#Consolidate transactions from both file
cat $1 $2 > temp.csv

#Get new record count from new file
line=$(wc -l temp.csv)
count=$(echo ${line} | cut -d" " -f1)

#Create temp file to calculate amount
cp temp.csv transactionsAmount_1.csv

#Amount Calculation
calculatedTotalAmount_1=0
while read line || [ -n "$line" ]; do
    amount=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $11}')  
	if [ ! -z "$amount" -a "$amount" != " " ]; then
			calculatedTotalAmount_1=$(echo "$amount + $calculatedTotalAmount_1" | bc)
	fi	    
done < transactionsAmount_1.csv

calculatedTotalAmount_rounded_1=`printf "%.2f" $calculatedTotalAmount_1`

#Create temp file to calculate amount
cp temp.csv transactionsAmount_2.csv

#Amount Calculation
calculatedTotalAmount_2=0
while read line || [ -n "$line" ]; do
    amount=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $14}') 
	if [ ! -z "$amount" -a "$amount" != " " ]; then
			calculatedTotalAmount_2=$(echo "$amount + $calculatedTotalAmount_2" | bc)
	fi	    
done < transactionsAmount_2.csv

calculatedTotalAmount_rounded_2=`printf "%.2f" $calculatedTotalAmount_2`

#Create temp file to calculate amount
cp temp.csv transactionsAmount_3.csv

#Amount Calculation
calculatedTotalAmount_3=0
while read line || [ -n "$line" ]; do
    amount=$(echo ${line} | awk 'NR%2{gsub(/,/,";")}1' RS=\" ORS= | awk -F\; '{print $89}') 
	if [ ! -z "$amount" -a "$amount" != " " ]; then
			calculatedTotalAmount_3=$(echo "$amount + $calculatedTotalAmount_3" | bc)
	fi	    
done < transactionsAmount_3.csv

calculatedTotalAmount_rounded_3=`printf "%.2f" $calculatedTotalAmount_3`

#Create new trailer with new total count
newTrailer=$field_1_trailer","$count","$calculatedTotalAmount_rounded_1","$calculatedTotalAmount_rounded_2","$calculatedTotalAmount_rounded_3
echo $newTrailer > trailer.txt
echo $header > header.txt

#Create new file
cat header.txt temp.csv trailer.txt > $3

#Remove temporarily created files in this program
rm header.txt temp.csv transactionsAmount_1.csv transactionsAmount_2.csv transactionsAmount_3.csv trailer.txt

#Remove original files
rm $1 $2