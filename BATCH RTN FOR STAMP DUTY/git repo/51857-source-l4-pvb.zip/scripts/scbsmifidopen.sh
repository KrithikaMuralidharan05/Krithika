#!/bin/sh
echo "OK, starting now..."
sftp -oPort=$1 -o PubkeyAcceptedKeyTypes=ssh-rsa,ssh-rsa-cert-v01@openssh.com $2@$3 <<EOF
lcd $4
cd $7
$5 $6
