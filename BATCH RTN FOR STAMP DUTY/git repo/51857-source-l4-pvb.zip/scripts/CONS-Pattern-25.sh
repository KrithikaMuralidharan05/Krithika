#!/bin/sh

#Validate arguments.
if [ "$#" -ne 3 ]
then
  echo "Incorrect number of arguments, Program accepts 3 arguments. <<R08_EXTRACT>> <<R20_EXTRACT>> <<CONSOLIDATED_FILE>>"
  exit 1
fi

if [ ! -f $1 ]; then
    echo 'The file '$1' does not exists.'
	exit 1
fi

if [ ! -f $2 ]; then
    echo 'The file '$2' does not exists.'
	exit 1
fi

#Copy base files to OUT directory
dir_name=$(dirname $3)
base_name_R08=$(basename $1)
base_name_R20=$(basename $2)

#Take backup of original files
cp $1 $dir_name/"R08_"$base_name_R08
cp $2 $dir_name/"R20_"$base_name_R20

#Remove empty lines from file
sed -i '/^\s*$/d' $1
sed -i '/^\s*$/d' $2

#Get count from each file
R08_Count=$(awk -F '[<>]' '/<PortfolioCount>/{print $3}' $1)
R20_Count=$(awk -F '[<>]' '/<PortfolioCount>/{print $3}' $2)

#Calculate the total count	
total_count=$((R08_Count+R20_Count))

#Update first file
sed -i '/<PortfolioCount>/d' $1
sed -i '/<\/PrivateBanking>/d' $1

#Update second file
sed -i '/<?xml version="1.0" encoding="UTF-8"?>/d' $2
sed -i '/<!DOCTYPE PrivateBanking SYSTEM "PrivateBankingV2.dtd">/d' $2
sed -i '/<PrivateBanking>/d' $2

#Consolidate both files
awk '{print}' $1 $2 > $3
sed -i "s/<PortfolioCount>$R20_Count<\/PortfolioCount>/<PortfolioCount>$total_count<\/PortfolioCount>/" $3

#Remove original files
rm $1 $2